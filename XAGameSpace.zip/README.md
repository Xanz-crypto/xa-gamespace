# XA Game Space V3 (root)

Menu awal bergaya Game Space dengan wallpaper video anime (gerakan patah-patah 10 fps).

Fitur:
- Stabil FPS: kunci batas bawah frekuensi CPU/GPU supaya clock tidak naik turun
- Smooth FPS: refresh rate maksimum, game mode performa, hemat baterai dimatikan
- Bersihkan RAM
- Auto deteksi game: otomatis boost saat game dibuka, otomatis pulih saat keluar
- Scan aplikasi latar belakang (user + sistem) lalu hentikan
- CPU Governor lengkap: governor, min dan max frekuensi per cluster

Build: push ke GitHub, ambil APK dari tab Actions (artifact XAGameSpace-V3-debug).
Video wallpaper ada di app/src/main/res/raw/anime_bg.mp4 (bisa diganti).
