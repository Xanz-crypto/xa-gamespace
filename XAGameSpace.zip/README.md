# XA Game Space V3.1 (root)

Menu awal bergaya Game Space dengan wallpaper video anime, ditambah **Game Panel** di dalam game.

## Baru di V3.1
- **RAM tidak dibersihkan otomatis** saat game dibuka (dan tidak ada scan ulang berkala). Pembersihan hanya manual:
  tombol Clean RAM / Stop App di Game Panel, atau menu utama.
- **Game Panel** (overlay di atas game):
  - Animasi masuk game: bentuk **X** muncul, lalu berjalan ke sisi kiri layar dan berubah jadi **garis**.
  - Geser garis ke kanan -> Game Panel terbuka.
  - **Kiri**: daftar game, geser atas-bawah, tap untuk pindah game.
  - **Tengah atas**: jam, refresh rate layar, RAM, CPU, suhu baterai.
  - **Tengah bawah**: menu performa (Stabil FPS, Smooth FPS, Clean RAM, Stop App, Auto Game).
  - **Kanan**: geser tab ke kiri -> pengaturan panel: Crosshair (ketuk ◎ untuk ganti gaya), Cahaya, Speaker,
    Jangan Ganggu, WiFi, Data, Monitor (overlay status kecil di kiri atas).

## Izin
- "Tampil di atas aplikasi lain" (SYSTEM_ALERT_WINDOW). Dengan root, diberikan otomatis lewat appops;
  tanpa itu, aplikasi membuka halaman izinnya saat pertama dijalankan.

## Fitur lama
- Stabil FPS, Smooth FPS, Bersihkan RAM, Auto deteksi game, Scan aplikasi latar, CPU Governor.

Build: push ke GitHub, ambil APK dari tab Actions (artifact XAGameSpace-V3.1-debug).
