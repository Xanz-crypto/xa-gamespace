# XA Game Space V3.7 (root / Shizuku)

## Baru di V3.7
- **Animasi pembuka baru**: maskot mengintip dulu dari tepi **kanan** layar (dua kali; kedua kalinya sambil "psst" dan melambai),
  jongkok bersiap, lalu **berlari ke kiri sambil menarik menu Game Space masuk** lewat tali. Ketuk panggung kosong untuk melewati.
- **Suara animasi**: `sfx_peek` (intip), `sfx_psst`, `sfx_dash` (bersiap lari), `sfx_pull` (menarik), `sfx_arrive` (menu mendarat),
  ditambah suara langkah kaki. Semua ikut tombol "Semua suara" di menu Suara.
- **Karakter & warna** (menu HIGH BOOST > Karakter): pilih **Kucing, Cewek, Cowok, atau Berdua**, ganti warna dari preset atau geser
  warna bebas, dengan pratinjau hidup dan tombol "Putar animasi pembuka". Pilihan dipakai di animasi pembuka, logo panel,
  dan animasi masuk game. Cewek/cowok adalah karakter orisinal yang digambar dengan Canvas (tanpa file gambar tambahan).

## Baru di V3.6
- **Kucing baru**: berwarna putih dengan pipi dan telinga merah muda seperti gambar contoh.
- **Animasi pembuka baru**: kucing berjalan dari kiri ke kanan dengan suara langkah kaki lucu (`sfx_step1.wav`, `sfx_step2.wav`),
  meninggalkan jejak kaki mungil. Menu Game Space terbuka di belakang kucing, mengikuti ke mana dia berjalan.
- **Logo panel bisa dipindah**: tahan logo kucing sebentar lalu seret ke mana saja (otomatis menempel ke sisi kiri/kanan terdekat),
  atau seret naik-turun untuk menggeser sepanjang tepi. Geser ke arah dalam atau ketuk untuk membuka panel.
  Posisi tersimpan dan dipakai lagi pada animasi masuk game berikutnya.
- **Efek basah dan bercahaya**: tetesan air, kilau cahaya menyapu, riak air di bawah kartu, dan cahaya tepi yang berganti warna
  (cyan, biru, ungu, pink) di menu Game Space. Game Panel juga punya tepi bercahaya dengan kilat yang berlari mengelilingi,
  tetesan air, dan ikon fitur yang menyala saat aktif.
- **Tombol Start** sekarang sepenuhnya berada di dalam blok game.

Menu awal bergaya Game Space dengan wallpaper video anime, ditambah **Game Panel** di dalam game.

## Baru di V3.2
- **Menu awal baru**: kartu game di tengah panggung neon, game lain di kiri/kanan (geser untuk ganti), tombol **Start**,
  bar status di atas (akses, suhu, RAM, jam), tombol **HIGH BOOST ▲** (menu fitur) dan **ESPORTS »** (Stabil + Smooth sekaligus).
- **Animasi loading**: huruf X digambar lalu disambar petir, lengkap dengan suara.
- **Sound**: sentuh fitur, geser kartu/panel, animasi masuk game (file WAV di `res/raw/sfx_*.wav`).
- **Izin Root + Shizuku**: ketuk chip AKSES untuk minta izin root / izin Shizuku. Root diprioritaskan, Shizuku jadi cadangan.
- **Notif fitur khusus akses**: label ROOT / ROOT/SHIZUKU di tiap fitur; bila akses kurang muncul pemberitahuan.
  - Khusus ROOT: Stabil FPS, CPU/GPU/FPS tuning, CPU Governor.
  - ROOT atau SHIZUKU: Smooth FPS, Bersihkan RAM, Stop App, Scan App, Auto Game, WiFi/Data/Jangan Ganggu.

## V3.1
- **RAM tidak dibersihkan otomatis** saat game dibuka (dan tidak ada scan ulang berkala). Pembersihan hanya manual:
  tombol Clean RAM / Stop App di Game Panel, atau menu utama.
- **Game Panel** (overlay di atas game):
  - Animasi masuk game: bentuk **X** muncul, lalu berjalan ke sisi kiri layar dan berubah jadi **garis**.
  - Geser garis ke kanan -> Game Panel terbuka.
  - **Kiri**: daftar game, geser atas-bawah, tap untuk pindah game.
  - **Tengah atas**: jam, refresh rate layar, RAM, CPU, suhu baterai.
  - **Tengah bawah**: menu performa (Stabil FPS, Smooth FPS, Clean RAM, Stop App, Auto Game).
  - **Tuning CPU / GPU / FPS** (tile di menu performa): governor, frekuensi min/max per cluster CPU, governor dan
    frekuensi min/max GPU, serta batas refresh rate layar. Perubahan GPU/CPU otomatis dipulihkan saat keluar game.
    Gauge tengah menampilkan FPS game nyata (via SurfaceFlinger, butuh root) bila terbaca, jika tidak menampilkan Hz layar.
  - **Kanan**: geser tab ke kiri -> pengaturan panel: Crosshair (ketuk ◎ untuk ganti gaya), Cahaya, Speaker,
    Jangan Ganggu, WiFi, Data, Monitor (overlay status kecil di kiri atas).

## Izin
- "Tampil di atas aplikasi lain" (SYSTEM_ALERT_WINDOW). Dengan root, diberikan otomatis lewat appops;
  tanpa itu, aplikasi membuka halaman izinnya saat pertama dijalankan.

## Fitur lama
- Stabil FPS, Smooth FPS, Bersihkan RAM, Auto deteksi game, Scan aplikasi latar, CPU Governor.

Build: push ke GitHub, ambil APK dari tab Actions (artifact XAGameSpace-V3.1-debug).

## Baru di V3.3
- **Game CMD** (menu HIGH BOOST): atur `cmd game` per game — mode (Standar/Performa/Baterai/Kustom), downscale 0.3–1.0, batas FPS 30–120, tombol Terapkan, "Terapkan + auto saat main", Reset, dan Lihat config. Hasil bergantung dukungan game/ROM.
- **Suara** (menu HIGH BOOST): mixer volume media, dering, alarm, notifikasi, panggilan, sistem + preset Mode Game/Senyap/Normal.
- Mixer dering/notifikasi/panggilan juga ada di panel dalam game. Semua butuh root atau Shizuku.

## Baru di V3.4
- **Pengaturan suara** (menu HIGH BOOST > Suara > Suara UI): klik fitur, geser, dan buka panel bisa dimatikan atau diganti: Klasik, Air jatuh, Kucing meow, Nubia, Xiaomi, Redmi, Realme, Klik bersih. Ada tombol matikan semua suara, juga di drawer panel.
- **Game Panel**: daftar game di sisi kiri diganti **POP UP APK**. Ketuk ＋ untuk menambah APK manual, ketuk ikon untuk membuka sebagai jendela mengambang, tekan lama untuk menghapus.
- **Optimal Jaringan** di Game Panel: tes ping, optimasi Wi-Fi, data seluler, DNS pribadi, dan tweak TCP (root).

## Baru di V3.5
- **Animasi loading menu awal**: kucing lucu melambai + suara imut + teks "HALLO SELAMAT BERMAIN".
- **Animasi masuk game**: kucing menjilat tangan lalu melompat ke sisi kiri dan jadi handle panel (kucing duduk melambai, geser ke kanan untuk buka panel).
- **Saat panel terbuka**: kucing mengintip di belakang panel sambil melambai.
- **Optimizer Root** dan **Optimizer V2 (Shizuku)** di sheet Jaringan pada Game Panel, lengkap dengan perbandingan ping sebelum dan sesudah.
- Suara kucing baru (sapaan, jilat, lompat) ada di `res/raw/sfx_hello|lick|jump.wav`.
