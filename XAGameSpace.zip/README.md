# XA Game Space (root)

Game Space ringan untuk Android dengan akses root (Magisk / KernelSU).

Fitur: daftar game + tombol Main, CPU/GPU governor performa, fixed performance mode, game mode sistem,
bersihkan RAM, hentikan aplikasi latar belakang, DND, matikan hemat baterai, matikan animasi,
monitor CPU/RAM/suhu/FPS (overlay), tombol Pulihkan untuk mengembalikan semua pengaturan.

## Build
- Otomatis: push ke GitHub, buka tab Actions, unduh artifact `XAGameSpace-debug` (APK).
- Lokal: `gradle assembleDebug` (JDK 17, Gradle 8.2+), atau buka di Code On the Go.
