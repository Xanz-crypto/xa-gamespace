# XA Game Space V3.2 (root / Shizuku)

Menu awal bergaya Game Space dengan wallpaper video anime, ditambah **Game Panel** di dalam game.

## Baru di V3.2
- **Menu awal baru**: kartu game di tengah panggung neon, game lain di kiri/kanan (geser untuk ganti), tombol **Start**,
  bar status di atas (akses, suhu, RAM, jam), tombol **HIGH BOOST ▲** (menu fitur) dan **ESPORTS »** (Stabil + Smooth sekaligus).
- **Animasi loading**: huruf X digambar lalu disambar petir, lengkap dengan suara.
- **Sound**: sentuh fitur, geser kartu/panel, animasi masuk game (file WAV di `res/raw/sfx_*.wav`).
- **Izin Root + Shizuku**: ketuk chip AKSES untuk minta izin root / izin Shizuku. Root diprioritaskan, Shizuku jadi cadangan.
- **Notif fitur khusus akses**: label ROOT / ROOT/SHIZUKU di tiap fitur; bila akses kurang muncul pemberitahuan.
  - Khusus ROOT: Stabil FPS, CPU/GPU/FPS tuning, CPU Governor.
  - ROOT atau SHIZUKU: Smooth FPS, Bersihkan RAM, Stop App, Scan App, Auto Game, WiFi/Data/Jangan Ganggu.

## V3.1
- **RAM tidak dibersihkan otomatis** saat game dibuka (dan tidak ada scan ulang berkala). Pembersihan hanya manual:
  tombol Clean RAM / Stop App di Game Panel, atau menu utama.
- **Game Panel** (overlay di atas game):
  - Animasi masuk game: bentuk **X** muncul, lalu berjalan ke sisi kiri layar dan berubah jadi **garis**.
  - Geser garis ke kanan -> Game Panel terbuka.
  - **Kiri**: daftar game, geser atas-bawah, tap untuk pindah game.
  - **Tengah atas**: jam, refresh rate layar, RAM, CPU, suhu baterai.
  - **Tengah bawah**: menu performa (Stabil FPS, Smooth FPS, Clean RAM, Stop App, Auto Game).
  - **Tuning CPU / GPU / FPS** (tile di menu performa): governor, frekuensi min/max per cluster CPU, governor dan
    frekuensi min/max GPU, serta batas refresh rate layar. Perubahan GPU/CPU otomatis dipulihkan saat keluar game.
    Gauge tengah menampilkan FPS game nyata (via SurfaceFlinger, butuh root) bila terbaca, jika tidak menampilkan Hz layar.
  - **Kanan**: geser tab ke kiri -> pengaturan panel: Crosshair (ketuk ◎ untuk ganti gaya), Cahaya, Speaker,
    Jangan Ganggu, WiFi, Data, Monitor (overlay status kecil di kiri atas).

## Izin
- "Tampil di atas aplikasi lain" (SYSTEM_ALERT_WINDOW). Dengan root, diberikan otomatis lewat appops;
  tanpa itu, aplikasi membuka halaman izinnya saat pertama dijalankan.

## Fitur lama
- Stabil FPS, Smooth FPS, Bersihkan RAM, Auto deteksi game, Scan aplikasi latar, CPU Governor.

Build: push ke GitHub, ambil APK dari tab Actions (artifact XAGameSpace-V3.1-debug).
