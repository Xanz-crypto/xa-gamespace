# XA Game Space V4.3 (root / Shizuku)

## Baru di V4.3
- Semua efek panel (aurora, gelembung, ombak, percikan, tetesan) kini **dipotong mengikuti bentuk bingkai** dan tidak keluar panel.
- **Animasi buka panel baru**: muncul dari sisi handle, kecil lalu membesar dengan kurva sangat halus (680 ms); tutup 380 ms.
- **Gauge, RAM, CPU, dan suhu terisi satu per satu** setelah panel selesai membesar.


## Baru di V4.2
- **Monitor FPS diperbaiki**: layer game dicari ulang dan dicoba satu per satu sampai ada data. Bila HP tidak memberi data per-layer,
  FPS dihitung dari laju komposisi SurfaceFlinger dan diberi label "FPS est.". Pesan error tidak lagi salah ("butuh root" padahal sudah ada akses).
- **Efek Game Panel baru**: aurora cahaya yang melayang, gelembung naik, kilau bintang, ombak air di dasar panel,
  percikan air dari permukaan, riak, dan percikan setiap panel disentuh.
- **Internet dipisah**: tombol **BOOST ROOT** (kernel penuh: TCP, antrean fq_codel anti-bufferbloat, power save Wi-Fi mati) dan
  **BOOST SHIZUKU** (tanpa kernel). Diagnosa kini memilih server terdekat dari 3 target dan menampilkan ping router terpisah.
- Catatan jujur: ping ke internet ditentukan jarak server dan provider. 1-10 ms hanya realistis ke router.


## Baru di V4.1
- **Fitur AI dihapus** (AI Deteksi lemot, kartu peringatan, efek merah, dan garis merah di handle).
- **Touch Optimizer**: respons sentuhan lebih cepat. Mode game touch panel, input boost CPU saat layar disentuh
  (khusus root dan hanya bila jalurnya ada di HP), serta tekan-tahan lebih cepat.
- **Touch Smooth**: animasi sistem dipercepat (Normal / Halus / Licin / Super) supaya geser dan scroll licin.
  Paling optimal dikombinasikan dengan Smooth FPS dan Stabil FPS.
  Tile **Touch** ada di Game Panel dan menu HIGH BOOST. Otomatis aktif saat boost game dan dikembalikan saat selesai.
- **Jaringan lebih dalam** (tile Jaringan di Game Panel dan menu HIGH BOOST):
  - **Diagnosa nyata**: ping, jitter, packet loss, waktu DNS, sinyal Wi-Fi (dBm), kecepatan link, pita 2.4/5 GHz, dan ping ke router.
    Hasilnya menunjukkan penyebab lag: sinyal, interferensi, atau provider.
  - **Boost Jaringan Total** (satu tombol): Wi-Fi latensi rendah, DNS terenkripsi tercepat (diukur dan diverifikasi, dibatalkan otomatis
    bila internet jadi tidak bisa resolve), tweak TCP kernel (root), hentikan aplikasi latar, lalu ukur ulang sebelum/sesudah.
  - **Wi-Fi Lock** selama game berjalan agar Wi-Fi tidak masuk mode hemat daya.
  - Semua nilai asli (DNS, TCP, setelan Wi-Fi) disimpan dan dikembalikan lewat **Reset ke bawaan**.

## Baru di V3.8
- **Kucing dan karakter dihapus** (animasi, logo panel, menu Karakter, dan semua suara maskot).
- **Intro beranda baru**: layar neon yang **selalu bergerak** (cincin HUD berputar, riak air, cahaya aurora, tetes air dan partikel
  melayang, huruf X berkilat) dengan tombol **OPEN GAME SPACE**. Tekan tombol untuk membuka beranda dengan transisi zoom.
  Wallpaper video beranda tetap terlihat samar di belakangnya.
- **Animasi masuk game baru**: huruf **X** digambar, berkilat, lalu menutup dan **berubah menjadi garis di pinggir layar**.
- **Logo panel sekarang berupa garis bercahaya** di tepi layar (titik cahaya berlari + panah petunjuk). Geser ke arah dalam atau ketuk
  untuk membuka panel; tahan sebentar lalu seret untuk memindahkannya (otomatis menempel ke sisi kiri/kanan).
- **Suara**: hanya suara klik, geser, dan buka panel (paket suara di menu Suara). File suara maskot dihapus sehingga aplikasi lebih ringan.

## Baru di V3.6
- **Kucing baru**: berwarna putih dengan pipi dan telinga merah muda seperti gambar contoh.
- **Animasi pembuka baru**: kucing berjalan dari kiri ke kanan dengan suara langkah kaki lucu (`sfx_step1.wav`, `sfx_step2.wav`),
  meninggalkan jejak kaki mungil. Menu Game Space terbuka di belakang kucing, mengikuti ke mana dia berjalan.
- **Logo panel bisa dipindah**: tahan logo kucing sebentar lalu seret ke mana saja (otomatis menempel ke sisi kiri/kanan terdekat),
  atau seret naik-turun untuk menggeser sepanjang tepi. Geser ke arah dalam atau ketuk untuk membuka panel.
  Posisi tersimpan dan dipakai lagi pada animasi masuk game berikutnya.
- **Efek basah dan bercahaya**: tetesan air, kilau cahaya menyapu, riak air di bawah kartu, dan cahaya tepi yang berganti warna
  (cyan, biru, ungu, pink) di menu Game Space. Game Panel juga punya tepi bercahaya dengan kilat yang berlari mengelilingi,
  tetesan air, dan ikon fitur yang menyala saat aktif.
- **Tombol Start** sekarang sepenuhnya berada di dalam blok game.

Menu awal bergaya Game Space dengan wallpaper video anime, ditambah **Game Panel** di dalam game.

## Baru di V3.2
- **Menu awal baru**: kartu game di tengah panggung neon, game lain di kiri/kanan (geser untuk ganti), tombol **Start**,
  bar status di atas (akses, suhu, RAM, jam), tombol **HIGH BOOST ▲** (menu fitur) dan **ESPORTS »** (Stabil + Smooth sekaligus).
- **Animasi loading**: huruf X digambar lalu disambar petir, lengkap dengan suara.
- **Sound**: sentuh fitur, geser kartu/panel, animasi masuk game (file WAV di `res/raw/sfx_*.wav`).
- **Izin Root + Shizuku**: ketuk chip AKSES untuk minta izin root / izin Shizuku. Root diprioritaskan, Shizuku jadi cadangan.
- **Notif fitur khusus akses**: label ROOT / ROOT/SHIZUKU di tiap fitur; bila akses kurang muncul pemberitahuan.
  - Khusus ROOT: Stabil FPS, CPU/GPU/FPS tuning, CPU Governor.
  - ROOT atau SHIZUKU: Smooth FPS, Bersihkan RAM, Stop App, Scan App, Auto Game, WiFi/Data/Jangan Ganggu.

## V3.1
- **RAM tidak dibersihkan otomatis** saat game dibuka (dan tidak ada scan ulang berkala). Pembersihan hanya manual:
  tombol Clean RAM / Stop App di Game Panel, atau menu utama.
- **Game Panel** (overlay di atas game):
  - Animasi masuk game: bentuk **X** muncul, lalu berjalan ke sisi kiri layar dan berubah jadi **garis**.
  - Geser garis ke kanan -> Game Panel terbuka.
  - **Kiri**: daftar game, geser atas-bawah, tap untuk pindah game.
  - **Tengah atas**: jam, refresh rate layar, RAM, CPU, suhu baterai.
  - **Tengah bawah**: menu performa (Stabil FPS, Smooth FPS, Clean RAM, Stop App, Auto Game).
  - **Tuning CPU / GPU / FPS** (tile di menu performa): governor, frekuensi min/max per cluster CPU, governor dan
    frekuensi min/max GPU, serta batas refresh rate layar. Perubahan GPU/CPU otomatis dipulihkan saat keluar game.
    Gauge tengah menampilkan FPS game nyata (via SurfaceFlinger, butuh root) bila terbaca, jika tidak menampilkan Hz layar.
  - **Kanan**: geser tab ke kiri -> pengaturan panel: Crosshair (ketuk ◎ untuk ganti gaya), Cahaya, Speaker,
    Jangan Ganggu, WiFi, Data, Monitor (overlay status kecil di kiri atas).

## Izin
- "Tampil di atas aplikasi lain" (SYSTEM_ALERT_WINDOW). Dengan root, diberikan otomatis lewat appops;
  tanpa itu, aplikasi membuka halaman izinnya saat pertama dijalankan.

## Fitur lama
- Stabil FPS, Smooth FPS, Bersihkan RAM, Auto deteksi game, Scan aplikasi latar, CPU Governor.

Build: push ke GitHub, ambil APK dari tab Actions (artifact XAGameSpace-V3.1-debug).

## Baru di V3.3
- **Game CMD** (menu HIGH BOOST): atur `cmd game` per game — mode (Standar/Performa/Baterai/Kustom), downscale 0.3–1.0, batas FPS 30–120, tombol Terapkan, "Terapkan + auto saat main", Reset, dan Lihat config. Hasil bergantung dukungan game/ROM.
- **Suara** (menu HIGH BOOST): mixer volume media, dering, alarm, notifikasi, panggilan, sistem + preset Mode Game/Senyap/Normal.
- Mixer dering/notifikasi/panggilan juga ada di panel dalam game. Semua butuh root atau Shizuku.

## Baru di V3.4
- **Pengaturan suara** (menu HIGH BOOST > Suara > Suara UI): klik fitur, geser, dan buka panel bisa dimatikan atau diganti: Klasik, Air jatuh, Kucing meow, Nubia, Xiaomi, Redmi, Realme, Klik bersih. Ada tombol matikan semua suara, juga di drawer panel.
- **Game Panel**: daftar game di sisi kiri diganti **POP UP APK**. Ketuk ＋ untuk menambah APK manual, ketuk ikon untuk membuka sebagai jendela mengambang, tekan lama untuk menghapus.
- **Optimal Jaringan** di Game Panel: tes ping, optimasi Wi-Fi, data seluler, DNS pribadi, dan tweak TCP (root).

## Baru di V3.5
- **Animasi loading menu awal**: kucing lucu melambai + suara imut + teks "HALLO SELAMAT BERMAIN".
- **Animasi masuk game**: kucing menjilat tangan lalu melompat ke sisi kiri dan jadi handle panel (kucing duduk melambai, geser ke kanan untuk buka panel).
- **Saat panel terbuka**: kucing mengintip di belakang panel sambil melambai.
- **Optimizer Root** dan **Optimizer V2 (Shizuku)** di sheet Jaringan pada Game Panel, lengkap dengan perbandingan ping sebelum dan sesudah.
- Suara kucing baru (sapaan, jilat, lompat) ada di `res/raw/sfx_hello|lick|jump.wav`.

## Baru di V3.9
- **Stop App (manual)** di Game Panel: sheet berisi daftar aplikasi yang sedang berjalan (label PENGGUNA / SISTEM beserta pemakaian RAM), centang manual, Pilih semua, Kosongkan, Segarkan, dan Hentikan terpilih. Aplikasi sistem tidak dipilih otomatis; aplikasi inti dilewati. Hasil menampilkan RAM yang kembali.
- **Monitor FPS real-time**: angka FPS besar berwarna (hijau/kuning/merah), grafik 60 sampel, AVG/MIN/MAX, plus RAM, CPU, Hz, dan suhu. FPS diambil tiap 0,5 detik (butuh root/Shizuku).
- **Pop Up APK bisa diperbesar dan diperkecil**: setelah aplikasi dibuka sebagai jendela mengambang, muncul kontrol ◀ ▲ ▼ ▶ (pindah), － ＋ (kecil/besar), ✕ (tutup kontrol). Butuh root/Shizuku; hasil bergantung ROM.

## Baru di V4.0
- **AI Deteksi lemot** (kartu di sisi kanan bar CPU pada Game Panel, ada saklar ON/OFF): memantau FPS, kestabilan frame, RAM, CPU, dan suhu. Bila HP patah-patah atau membeku sesaat, panel menyala **merah pekat berdenyut**, garis handle ikut berdenyut merah, dan kartu menampilkan penyebab yang paling mungkin, saran, serta tombol **⚡ OPTIMAL** (hentikan aplikasi latar + bersihkan RAM).
- Deteksi FPS/frame butuh root atau Shizuku. Tanpa itu, AI hanya bisa membaca beban RAM/CPU.
- Pembacaan FPS kini satu kali per putaran untuk monitor dan AI sekaligus, jadi tidak ada beban ganda.

## Baru di V4.4
- **Game Panel layar penuh**: panel kini memenuhi seluruh layar (termasuk area bilah navigasi), dengan jarak aman di tepi.
- **Kartu game** di sebelah kanan RAM / CPU / SUHU: ikon + nama game, "Performa maksimal", dan status Stabil / Smooth / Auto (tanpa tombol Start).
- Teks "Siap main?" diganti **"Performa maksimal"** (menu utama dan intro).
- **Boost jaringan lebih stabil dan tidak menghentikan aplikasi latar**: menambah penstabil koneksi (Doze dimatikan selama game lalu dikembalikan otomatis, Adaptive connectivity dan Wi-Fi wakeup dimatikan), diagnosa 3 server berjalan bersamaan (lebih cepat), dan **pembacaan ulang** kondisi sebenarnya (✓/✗) setelah boost.
- **Hentikan app latar dipisah** dari Boost jaringan: tombol "Buka Stop App" untuk memilih manual.

## Baru di V4.5
- **Game Space dan animasi pembuka kini benar-benar layar penuh**: tampil sampai ke area kamera (punch-hole) dan di bawah bilah sistem; tombol dan teks digeser otomatis menjauhi kamera agar tidak tertutup.
- **Game Panel diperkecil** (seperti panel Xiaomi): rancangan tetap 800x340 dp lalu diperkecil 75%. Ukuran bisa diubah lewat `Hud.PANEL_SCALE` (misal 0.65 lebih kecil, 0.85 lebih besar).

## Baru di V4.6
- **Game Panel pindah ke pojok kiri** (atau kanan bila handle di kanan) dan **lebih pendek** (desain 660 dp, sebelumnya 800 dp). Tidak lagi di tengah layar.
- **Kipas cooler berputar** di sebelah kartu game (`Fan.kt`). Makin tinggi suhu dan beban CPU, kipas makin cepat; cincin RGB ikut berputar dan suhu tampil di bawahnya.
- **Menu panel ke-2 (Pengaturan Panel) tidak muncul duluan**. Isinya tersembunyi sampai tab di kanan panel digeser atau diketuk.
- **Kartu game di Game Space lebih menyatu**: badan kaca tembus, aurora dan gelembung bergerak di dalam kartu, kilat cahaya mengelilingi bingkai, ikon melayang, kartu ikut melayang, berkas cahaya dari panggung ke kartu, dan semua perubahan kartu tengah/samping berjalan halus (tanpa loncat).

## Perbaikan V4.6b
- **Animasi kartu game jauh lebih halus**: digambar 60 fps (sebelumnya 30 fps), geser/snap memakai kurva yang lebih panjang dan lembut, dan tidak ada lagi pembuatan objek berat tiap frame (gradient dipakai ulang, teks di-cache) sehingga tidak patah-patah.
- **Gambar game menempel di blok kartu**: ikon tidak lagi bergerak sendiri. Ikon digambar dengan satu transformasi bersama kartu (ikut geser, putar 3D, dan melayang persis sama) dan posisinya desimal sehingga tidak bergetar di dalam blok.

## Perbaikan V4.6c
- **Game Panel dibesarkan**: tinggi panel kini hampir setinggi layar dengan celah kecil di atas dan bawah (94% tinggi layar), lebar dibatasi sekitar 60% layar agar tidak terlalu panjang, tetap di pojok kiri. Ukuran dihitung otomatis dari layar di `PanelUi`; ubah angka `0.94f` (tinggi) atau `0.60f` (lebar) di `Overlay.kt` bila mau celah lebih besar/kecil.

## Perbaikan V4.6d
- **Suara bawaan diganti ke "Air jatuh"** (klik, geser, buka panel). Pengaturan lama yang masih "Klasik" dikembalikan ke bawaan sekali saja; pilihan lain tetap dipertahankan dan bisa diubah di menu Suara.

## Perbaikan V4.6e
- **Teks, ikon, chip, tombol Start, dan tetesan kartu satu gerakan**: tetesan layar yang dulu menutupi kartu (diam di depan) dipindah ke belakang kartu. Isi kartu semuanya ikut satu transformasi dengan kartunya.
- **Gelembung/tetesan tidak lagi diam**: di kartu, di belakang kartu, di Game Panel, dan di intro, tetesan kini melayang naik pelan sambil bergoyang lalu muncul lagi.

## Perbaikan V4.6f
- **Game Panel kembali ke ukuran awal** (800x340 dp x 0,75, tidak terpotong), tetap di tengah secara vertikal dan hanya **digeser ke tepi kiri** (kanan bila handle di kanan).
- **Kartu game dan kipas cooler sama ukurannya** (150 x 140 dp, bingkai dan warna sama).

## Perbaikan V4.6g
- **Animasi buka/tutup HIGH BOOST**: tirai gelap memudar, kartu menu naik dari tombol HIGH BOOST sambil membesar (kurva halus 520 ms), lalu ikon fitur muncul bergantian satu per satu. Tombol HIGH BOOST memantul saat ditekan. Tutup memakai animasi turun dan memudar (260 ms). Animasi yang sama dipakai untuk semua panel Game Space lain (kartu naik halus, tanpa ikon bergantian).

## Perbaikan V4.6h
- **Tombol titik tiga (⋮) di kanan atas diganti kecepatan jaringan real-time**: ↓ unduh (hijau) dan ↑ unggah (pink), diperbarui tiap 1 detik. Ketuk untuk membuka menu Jaringan. Menu HIGH BOOST tetap dibuka lewat tombol HIGH BOOST di bawah.

## Perbaikan V4.6i
- **Desain lubang angin gaya insang hiu** di kanan kipas (`Vent.kt`): 5 celah miring ke atas yang bolong (hitam pekat) dengan cahaya tepi, dan cahaya berlari naik di tiap celah seperti udara keluar. Aliran makin cepat saat suhu/CPU naik, selaras dengan kipas. Ukuran 50 x 140 dp, bingkai sama dengan kartu game dan kipas.

## Perbaikan V4.6j
- **Teks kartu game menempel ke kartunya**: nama game, "Siap boost · ROOT", chip Stabil FPS / Smooth FPS / Auto Game, dan tombol Start kini memakai tata letak yang sama di SEMUA kartu (seperti foto). Tidak ada lagi pergantian tata letak tengah/samping, jadi semua teks ikut geser, putar, dan melayang persis bersama kartunya. Kartu di samping hanya lebih redup; tombol Start hanya bisa ditekan di kartu tengah.
