# XA Game Space v2 (root)

Dashboard (Beranda, Game, Alat, Setelan) + mode Game Space landscape.

- Beranda: status perangkat, RAM, penyimpanan, suhu/baterai, performa live, tombol Boost
- Game: kartu game dengan profil mode (Hemat, Seimbang, Performa, Kustom), monitor, tombol Main
- Alat: pulihkan, bersihkan RAM, stop app latar, uji kompatibilitas
- Setelan: warna aksen, profil kustom, overlay (posisi, ukuran, kepekatan, data), perilaku, reset
- Game Space: layar landscape bergaya console dengan sidebar aksi cepat

Build: push ke GitHub, lalu ambil APK dari tab Actions (artifact XAGameSpace-debug).
