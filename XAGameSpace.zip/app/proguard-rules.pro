# Shizuku memakai AIDL dan refleksi, jangan dihapus
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-keep class com.xa.gamespace.Music { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
