package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import java.util.Random
import kotlin.math.min
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.cos

// ============ Intro beranda ============
// Layar pembuka bergaya neon + air yang SELALU bergerak (cincin HUD berputar, riak air, aurora, partikel,
// huruf X berkilat) sampai pengguna menekan tombol "OPEN GAME SPACE".
// Wallpaper video beranda tetap terlihat samar di belakangnya.
class HomeIntro(ctx: Context, private val onOpen: () -> Unit) : FrameLayout(ctx) {
    private val button = GlowButton(ctx)

    init {
        isClickable = true            // sentuhan tidak tembus ke beranda di belakang
        addView(IntroCanvas(ctx), LayoutParams(-1, -1))
        addView(WetGlowView(ctx, 18, true, 0.8f), LayoutParams(-1, -1))

        val lp = LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = ctx.px(28)
        button.alpha = 0f
        button.translationY = ctx.pxf(24f)
        addView(button, lp)

        // kontak di pojok kiri bawah, TikTok di pojok kanan bawah (satu baris, tidak menabrak tombol)
        val cyan = android.graphics.Color.parseColor("#C8F6FF")
        val glow = android.graphics.Color.parseColor("#2EC8FF")
        fun corner(t: String, right: Boolean) = android.widget.TextView(ctx).apply {
            text = t
            textSize = 11f
            typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
            letterSpacing = 0.1f
            setTextColor(cyan)
            setShadowLayer(10f, 0f, 0f, glow)
            gravity = (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        }
        val bar = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(corner("WA  0851-3583-4977", false), android.widget.LinearLayout.LayoutParams(0, -2, 1f))
            addView(corner("TIKTOK  @XAGameSpace", true), android.widget.LinearLayout.LayoutParams(0, -2, 1f))
        }
        val blp = LayoutParams(-1, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        blp.leftMargin = ctx.px(24); blp.rightMargin = ctx.px(24); blp.bottomMargin = ctx.px(14)
        addView(bar, blp)
        // tombol muncul setelah X selesai digambar
        button.animate().alpha(1f).translationY(0f).setStartDelay(1100).setDuration(650).start()
        button.setOnClickListener { onOpen() }
    }
}

internal class IntroCanvas(ctx: Context) : View(ctx) {
    private val t0 = System.nanoTime()
    private val bg = Paint()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val rect = RectF()
    private val mat = Matrix()
    private var titleShader: LinearGradient? = null
    private val aurora = Array(3) { Paint() }
    private val aColors = intArrayOf(Color.parseColor("#3CC8FF"), Color.parseColor("#B04CFF"), Color.parseColor("#FF6FD8"))

    // partikel melayang naik: x, kecepatan, ukuran, fase
    private val rnd = Random(11)
    private val n = 30
    private val qx = FloatArray(n) { rnd.nextFloat() }
    private val qs = FloatArray(n) { 0.05f + rnd.nextFloat() * 0.09f }
    private val qr = FloatArray(n) { rnd.nextFloat() }
    private val qp = FloatArray(n) { rnd.nextFloat() }

    private fun dp(v: Float) = context.pxf(v)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        bg.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            Color.argb(222, 8, 12, 36), Color.argb(222, 44, 20, 84), Shader.TileMode.CLAMP)
        for (i in 0 until 3) {
            aurora[i].shader = RadialGradient(0f, 0f, 1f,
                intArrayOf(Color.argb(95, Color.red(aColors[i]), Color.green(aColors[i]), Color.blue(aColors[i])),
                    Color.argb(0, Color.red(aColors[i]), Color.green(aColors[i]), Color.blue(aColors[i]))),
                null, Shader.TileMode.CLAMP)
        }
        titleShader = LinearGradient(0f, 0f, dp(180f), 0f,
            intArrayOf(Color.WHITE, Color.parseColor("#3CC8FF"), Color.WHITE),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.MIRROR)
        txt.shader = titleShader
    }

    private fun arc(cv: Canvas, cx: Float, cy: Float, r: Float, start: Float, sweep: Float) {
        rect.set(cx - r, cy - r, cx + r, cy + r)
        cv.drawArc(rect, start, sweep, false, ring)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val tm = (System.nanoTime() - t0) / 1_000_000_000f

        cv.drawRect(0f, 0f, w, h, bg)

        // aurora: tiga cahaya besar yang bergerak pelan
        val big = max(w, h) * 0.5f
        for (i in 0 until 3) {
            val ax = w * (0.5f + 0.38f * sin(tm * 0.23f + i * 2.1f))
            val ay = h * (0.45f + 0.30f * cos(tm * 0.19f + i * 1.7f))
            cv.save()
            cv.translate(ax, ay)
            cv.scale(big, big)
            cv.drawCircle(0f, 0f, 1f, aurora[i])
            cv.restore()
        }

        // partikel + tetes air melayang naik
        for (i in 0 until n) {
            val fr = (tm * qs[i] + qp[i]) % 1f
            val yy = h * (1.05f - 1.1f * fr)
            val xx = w * qx[i] + sin(tm * 0.8f + i) * dp(14f)
            val a = sin(PIf * fr)
            val rr = dp(1.6f) + qr[i] * dp(4.5f)
            if (i % 3 == 0) {
                Wet.droplet(cv, xx, yy, rr * 1.7f, a)
            } else {
                val c = Wet.cycle(tm + i, 9f)
                p.style = Paint.Style.FILL
                p.color = Color.argb((150 * a).toInt(), Color.red(c), Color.green(c), Color.blue(c))
                cv.drawCircle(xx, yy, rr, p)
            }
        }

        // pusat: cincin HUD + riak air + X
        val cx = w / 2f
        val unit = min(h * 0.22f, dp(100f))
        val cy = h * 0.37f
        val pin = animSm((tm - 0.1f) / 0.9f)
        val col = Wet.cycle(tm, 8f)
        val cr = Color.red(col); val cg = Color.green(col); val cb = Color.blue(col)

        // riak air memancar dari X, berulang
        for (k in 0 until 3) {
            val ph = (tm / 2.8f + k / 3f) % 1f
            ring.color = Color.argb((120 * (1f - ph) * pin).toInt(), cr, cg, cb)
            ring.strokeWidth = dp(1.6f)
            cv.drawCircle(cx, cy, unit * (0.45f + 1.35f * ph), ring)
        }

        // cincin HUD berputar
        ring.color = Color.argb((210 * pin).toInt(), cr, cg, cb)
        ring.strokeWidth = dp(2.4f)
        val s1 = tm * 45f
        for (j in 0 until 4) arc(cv, cx, cy, unit, s1 + j * 90f, 55f)
        ring.color = Color.argb((150 * pin).toInt(), 255, 255, 255)
        ring.strokeWidth = dp(1.4f)
        val s2 = -tm * 70f
        for (j in 0 until 6) arc(cv, cx, cy, unit * 0.82f, s2 + j * 60f, 22f)
        val c2 = Wet.cycle(tm + 4f, 8f)
        ring.color = Color.argb((110 * pin).toInt(), Color.red(c2), Color.green(c2), Color.blue(c2))
        ring.strokeWidth = dp(1.2f)
        val s3 = tm * 22f
        for (j in 0 until 2) arc(cv, cx, cy, unit * 1.2f, s3 + j * 180f, 110f)

        // huruf X: digambar dua goresan, lalu terus bernapas + kilatan berkala
        val bob = sin(tm * 1.6f) * dp(3f)
        val breathe = 1f + 0.035f * sin(tm * 2.4f)
        val e = unit * 0.36f * breathe
        val core = unit * 0.11f
        val p1 = animSm((tm - 0.20f) / 0.45f)
        val p2 = animSm((tm - 0.55f) / 0.45f)
        val cyx = cy + bob
        val flash = if (tm > 1.1f) max(0f, 1f - ((tm - 1.1f) % 3.2f) / 0.45f) else 0f
        val boost = 0.85f + 0.25f * sin(tm * 2.4f) + 0.9f * flash
        xStroke(cv, cx - e, cyx - e, cx + e, cyx + e, p1, core, col, boost)
        xStroke(cv, cx + e, cyx - e, cx - e, cyx + e, p2, core, col, boost)
        // cahaya berlari di sepanjang goresan
        if (p1 >= 1f) runner(cv, cx - e, cyx - e, cx + e, cyx + e, (tm * 0.55f) % 1f, col)
        if (p2 >= 1f) runner(cv, cx + e, cyx - e, cx - e, cyx + e, (tm * 0.55f + 0.5f) % 1f, col)
        if (flash > 0.02f) {
            ring.color = Color.argb((170 * flash).toInt(), 200, 240, 255)
            ring.strokeWidth = dp(2f)
            cv.drawCircle(cx, cy, unit * (0.5f + 0.9f * (1f - flash)), ring)
        }

        // judul + subjudul
        val ta = animSm((tm - 1.0f) / 0.6f)
        if (ta > 0f) {
            val ty = cy + unit + dp(36f) + (1f - ta) * dp(10f)
            txt.textSize = dp(19f)
            txt.letterSpacing = 0.28f
            txt.alpha = (255 * ta).toInt()
            mat.setTranslate(tm * dp(60f), 0f)
            titleShader?.setLocalMatrix(mat)
            cv.drawText("XA  GAME  SPACE", cx, ty, txt)
            val sa = animSm((tm - 1.3f) / 0.6f)
            sub.textSize = dp(11f)
            sub.letterSpacing = 0.08f
            sub.color = Color.argb((220 * sa).toInt(), 159, 184, 208)
            cv.drawText("Performa maksimal untuk game kamu", cx, ty + dp(22f), sub)
        }

        postInvalidateOnAnimation()
    }

    private fun xStroke(cv: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, prog: Float, core: Float, col: Int, boost: Float) {
        if (prog <= 0f) return
        val ex = x0 + (x1 - x0) * prog
        val ey = y0 + (y1 - y0) * prog
        val r = Color.red(col); val g = Color.green(col); val b = Color.blue(col)
        line.color = Color.argb((60 * boost).toInt().coerceIn(0, 255), r, g, b)
        line.strokeWidth = core * 3.4f
        cv.drawLine(x0, y0, ex, ey, line)
        line.color = Color.argb((150 * boost).toInt().coerceIn(0, 255), r, g, b)
        line.strokeWidth = core * 1.9f
        cv.drawLine(x0, y0, ex, ey, line)
        line.color = Color.argb(245, 235, 250, 255)
        line.strokeWidth = core
        cv.drawLine(x0, y0, ex, ey, line)
        if (prog < 0.98f) {
            p.style = Paint.Style.FILL
            p.color = Color.argb(120, r, g, b)
            cv.drawCircle(ex, ey, dp(8f), p)
            p.color = Color.WHITE
            cv.drawCircle(ex, ey, dp(3.2f), p)
        }
    }

    private fun runner(cv: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, f: Float, col: Int) {
        val x = x0 + (x1 - x0) * f
        val y = y0 + (y1 - y0) * f
        val a = sin(PIf * f)
        p.style = Paint.Style.FILL
        p.color = Color.argb((120 * a).toInt(), Color.red(col), Color.green(col), Color.blue(col))
        cv.drawCircle(x, y, dp(8f), p)
        p.color = Color.argb((255 * a).toInt(), 255, 255, 255)
        cv.drawCircle(x, y, dp(3f), p)
    }
}

// Tombol "OPEN GAME SPACE": denyut, tepi berganti warna, kilau menyapu, dan panah yang bergerak terus.
class GlowButton(ctx: Context) : View(ctx) {
    private val t0 = System.nanoTime()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    private val clip = Path()
    private val rect = RectF()
    private val chev = Path()
    private val bandW = ctx.pxf(70f)

    init { isClickable = true }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(context.px(250), context.px(48))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fill.shader = LinearGradient(0f, 0f, w.toFloat(), 0f,
            Color.argb(225, 16, 110, 190), Color.argb(225, 118, 44, 196), Shader.TileMode.CLAMP)
        shine.shader = LinearGradient(0f, 0f, bandW, 0f,
            intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(95, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val tm = (System.nanoTime() - t0) / 1_000_000_000f
        val dpx = context.pxf(1f)
        val sc = (if (isPressed) 0.95f else 1f) * (1f + 0.02f * sin(tm * 3f))
        val col = Wet.cycle(tm, 6f)
        val pulse = 0.6f + 0.4f * sin(tm * 3.2f)

        cv.save()
        cv.scale(sc, sc, w / 2f, h / 2f)
        val pad = dpx * 4f
        rect.set(pad, pad, w - pad, h - pad)
        val rad = (h - pad * 2f) / 2f

        // cahaya luar berdenyut
        edge.color = Color.argb((90 * pulse).toInt(), Color.red(col), Color.green(col), Color.blue(col))
        edge.strokeWidth = dpx * 7f
        cv.drawRoundRect(rect, rad, rad, edge)
        // badan tombol
        cv.drawRoundRect(rect, rad, rad, fill)
        // kilau menyapu
        clip.reset()
        clip.addRoundRect(rect, rad, rad, Path.Direction.CW)
        cv.save()
        cv.clipPath(clip)
        val sx = ((tm * 0.55f) % 1.6f) * (w + bandW) - bandW
        cv.translate(sx, 0f)
        cv.drawRect(0f, 0f, bandW, h, shine)
        cv.restore()
        // tepi terang
        edge.color = col or (0xFF shl 24)
        edge.strokeWidth = dpx * 1.8f
        cv.drawRoundRect(rect, rad, rad, edge)

        // teks
        txt.textSize = dpx * 14f
        txt.letterSpacing = 0.16f
        cv.drawText("OPEN GAME SPACE", w / 2f - dpx * 10f, h / 2f - (txt.ascent() + txt.descent()) / 2f, txt)

        // tiga panah bergelombang di kanan
        edge.strokeWidth = dpx * 2f
        for (i in 0 until 3) {
            val a = 0.25f + 0.75f * max(0f, sin(tm * 5f - i * 0.9f))
            edge.color = Color.argb((255 * a).toInt(), 255, 255, 255)
            val x = w - dpx * 30f + i * dpx * 7f
            chev.reset()
            chev.moveTo(x, h / 2f - dpx * 5f)
            chev.lineTo(x + dpx * 4f, h / 2f)
            chev.lineTo(x, h / 2f + dpx * 5f)
            cv.drawPath(chev, edge)
        }
        cv.restore()

        postInvalidateOnAnimation()
    }

    override fun drawableStateChanged() {
        super.drawableStateChanged()
        invalidate()
    }
}
