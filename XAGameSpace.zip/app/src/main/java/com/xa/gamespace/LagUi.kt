package com.xa.gamespace

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.sin

// =====================================================================
//  AI Deteksi lemot: membaca FPS/frame, RAM, CPU, suhu lalu menebak penyebab
// =====================================================================
object LagAi {
    data class Verdict(val active: Boolean, val title: String, val causes: List<String>, val tip: String)

    private val idle = Verdict(false, "", emptyList(), "")

    @Volatile var last: Verdict = idle
        private set

    private val hist = ArrayList<Int>()
    private var bad = 0
    private var good = 0
    private var active = false
    private var ram = 0
    private var cpu = 0
    private var temp = 0f

    fun enabled(ctx: Context): Boolean = Store(ctx).get("ai_on") != "0"
    fun setEnabled(ctx: Context, v: Boolean) = Store(ctx).put("ai_on", if (v) "1" else "0")

    @Synchronized fun stats(s: SysStats.Sample) { ram = s.ramPct; cpu = s.cpuPct; temp = s.tempC }

    @Synchronized fun reset() {
        hist.clear(); bad = 0; good = 0; active = false; last = idle
    }

    // Dipanggil tiap 0,5 - 1 detik. Mengembalikan keputusan baru bila berubah.
    @Synchronized fun feed(f: SysStats.Frame): Verdict? {
        if (f.fps >= 0) {
            hist.add(f.fps)
            if (hist.size > 40) hist.removeAt(0)
        }
        val sorted = hist.sorted()
        val base = if (sorted.size >= 8) sorted[(sorted.size * 0.8f).toInt().coerceAtMost(sorted.size - 1)] else 0
        val sudden = f.fps >= 0 && base >= 24 && f.fps < base * 0.6f
        val freeze = f.fps >= 0 && (f.maxGapMs >= 120 || (f.fps == 0 && base >= 24))
        val janky = f.janks >= 3
        val heavy = f.fps < 0 && cpu >= 95 && ram >= 92
        val trouble = sudden || freeze || janky || heavy

        if (trouble) { bad++; good = 0 } else { good++; bad = 0 }
        if (!active && bad >= 2) active = true
        if (active && good >= 6) active = false

        if (!active) {
            if (last == idle) return null
            last = idle
            return idle
        }
        if (!trouble && last.active) return null

        val causes = ArrayList<String>()
        if (temp >= 43f) causes.add("Suhu baterai ${temp.toInt()}°C: HP menurunkan kecepatan prosesor agar tidak kepanasan (throttling).")
        if (ram >= 88) causes.add("RAM terpakai $ram%: memori hampir penuh, sistem sibuk membuang data sehingga game tersendat.")
        if (cpu >= 85) causes.add("CPU sibuk $cpu%: ada proses berat di latar yang berebut prosesor dengan game.")
        if (causes.isEmpty() && freeze) causes.add("Game sempat berhenti ${f.maxGapMs} ms: kemungkinan sedang memuat data atau jaringan tidak stabil.")
        if (causes.isEmpty()) causes.add("Frame tidak stabil tanpa beban sistem yang jelas: kemungkinan berasal dari game itu sendiri atau jaringan.")

        val title = when {
            freeze -> "HP membeku sesaat"
            sudden || janky -> "Gerakan patah-patah"
            else -> "HP kewalahan"
        }
        val tip = when {
            temp >= 43f -> "Turunkan grafis game, matikan Stabil FPS, dan istirahatkan HP 2–3 menit."
            ram >= 88 || cpu >= 85 -> "Tekan OPTIMAL untuk menghentikan aplikasi latar dan membersihkan RAM."
            else -> "Tekan OPTIMAL. Bila tetap lemot, coba Optimizer Jaringan atau turunkan grafis game."
        }
        val v = Verdict(true, title, causes, tip)
        if (v == last) return null
        last = v
        return v
    }
}

// Kartu AI Deteksi di sisi kanan bar CPU: saklar ON/OFF, status, peringatan penyebab, tombol OPTIMAL
class LagCard(private val ctx: Context, private val onOptimal: () -> Unit) : LinearLayout(ctx) {
    private val pill = Pill(ctx)
    private val status = TextView(ctx)
    private val alertBox = LinearLayout(ctx)
    private val title = TextView(ctx)
    private val causes = TextView(ctx)
    private val tip = TextView(ctx)
    private val result = TextView(ctx)

    private fun px(v: Int) = ctx.px(v)

    private fun styled(t: TextView, size: Float, color: Int, bold: Boolean = false) {
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
    }

    init {
        orientation = VERTICAL
        setPadding(px(10), px(8), px(10), px(8))

        val head = LinearLayout(ctx)
        head.orientation = HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val lb = TextView(ctx)
        lb.text = "🧠 AI DETEKSI"
        styled(lb, 10f, Hud.cyan, true)
        lb.letterSpacing = 0.1f
        head.addView(lb, LayoutParams(0, -2, 1f))
        pill.textSize = 9f
        pill.setPadding(px(9), px(3), px(9), px(3))
        pill.setOn(LagAi.enabled(ctx))
        pill.onToggle = { v ->
            LagAi.setEnabled(ctx, v)
            GameOverlay.applyAi()
            setState(LagAi.last, v)
        }
        head.addView(pill)
        addView(head)

        styled(status, 10f, Hud.sub, true)
        addView(status, LayoutParams(-1, -2).also { it.topMargin = px(4) })

        alertBox.orientation = VERTICAL
        styled(title, 11.5f, Color.parseColor("#FF6B6B"), true)
        alertBox.addView(title)
        styled(causes, 9.5f, Color.WHITE)
        alertBox.addView(causes, LayoutParams(-1, -2).also { it.topMargin = px(3) })
        styled(tip, 9f, Color.parseColor("#FFC9C9"))
        alertBox.addView(tip, LayoutParams(-1, -2).also { it.topMargin = px(4) })
        val btn = TextView(ctx)
        btn.text = "⚡ OPTIMAL"
        styled(btn, 11f, Color.WHITE, true)
        btn.gravity = Gravity.CENTER
        btn.setPadding(px(10), px(7), px(10), px(7))
        btn.background = Hud.rounded(Color.parseColor("#E53935"), Color.parseColor("#FF8A80"), ctx.pxf(14f), 1f)
        btn.setOnClickListener { Sfx.tap(); onOptimal() }
        alertBox.addView(btn, LayoutParams(-1, -2).also { it.topMargin = px(6) })
        addView(alertBox)
        alertBox.visibility = View.GONE

        styled(result, 9.5f, Color.parseColor("#38E8A5"))
        addView(result, LayoutParams(-1, -2).also { it.topMargin = px(4) })

        setState(LagAi.last, LagAi.enabled(ctx))
    }

    fun setResult(t: String) { result.text = t }

    fun setState(v: LagAi.Verdict, enabled: Boolean) {
        pill.setOn(enabled)
        when {
            !enabled -> {
                status.text = "Nonaktif"
                status.setTextColor(Hud.sub)
                alertBox.visibility = View.GONE
                result.text = ""
                background = Hud.rounded(Color.argb(150, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
            }
            !v.active -> {
                status.text = "● Normal · memantau"
                status.setTextColor(Color.parseColor("#38E8A5"))
                alertBox.visibility = View.GONE
                background = Hud.rounded(Color.argb(150, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
            }
            else -> {
                status.text = "⚠ Terdeteksi lemot"
                status.setTextColor(Color.parseColor("#FF6B6B"))
                title.text = v.title
                causes.text = v.causes.joinToString("\n") { "• $it" }
                tip.text = v.tip
                alertBox.visibility = View.VISIBLE
                background = Hud.rounded(Color.argb(235, 90, 6, 6), Color.parseColor("#FF4040"), ctx.pxf(10f), 1.5f)
            }
        }
    }
}

// Efek merah pekat berdenyut di atas panel saat lemot terdeteksi (tidak menangkap sentuhan)
class LagFxView(c: Context) : View(c) {
    private val tint = Paint()
    private val vig = Paint()
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private var anim: ValueAnimator? = null
    private var pulse = 0f

    init { visibility = GONE }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        vig.shader = RadialGradient(w / 2f, h / 2f, max(w, h) * 0.62f,
            intArrayOf(Color.argb(0, 255, 0, 0), Color.argb(0, 255, 0, 0), Color.argb(215, 190, 0, 0)),
            floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
    }

    fun setActive(a: Boolean) {
        if (a) {
            visibility = VISIBLE
            if (anim == null) {
                val an = ValueAnimator.ofFloat(0f, 1f)
                an.duration = 1000
                an.repeatCount = ValueAnimator.INFINITE
                an.interpolator = LinearInterpolator()
                an.addUpdateListener {
                    pulse = 0.5f + 0.5f * sin(catTime() * 5.5f)
                    invalidate()
                }
                anim = an
                an.start()
            }
        } else {
            anim?.cancel()
            anim = null
            visibility = GONE
        }
    }

    private fun catTime(): Float = ((System.nanoTime() / 1_000_000L) % 600000L) / 1000f

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        tint.color = Color.argb((55 + 55 * pulse).toInt(), 200, 0, 0)
        cv.drawRect(0f, 0f, w, h, tint)
        vig.alpha = (170 + 85 * pulse).toInt().coerceAtMost(255)
        cv.drawRect(0f, 0f, w, h, vig)
        edge.color = Color.argb((150 + 100 * pulse).toInt().coerceAtMost(255), 255, 40, 40)
        edge.strokeWidth = context.pxf(3f)
        rect.set(context.pxf(1.5f), context.pxf(1.5f), w - context.pxf(1.5f), h - context.pxf(1.5f))
        cv.drawRoundRect(rect, context.pxf(10f), context.pxf(10f), edge)
    }
}
