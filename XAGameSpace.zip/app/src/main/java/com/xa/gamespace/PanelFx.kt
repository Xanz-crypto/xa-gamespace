package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import java.util.Random
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

// Efek hidup untuk Game Panel, senada dengan Game Space (neon + air):
//  front = false : lapisan BELAKANG isi panel -> cahaya aurora yang melayang, gelembung naik, kilau bintang, ombak air di dasar
//  front = true  : lapisan DEPAN isi panel   -> percikan air dari permukaan, riak, dan percikan saat panel disentuh
// Tidak menangkap sentuhan.
class PanelFxView(ctx: Context, private val front: Boolean) : View(ctx) {
    private class P(var x: Float, var y: Float, var vx: Float, var vy: Float, val life: Float, val r: Float, val kind: Int) {
        var age = 0f
    }

    // bentuk panel; semua efek dipotong di sini supaya tidak keluar bingkai
    var clip: Path? = null

    private val ps = ArrayList<P>()
    private val rnd = Random(7)
    private val dens = ctx.resources.displayMetrics.density
    private var lastNs = 0L
    private var nextAuto = 0.6f
    private var running = false

    // belakang
    private val blob = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mat = Matrix()
    // filter warna aurora dibuat ulang hanya tiap 0,4 detik (bukan tiap frame): hemat alokasi, warna tetap mengalir halus
    private val auroraCf = arrayOfNulls<PorterDuffColorFilter>(3)
    private var cfAt = -10f
    private var blobShader: RadialGradient? = null
    private val wave = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wavePath = Path()
    // tirai aurora (pita cahaya bergelombang + sinar vertikal)
    private val curtain = Paint(Paint.ANTI_ALIAS_FLAG)
    private val curtainPath = Path()
    private val rayP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val star = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val bx = FloatArray(9) { rnd.nextFloat() }
    private val bsp = FloatArray(9) { 0.035f + rnd.nextFloat() * 0.05f }
    private val bph = FloatArray(9) { rnd.nextFloat() * 6.28f }
    private val brr = FloatArray(9) { 2.2f + rnd.nextFloat() * 4.5f }
    private val sx = FloatArray(6) { 0.05f + rnd.nextFloat() * 0.9f }
    private val sy = FloatArray(6) { 0.08f + rnd.nextFloat() * 0.84f }
    private val ssp = FloatArray(6) { 0.9f + rnd.nextFloat() * 1.4f }
    private val sph = FloatArray(6) { rnd.nextFloat() * 6.28f }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        lastNs = 0L
        invalidate()
    }

    override fun onDetachedFromWindow() {
        running = false
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        blobShader = RadialGradient(0f, 0f, 1f,
            intArrayOf(Color.argb(255, 255, 255, 255), Color.argb(90, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        blob.shader = blobShader
        curtain.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(170, 255, 255, 255), Color.argb(60, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.32f, 0.62f, 1f), Shader.TileMode.CLAMP)
        val wh = 46f * dens
        wave.shader = LinearGradient(0f, h - wh, 0f, h.toFloat(),
            Color.argb(70, 70, 200, 255), Color.argb(12, 80, 120, 255), Shader.TileMode.CLAMP)
    }

    // percikan dari titik (x, y)
    fun splash(x: Float, y: Float, power: Float) {
        if (ps.size > 90) return
        val n = 6 + rnd.nextInt(6)
        for (i in 0 until n) {
            val ang = Math.toRadians(-90.0 + (rnd.nextFloat() - 0.5f) * 140.0)
            val sp = (150f + rnd.nextFloat() * 170f) * dens * power
            ps.add(P(x, y, (cos(ang) * sp).toFloat(), (sin(ang) * sp).toFloat(),
                0.9f + rnd.nextFloat() * 0.6f, (1.3f + rnd.nextFloat() * 2.2f) * dens, 0))
        }
        for (i in 0 until 4) {
            val ang = rnd.nextFloat() * 6.283f
            val sp = (40f + rnd.nextFloat() * 90f) * dens
            ps.add(P(x, y, cos(ang) * sp, sin(ang) * sp - 40f * dens, 0.35f + rnd.nextFloat() * 0.25f, 1.1f * dens, 2))
        }
        ps.add(P(x, y, 0f, 0f, 1.0f, 30f * dens * power, 1))
        ps.add(P(x, y, 0f, 0f, 1.4f, 18f * dens * power, 1).also { it.age = -0.12f })
    }

    // dipanggil saat panel disentuh
    fun burst(x: Float, y: Float) {
        if (front) splash(x, y, 1.05f)
    }

    private fun stepParticles(dt: Float) {
        val g = 640f * dens
        val it = ps.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.age += dt
            if (p.age >= p.life) { it.remove(); continue }
            if (p.kind != 1) {
                p.vy += g * dt
                p.x += p.vx * dt
                p.y += p.vy * dt
                if (p.y > height + 10f * dens) it.remove()
            }
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val t = animNow()
        val c = clip
        val sv = cv.save()
        if (c != null) cv.clipPath(c)
        if (front) drawFront(cv, w, h, t) else drawBack(cv, w, h, t)
        cv.restoreToCount(sv)
        // belakang 20 fps (gerakannya lambat); depan 30 fps saat ada percikan, 15 fps saat sepi
        if (running) Gate.later(this, if (!front) 50 else if (ps.isEmpty()) 66 else 33)
    }

    // ---------- belakang ----------
    private fun drawBack(cv: Canvas, w: Float, h: Float, t: Float) {
        val sh = blobShader ?: return
        if (t < cfAt || t - cfAt > 0.4f) {
            for (i in 0 until 3) auroraCf[i] = PorterDuffColorFilter(Wet.cycle(t + i * 3.3f, 12f), PorterDuff.Mode.SRC_IN)
            cfAt = t
        }
        // aurora: tiga bola cahaya berwarna yang melayang pelan
        for (i in 0 until 3) {
            val cx = w * (0.5f + 0.42f * sin(t * (0.11f + 0.04f * i) + i * 2.1f))
            val cy = h * (0.5f + 0.40f * cos(t * (0.09f + 0.03f * i) + i * 1.7f))
            val r = max(w, h) * (0.30f + 0.06f * i)
            mat.setScale(r, r)
            mat.postTranslate(cx, cy)
            sh.setLocalMatrix(mat)
            blob.colorFilter = auroraCf[i]
            blob.alpha = (80 + 26 * sin(t * 0.7f + i)).toInt().coerceIn(0, 255)
            cv.drawCircle(cx, cy, r, blob)
        }

        drawCurtains(cv, w, h, t)

        // gelembung naik
        for (i in bx.indices) {
            val prog = (bsp[i] * t + bph[i]) % 1f
            val y = h + 8f * dens - prog * (h + 16f * dens)
            val x = bx[i] * w + sin(t * 0.8f + bph[i]) * 10f * dens
            val a = (if (prog < 0.12f) prog / 0.12f else if (prog > 0.8f) (1f - prog) / 0.2f else 1f).coerceIn(0f, 1f)
            val r = brr[i] * dens
            ring.strokeWidth = dens
            ring.color = Color.argb((95 * a).toInt(), 200, 238, 255)
            cv.drawCircle(x, y, r, ring)
            dot.color = Color.argb((150 * a).toInt(), 255, 255, 255)
            cv.drawCircle(x - r * 0.35f, y - r * 0.35f, r * 0.22f, dot)
        }

        // kilau bintang berkedip
        for (i in sx.indices) {
            val k = max(0f, sin(t * ssp[i] + sph[i])).pow(4)
            if (k < 0.05f) continue
            val x = sx[i] * w
            val y = sy[i] * h
            val len = (2.5f + 5f * k) * dens
            val col = Wet.cycle(t + i, 9f)
            star.strokeWidth = 1.1f * dens
            star.color = Color.argb((200 * k).toInt(), Color.red(col) / 2 + 128, Color.green(col) / 2 + 128, 255)
            cv.drawLine(x - len, y, x + len, y, star)
            cv.drawLine(x, y - len, x, y + len, star)
            dot.color = Color.argb((255 * k).toInt(), 255, 255, 255)
            cv.drawCircle(x, y, 1.1f * dens, dot)
        }

        // ombak air di dasar panel
        for (layer in 0 until 2) {
            val base = (20f - layer * 6f) * dens
            val amp = (4.5f - layer * 1.5f) * dens
            val ph = t * (1.3f + layer * 0.7f) + layer * 2f
            wavePath.reset()
            wavePath.moveTo(0f, h)
            var x = 0f
            val step = 22f * dens
            while (x <= w + step) {
                wavePath.lineTo(x, h - base - amp * sin(x / (46f * dens) + ph))
                x += step
            }
            wavePath.lineTo(w, h)
            wavePath.close()
            wave.alpha = if (layer == 0) 255 else 150
            cv.drawPath(wavePath, wave)
        }
    }

    // tirai aurora: tiga pita cahaya hijau-cyan-ungu yang meliuk, dengan sinar vertikal yang berkedip seperti aurora asli
    private fun drawCurtains(cv: Canvas, w: Float, h: Float, t: Float) {
        val stepX = 9f * dens
        for (i in 0 until 3) {
            val ph = t * (0.35f + 0.12f * i) + i * 2.3f
            val baseY = h * (0.16f + 0.13f * i)
            val amp = h * (0.07f + 0.02f * i)
            val len = h * (0.50f + 0.06f * sin(t * 0.4f + i))
            val col = Wet.cycle(t * 0.8f + i * 3.1f, 12f)
            curtainPath.reset()
            var x = 0f
            var first = true
            while (x <= w + stepX) {
                val y = baseY + amp * sin(x / (70f * dens) + ph) + amp * 0.5f * sin(x / (31f * dens) - ph * 1.7f)
                if (first) { curtainPath.moveTo(x, y); first = false } else curtainPath.lineTo(x, y)
                x += stepX
            }
            x = w + stepX
            while (x >= 0f) {
                val y = baseY + amp * sin(x / (70f * dens) + ph) + amp * 0.5f * sin(x / (31f * dens) - ph * 1.7f)
                curtainPath.lineTo(x, y + len * (0.75f + 0.25f * sin(x / (55f * dens) + ph * 1.3f)))
                x -= stepX
            }
            curtainPath.close()
            curtain.colorFilter = PorterDuffColorFilter(col, PorterDuff.Mode.SRC_IN)
            curtain.alpha = (70 + 25 * sin(t * 0.9f + i * 1.4f)).toInt().coerceIn(0, 255)
            cv.drawPath(curtainPath, curtain)
            // sinar vertikal
            rayP.strokeWidth = 2f * dens
            x = 0f
            var k = 0
            while (x <= w) {
                val a = (0.5f + 0.5f * sin(x / (23f * dens) + t * (1.1f + 0.3f * i) + k * 0.7f)).pow(3)
                val y0 = baseY + amp * sin(x / (70f * dens) + ph) + amp * 0.5f * sin(x / (31f * dens) - ph * 1.7f)
                val y1 = y0 + len * (0.35f + 0.5f * a)
                rayP.color = Color.argb((95 * a).toInt(), Color.red(col), Color.green(col), Color.blue(col))
                cv.drawLine(x, y0, x, y1, rayP)
                x += stepX
                k++
            }
        }
        curtain.colorFilter = null
    }

    // ---------- depan ----------
    private fun drawFront(cv: Canvas, w: Float, h: Float, t: Float) {
        val nowNs = System.nanoTime()
        val dt = if (lastNs == 0L) 0.033f else ((nowNs - lastNs) / 1e9f).coerceIn(0.005f, 0.06f)
        lastNs = nowNs

        // percikan otomatis dari permukaan air
        nextAuto -= dt
        if (nextAuto <= 0f) {
            nextAuto = 1.6f + rnd.nextFloat() * 2.2f
            if (rnd.nextFloat() < 0.65f) {
                splash(w * (0.08f + rnd.nextFloat() * 0.84f), h - 20f * dens, 0.85f)
            } else if (ps.size < 60) {
                // setetes air jatuh di tengah panel: riak + percikan kecil
                val x = w * (0.1f + rnd.nextFloat() * 0.8f)
                val y = h * (0.15f + rnd.nextFloat() * 0.65f)
                ps.add(P(x, y, 0f, 0f, 1.2f, 22f * dens, 1))
                for (i in 0 until 3) {
                    val ang = Math.toRadians(-90.0 + (rnd.nextFloat() - 0.5f) * 90.0)
                    val sp = (70f + rnd.nextFloat() * 60f) * dens
                    ps.add(P(x, y, (cos(ang) * sp).toFloat(), (sin(ang) * sp).toFloat(), 0.6f, 1.4f * dens, 0))
                }
            }
        }
        stepParticles(dt)

        val col = Wet.cycle(t, 8f)
        val rr = Color.red(col) / 2 + 120
        val gg = Color.green(col) / 2 + 120
        for (p in ps) {
            if (p.age < 0f) continue
            val f = p.age / p.life
            when (p.kind) {
                1 -> {
                    val r = p.r * (0.25f + 0.75f * f)
                    ring.strokeWidth = 1.5f * dens * (1f - f * 0.5f)
                    ring.color = Color.argb((170 * (1f - f)).toInt().coerceIn(0, 255), rr, gg, 255)
                    cv.save()
                    cv.scale(1f, 0.42f, p.x, p.y)
                    cv.drawCircle(p.x, p.y, r, ring)
                    cv.restore()
                }
                2 -> {
                    dot.color = Color.argb((255 * (1f - f)).toInt().coerceIn(0, 255), 255, 255, 255)
                    cv.drawCircle(p.x, p.y, p.r, dot)
                }
                else -> {
                    val a = if (f > 0.7f) (1f - f) / 0.3f else 1f
                    Wet.droplet(cv, p.x, p.y, p.r, a.coerceIn(0f, 1f))
                }
            }
        }
    }
}
