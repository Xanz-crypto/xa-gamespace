package com.xa.gamespace

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// ================= SHELL: jalankan perintah seperti module SkiaPerf (root atau Shizuku) =================
// Preset memakai fungsi yang sama dengan Texture / RateCmd, jadi alurnya identik dengan module.
class ShellPanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box = u.vbox()
    private val input = EditText(a)
    private val out = TextView(a)

    private data class Preset(val label: String, val cmd: String)

    private val presets = listOf(
        Preset("Texture LV1", Texture.applyCmd("1")),
        Preset("Texture LV2", Texture.applyCmd("2")),
        Preset("Texture LV3", Texture.applyCmd("3")),
        Preset("Texture LV4", Texture.applyCmd("4")),
        Preset("Texture Reset", Texture.resetCmd()),
        Preset("GPU Vsync ON", RateCmd.gpuVsyncCmd(true)),
        Preset("GPU Vsync OFF", RateCmd.gpuVsyncCmd(false)),
        Preset("Render 120 Hz", RateCmd.renderCmd("120")),
        Preset("Render Bawaan", RateCmd.renderDefaultCmd()),
        Preset("VSync FPS 120", RateCmd.vsyncFpsCmd("120")),
        Preset("Cek Status", Texture.VERIFY_OK + "\n" + RateCmd.VERIFY_GPU)
    )

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        draw()
    }

    private fun draw() {
        box.removeAllViews()
        box.addView(u.label("PRESET · sama dengan module SkiaPerf", 11f, Theme.sub, true), u.lp(b = 4))

        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        val row = u.hbox()
        presets.forEach { p ->
            val t = u.label(p.label, 12f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(u.dp(12), u.dp(7), u.dp(12), u.dp(7))
            t.background = u.glass(20, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
            t.setOnClickListener { run(p.cmd, p.label) }
            row.addView(t, u.lp(-2, -2, r = 6))
        }
        hs.addView(row)
        box.addView(hs, u.lp(b = 12))

        box.addView(u.label("PERINTAH BEBAS", 11f, Theme.sub, true), u.lp(b = 4))
        input.hint = "contoh: getprop debug.gpurend.vsync"
        input.setHintTextColor(Color.argb(120, 255, 255, 255))
        input.setTextColor(Color.WHITE)
        input.textSize = 13f
        input.typeface = Typeface.MONOSPACE
        input.minLines = 2
        input.gravity = Gravity.TOP or Gravity.START
        input.background = u.glass(12, Color.argb(120, 0, 0, 0), Color.argb(60, 255, 255, 255))
        input.setPadding(u.dp(10), u.dp(8), u.dp(10), u.dp(8))
        box.addView(input, u.lp(b = 8))

        val bar = u.hbox()
        bar.addView(u.btn("Jalankan", true) {
            val c = input.text.toString().trim()
            if (c.isNotEmpty()) run(c, "Perintah")
        }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn("Bersihkan") { out.text = ""; input.setText("") })
        box.addView(bar, u.lp(b = 10))

        out.textSize = 11f
        out.typeface = Typeface.MONOSPACE
        out.setTextColor(Theme.sub)
        out.setTextIsSelectable(true)
        box.addView(out)
    }

    private fun run(cmd: String, label: String) {
        if (!Access.requires(a, label, false)) return
        out.text = "Menjalankan $label..."
        Thread {
            val r = Access.run(cmd)
            a.runOnUiThread {
                out.text = "$label\n" + (r.ifBlank { "(tanpa output)" })
            }
        }.start()
    }
}
