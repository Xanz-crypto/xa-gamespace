package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.sin

// Modul status di tengah panel, meniru HUD referensi: busur bersegmen di kiri (RAM) dan kanan (CPU),
// angka FPS besar di tengah, bingkai miring di atas dan bawah, suhu di bawah. Nilai bergerak halus (easing).
class HudStatView(ctx: Context) : View(ctx) {
    private var fps = 0f; private var fpsT = 0f
    private var ram = 0f; private var ramT = 0f
    private var cpu = 0f; private var cpuT = 0f
    private var temp = 0f; private var tempT = 0f
    private var cap = "FPS"
    private var lastT = 0L

    private val seg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.BUTT }
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val tx = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val box = RectF()
    private val path = Path()

    fun update(fpsV: Float, caption: String, ramV: Float, cpuV: Float, tempV: Float) {
        fpsT = fpsV; ramT = ramV; cpuT = cpuV; tempT = tempV; cap = caption
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(context.px(340), context.px(122))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastT = System.nanoTime()
        invalidate()
    }

    private fun arcBar(cv: Canvas, cx: Float, cy: Float, rad: Float, start: Float, dir: Float, value: Float, t: Float) {
        val n = 10
        val step = 8f
        box.set(cx - rad, cy - rad, cx + rad, cy + rad)
        seg.strokeWidth = context.pxf(11f)
        val on = (value / 100f * n)
        for (i in 0 until n) {
            // i = 0 paling bawah
            val a = start + dir * i * step
            val fillK = (on - i).coerceIn(0f, 1f)
            val c = Wet.mix(Hud.neon, Wet.cycle(t + i * 0.25f, 8f), 0.55f)
            seg.color = if (fillK > 0f) Color.argb((70 + 185 * fillK).toInt(), Color.red(c), Color.green(c), Color.blue(c))
            else Color.argb(70, 120, 160, 200)
            cv.drawArc(box, a, dir * (step - 1.6f), false, seg)
        }
    }

    override fun onDraw(cv: Canvas) {
        val n = System.nanoTime()
        val dt = ((n - lastT) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastT = n
        val k = 1f - Math.exp((-4f * dt).toDouble()).toFloat()
        fps += (fpsT - fps) * k; ram += (ramT - ram) * k; cpu += (cpuT - cpu) * k; temp += (tempT - temp) * k

        val t = animNow()
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val col = Wet.cycle(t, 8f)

        // busur bersegmen: kiri = RAM, kanan = CPU
        val rad = context.pxf(104f)
        arcBar(cv, cx, cy, rad, 140f, 1f, ram, t)            // kiri: terisi dari bawah ke atas
        arcBar(cv, cx, cy, rad, 40f, -1f, cpu, t)            // kanan: terisi dari bawah ke atas

        // bingkai miring atas & bawah
        ln.strokeWidth = context.pxf(1.6f)
        val pl = 0.7f + 0.3f * sin(t * 2f)
        ln.color = Color.argb((150 + 80 * pl).toInt().coerceAtMost(255), Color.red(col), Color.green(col), Color.blue(col))
        val d = context.pxf(14f)
        path.reset()
        path.moveTo(cx - context.pxf(86f) - d, context.pxf(26f)); path.lineTo(cx - context.pxf(86f), context.pxf(12f))
        path.lineTo(cx + context.pxf(86f), context.pxf(12f)); path.lineTo(cx + context.pxf(86f) + d, context.pxf(26f))
        cv.drawPath(path, ln)
        path.reset()
        path.moveTo(cx - context.pxf(86f) - d, h - context.pxf(26f)); path.lineTo(cx - context.pxf(86f), h - context.pxf(12f))
        path.lineTo(cx + context.pxf(86f), h - context.pxf(12f)); path.lineTo(cx + context.pxf(86f) + d, h - context.pxf(26f))
        cv.drawPath(path, ln)

        // angka
        tx.color = Color.WHITE
        tx.textSize = context.pxf(40f)
        cv.drawText("${fps.toInt()}", cx, cy + context.pxf(8f), tx)
        tx.textSize = context.pxf(9.5f); tx.color = Hud.sub
        cv.drawText(cap, cx, cy + context.pxf(24f), tx)

        tx.textSize = context.pxf(19f); tx.color = Hud.neon
        cv.drawText("${ram.toInt()}%", cx - context.pxf(66f), cy + context.pxf(2f), tx)
        tx.textSize = context.pxf(9f); tx.color = Hud.sub
        cv.drawText("RAM", cx - context.pxf(66f), cy + context.pxf(15f), tx)

        tx.textSize = context.pxf(19f); tx.color = Hud.neon
        cv.drawText("${cpu.toInt()}%", cx + context.pxf(66f), cy + context.pxf(2f), tx)
        tx.textSize = context.pxf(9f); tx.color = Hud.sub
        cv.drawText("CPU", cx + context.pxf(66f), cy + context.pxf(15f), tx)

        tx.textSize = context.pxf(9.5f); tx.color = Wet.mix(Color.WHITE, col, 0.4f)
        cv.drawText("SUHU ${temp.toInt()}°C", cx, h - context.pxf(17f), tx)

        postInvalidateOnAnimation()
    }
}
