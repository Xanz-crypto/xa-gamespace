package com.xa.gamespace

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// =====================================================================
//  Pembatasan jaringan latar belakang: jaringan fokus ke game saja.
//
//  Level 1  RINGAN : Data Saver sistem (data latar dibatasi, game + app yang diizinkan dikecualikan)
//                    -> semua akses (root / Shizuku). Efektif di data seluler / Wi-Fi berbayar.
//  Level 2  SEDANG : + aplikasi latar ditidurkan (set-inactive + larangan jalan di latar)
//                    -> semua akses. Jaringan app idle diblokir sistem saat baterai (tidak mengisi daya).
//  Level 3  KERAS  : + firewall iptables per-UID: semua app latar ditolak total di Wi-Fi maupun data
//                    -> khusus ROOT. Tanpa root otomatis jatuh ke level 2 + hentikan paksa.
//
//  Yang TIDAK pernah dibatasi: game, aplikasi inti (SystemUI, telepon, keyboard, launcher, layanan Google),
//  aplikasi VPN, aplikasi SMS bawaan, aplikasi ini, dan daftar "Aplikasi diizinkan".
//  Semua perubahan dicatat dan dikembalikan oleh stop() (otomatis saat game selesai bila dimulai saat game aktif).
// =====================================================================
object NetBg {
    private const val CH = "xa_bg"
    private const val QOS = "xa_qos"
    private const val KEY = "net_bg"
    private val SAFE_PKG = Regex("^[A-Za-z0-9_.]+$")
    private val MODES = setOf("allow", "ignore", "deny", "default", "foreground")
    private val OPS = listOf("RUN_ANY_IN_BACKGROUND", "RUN_IN_BACKGROUND")

    class Target(val pkg: String, val uid: Int, val label: String)
    class Result(val lines: List<String>, val count: Int)

    // ---------- daftar diizinkan ----------
    fun allow(ctx: Context): Set<String> =
        Store(ctx).get("net_allow").split(",").filter { it.isNotBlank() }.toSet()

    fun setAllow(ctx: Context, pkg: String, on: Boolean) {
        val l = allow(ctx).toMutableSet()
        if (on) l.add(pkg) else l.remove(pkg)
        Store(ctx).put("net_allow", l.joinToString(","))
    }

    fun includeSystem(ctx: Context): Boolean = Store(ctx).get("net_bg_sys") == "1"

    // ---------- target: aplikasi latar yang boleh dibatasi ----------
    fun targets(ctx: Context): List<Target> {
        val pm = ctx.packageManager
        val st = Store(ctx)
        val allow = allow(ctx)
        val games = HashSet<String>()
        games.addAll(Games.packages(ctx))
        st.game?.let { games.add(it) }
        val prot = Boost.protectedCheck(ctx)
        val vpn = HashSet<String>()
        try {
            for (ri in pm.queryIntentServices(Intent("android.net.VpnService"), 0)) {
                ri.serviceInfo?.packageName?.let { vpn.add(it) }
            }
        } catch (e: Exception) {}
        val sms = try { android.provider.Telephony.Sms.getDefaultSmsPackage(ctx) } catch (e: Throwable) { null }
        val apps = try { pm.getInstalledApplications(0) } catch (e: Exception) { return emptyList() }
        val sysOk = includeSystem(ctx)
        val keepUids = HashSet<Int>()
        val cand = ArrayList<ApplicationInfo>()
        for (ai in apps) {
            val p = ai.packageName
            if (p == ctx.packageName || p in allow || p in games || p in vpn || p == sms || prot(p)) {
                keepUids.add(ai.uid)
                continue
            }
            if (ai.uid < 10000) continue
            val sys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val updated = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            if (sys && !updated && !sysOk) continue
            if (pm.checkPermission("android.permission.INTERNET", p) != PackageManager.PERMISSION_GRANTED) continue
            cand.add(ai)
        }
        return cand.filter { it.uid !in keepUids && SAFE_PKG.matches(it.packageName) }
            .map { Target(it.packageName, it.uid, try { it.loadLabel(pm).toString() } catch (e: Exception) { it.packageName }) }
    }

    private fun uidOf(ctx: Context, pkg: String): Int? =
        try { ctx.packageManager.getApplicationInfo(pkg, 0).uid } catch (e: Exception) { null }

    // ---------- catatan keadaan ----------
    private fun addState(ctx: Context, line: String) {
        val st = Store(ctx)
        val cur = st.get(KEY)
        st.put(KEY, if (cur.isBlank()) line else "$cur\n$line")
    }

    fun active(ctx: Context): Boolean = Store(ctx).get(KEY).isNotBlank()

    // level yang sedang aktif (0 = mati)
    fun level(ctx: Context): Int {
        for (l in Store(ctx).get(KEY).lines()) {
            val p = l.split("|")
            if (p[0] == "LV" && p.size >= 2) return (p[1].toIntOrNull() ?: 0).coerceIn(0, 3)
        }
        return 0
    }

    fun status(ctx: Context): String {
        val raw = Store(ctx).get(KEY)
        if (raw.isBlank()) return "Pembatasan latar: mati"
        var lv = 0
        var n = 0
        var src = "manual"
        for (l in raw.lines()) {
            val p = l.split("|")
            if (p[0] == "LV" && p.size >= 3) { lv = p[1].toIntOrNull() ?: 0; n = p[2].toIntOrNull() ?: 0 }
            if (p[0] == "SRC" && p.size >= 2) src = p[1]
        }
        val name = when (lv) { 1 -> "Ringan"; 2 -> "Sedang"; 3 -> "Keras"; else -> "?" }
        return "Pembatasan latar AKTIF · $name · $n app · " +
            if (src == "game") "dilepas otomatis saat game selesai" else "tekan Lepas batasan bila selesai"
    }

    // ---------- terapkan ----------
    fun apply(ctx: Context, level: Int): Result {
        if (level <= 0) return Result(listOf(stop(ctx)), 0)
        if (!Access.hasAny()) return Result(listOf("✗ Pembatasan latar butuh root atau Shizuku."), 0)
        stop(ctx)
        val st = Store(ctx)
        val root = Access.isRoot
        val ts = targets(ctx)
        val lines = ArrayList<String>()
        val src = if (st.active) "game" else "manual"
        addState(ctx, "SRC|$src")

        // 1) Data Saver + daftar putih game dan app yang diizinkan
        val pm = ctx.packageManager
        val keep = HashSet<Int>()
        val keepPk = HashSet<String>()
        keepPk.addAll(allow(ctx))
        st.game?.let { keepPk.add(it) }
        for (p in Games.packages(ctx)) if (keepPk.size < 40) keepPk.add(p)
        for (p in keepPk) uidOf(ctx, p)?.let { if (it >= 10000) keep.add(it) }
        val before = Access.run("cmd netpolicy get restrict-background; cmd netpolicy list restrict-background-whitelist")
        val wasOn = Regex("status:\\s*enabled", RegexOption.IGNORE_CASE).containsMatchIn(before)
        var already = emptySet<Int>()
        for (l in before.lines()) if (l.contains("whitelist", true)) {
            already = Regex("\\d{5,}").findAll(l).mapNotNull { it.value.toIntOrNull() }.toSet()
        }
        addState(ctx, "DS|" + if (wasOn) "1" else "0")
        val c1 = ArrayList<String>()
        c1.add("cmd netpolicy set restrict-background true")
        for (u in keep) if (u !in already) { c1.add("cmd netpolicy add restrict-background-whitelist $u"); addState(ctx, "WL|$u") }
        Access.run(c1.joinToString("\n"))
        lines.add("✓ Data Saver sistem aktif; game & ${allow(ctx).size} app diizinkan dikecualikan (efektif di data seluler / Wi-Fi berbayar)")

        // 2) aplikasi latar ditidurkan
        if (level >= 2 && ts.isNotEmpty()) {
            val pkgs = ts.map { it.pkg }
            val rd = StringBuilder()
            rd.append("for p in ").append(pkgs.joinToString(" ")).append("; do\n")
            for (op in OPS) rd.append("  echo \"AO|§p|$op|§(cmd appops get §p $op 2>/dev/null | head -n 1)\"\n")
            rd.append("done\n")
            val prior = Access.run(rd.toString().replace('§', '$'))
            val prev = HashMap<String, String>()
            for (l in prior.lines()) {
                val f = l.split("|", limit = 4)
                if (f.size == 4 && f[0] == "AO") {
                    val m = Regex(":\\s*([a-z_]+)").find(f[3])?.groupValues?.get(1)
                    if (m != null && m in MODES) prev[f[1] + "|" + f[2]] = m
                }
            }
            val c2 = StringBuilder()
            for (p in pkgs) {
                for (op in OPS) {
                    val old = prev["$p|$op"] ?: continue
                    c2.append("cmd appops set $p $op ignore\n")
                    addState(ctx, "AO|$p|$op|$old")
                }
                c2.append("am set-inactive $p true\n")
                addState(ctx, "IN|$p")
            }
            Access.run(c2.toString())
            lines.add("✓ ${ts.size} aplikasi latar ditidurkan (dilarang jalan di latar; jaringan idle diblokir sistem saat tidak mengisi daya)")
        } else if (level >= 2) {
            lines.add("○ Tidak ada aplikasi latar yang perlu ditidurkan")
        }

        // 3) firewall keras (root)
        if (level >= 3) {
            if (root && ts.isNotEmpty()) {
                val uids = ts.map { it.uid }.distinct()
                val sb = StringBuilder()
                for (t in listOf("iptables", "ip6tables")) {
                    sb.append("$t -N $CH 2>/dev/null || $t -F $CH\n")
                    sb.append("$t -A $CH -o lo -j RETURN\n")
                    for (u in uids) sb.append("$t -A $CH -m owner --uid-owner $u -j REJECT\n")
                    sb.append("$t -C OUTPUT -j $CH 2>/dev/null || $t -I OUTPUT 1 -j $CH\n")
                }
                Access.run(sb.toString())
                addState(ctx, "IPT|1")
                val n = Access.run("iptables -S $CH 2>/dev/null | grep -c -- '--uid-owner'").trim().toIntOrNull() ?: 0
                if (n > 0) lines.add("✓ Firewall: $n aplikasi latar diblokir total di Wi-Fi dan data")
                else lines.add("✗ Firewall tidak menerima aturan (kernel tanpa modul owner/REJECT). Level Sedang tetap aktif.")
            } else if (!root) {
                Boost.stop(ts.map { it.pkg })
                lines.add("✗ Blokir firewall butuh ROOT. Sebagai gantinya ${ts.size} app latar dihentikan paksa.")
            }
        }
        addState(ctx, "LV|$level|${ts.size}")
        return Result(lines, ts.size)
    }

    // Prioritas paket game (DSCP EF): router dengan WMM mengutamakan paket ini. Root, butuh game aktif.
    fun applyQos(ctx: Context): String {
        if (!Access.isRoot) return "✗ Prioritas paket game butuh root."
        val g = Store(ctx).game ?: return "○ Prioritas paket game: aktif saat game berjalan (belum ada game aktif)"
        val uid = uidOf(ctx, g) ?: return "✗ Prioritas paket game: UID game tidak terbaca"
        val sb = StringBuilder()
        for (t in listOf("iptables", "ip6tables")) {
            sb.append("$t -t mangle -N $QOS 2>/dev/null || $t -t mangle -F $QOS\n")
            sb.append("$t -t mangle -A $QOS -j DSCP --set-dscp-class EF\n")
            sb.append("$t -t mangle -C OUTPUT -m owner --uid-owner $uid -j $QOS 2>/dev/null || ")
            sb.append("$t -t mangle -I OUTPUT 1 -m owner --uid-owner $uid -j $QOS\n")
        }
        Access.run(sb.toString())
        addState(ctx, "QOS|$uid")
        val n = Access.run("iptables -t mangle -S $QOS 2>/dev/null | grep -c DSCP").trim().toIntOrNull() ?: 0
        return if (n > 0) "✓ Paket game diberi prioritas (DSCP EF); efektif bila router mendukung WMM"
        else "✗ Prioritas paket: kernel tanpa modul DSCP, dilewati"
    }

    fun killTargets(ctx: Context): Int {
        val ts = targets(ctx).map { it.pkg }
        Boost.stop(ts)
        return ts.size
    }

    fun verify(ctx: Context): List<String> {
        val out = ArrayList<String>()
        if (!active(ctx)) return out
        val o = Access.run("cmd netpolicy get restrict-background")
        out.add((if (o.contains("enabled", true)) "✓ " else "✗ ") + "Data Saver sistem " +
            if (o.contains("enabled", true)) "aktif" else "tidak aktif")
        if (Access.isRoot) {
            val n = Access.run("iptables -S $CH 2>/dev/null | grep -c -- '--uid-owner'").trim().toIntOrNull() ?: 0
            if (n > 0) out.add("✓ Firewall latar: $n aplikasi")
        }
        return out
    }

    // ---------- lepas ----------
    fun stop(ctx: Context): String {
        val st = Store(ctx)
        val raw = st.get(KEY)
        if (raw.isBlank()) return "Pembatasan latar sudah mati."
        val c = ArrayList<String>()
        var qosUid: Int? = null
        var ipt = false
        var prevOn = true
        for (l in raw.lines()) {
            val p = l.split("|")
            when (p[0]) {
                "DS" -> prevOn = p.getOrNull(1) == "1"
                "WL" -> p.getOrNull(1)?.toIntOrNull()?.let { c.add("cmd netpolicy remove restrict-background-whitelist $it") }
                "IN" -> p.getOrNull(1)?.takeIf { SAFE_PKG.matches(it) }?.let { c.add("am set-inactive $it false") }
                "AO" -> if (p.size >= 4 && SAFE_PKG.matches(p[1]) && p[2] in OPS) {
                    c.add("cmd appops set ${p[1]} ${p[2]} ${if (p[3] in MODES) p[3] else "default"}")
                }
                "IPT" -> ipt = true
                "QOS" -> qosUid = p.getOrNull(1)?.toIntOrNull()
            }
        }
        if (!prevOn) c.add("cmd netpolicy set restrict-background false")
        if (Access.isRoot) {
            if (ipt) for (t in listOf("iptables", "ip6tables")) {
                c.add("while $t -D OUTPUT -j $CH 2>/dev/null; do :; done")
                c.add("$t -F $CH 2>/dev/null; $t -X $CH 2>/dev/null")
            }
            val q = qosUid
            if (q != null) for (t in listOf("iptables", "ip6tables")) {
                c.add("while $t -t mangle -D OUTPUT -m owner --uid-owner $q -j $QOS 2>/dev/null; do :; done")
                c.add("$t -t mangle -F $QOS 2>/dev/null; $t -t mangle -X $QOS 2>/dev/null")
            }
        }
        if (c.isNotEmpty()) Access.run(c.joinToString("\n"))
        st.put(KEY, "")
        return "Pembatasan jaringan latar dilepas, semua kembali normal."
    }

    // dipanggil saat game selesai: hanya melepas yang dimulai ketika game aktif
    fun releaseGame(ctx: Context) {
        val raw = Store(ctx).get(KEY)
        if (raw.lines().any { it == "SRC|game" }) stop(ctx)
    }
}

// Sheet pilih aplikasi yang TIDAK dibatasi (selain game). Dipakai di dalam NetSheet.
class NetAllowSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val list = LinearLayout(ctx)
    private val summary = TextView(ctx)
    private var items: List<Item> = emptyList()

    private class Item(val pkg: String, val label: String, val icon: Drawable?)

    private fun px(v: Int) = ctx.px(v)

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("✔ APLIKASI DIIZINKAN", 12f, Hud.cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        val x = tv("‹ Kembali", 12f, Color.WHITE, true)
        x.setPadding(px(10), px(2), px(4), px(2))
        x.setOnClickListener { Sfx.tap(); onClose() }
        head.addView(x)
        root.addView(head)
        root.addView(tv(
            "Aplikasi yang dicentang TIDAK dibatasi saat mode fokus game, misalnya Discord / WhatsApp untuk suara tim. " +
                "Game selalu diizinkan otomatis. Aplikasi inti dan VPN juga selalu aman.",
            9.5f, Hud.sub), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(2); it.bottomMargin = px(6) })
        summary.textSize = 10f
        summary.setTextColor(Hud.sub)
        root.addView(summary, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(4) })
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        load()
    }

    private fun load() {
        summary.text = "Memuat daftar aplikasi..."
        Thread {
            val pm = ctx.packageManager
            val prot = Boost.protectedCheck(ctx)
            val r = ArrayList<Item>()
            try {
                for (ai in pm.getInstalledApplications(0)) {
                    val p = ai.packageName
                    if (p == ctx.packageName || prot(p)) continue
                    if (pm.getLaunchIntentForPackage(p) == null) continue
                    if (pm.checkPermission("android.permission.INTERNET", p) != PackageManager.PERMISSION_GRANTED) continue
                    r.add(Item(p, ai.loadLabel(pm).toString(), try { ai.loadIcon(pm) } catch (e: Exception) { null }))
                }
            } catch (e: Exception) {}
            root.post { items = r; render() }
        }.start()
    }

    private fun render() {
        list.removeAllViews()
        val al = NetBg.allow(ctx)
        summary.text = "${al.size} diizinkan · ${items.size} aplikasi berjaringan"
        val sorted = items.sortedWith(compareByDescending<Item> { it.pkg in al }.thenBy { it.label.lowercase() })
        for (a in sorted) list.addView(row(a))
    }

    private fun row(a: Item): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(px(4), px(5), px(4), px(5))
        val ic = ImageView(ctx)
        a.icon?.let { ic.setImageDrawable(it) }
        r.addView(ic, LinearLayout.LayoutParams(px(28), px(28)).also { it.rightMargin = px(8) })
        val n = tv(a.label, 12f)
        n.maxLines = 1
        n.ellipsize = android.text.TextUtils.TruncateAt.END
        r.addView(n, LinearLayout.LayoutParams(0, -2, 1f))
        val on = a.pkg in NetBg.allow(ctx)
        val box = tv(if (on) "☑" else "☐", 18f, if (on) Hud.cyan else Hud.sub, true)
        box.setPadding(px(10), px(2), px(6), px(2))
        r.addView(box)
        r.setOnClickListener {
            Sfx.tap()
            val now = a.pkg !in NetBg.allow(ctx)
            NetBg.setAllow(ctx, a.pkg, now)
            box.text = if (now) "☑" else "☐"
            box.setTextColor(if (now) Hud.cyan else Hud.sub)
            summary.text = "${NetBg.allow(ctx).size} diizinkan · ${items.size} aplikasi berjaringan"
        }
        return r
    }
}
