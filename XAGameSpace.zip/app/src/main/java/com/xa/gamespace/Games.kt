package com.xa.gamespace

import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Build

data class GameApp(val pkg: String, val label: String, val icon: Drawable?)

object Games {
    // kartu "+ Tambah Game" di ujung kanan carousel (bukan game sungguhan)
    const val ADD_PKG = "__add_game__"
    private val KNOWN = setOf(
        "com.mobile.legends", "com.tencent.ig", "com.pubg.imobile", "com.pubg.krmobile",
        "com.vng.pubgmobile", "com.rekoo.pubgm", "com.dts.freefireth", "com.dts.freefiremax",
        "com.miHoYo.GenshinImpact", "com.HoYoverse.hkrpgoversea", "com.miHoYo.hkrpg",
        "com.activision.callofduty.shooter", "com.garena.game.codm", "com.roblox.client",
        "com.mojang.minecraftpe", "com.supercell.clashofclans", "com.supercell.clashroyale",
        "com.supercell.brawlstars", "com.levelinfinite.sgameGlobal", "com.tencent.tmgp.sgame",
        "com.riotgames.league.wildrift", "com.ea.gp.fifamobile", "com.ea.gp.apexlegendsmobilefps",
        "com.kiloo.subwaysurf", "com.innersloth.spacemafia", "com.gameloft.android.ANMP.GloftA9HM",
        "com.netease.lztgglobal", "com.netease.newspike", "com.proximabeta.mf.uamo",
        "com.lilithgame.roc.gp", "com.moonton.mobilehero", "com.garena.game.kgid"
    )
    private val SKIP_PREFIX = listOf("com.google.android", "com.samsung", "com.sec.", "com.miui",
        "com.xiaomi", "com.android", "com.oppo", "com.coloros", "com.vivo", "com.huawei")

    @Suppress("DEPRECATION")
    private fun isGame(ai: ApplicationInfo): Boolean {
        if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) return true
        if ((ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return true
        if (ai.packageName in KNOWN) return true
        val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        if (!system && SKIP_PREFIX.none { ai.packageName.startsWith(it) }) {
            val p = ai.packageName.lowercase()
            if (p.contains(".game") || p.endsWith("game") || p.contains("games")) return true
        }
        return false
    }

    fun detect(ctx: Context): List<GameApp> {
        val pm = ctx.packageManager
        // game yang ditambahkan manual lewat kartu +
        val extra = Store(ctx).get("extra_games").split(",").filter { it.isNotBlank() }.toSet()
        return try {
            pm.getInstalledApplications(0)
                .filter { it.packageName != ctx.packageName && (isGame(it) || it.packageName in extra) }
                .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
                .map { GameApp(it.packageName, it.loadLabel(pm).toString(), try { it.loadIcon(pm) } catch (e: Exception) { null }) }
                .sortedBy { it.label.lowercase() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun packages(ctx: Context): Set<String> = detect(ctx).map { it.pkg }.toSet()
}
