package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.sin

// Lubang angin miring ke atas seperti insang hiu (sirip), di sebelah kanan kipas.
// Cahaya berlari naik di tiap celah seperti udara keluar; makin panas / berat CPU, makin cepat.
class GillVentView(ctx: Context) : View(ctx) {
    private val slits = 5
    private var flow = 0.35f          // kecepatan aliran (yang digambar)
    private var targetFlow = 0.35f
    private var phase = 0f
    private var lastT = 0L

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val line = Path()

    init {
        // kotak yang sama dengan kartu game dan kipas
        background = Hud.rounded(Color.argb(150, 12, 36, 70), Hud.cyan, ctx.pxf(14f), 1.5f)
    }

    fun setLoad(cpuPct: Int, tempC: Float) {
        val hot = (tempC - 34f).coerceAtLeast(0f)
        targetFlow = (0.35f + cpuPct * 0.006f + hot * 0.03f).coerceAtMost(1.6f)
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize(context.px(50), w), resolveSize(context.px(140), h))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastT = System.nanoTime()
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val n = System.nanoTime()
        val dt = ((n - lastT) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastT = n
        flow += (targetFlow - flow) * (1f - Math.exp((-3f * dt).toDouble()).toFloat())
        phase = (phase + flow * dt) % 1000f

        val t = animNow()
        val col = Wet.cycle(t, 6f)
        val cr = Color.red(col); val cg = Color.green(col); val cb = Color.blue(col)
        val w = width.toFloat()
        val h = height.toFloat()
        val padY = context.pxf(16f)
        val slant = context.pxf(11f)               // kemiringan: bawah kiri -> atas kanan
        val gap = (w - context.pxf(20f) - slant) / (slits - 1)
        val x0 = context.pxf(10f)

        for (i in 0 until slits) {
            // celah tengah sedikit lebih panjang seperti insang
            val mid = 1f - kotlin.math.abs(i - (slits - 1) / 2f) / ((slits - 1) / 2f)
            val extra = context.pxf(8f) * mid
            val bx = x0 + i * gap
            val by = h - padY + extra * 0.4f
            val tx = bx + slant
            val ty = padY - extra * 0.6f
            line.reset()
            line.moveTo(bx, by)
            line.lineTo(tx, ty)

            // cahaya tepi
            p.strokeWidth = context.pxf(9f)
            p.color = Color.argb((38 + 22 * (0.5f + 0.5f * sin(t * 2f + i))).toInt(), cr, cg, cb)
            cv.drawPath(line, p)
            // lubang (bolong): hitam pekat
            p.strokeWidth = context.pxf(5.5f)
            p.color = Color.argb(245, 2, 8, 16)
            cv.drawPath(line, p)
            // pinggiran tipis
            p.strokeWidth = context.pxf(5.5f)
            p.color = Color.argb(0, 0, 0, 0)

            // cahaya berlari naik di dalam celah (udara keluar)
            val q = (phase * 0.9f + i * 0.21f) % 1f
            val len = 0.20f
            val a = sin(q * PIf).coerceIn(0f, 1f)
            val sx = bx + (tx - bx) * q
            val sy = by + (ty - by) * q
            val ex = bx + (tx - bx) * (q + len).coerceAtMost(1f)
            val ey = by + (ty - by) * (q + len).coerceAtMost(1f)
            p.strokeWidth = context.pxf(5f)
            p.color = Color.argb((120 * a).toInt(), cr, cg, cb)
            cv.drawLine(sx, sy, ex, ey, p)
            p.strokeWidth = context.pxf(2f)
            p.color = Color.argb((230 * a).toInt(), 235, 250, 255)
            cv.drawLine(sx, sy, ex, ey, p)
        }
        Gate.later(this, 33)
    }
}
