package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import java.util.Random
import kotlin.math.floor
import kotlin.math.sin

// Efek "habis kena air": tetesan bening berkilau, kilau cahaya yang menyapu, dan cahaya tepi berwarna
object Wet {
    val palette = intArrayOf(
        Color.parseColor("#3CC8FF"), // cyan
        Color.parseColor("#4F6BFF"), // biru
        Color.parseColor("#B04CFF"), // ungu
        Color.parseColor("#FF6FD8")  // pink
    )

    fun mix(a: Int, b: Int, f: Float): Int {
        val m = f.coerceIn(0f, 1f)
        return Color.argb(
            (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * m).toInt(),
            (Color.red(a) + (Color.red(b) - Color.red(a)) * m).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * m).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * m).toInt()
        )
    }

    // warna yang berganti pelan-pelan: cyan > biru > ungu > pink > cyan
    fun cycle(t: Float, period: Float = 9f): Int {
        val x = ((t / period) % 1f) * palette.size
        val i = floor(x).toInt() % palette.size
        return mix(palette[i], palette[(i + 1) % palette.size], x - floor(x))
    }

    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(0f, 0f, 1f,
            intArrayOf(Color.argb(10, 255, 255, 255), Color.argb(38, 150, 215, 255), Color.argb(130, 205, 238, 255)),
            floatArrayOf(0f, 0.72f, 1f), Shader.TileMode.CLAMP)
    }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 0.07f }
    private val hi = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    // satu tetes air: badan bening, bingkai tipis, dua titik kilau
    fun droplet(cv: Canvas, x: Float, y: Float, r: Float, a: Float) {
        if (a <= 0.01f) return
        cv.save()
        cv.translate(x, y)
        cv.scale(r, r)
        body.alpha = (255 * a).toInt().coerceIn(0, 255)
        cv.drawCircle(0f, 0f, 1f, body)
        rim.color = Color.argb((150 * a).toInt(), 220, 244, 255)
        cv.drawCircle(0f, 0f, 0.96f, rim)
        hi.color = Color.argb((235 * a).toInt(), 255, 255, 255)
        cv.drawCircle(-0.36f, -0.4f, 0.26f, hi)
        hi.color = Color.argb((120 * a).toInt(), 170, 225, 255)
        cv.drawCircle(0.4f, 0.46f, 0.14f, hi)
        cv.restore()
    }

    // ekor tetes yang meluncur turun
    fun trail(cv: Canvas, x: Float, y: Float, r: Float, a: Float) {
        for (k in 1..4) {
            hi.color = Color.argb((70 * a / k).toInt(), 200, 235, 255)
            cv.drawCircle(x, y - k * r * 1.5f, r * (0.55f - 0.1f * k).coerceAtLeast(0.15f), hi)
        }
    }
}

// Lapisan efek basah penuh layar. Tidak menangkap sentuhan.
class WetGlowView(ctx: Context, private val count: Int = 24, private val edge: Boolean = true,
                  private val strength: Float = 1f) : View(ctx) {
    private val rnd = Random(21)
    private val fx = FloatArray(count) { rnd.nextFloat() }
    private val fy = FloatArray(count) { rnd.nextFloat() }
    private val fr = FloatArray(count) { 2f + rnd.nextFloat() * 5.5f }
    private val slide = BooleanArray(count) { rnd.nextFloat() < 0.35f }
    private val spd = FloatArray(count) { 0.012f + rnd.nextFloat() * 0.02f }
    private val ph = FloatArray(count) { rnd.nextFloat() * 6.28f }

    private val edgePaints = Array(4) { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val sweep = Paint()
    private var band: LinearGradient? = null
    private var bandW = 0f
    private val mat = Matrix()
    private var running = false

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        invalidate()
    }

    override fun onDetachedFromWindow() {
        running = false
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val e = minOf(w, h) * 0.17f
        val white = Color.argb(255, 255, 255, 255)
        val none = Color.argb(0, 255, 255, 255)
        edgePaints[0].shader = LinearGradient(0f, 0f, e, 0f, white, none, Shader.TileMode.CLAMP)
        edgePaints[1].shader = LinearGradient(w.toFloat(), 0f, w - e, 0f, white, none, Shader.TileMode.CLAMP)
        edgePaints[2].shader = LinearGradient(0f, 0f, 0f, e, white, none, Shader.TileMode.CLAMP)
        edgePaints[3].shader = LinearGradient(0f, h.toFloat(), 0f, h - e, white, none, Shader.TileMode.CLAMP)
        bandW = w * 0.32f
        band = LinearGradient(0f, 0f, bandW, 0f,
            intArrayOf(Color.argb(0, 190, 235, 255), Color.argb(46, 205, 240, 255), Color.argb(0, 190, 235, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        sweep.shader = band
    }

    // bentuk panel; efek dipotong di sini supaya tidak keluar bingkai
    var clip: android.graphics.Path? = null

    override fun onDraw(cv: Canvas) {
        val c = clip
        val sv = cv.save()
        if (c != null) cv.clipPath(c)
        drawAll(cv)
        cv.restoreToCount(sv)
    }

    private fun drawAll(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val now = animNow()
        val dens = context.resources.displayMetrics.density

        if (edge) {
            val pulse = 0.62f + 0.38f * sin(now * 1.7f)
            val e = minOf(w, h) * 0.17f
            val cA = Wet.cycle(now)
            val cB = Wet.cycle(now + 4.5f)
            val al = (125 * pulse * strength).toInt().coerceIn(0, 255)
            for (i in 0 until 4) {
                val p = edgePaints[i]
                p.colorFilter = PorterDuffColorFilter(if (i % 2 == 0) cA else cB, PorterDuff.Mode.SRC_IN)
                p.alpha = al
            }
            cv.drawRect(0f, 0f, e, h, edgePaints[0])
            cv.drawRect(w - e, 0f, w, h, edgePaints[1])
            cv.drawRect(0f, 0f, w, e, edgePaints[2])
            cv.drawRect(0f, h - e, w, h, edgePaints[3])
        }

        // kilau cahaya menyapu miring
        if (band != null) {
            val travel = w + bandW * 2f
            val bx = ((now * 0.11f) % 1f) * travel - bandW
            cv.save()
            cv.rotate(-14f, w / 2f, h / 2f)
            mat.setTranslate(bx, 0f)
            band!!.setLocalMatrix(mat)
            sweep.alpha = (255 * strength).toInt().coerceIn(0, 255)
            cv.drawRect(bx, -h, bx + bandW, h * 2f, sweep)
            cv.restore()
        }

        // tetesan air
        for (i in 0 until count) {
            val r = fr[i] * dens
            val x = fx[i] * w
            if (slide[i]) {
                val y = (((fy[i] + now * spd[i]) % 1.15f) - 0.05f) * h
                Wet.trail(cv, x, y, r, 0.9f * strength)
                Wet.droplet(cv, x, y, r, 0.95f * strength)
            } else {
                val tw = 0.78f + 0.22f * sin(now * 1.5f + ph[i])
                Wet.droplet(cv, x, fy[i] * h, r, tw * strength)
            }
        }
        if (running) postInvalidateDelayed(40)
    }
}
