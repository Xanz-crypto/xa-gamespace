package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import kotlin.math.sin

// Tombol ikon bulat bergaya HUD (ikon dalam cincin + label di bawah), menggantikan tile segi enam.
// Saat aktif: cincin menyala, ada busur cahaya yang berputar pelan. Perubahan nyala dibuat halus (easing).
class RingTile(c: Context, private val glyph: String, private val label: String, private val badge: Boolean = false) : View(c) {
    var on = false
        set(v) { field = v; invalidate() }
    var tag: String? = null
    var tagOk = true

    private var lit = 0f          // 0..1, mengejar status on secara halus
    private var press = 0f
    private var lastT = 0L

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val gl = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = c.pxf(19f); color = Color.WHITE }
    private val lb = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = c.pxf(9.5f); typeface = Typeface.DEFAULT_BOLD }
    private val tg = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = c.pxf(7f); typeface = Typeface.DEFAULT_BOLD }
    private val bd = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()

    init { isClickable = true }

    override fun performClick(): Boolean {
        Sfx.tap()
        return super.performClick()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(context.px(62), context.px(90))
    }

    override fun drawableStateChanged() {
        super.drawableStateChanged()
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastT = System.nanoTime()
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val n = System.nanoTime()
        val dt = ((n - lastT) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastT = n
        val k = 1f - Math.exp((-6f * dt).toDouble()).toFloat()
        lit += ((if (on) 1f else 0f) - lit) * k
        press += ((if (isPressed) 1f else 0f) - press) * k

        val t = animNow()
        val gc = Wet.cycle(t, 7f)
        val cr = Color.red(gc); val cg = Color.green(gc); val cb = Color.blue(gc)
        val cx = width / 2f
        val cy = context.pxf(26f)
        val r = context.pxf(21f) * (1f - 0.1f * press)

        // cahaya lembut di belakang ikon
        if (lit > 0.01f) {
            val pl = 0.7f + 0.3f * sin(t * 2.4f)
            fill.shader = RadialGradient(cx, cy, r * 1.9f, Color.argb((110 * lit * pl).toInt(), cr, cg, cb),
                Color.argb(0, cr, cg, cb), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, r * 1.9f, fill)
            fill.shader = null
        }
        // badan kaca
        fill.color = Color.argb((120 + 50 * lit).toInt(), (10 + 30 * lit).toInt(), (28 + 90 * lit).toInt(), (50 + 130 * lit).toInt())
        cv.drawCircle(cx, cy, r, fill)
        // cincin
        ring.strokeWidth = context.pxf(1.7f)
        ring.color = Wet.mix(Color.argb(200, 170, 205, 235), Hud.cyan, lit)
        cv.drawCircle(cx, cy, r, ring)
        // busur cahaya berputar pelan saat aktif
        if (lit > 0.02f) {
            oval.set(cx - r - context.pxf(3f), cy - r - context.pxf(3f), cx + r + context.pxf(3f), cy + r + context.pxf(3f))
            ring.strokeWidth = context.pxf(2.2f)
            ring.strokeCap = Paint.Cap.ROUND
            ring.color = Color.argb((230 * lit).toInt(), cr, cg, cb)
            val a0 = (t * 70f) % 360f
            cv.drawArc(oval, a0, 70f, false, ring)
            cv.drawArc(oval, a0 + 180f, 40f, false, ring)
            ring.strokeCap = Paint.Cap.BUTT
        }
        cv.drawText(glyph, cx, cy - (gl.ascent() + gl.descent()) / 2f, gl)
        lb.color = Wet.mix(Color.WHITE, Hud.cyan, lit)
        val sp = label.indexOf(' ')
        if (sp > 0) {
            cv.drawText(label.substring(0, sp), cx, context.pxf(60f), lb)
            cv.drawText(label.substring(sp + 1), cx, context.pxf(71f), lb)
        } else cv.drawText(label, cx, context.pxf(63f), lb)
        tag?.let {
            tg.color = if (tagOk) Color.parseColor("#38E8A5") else Color.parseColor("#FFC24B")
            cv.drawText(it + if (tagOk) "" else " !", cx, context.pxf(83f), tg)
        }
        if (badge) {
            val bx = cx + r * 0.8f
            val by = cy - r * 0.8f
            val br = context.pxf(7f)
            bd.style = Paint.Style.FILL
            bd.color = Wet.mix(Color.parseColor("#0A1C30"), Hud.cyan, lit)
            cv.drawCircle(bx, by, br, bd)
            bd.style = Paint.Style.STROKE
            bd.strokeWidth = context.pxf(1f)
            bd.color = Hud.cyan
            cv.drawCircle(bx, by, br, bd)
            bd.style = Paint.Style.FILL
            bd.textAlign = Paint.Align.CENTER
            bd.textSize = context.pxf(9f)
            bd.typeface = Typeface.DEFAULT_BOLD
            bd.color = Wet.mix(Hud.cyan, Color.parseColor("#04141F"), lit)
            cv.drawText(if (on) "✓" else "+", bx, by - (bd.ascent() + bd.descent()) / 2f, bd)
        }
        // terus menggambar hanya saat ada animasi
        if (on || lit > 0.02f || press > 0.02f) postInvalidateOnAnimation()
    }
}
