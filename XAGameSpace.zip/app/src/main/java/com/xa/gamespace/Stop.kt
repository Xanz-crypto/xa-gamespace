package com.xa.gamespace

import android.app.ActivityManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

// Sheet "Stop App" di Game Panel: pilih manual aplikasi latar (pengguna / sistem) yang mau dihentikan
class StopSheet(private val ctx: Context, private val keep: String?, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val list = LinearLayout(ctx)
    private val summary = TextView(ctx)
    private val result = TextView(ctx)
    private var apps: List<RunApp> = emptyList()

    private fun px(v: Int) = ctx.px(v)

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun btn(t: String, primary: Boolean = false, click: () -> Unit): TextView {
        val v = tv(t, 11f, if (primary) Color.parseColor("#04141F") else Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.setPadding(px(12), px(7), px(12), px(7))
        v.background = if (primary) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(16f), 1f)
        else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(60, 255, 255, 255), ctx.pxf(16f), 1f)
        v.setOnClickListener { Sfx.tap(); click() }
        return v
    }

    private fun availMb(): Long {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.availMem / 1048576
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        root.setPadding(px(12), px(10), px(12), px(10))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("STOP APP LATAR BELAKANG", 12f, Hud.cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        val x = tv("✕", 16f)
        x.setPadding(px(10), px(2), px(4), px(2))
        x.setOnClickListener { Sfx.tap(); onClose() }
        head.addView(x)
        root.addView(head)

        root.addView(tv(
            "PENGGUNA = aplikasi yang kamu pasang, aman dihentikan dan dipilih otomatis.\n" +
                "SISTEM = aplikasi bawaan non-inti, tidak dipilih otomatis; centang bila yakin.\n" +
                "Aplikasi inti (SystemUI, telepon, keyboard, launcher, layanan Google) disembunyikan agar HP tidak error.",
            9.5f, Hud.sub), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(2); it.bottomMargin = px(6) })

        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.addView(btn("Pilih semua") { setAll(true) }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(6) })
        bar.addView(btn("Kosongkan") { setAll(false) }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(6) })
        bar.addView(btn("Segarkan") { load() }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(6) })
        bar.addView(btn("⛔ Hentikan terpilih", true) { stopSelected() })
        root.addView(bar)

        summary.textSize = 10f
        summary.setTextColor(Hud.sub)
        root.addView(summary, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(6); it.bottomMargin = px(4) })

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        result.textSize = 10f
        result.setTextColor(Color.parseColor("#38E8A5"))
        root.addView(result, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(4) })

        load()
    }

    private fun updateSummary() {
        val sel = apps.filter { it.selected }
        summary.text = "${apps.size} aplikasi berjalan · terpilih ${sel.size} (${sel.sumOf { it.memMb }} MB)"
    }

    private fun setAll(v: Boolean) {
        apps.forEach { it.selected = v }
        render()
    }

    private fun load() {
        summary.text = "Memindai aplikasi yang berjalan..."
        list.removeAllViews()
        Thread {
            val r = Boost.scan(ctx, keep)
            r.forEach { it.selected = !it.system }
            root.post { apps = r; render() }
        }.start()
    }

    private fun render() {
        list.removeAllViews()
        updateSummary()
        if (apps.isEmpty()) {
            list.addView(tv("Tidak ada aplikasi latar yang bisa dihentikan.", 11f, Hud.sub))
            return
        }
        for (a in apps) list.addView(rowFor(a))
    }

    private fun rowFor(a: RunApp): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(px(4), px(6), px(4), px(6))
        val c = tv(if (a.selected) "☑" else "☐", 17f, if (a.selected) Hud.cyan else Hud.sub, true)
        r.addView(c, LinearLayout.LayoutParams(px(28), -2))
        val n = tv(a.label, 12f)
        n.maxLines = 1
        n.ellipsize = android.text.TextUtils.TruncateAt.END
        r.addView(n, LinearLayout.LayoutParams(0, -2, 1f))
        val tag = tv(if (a.system) "SISTEM" else "PENGGUNA", 8.5f,
            if (a.system) Color.parseColor("#FFC24B") else Color.parseColor("#38E8A5"), true)
        r.addView(tag, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = px(6); it.rightMargin = px(8) })
        r.addView(tv("${a.memMb} MB", 10.5f, Hud.sub), LinearLayout.LayoutParams(px(58), -2))
        r.setOnClickListener {
            Sfx.tap()
            a.selected = !a.selected
            c.text = if (a.selected) "☑" else "☐"
            c.setTextColor(if (a.selected) Hud.cyan else Hud.sub)
            updateSummary()
        }
        return r
    }

    private fun stopSelected() {
        if (!Access.requires(ctx, "Stop App", false)) return
        val sel = apps.filter { it.selected }
        if (sel.isEmpty()) {
            Toast.makeText(ctx.applicationContext, "Belum ada aplikasi yang dipilih", Toast.LENGTH_SHORT).show()
            return
        }
        result.text = "Menghentikan ${sel.size} aplikasi..."
        Thread {
            val before = availMb()
            Boost.stop(sel.map { it.pkg })
            try { Thread.sleep(800) } catch (e: InterruptedException) {}
            val gain = (availMb() - before).coerceAtLeast(0)
            root.post {
                result.text = "${sel.size} aplikasi dihentikan · RAM kembali sekitar $gain MB"
                load()
            }
        }.start()
    }
}
