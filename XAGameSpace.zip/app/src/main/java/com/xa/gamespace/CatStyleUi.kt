package com.xa.gamespace

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import kotlin.math.min
import kotlin.math.sin

// Pratinjau hidup maskot di layar pengaturan
class MascotPreview(c: Context) : View(c) {
    private val cat = CatDrawer()
    private var time = 0f
    private var anim: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1000
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { time = catNow(); invalidate() }
        anim = a
        a.start()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val size = min(height * 0.86f, context.pxf(130f))
        val ph = time % 5f
        val wave = catSm(ph / 0.25f) * (1f - catSm((ph - 2.4f) / 0.3f))
        val mouth = if (ph in 0.1f..0.5f) sin(Math.PI.toFloat() * (ph - 0.1f) / 0.4f) * 0.8f else 0f
        cat.draw(cv, width / 2f, height * 0.94f, size, time, wave, 0f, mouth)
    }
}

// Pengaturan karakter (kucing / cewek / cowok / berdua) dan warna maskot
class CharacterPanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box = u.vbox()
    private val preview = MascotPreview(a)
    private var hueBar: SeekBar? = null

    init {
        root.addView(preview, u.lp(-1, u.dp(140), b = 6))
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        render()
    }

    private fun chip(label: String, on: Boolean, click: () -> Unit): View {
        val t = u.label(label, 12f, if (on) Color.parseColor("#04141F") else Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(u.dp(12), u.dp(7), u.dp(12), u.dp(7))
        t.background = if (on) u.glass(20, Hud.cyan, Hud.cyan)
        else u.glass(20, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
        t.setOnClickListener { click() }
        return t
    }

    private fun dot(color: Int, on: Boolean, click: () -> Unit): View {
        val t = u.label(if (color == 0) "↺" else "", 14f, Color.parseColor("#3B2A2A"), true)
        t.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(if (color == 0) Color.WHITE else color)
        g.setStroke(u.dp(if (on) 3 else 1), if (on) Hud.cyan else Color.argb(120, 255, 255, 255))
        t.background = g
        t.setOnClickListener { click() }
        return t
    }

    private fun apply(ch: String = CatStyle.character, tint: Int = CatStyle.tint) {
        CatStyle.save(a, ch, tint)
        preview.invalidate()
    }

    private fun render() {
        box.removeAllViews()

        box.addView(u.label("KARAKTER", 11f, Theme.sub, true), u.lp(b = 4))
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        val row = u.hbox()
        for ((v, name) in CatStyle.chars) {
            row.addView(chip(name, v == CatStyle.character) {
                Sfx.tap()
                apply(ch = v)
                render()
            }, u.lp(-2, -2, r = 6))
        }
        hs.addView(row)
        box.addView(hs, u.lp(b = 12))

        val forHuman = CatStyle.character != CatStyle.CAT
        box.addView(u.label(if (forHuman) "WARNA BAJU" else "WARNA KUCING", 11f, Theme.sub, true), u.lp(b = 4))
        val hs2 = HorizontalScrollView(a)
        hs2.isHorizontalScrollBarEnabled = false
        val dots = u.hbox()
        for ((c, _) in CatStyle.presets) {
            dots.addView(dot(c, c == CatStyle.tint) {
                Sfx.tap()
                apply(tint = c)
                render()
            }, u.lp(u.dp(34), u.dp(34), r = 8))
        }
        hs2.addView(dots)
        box.addView(hs2, u.lp(b = 10))

        box.addView(u.label("WARNA BEBAS (GESER)", 11f, Theme.sub, true), u.lp(b = 2))
        val bar = SeekBar(a)
        bar.max = 359
        val cur = CatStyle.tint
        if (cur != 0) {
            val hsv = FloatArray(3)
            Color.colorToHSV(cur, hsv)
            bar.progress = hsv[0].toInt().coerceIn(0, 359)
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) apply(tint = CatStyle.fromHue(p.toFloat()))
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { Sfx.tap(); render() }
        })
        hueBar = bar
        box.addView(bar, u.lp(b = 10))

        box.addView(u.btn("▶  Putar animasi pembuka", true) { a.replayIntro() }, u.lp(b = 8))

        box.addView(u.label(
            "Karakter dan warna dipakai di animasi pembuka, logo panel, dan animasi masuk game. " +
            "Cewek, cowok, dan berdua adalah karakter orisinal buatan aplikasi ini.", 10f, Theme.sub))
    }
}
