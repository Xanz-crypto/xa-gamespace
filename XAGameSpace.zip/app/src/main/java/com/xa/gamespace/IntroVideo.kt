package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.VideoView

// Video intro saat game dibuka: res/raw/xa_intro.mp4 (sudah termasuk suara).
// Selesai diputar (atau gagal) -> onEnd dipanggil supaya handle panel tetap muncul.
class IntroVideo(c: Context, private val onEnd: () -> Unit) : FrameLayout(c) {
    private var done = false

    private fun finish() {
        if (done) return
        done = true
        onEnd()
    }

    init {
        setBackgroundColor(Color.BLACK)
        val vv = VideoView(c)
        addView(vv, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.CENTER))
        val res = c.resources.getIdentifier("xa_intro", "raw", c.packageName)
        if (res == 0) {
            postDelayed({ finish() }, 0)
        } else {
            vv.setOnCompletionListener { finish() }
            vv.setOnErrorListener { _, _, _ -> finish(); true }
            vv.setVideoURI(Uri.parse("android.resource://${c.packageName}/$res"))
            vv.start()
        }
    }
}
