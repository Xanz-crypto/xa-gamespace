package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

// Pengaturan tampilan maskot: karakter (kucing / cewek / cowok / berdua) dan warnanya.
object CatStyle {
    const val CAT = "cat"
    const val GIRL = "girl"
    const val BOY = "boy"
    const val DUO = "duo"

    val chars = listOf(CAT to "Kucing", GIRL to "Cewek", BOY to "Cowok", DUO to "Berdua")

    // warna 0 = warna asli karakter
    val presets: List<Pair<Int, String>> = listOf(
        0 to "Asli",
        Color.parseColor("#FFB36B") to "Oranye",
        Color.parseColor("#4A4A55") to "Hitam",
        Color.parseColor("#B9BCC6") to "Abu-abu",
        Color.parseColor("#C58B5A") to "Cokelat",
        Color.parseColor("#F3DDB0") to "Krem",
        Color.parseColor("#8EC5FF") to "Biru",
        Color.parseColor("#C4A2FF") to "Ungu",
        Color.parseColor("#FF9EC0") to "Pink",
        Color.parseColor("#9EE3B0") to "Hijau"
    )

    @Volatile var character: String = CAT
    @Volatile var tint: Int = 0

    private fun prefs(c: Context) =
        c.applicationContext.getSharedPreferences("xa_cat_style", Context.MODE_PRIVATE)

    // dibaca ulang tiap dipanggil (murah), supaya overlay game selalu memakai pilihan terbaru
    fun init(c: Context) {
        val p = prefs(c)
        character = p.getString("char", CAT) ?: CAT
        if (chars.none { it.first == character }) character = CAT
        tint = p.getInt("tint", 0)
    }

    fun save(c: Context, ch: String = character, t: Int = tint) {
        character = ch
        tint = t
        prefs(c).edit().putString("char", ch).putInt("tint", t).apply()
    }

    // setengah lebar maskot (satuan: tinggi maskot), dipakai animasi mengintip di tepi layar
    fun halfWidth(): Float = if (character == DUO) 0.55f else 0.31f

    fun mix(a: Int, b: Int, m: Float): Int {
        val k = m.coerceIn(0f, 1f)
        return Color.argb(
            255,
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    fun fromHue(h: Float): Int = Color.HSVToColor(floatArrayOf(h.coerceIn(0f, 359f), 0.55f, 1f))
}

// Fasad: semua tempat yang menggambar maskot cukup memakai CatDrawer; karakter mengikuti pilihan pengguna.
class CatDrawer {
    private val cat = CatBodyDrawer()
    private val girl = ChibiDrawer(false)
    private val boy = ChibiDrawer(true)

    fun draw(cv: Canvas, x: Float, base: Float, size: Float, time: Float,
             wave: Float, lick: Float, mouth: Float,
             sx: Float = 1f, sy: Float = 1f, rot: Float = 0f,
             walk: Float = 0f, step: Float = 0f) {
        val tint = CatStyle.tint
        when (CatStyle.character) {
            CatStyle.GIRL -> girl.draw(cv, x, base, size, time, wave, lick, mouth, sx, sy, rot, walk, step, tint)
            CatStyle.BOY -> boy.draw(cv, x, base, size, time, wave, lick, mouth, sx, sy, rot, walk, step, tint)
            CatStyle.DUO -> {
                val s = size * 0.86f
                val off = size * 0.27f
                girl.draw(cv, x - off, base, s, time, wave, lick, mouth, sx, sy, rot, walk, step, tint)
                boy.draw(cv, x + off, base, s, time + 0.7f, wave, lick, mouth, sx, sy, rot, walk, step + 1.3f, tint)
            }
            else -> {
                cat.setTint(tint)
                cat.draw(cv, x, base, size, time, wave, lick, mouth, sx, sy, rot, walk, step)
            }
        }
    }
}

// Karakter manusia chibi (orisinal, digambar dengan Canvas). Titik acuan = telapak kaki, tinggi = size.
internal class ChibiDrawer(private val boy: Boolean) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val rect = RectF()

    private val OUT = Color.parseColor("#7A5048")
    private val SKIN = Color.parseColor("#FFE2CC")
    private val EYE = Color.parseColor("#3B2622")
    private val HAIR = Color.parseColor(if (boy) "#2F2A33" else "#7A4B3A")
    private val HAIR_OUT = CatStyle.mix(HAIR, Color.BLACK, 0.35f)
    private val PANTS = Color.parseColor(if (boy) "#3A3F55" else "#4A4E7A")
    private val DEF_OUTFIT = Color.parseColor(if (boy) "#7CC4FF" else "#FF9EB5")

    private fun oval(cv: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int, outline: Int = OUT, w: Float = 2.2f) {
        rect.set(l, t, r, b)
        fill.color = color
        cv.drawOval(rect, fill)
        if (w > 0f) { line.color = outline; line.strokeWidth = w; cv.drawOval(rect, line) }
    }

    private fun rrect(cv: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int, outline: Int = OUT, w: Float = 2.2f) {
        rect.set(l, t, r, b)
        fill.color = color
        cv.drawRoundRect(rect, rad, rad, fill)
        if (w > 0f) { line.color = outline; line.strokeWidth = w; cv.drawRoundRect(rect, rad, rad, line) }
    }

    private fun fillPath(cv: Canvas, color: Int, outline: Int, w: Float = 2.2f) {
        fill.color = color
        cv.drawPath(path, fill)
        if (w > 0f) { line.color = outline; line.strokeWidth = w; cv.drawPath(path, line) }
    }

    private fun sleeve(cv: Canvas, color: Int, x0: Float, y0: Float, x1: Float, y1: Float) {
        line.color = OUT; line.strokeWidth = 10.5f; cv.drawLine(x0, y0, x1, y1, line)
        line.color = color; line.strokeWidth = 7.2f; cv.drawLine(x0, y0, x1, y1, line)
    }

    private fun eye(cv: Canvas, ex: Float, happy: Float, blink: Boolean) {
        if (happy > 0.5f || blink) {
            path.reset()
            path.moveTo(ex - 5f, -63f)
            path.quadTo(ex, if (blink) -64f else -70f, ex + 5f, -63f)
            line.color = EYE; line.strokeWidth = 2.6f
            cv.drawPath(path, line)
        } else {
            oval(cv, ex - 4.8f, -71f, ex + 4.8f, -58f, EYE, EYE, 0f)
            oval(cv, ex - 3.4f, -69.6f, ex - 0.2f, -66.4f, Color.WHITE, Color.WHITE, 0f)
            oval(cv, ex + 0.8f, -63.4f, ex + 2.8f, -61.4f, Color.WHITE, Color.WHITE, 0f)
        }
    }

    fun draw(cv: Canvas, x: Float, base: Float, size: Float, time: Float,
             wave: Float, lick: Float, mouth: Float,
             sx: Float, sy: Float, rot: Float,
             walk: Float, step: Float, tint: Int) {
        if (size <= 1f) return
        val outfit = if (tint != 0) tint else DEF_OUTFIT
        val outfitDark = CatStyle.mix(outfit, Color.BLACK, 0.22f)
        val sw = sin(step) * walk
        val u = size / 100f * 0.93f
        cv.save()
        cv.translate(x, base)
        cv.rotate(rot, 0f, -size * 0.35f)
        cv.scale(sx, sy)
        cv.scale(1f, 1f + 0.015f * sin(time * 3.1f))
        cv.scale(u, u)
        if (walk > 0f) {
            cv.translate(0f, -abs(sin(step)) * 5f * walk)
            cv.rotate(sw * 5f, 0f, 0f)
        }

        // kaki + sepatu
        val liftL = max(0f, sw) * 7f
        val liftR = max(0f, -sw) * 7f
        val legColor = if (boy) PANTS else SKIN
        rrect(cv, -12.5f, -24f - liftL, -3f, -5f - liftL, 4f, legColor)
        rrect(cv, 3f, -24f - liftR, 12.5f, -5f - liftR, 4f, legColor)
        oval(cv, -16f, -9f - liftL, -1f, 0f - liftL, Color.WHITE)
        oval(cv, 1f, -9f - liftR, 16f, 0f - liftR, Color.WHITE)
        if (!boy) {
            // rok
            path.reset()
            path.moveTo(-17f, -26f); path.lineTo(17f, -26f); path.lineTo(23f, -13f)
            path.quadTo(0f, -9f, -23f, -13f); path.close()
            fillPath(cv, PANTS, OUT)
        }

        // badan: hoodie
        rrect(cv, -17f, -49f, 17f, -17f, 10f, outfit)
        rrect(cv, -9f, -32f, 9f, -22f, 4f, outfitDark, outfitDark, 0f)
        line.color = Color.WHITE; line.strokeWidth = 1.6f
        cv.drawLine(-4.5f, -47f, -4.5f, -39f, line)
        cv.drawLine(4.5f, -47f, 4.5f, -39f, line)

        // tangan kiri (diam / mengayun saat jalan)
        val al = -sw * 5f
        sleeve(cv, outfit, -15f, -43f, -21f + al, -26f)
        oval(cv, -25.5f + al, -29f, -16.5f + al, -20f, SKIN)

        // kepala (sedikit miring)
        cv.save()
        cv.rotate(4f * sin(time * 2f) + 6f * lick + sw * 3f, 0f, -45f)
        if (!boy) {
            // rambut belakang + dua cepol
            oval(cv, -35f, -99f, 35f, -42f, HAIR, HAIR_OUT)
            oval(cv, -36f, -106f, -18f, -88f, HAIR, HAIR_OUT)
            oval(cv, 18f, -106f, 36f, -88f, HAIR, HAIR_OUT)
        }
        // wajah
        oval(cv, -30f, -95f, 30f, -41f, SKIN)
        // rambut depan
        path.reset()
        if (boy) {
            path.moveTo(-31f, -64f); path.lineTo(-36f, -84f); path.lineTo(-26f, -86f)
            path.lineTo(-27f, -103f); path.lineTo(-14f, -95f); path.lineTo(-8f, -110f)
            path.lineTo(0f, -97f); path.lineTo(9f, -109f); path.lineTo(14f, -96f)
            path.lineTo(27f, -104f); path.lineTo(26f, -86f); path.lineTo(36f, -84f)
            path.lineTo(31f, -64f); path.lineTo(25f, -77f); path.lineTo(15f, -72f)
            path.lineTo(9f, -84f); path.lineTo(0f, -73f); path.lineTo(-8f, -85f)
            path.lineTo(-15f, -72f); path.lineTo(-25f, -78f); path.close()
        } else {
            path.moveTo(-31f, -64f)
            path.cubicTo(-38f, -108f, 38f, -108f, 31f, -64f)
            path.quadTo(28f, -80f, 16f, -85f)
            path.quadTo(9f, -74f, 0f, -82f)
            path.quadTo(-9f, -74f, -16f, -85f)
            path.quadTo(-28f, -80f, -31f, -64f)
            path.close()
        }
        fillPath(cv, HAIR, HAIR_OUT)
        if (!boy) {
            // jepit rambut mengikuti warna pilihan
            oval(cv, 14f, -92f, 21f, -86f, outfit, OUT, 1.2f)
        }
        // mata
        val happy = max(lick, if (wave > 0.5f) 0.7f else 0f)
        val blink = (time % 3.4f) < 0.14f
        eye(cv, -11f, happy, blink)
        eye(cv, 11f, happy, blink)
        // pipi merona
        fill.color = Color.argb(150, 255, 140, 150)
        rect.set(-27f, -57f, -16f, -50f); cv.drawOval(rect, fill)
        rect.set(16f, -57f, 27f, -50f); cv.drawOval(rect, fill)
        // mulut
        if (mouth > 0.05f) {
            oval(cv, -3.6f, -52f, 3.6f, -50f + 7f * mouth, Color.parseColor("#7A1F2B"), OUT, 0f)
            oval(cv, -2.2f, -48f + 3f * mouth, 2.2f, -46.5f + 4.5f * mouth, Color.parseColor("#FF9AA8"), OUT, 0f)
        } else {
            path.reset()
            path.moveTo(-4.5f, -53f); path.quadTo(0f, -48.5f, 4.5f, -53f)
            line.color = OUT; line.strokeWidth = 1.8f; cv.drawPath(path, line)
        }
        cv.restore()

        // tangan kanan: melambai
        var th = catMix(-6f + sw * 14f, -150f + 24f * sin(time * 9.5f), wave)
        th = catMix(th, 140f + 7f * sin(time * 11f), lick)
        val len = catMix(22f, 17f, lick)
        cv.save()
        cv.translate(15f, -43f)
        cv.rotate(th)
        sleeve(cv, outfit, 0f, 0f, 0f, len)
        oval(cv, -4.5f, len - 3f, 4.5f, len + 5.5f, SKIN)
        cv.restore()

        cv.restore()
    }
}
