package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// =====================================================================
//  Touch Optimizer + Touch Smooth
//  - Touch Optimizer : respons sentuhan lebih cepat (touch panel mode game, input boost CPU, long-press cepat)
//  - Touch Smooth    : animasi sistem dipercepat supaya geser/scroll terasa licin, tidak patah-patah
//  Semua nilai asli disimpan dulu (snapshot) dan dikembalikan saat boost dimatikan / tombol Reset.
//  Jalur kernel hanya ditulis bila ada di HP dan bisa ditulis (khusus root); yang tidak ada dilewati.
// =====================================================================
object TouchOpt {
    private const val KEY = "snap_touch"

    // jalur touch panel (mode game / sampling) -> nilai aktif
    private val PANEL = listOf(
        "/proc/touchpanel/game_switch_enable" to "1",
        "/sys/devices/virtual/touch/touch_dev/bump_sample_rate" to "1",
        "/sys/class/touch/touch_dev/bump_sample_rate" to "1"
    )

    // input boost: CPU dinaikkan sesaat setiap ada sentuhan (milidetik)
    private val BOOST = listOf(
        "/sys/module/cpu_boost/parameters/input_boost_ms" to "120",
        "/sys/devices/system/cpu/cpu_boost/input_boost_ms" to "120",
        "/sys/module/cpu_input_boost/parameters/input_boost_duration" to "120",
        "/sys/module/msm_performance/parameters/touchboost" to "1"
    )

    private val FILES = PANEL + BOOST
    private val FILE_SET = FILES.map { it.first }.toSet()

    private val GLOBAL_KEYS = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
    private val SECURE_KEYS = listOf("long_press_timeout", "multi_press_timeout")
    private val SET_KEYS = GLOBAL_KEYS.map { "global|$it" } + SECURE_KEYS.map { "secure|$it" }

    private val NUM = Regex("^[0-9.]+$")
    private val INT = Regex("^[0-9]+$")

    private fun snapScript(): String {
        val sb = StringBuilder()
        for (k in GLOBAL_KEYS) sb.append("echo \"S|global|$k|§(settings get global $k)\"\n")
        for (k in SECURE_KEYS) sb.append("echo \"S|secure|$k|§(settings get secure $k)\"\n")
        for ((p, _) in FILES) sb.append("[ -w $p ] && echo \"F|$p|§(head -n 1 $p 2>/dev/null)\"\n")
        return sb.toString().replace('§', '$')
    }

    // Terapkan. Mengembalikan laporan singkat apa yang aktif.
    fun apply(ctx: Context, boost: Boolean, smooth: Boolean, anim: Float): String {
        val s = Store(ctx)
        if (s.get(KEY).isBlank()) {
            val snap = Access.run(snapScript())
            if (snap.lines().any { it.startsWith("S|") || it.startsWith("F|") }) s.put(KEY, snap)
        }
        val c = ArrayList<String>()
        if (boost) {
            c.add("settings put secure long_press_timeout 250")
            c.add("settings put secure multi_press_timeout 250")
            for ((p, v) in FILES) c.add("[ -w $p ] && echo $v > $p")
        }
        if (smooth) {
            val a = anim.coerceIn(0.2f, 1f).toString()
            for (k in GLOBAL_KEYS) c.add("settings put global $k $a")
        }
        if (c.isNotEmpty()) Access.run(c.joinToString("\n"))

        val found = s.get(KEY).lines().filter { it.startsWith("F|") }.map { it.split("|").getOrElse(1) { "" } }
        val panel = found.filter { p -> PANEL.any { it.first == p } }.map { it.substringAfterLast('/') }
        val boosts = found.filter { p -> BOOST.any { it.first == p } }.map { it.substringAfterLast('/') }
        val out = StringBuilder()
        if (boost) {
            out.append("Touch Optimizer aktif.\n")
            out.append("• Respons tekan-tahan dipercepat\n")
            out.append("• Touch panel: ").append(if (panel.isEmpty()) "tidak ada jalur di HP ini / butuh root" else panel.joinToString()).append("\n")
            out.append("• Input boost CPU: ").append(if (boosts.isEmpty()) "tidak ada jalur di HP ini / butuh root" else boosts.joinToString()).append("\n")
        }
        if (smooth) out.append("Touch Smooth aktif: animasi sistem ${anim}x (lebih cepat = lebih licin).\n")
        if (!boost && !smooth) out.append("Tidak ada fitur touch yang dinyalakan.")
        return out.toString().trim()
    }

    // Kembalikan semua nilai asli.
    fun restore(ctx: Context): String {
        val s = Store(ctx)
        val snap = s.get(KEY)
        if (snap.isBlank()) return "Tidak ada yang perlu dikembalikan."
        val c = ArrayList<String>()
        for (l in snap.lines()) {
            val p = l.trim().split("|")
            if (p.size >= 4 && p[0] == "S" && "${p[1]}|${p[2]}" in SET_KEYS) {
                val v = p[3]
                if (v.isBlank() || v == "null") c.add("settings delete ${p[1]} ${p[2]}")
                else if (NUM.matches(v)) c.add("settings put ${p[1]} ${p[2]} $v")
            } else if (p.size >= 3 && p[0] == "F" && p[1] in FILE_SET && INT.matches(p[2])) {
                c.add("[ -w ${p[1]} ] && echo ${p[2]} > ${p[1]}")
            }
        }
        if (c.isNotEmpty()) Access.run(c.joinToString("\n"))
        s.put(KEY, "")
        return "Touch dikembalikan ke bawaan HP."
    }

    // Info jalur touch yang ada di HP ini (untuk ditampilkan).
    fun detect(): String {
        val sb = StringBuilder()
        for ((p, _) in FILES) sb.append("[ -e $p ] && { [ -w $p ] && echo \"W|$p\" || echo \"R|$p\"; }\n")
        sb.append("echo \"D1|§(ls /proc/touchpanel 2>/dev/null | head -n 24 | tr '\\n' ' ')\"\n")
        sb.append("echo \"D2|§(ls /sys/devices/virtual/touch/touch_dev 2>/dev/null | head -n 24 | tr '\\n' ' ')\"\n")
        val o = Access.run(sb.toString().replace('§', '$'))
        val w = o.lines().count { it.startsWith("W|") }
        val r = o.lines().count { it.startsWith("R|") }
        val d1 = o.lines().firstOrNull { it.startsWith("D1|") }?.removePrefix("D1|")?.trim().orEmpty()
        val d2 = o.lines().firstOrNull { it.startsWith("D2|") }?.removePrefix("D2|")?.trim().orEmpty()
        val res = StringBuilder()
        res.append("Jalur kernel yang cocok: $w bisa ditulis")
        if (r > 0) res.append(", $r hanya baca")
        res.append(".")
        if (d1.isNotEmpty()) res.append("\n/proc/touchpanel: ").append(d1.take(160))
        if (d2.isNotEmpty()) res.append("\ntouch_dev: ").append(d2.take(160))
        return res.toString()
    }
}

// Sheet Touch Optimizer (dipakai di Game Panel dan menu utama)
class TouchSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val box = LinearLayout(ctx)
    private val result = TextView(ctx)
    private val info = TextView(ctx)
    private val animRow = LinearLayout(ctx)
    private val store = Store(ctx)

    private fun px(v: Int) = ctx.px(v)

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun btn(t: String, primary: Boolean = false, on: Boolean = false, click: () -> Unit): TextView {
        val hi = primary || on
        val v = tv(t, 11f, if (hi) Color.parseColor("#04141F") else Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.setPadding(px(12), px(7), px(12), px(7))
        v.background = if (hi) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(16f), 1f)
        else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(60, 255, 255, 255), ctx.pxf(16f), 1f)
        v.setOnClickListener { Sfx.tap(); click() }
        return v
    }

    private fun section(title: String, desc: String, tag: String, pill: Pill?) {
        val h = LinearLayout(ctx)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.addView(tv(title, 12f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        h.addView(tv(tag, 9f, Color.parseColor("#FFC24B"), true).also { it.setPadding(0, 0, px(8), 0) })
        if (pill != null) h.addView(pill)
        box.addView(h, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(10) })
        box.addView(tv(desc, 10f, Hud.sub), LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(5) })
    }

    private fun renderAnim() {
        animRow.removeAllViews()
        val opts = listOf("Normal" to 1.0f, "Halus" to 0.7f, "Licin" to 0.5f, "Super" to 0.3f)
        for ((name, v) in opts) {
            animRow.addView(btn(name, on = store.touchAnim == v) {
                store.touchAnim = v
                renderAnim()
            }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(6) })
        }
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        root.setPadding(px(12), px(10), px(12), px(10))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("TOUCH OPTIMIZER", 12f, Hud.cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        val x = tv("✕", 16f)
        x.setPadding(px(10), px(2), px(4), px(2))
        x.setOnClickListener { Sfx.tap(); onClose() }
        head.addView(x)
        root.addView(head)

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        box.orientation = LinearLayout.VERTICAL
        sv.addView(box)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val pOpt = Pill(ctx)
        pOpt.setOn(store.touch)
        pOpt.onToggle = { v -> store.touch = v; reapplyIfActive() }
        section("Touch Optimizer",
            "Sentuhan lebih responsif: mode game touch panel, input boost CPU saat layar disentuh, dan tekan-tahan lebih cepat. " +
                "Otomatis aktif saat game dibuka dan dikembalikan saat selesai.", "ROOT/SHIZUKU", pOpt)

        val pSm = Pill(ctx)
        pSm.setOn(store.touchSmooth)
        pSm.onToggle = { v -> store.touchSmooth = v; reapplyIfActive() }
        section("Touch Smooth",
            "Geser dan scroll jadi licin, tidak patah-patah: animasi sistem dipercepat. " +
                "Untuk hasil terbaik nyalakan juga Smooth FPS (kunci refresh rate) dan Stabil FPS (clock tidak naik-turun).",
            "ROOT/SHIZUKU", pSm)
        animRow.orientation = LinearLayout.HORIZONTAL
        renderAnim()
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(animRow)
        box.addView(hs)

        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.addView(btn("Terapkan sekarang", primary = true) { applyNow() },
            LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(8) })
        bar.addView(btn("Reset ke bawaan") { resetNow() })
        box.addView(bar, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(14) })

        result.textSize = 10f
        result.setTextColor(Color.parseColor("#38E8A5"))
        box.addView(result, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })

        info.textSize = 9.5f
        info.setTextColor(Hud.sub)
        info.text = "Memeriksa jalur touch di HP ini..."
        box.addView(info, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(10) })
        Thread {
            Access.ensure()
            val d = if (Access.hasAny()) TouchOpt.detect() else "Aktifkan root/Shizuku untuk memeriksa jalur touch."
            root.post { info.text = d }
        }.start()
    }

    // bila boost sedang aktif, langsung terapkan perubahan toggle
    private fun reapplyIfActive() {
        if (store.active) Thread { Boost.refresh(ctx) }.start()
    }

    private fun applyNow() {
        if (!Access.requires(ctx, "Touch Optimizer", false)) return
        result.setTextColor(Hud.sub)
        result.text = "Menerapkan..."
        Thread {
            TouchOpt.restore(ctx)
            val r = TouchOpt.apply(ctx, store.touch, store.touchSmooth, store.touchAnim)
            root.post { result.setTextColor(Color.parseColor("#38E8A5")); result.text = r }
        }.start()
    }

    private fun resetNow() {
        if (!Access.requires(ctx, "Touch Optimizer", false)) return
        Thread {
            val r = TouchOpt.restore(ctx)
            root.post { result.setTextColor(Color.parseColor("#38E8A5")); result.text = r }
        }.start()
    }
}
