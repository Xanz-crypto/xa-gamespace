package com.xa.gamespace

import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class GamePage(private val a: MainActivity) : Page {
    private val u = a.ui
    private val st = a.store
    private var built = false
    private lateinit var grid: LinearLayout
    private lateinit var tTemp: TextView
    private lateinit var tCpu: TextView
    private lateinit var tPing: TextView
    private lateinit var tFps: TextView
    private lateinit var tBatt: TextView
    private lateinit var playBtn: TextView

    override fun build(): View {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        val col = u.vbox()
        col.setPadding(u.dp(16), u.dp(22), u.dp(16), u.dp(24))
        sv.addView(col)

        col.addView(u.label("Pilih Game", 24f, Theme.text, true))
        col.addView(u.label("Ketuk kartu untuk memilih. Ketuk label MODE untuk ganti profil boost.", 12f, Theme.sub), u.lp(b = 14))

        grid = u.vbox()
        col.addView(grid)
        col.addView(u.ghostBtn("＋  Tambah atau kelola game") { a.pickGames { render() } }, u.lp(b = 12))

        val bar = u.card()
        bar.addView(u.label("MONITOR GAME", 10f, Theme.sub, true), u.lp(b = 8))
        val (a1, v1) = u.tile("SUHU", "-", Theme.text, true); tTemp = v1
        val (a2, v2) = u.tile("CPU", "-", Theme.text, true); tCpu = v2
        val (a3, v3) = u.tile("PING", "-", Theme.text, true); tPing = v3
        val (a4, v4) = u.tile("FPS", "-", Theme.text, true); tFps = v4
        val (a5, v5) = u.tile("BATERAI", "-", Theme.text, true); tBatt = v5
        bar.addView(u.row(a1, a2, a3, a4, a5))
        col.addView(bar)

        playBtn = u.gradBtn("▶  Main") { a.selectedGame()?.let { a.play(it) } }
        col.addView(playBtn, u.lp(b = 10))
        col.addView(u.ghostBtn("🎮  Buka Game Space (landscape)") { a.openSpace() })

        built = true
        render()
        return sv
    }

    fun render() {
        if (!built) return
        grid.removeAllViews()
        val games = st.games.toList().sortedBy { u.appLabel(it).lowercase() }
        if (games.isEmpty()) {
            grid.addView(u.label("Belum ada game. Tekan tombol Tambah di bawah.", 13f, Theme.sub), u.lp(b = 12))
        }
        val sel = a.selectedGame()
        val h = u.dp(150)
        games.chunked(2).forEach { pair ->
            val row = u.hbox()
            pair.forEachIndexed { i, pkg ->
                val card = u.gameCard(pkg, pkg == sel, st.gameMode(pkg), 0, h,
                    { st.selected = pkg; render() },
                    {
                        val cur = Boost.MODES.indexOf(st.gameMode(pkg))
                        st.setGameMode(pkg, Boost.MODES[(cur + 1) % Boost.MODES.size])
                        render()
                    })
                card.layoutParams = u.lp(0, h, 1f, l = if (i == 0) 0 else 10, b = 10)
                row.addView(card)
            }
            if (pair.size == 1) row.addView(View(a), u.lp(0, h, 1f, l = 10, b = 10))
            grid.addView(row)
        }
        playBtn.text = sel?.let { "▶  Main  " + u.appLabel(it) } ?: "▶  Pilih game dulu"
    }

    override fun update(s: Snap) {
        if (!built) return
        tTemp.text = String.format("%.0f°C", s.temp)
        tCpu.text = "${s.cpu}%"
        tPing.text = if (s.ping >= 0) "${s.ping}ms" else "-"
        tFps.text = if (s.fps > 0) "${s.fps}" else "-"
        tBatt.text = "${s.batt}%"
    }
}
