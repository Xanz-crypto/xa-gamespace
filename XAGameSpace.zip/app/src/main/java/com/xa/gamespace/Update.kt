package com.xa.gamespace

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// Cek update lewat file version.json di repo GitHub (dibaca publik)
object Update {
    const val URL_JSON = "https://raw.githubusercontent.com/Xanz-kripto/xa-gamespace/main/version.json"

    class Info(val latest: Int, val min: Int, val name: String, val link: String, val notes: String)

    fun currentCode(ctx: Context): Int =
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode } catch (e: Exception) { 0 }

    // latest: versi terbaru. min: versi terendah yang masih boleh dipakai.
    fun check(act: Activity, onResult: (Info?, Int) -> Unit) {
        val cur = currentCode(act)
        Thread {
            val info = try {
                val c = URL(URL_JSON).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val body = c.inputStream.bufferedReader().use { it.readText() }
                val j = JSONObject(body)
                Info(j.getInt("latest"), j.getInt("min"), j.optString("name"), j.optString("link"), j.optString("notes"))
            } catch (e: Exception) { null }   // offline: aplikasi tetap bisa dipakai
            Handler(Looper.getMainLooper()).post { onResult(info, cur) }
        }.start()
    }
}
