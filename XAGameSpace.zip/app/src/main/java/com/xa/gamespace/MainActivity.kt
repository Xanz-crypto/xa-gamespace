package com.xa.gamespace

import android.app.Activity
import android.app.AlertDialog
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class Tile(u: Ui, icon: String, title: String, tag: String? = null, tagOk: Boolean = true, click: () -> Unit) {
    val view: LinearLayout = u.vbox()
    private val sub = u.label("", 10f, Theme.sub, true)
    private val ui = u

    init {
        view.gravity = Gravity.CENTER
        view.setPadding(u.dp(6), u.dp(6), u.dp(6), u.dp(10))
        val tg = u.label(tag ?: " ", 8f, if (tagOk) Theme.good else Theme.warn, true)
        tg.gravity = Gravity.END
        view.addView(tg, u.lp(-1, -2))
        val ic = u.label(icon, 22f)
        ic.gravity = Gravity.CENTER
        val t = u.label(title, 12f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        sub.gravity = Gravity.CENTER
        view.addView(ic)
        view.addView(t, u.lp(t = 4))
        view.addView(sub, u.lp(t = 2))
        view.background = u.glass()
        view.setOnClickListener { Sfx.tap(); click() }
    }

    fun text(s: String) { sub.text = s }

    fun set(on: Boolean) {
        sub.text = if (on) "AKTIF" else "MATI"
        sub.setTextColor(if (on) Theme.good else Theme.sub)
        view.background = if (on) ui.glass(16, Color.argb(160, 10, 40, 60), Hud.cyan) else ui.glass()
    }
}

class MainActivity : Activity() {
    lateinit var store: Store
    lateinit var u: Ui
    private lateinit var video: VideoBg
    private lateinit var panelHost: FrameLayout
    private lateinit var carousel: GameCarousel
    private lateinit var ramChip: TextView
    private lateinit var accessChip: TextView
    private lateinit var tempChip: TextView
    private lateinit var esports: TextView
    private lateinit var rootView: FrameLayout
    private lateinit var uiLayer: FrameLayout
    private var opening = false
    private val h = Handler(Looper.getMainLooper())
    private var ticking = false
    private var splashDone = false
    private var pendingOverlay = false

    private val shizukuBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refreshAccess() } }
    private val shizukuResult = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refreshAccess() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        u = Ui(this)
        Sfx.init(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val root = FrameLayout(this)
        rootView = root
        root.setBackgroundColor(Color.BLACK)
        video = VideoBg(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1))

        val shade = View(this)
        shade.setBackgroundColor(Color.argb(150, 3, 5, 12))
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))

        // seluruh isi beranda ada di uiLayer: tersembunyi saat intro, muncul setelah tombol OPEN GAME SPACE ditekan
        val content = FrameLayout(this)
        uiLayer = content
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        carousel = GameCarousel(this)
        carousel.info = { "Siap boost · ${Access.mode.name}" }
        carousel.onStart = { g -> play(g.pkg) }
        carousel.onSelect = { g -> store.put("last_game", g.pkg) }
        content.addView(carousel, FrameLayout.LayoutParams(-1, -1))

        content.addView(buildTop(), FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        buildBottom(content)

        // efek basah: tetesan air, kilau cahaya, dan cahaya tepi yang berganti warna
        content.addView(WetGlowView(this, 24, true, 1f), FrameLayout.LayoutParams(-1, -1))

        panelHost = FrameLayout(this)
        panelHost.visibility = View.GONE
        content.addView(panelHost, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)
        startIntro()

        renderGames()
        refreshTags()

        try {
            Shizuku.addBinderReceivedListenerSticky(shizukuBinder)
            Shizuku.addRequestPermissionResultListener(shizukuResult)
        } catch (t: Throwable) {}

        Thread {
            val ok = Access.checkRoot()
            if (ok) Root.run("appops set $packageName SYSTEM_ALERT_WINDOW allow")
            if (ok && !store.active && store.get("cpu_default").isBlank()) {
                store.put("cpu_default", Cpu.serialize(Cpu.read()))
            }
            runOnUiThread {
                refreshAccess()
                if (!ok) {
                    if (Access.shizukuGranted()) {
                        toast("Mode Shizuku aktif. Fitur khusus root dinonaktifkan.")
                    } else if (Access.shizukuRunning()) {
                        Access.requestShizuku(100)
                    } else {
                        toast("Root & Shizuku belum aktif. Ketuk chip AKSES di atas untuk mengatur.")
                    }
                }
                if (splashDone) ensureOverlay() else pendingOverlay = true
            }
        }.start()

        if (store.auto || store.active) GameService.start(this)
    }

    private var splashView: View? = null

    // Intro: layar neon yang terus bergerak + tombol OPEN GAME SPACE
    private fun startIntro() {
        if (splashView != null) return
        splashDone = false
        opening = false
        uiLayer.alpha = 0f
        val intro = HomeIntro(this) { openHome() }
        splashView = intro
        rootView.addView(intro, FrameLayout.LayoutParams(-1, -1))
    }

    // tombol ditekan: intro membesar lalu pudar, beranda muncul dari sedikit membesar ke ukuran normal
    private fun openHome() {
        val intro = splashView ?: return
        if (opening) return
        opening = true
        Sfx.play("open", 0.8f)
        uiLayer.scaleX = 1.07f
        uiLayer.scaleY = 1.07f
        uiLayer.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(650)
            .setInterpolator(DecelerateInterpolator()).start()
        intro.animate().alpha(0f).scaleX(1.2f).scaleY(1.2f).setDuration(650)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction {
                rootView.removeView(intro)
                splashView = null
                splashDone = true
                if (pendingOverlay) { pendingOverlay = false; ensureOverlay() }
            }.start()
    }

    private fun ensureOverlay() {
        if (GameOverlay.canDraw(this)) return
        toast("Izinkan 'Tampil di atas aplikasi lain' agar Game Panel muncul di dalam game")
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {}
    }

    // ---------- tampilan ----------
    private fun buildTop(): View {
        val top = u.hbox()
        top.setPadding(u.dp(24), u.dp(8), u.dp(24), u.dp(4))
        val tb = u.vbox()
        val brand = u.label("XA  GAME  SPACE", 11f, Hud.cyan, true)
        brand.letterSpacing = 0.2f
        tb.addView(brand)
        tb.addView(u.label("Performa maksimal", 18f, Color.WHITE, true))
        top.addView(tb, u.lp(0, -2, 1f))

        accessChip = u.chip("AKSES  …", Theme.sub)
        accessChip.setOnClickListener { Sfx.tap(); showAccessDialog() }
        top.addView(accessChip, u.lp(-2, -2, r = 8))
        tempChip = u.chip("SUHU  -", Color.WHITE)
        top.addView(tempChip, u.lp(-2, -2, r = 8))
        ramChip = u.chip("RAM  -", Color.WHITE)
        top.addView(ramChip, u.lp(-2, -2, r = 12))
        val clk = TextClock(this)
        clk.format24Hour = "HH:mm"
        clk.format12Hour = "HH:mm"
        clk.textSize = 17f
        clk.setTextColor(Color.WHITE)
        clk.typeface = Typeface.DEFAULT_BOLD
        top.addView(clk, u.lp(-2, -2, r = 12))
        val more = u.label("⋮", 22f, Color.WHITE, true)
        more.setPadding(u.dp(8), 0, u.dp(4), 0)
        more.setOnClickListener { Sfx.tap(); showFeatures() }
        top.addView(more)
        return top
    }

    private fun buildBottom(root: FrameLayout) {
        val boost = u.label("▲   HIGH BOOST", 12f, Color.WHITE, true)
        boost.letterSpacing = 0.15f
        boost.gravity = Gravity.CENTER
        boost.setPadding(u.dp(26), u.dp(6), u.dp(26), u.dp(6))
        boost.background = u.glass(14, Color.argb(190, 40, 14, 70), Color.parseColor("#B04CFF"))
        boost.setOnClickListener { Sfx.tap(); showFeatures() }
        val bp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        bp.bottomMargin = u.dp(6)
        root.addView(boost, bp)

        esports = u.label("ESPORTS »", 16f, Color.WHITE, true)
        esports.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        esports.setPadding(u.dp(14), u.dp(6), u.dp(14), u.dp(6))
        esports.setOnClickListener { Sfx.tap(); toggleEsports() }
        val ep = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END)
        ep.bottomMargin = u.dp(26); ep.rightMargin = u.dp(24)
        root.addView(esports, ep)
    }

    private fun refreshTags() {
        carousel.tags = listOf("Stabil FPS" to store.stabil, "Smooth FPS" to store.smooth, "Auto Game" to store.auto)
        val on = store.stabil && store.smooth
        esports.setTextColor(if (on) Hud.cyan else Color.WHITE)
    }

    private fun toggleEsports() {
        val on = !(store.stabil && store.smooth)
        store.smooth = on
        store.stabil = on && Access.isRoot
        if (on && !Access.isRoot) Access.requires(this, "Stabil FPS", true)
        if (on && !Access.hasAny()) Access.requires(this, "Smooth FPS", false)
        toast(if (on) "Mode Esports aktif" else "Mode Esports mati")
        refreshTags()
        reapply()
    }

    fun refreshAccess() {
        val m = Access.mode
        val (txt, col) = when (m) {
            Access.Mode.ROOT -> "ROOT  ✓" to Theme.good
            Access.Mode.SHIZUKU -> "SHIZUKU  ✓" to Theme.warn
            Access.Mode.NONE -> "AKSES  ✗" to Theme.bad
        }
        accessChip.text = txt
        accessChip.setTextColor(col)
        carousel.invalidate()
    }

    private fun showAccessDialog() {
        val root = if (Access.isRoot) "aktif ✓" else "tidak terdeteksi ✗"
        val sh = when {
            Access.shizukuGranted() -> "aktif & diizinkan ✓"
            Access.shizukuRunning() -> "berjalan, izin belum diberikan"
            else -> "belum berjalan / belum terpasang"
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Akses sistem")
            .setMessage("Root: $root\nShizuku: $sh\n\n" +
                "• Khusus ROOT: Stabil FPS, CPU/GPU Tuning, tweak TCP kernel, jalur touch panel.\n" +
                "• ROOT atau SHIZUKU: Smooth FPS, Touch Optimizer/Smooth, Boost Jaringan, Bersihkan RAM, Stop App, Scan App, Auto Game, WiFi/Data/DND.")
            .setPositiveButton("Minta izin root") { _, _ ->
                toast("Menunggu izin root...")
                Thread {
                    val ok = Access.checkRoot()
                    if (ok) Root.run("appops set $packageName SYSTEM_ALERT_WINDOW allow")
                    runOnUiThread { refreshAccess(); toast(if (ok) "Root diizinkan" else "Root ditolak / tidak ada") }
                }.start()
            }
            .setNeutralButton("Izin Shizuku") { _, _ ->
                if (Access.shizukuGranted()) { toast("Shizuku sudah diizinkan"); refreshAccess() }
                else if (Access.shizukuRunning()) Access.requestShizuku(100)
                else {
                    toast("Shizuku belum berjalan. Buka aplikasi Shizuku lalu tekan Start.")
                    try {
                        packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
                    } catch (e: Exception) {}
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun showFeatures() {
        val col = u.vbox()
        col.gravity = Gravity.CENTER

        val tStabil = Tile(u, "🎯", "Stabil FPS", Access.tagFor(true), Access.satisfied(true)) {}
        val tSmooth = Tile(u, "🌊", "Smooth FPS", Access.tagFor(false), Access.satisfied(false)) {}
        val tRam = Tile(u, "🧹", "Bersihkan RAM", Access.tagFor(false), Access.satisfied(false)) {}
        val tAuto = Tile(u, "🤖", "Auto Game", Access.tagFor(false), Access.satisfied(false)) {}
        val tScan = Tile(u, "🔍", "Scan App", Access.tagFor(false), Access.satisfied(false)) {}
        val tCpu = Tile(u, "⚙", "CPU Governor", Access.tagFor(true), Access.satisfied(true)) {}
        val tGame = Tile(u, "🎬", "Game CMD", Access.tagFor(false), Access.satisfied(false)) {}
        val tSnd = Tile(u, "🔊", "Suara") {}
        val tTouch = Tile(u, "👆", "Touch", Access.tagFor(false), Access.satisfied(false)) {}
        val tNet = Tile(u, "📶", "Jaringan", Access.tagFor(false), Access.satisfied(false)) {}
        tTouch.set(store.touch || store.touchSmooth); tNet.text("Wi-Fi · DNS · TCP")
        tTouch.view.setOnClickListener {
            Sfx.tap()
            showPanel("Touch Optimizer", TouchSheet(this) { closePanel() }.root)
        }
        tNet.view.setOnClickListener {
            Sfx.tap()
            showPanel("Optimal Jaringan", NetSheet(this, { showPanel("Scan aplikasi latar belakang", ScanPanel(this).root) }) { closePanel() }.root)
        }
        tGame.text("FPS · Downscale"); tSnd.text("Klik · Mixer")
        tGame.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Game CMD", false)) return@setOnClickListener
            showPanel("Game CMD · mode, downscale, FPS", GameCmdPanel(this).root)
        }
        tSnd.view.setOnClickListener {
            Sfx.tap()
            showPanel("Suara", SoundHub(this).root)
        }

        tStabil.set(store.stabil); tSmooth.set(store.smooth); tAuto.set(store.auto)
        tRam.text("Sekali tap"); tScan.text("User + sistem"); tCpu.text("Lengkap")

        tStabil.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Stabil FPS", true)) return@setOnClickListener
            store.stabil = !store.stabil; tStabil.set(store.stabil); refreshTags(); reapply()
        }
        tSmooth.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Smooth FPS", false)) return@setOnClickListener
            store.smooth = !store.smooth; tSmooth.set(store.smooth); refreshTags(); reapply()
        }
        tRam.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Bersihkan RAM", false)) return@setOnClickListener
            cleanRam(tRam)
        }
        tAuto.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Auto Game", false)) return@setOnClickListener
            store.auto = !store.auto; tAuto.set(store.auto); refreshTags()
            if (store.auto) GameService.start(this)
        }
        tScan.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Scan App", false)) return@setOnClickListener
            showPanel("Scan aplikasi latar belakang", ScanPanel(this).root)
        }
        tCpu.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "CPU Governor", true)) return@setOnClickListener
            showPanel("CPU Governor", CpuPanel(this).root)
        }

        val r1 = u.hbox(); val r2 = u.hbox()
        listOf(tStabil, tSmooth, tTouch, tRam, tAuto).forEachIndexed { i, t -> r1.addView(t.view, u.lp(0, -2, 1f, r = if (i < 4) 8 else 0)) }
        listOf(tScan, tCpu, tGame, tNet, tSnd).forEachIndexed { i, t -> r2.addView(t.view, u.lp(0, -2, 1f, r = if (i < 4) 8 else 0)) }
        col.addView(r1, u.lp(b = 8))
        col.addView(r2)
        showPanel("HIGH BOOST", col)
    }

    private fun reapply() {
        if (store.active) Thread { Boost.refresh(this) }.start()
    }

    private fun cleanRam(t: Tile) {
        toast("Membersihkan RAM...")
        t.text("Memproses...")
        Thread {
            val freed = Boost.cleanRam(this)
            runOnUiThread {
                t.text("+$freed MB")
                toast("RAM dibebaskan $freed MB")
                updateRam()
            }
        }.start()
    }

    fun renderGames() {
        Thread {
            val g = Games.detect(this)
            runOnUiThread { carousel.setItems(g, store.get("last_game")) }
        }.start()
    }

    private fun play(pkg: String) {
        val li = packageManager.getLaunchIntentForPackage(pkg)
        if (li == null) { toast("Game tidak bisa dibuka"); return }
        Thread {
            val ok = Root.available()
            runOnUiThread {
                if (ok) GameService.start(this, pkg) else toast("Tanpa root/Shizuku: game dibuka tanpa boost")
                startActivity(li)
            }
        }.start()
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- Panel ----------
    fun showPanel(title: String, body: View) {
        panelHost.removeAllViews()
        val shade = View(this)
        shade.setBackgroundColor(Color.argb(170, 0, 0, 0))
        shade.setOnClickListener { closePanel() }
        panelHost.addView(shade, FrameLayout.LayoutParams(-1, -1))

        val card = u.vbox()
        card.background = u.glass(20, Color.argb(235, 8, 14, 26), Hud.cyanDim)
        card.setPadding(u.dp(18), u.dp(12), u.dp(18), u.dp(12))
        val head = u.hbox()
        head.addView(u.label(title, 16f, Color.WHITE, true), u.lp(0, -2, 1f))
        val x = u.label("✕", 18f, Color.WHITE, true)
        x.setPadding(u.dp(12), u.dp(4), u.dp(4), u.dp(4))
        x.setOnClickListener { Sfx.tap(); closePanel() }
        head.addView(x)
        card.addView(head, u.lp(b = 8))
        val boostPanel = title == "HIGH BOOST"
        card.addView(body, u.lp(-1, if (boostPanel) -2 else 0, if (boostPanel) 0f else 1f))
        val p = FrameLayout.LayoutParams(-1, -1)
        if (title == "HIGH BOOST") {
            p.setMargins(u.dp(120), u.dp(40), u.dp(120), u.dp(40))
        } else {
            p.setMargins(u.dp(56), u.dp(12), u.dp(56), u.dp(12))
        }
        if (title == "HIGH BOOST") { p.height = -2; p.gravity = Gravity.CENTER }
        panelHost.addView(card, p)
        panelHost.visibility = View.VISIBLE
        Sfx.play("open", 0.8f)
    }

    fun closePanel() {
        panelHost.visibility = View.GONE
        panelHost.removeAllViews()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panelHost.visibility == View.VISIBLE) closePanel() else super.onBackPressed()
    }

    // ---------- chip RAM & suhu ----------
    private fun updateRam() {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val pct = if (mi.totalMem > 0) (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt() else 0
        ramChip.text = "RAM  $pct%"
        try {
            val i = registerReceiver(null as BroadcastReceiver?, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            if (t > 0) tempChip.text = "SUHU  ${t / 10}°"
        } catch (e: Exception) {}
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!ticking) return
            updateRam()
            refreshAccess()
            h.postDelayed(this, 3000)
        }
    }

    override fun onResume() {
        super.onResume()
        video.resume()
        ticking = true
        h.post(tick)
    }

    override fun onPause() {
        ticking = false
        h.removeCallbacks(tick)
        video.pause()
        super.onPause()
    }

    override fun onDestroy() {
        try {
            Shizuku.removeBinderReceivedListener(shizukuBinder)
            Shizuku.removeRequestPermissionResultListener(shizukuResult)
        } catch (t: Throwable) {}
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }
}
