package com.xa.gamespace

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var root: LinearLayout
    private lateinit var rootInfo: TextView
    private lateinit var monitor: TextView
    private lateinit var gameList: LinearLayout
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var polling = false
    private var stats: Stats? = null

    private val bg = Color.parseColor("#0B0B10")
    private val card = Color.parseColor("#17171F")
    private val red = Color.parseColor("#FF2D55")
    private val cyan = Color.parseColor("#00E5FF")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        build()
        Thread {
            val ok = Root.available()
            ui.post {
                rootInfo.text = if (ok) "Root: AKTIF" else "Root: TIDAK ADA / belum diizinkan"
                rootInfo.setTextColor(if (ok) cyan else red)
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        polling = true
        stats = Stats(this)
        Thread {
            while (polling) {
                val t = stats?.read(store.game) ?: ""
                ui.post { monitor.text = t }
                try { Thread.sleep(2000) } catch (e: InterruptedException) { break }
            }
        }.start()
        renderGames()
    }

    override fun onPause() {
        polling = false
        super.onPause()
    }

    private fun box(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        val g = GradientDrawable()
        g.setColor(card)
        g.cornerRadius = dp(14).toFloat()
        l.background = g
        l.setPadding(dp(14), dp(12), dp(14), dp(12))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, dp(12))
        l.layoutParams = lp
        return l
    }

    private fun text(s: String, size: Float = 14f, color: Int = Color.WHITE): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        return t
    }

    private fun btn(s: String, color: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(10).toFloat()
        b.background = g
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(vararg v: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        v.forEach {
            it.layoutParams = LinearLayout.LayoutParams(0, -2, 1f).also { lp -> lp.setMargins(dp(3), dp(3), dp(3), dp(3)) }
            r.addView(it)
        }
        return r
    }

    private fun build() {
        val sv = ScrollView(this)
        sv.setBackgroundColor(bg)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(24))
        sv.addView(root)
        setContentView(sv)

        root.addView(text("XA Game Space", 24f, cyan))
        rootInfo = text("Root: memeriksa...", 13f, Color.GRAY)
        root.addView(rootInfo)
        root.addView(View(this), LinearLayout.LayoutParams(-1, dp(12)))

        // Monitor
        val m = box()
        m.addView(text("Monitor", 13f, Color.GRAY))
        monitor = text("...", 16f)
        m.addView(monitor)
        root.addView(m)

        // Aksi
        val a = box()
        a.addView(row(
            btn("Boost sekarang", red) {
                Thread {
                    Boost.on(this, store.game)
                    ui.post { toast("Boost aktif") }
                }.start()
            },
            btn("Pulihkan", Color.parseColor("#2A2A36")) {
                Thread {
                    Boost.off(this)
                    ui.post {
                        stopService(Intent(this, OverlayService::class.java))
                        toast("Pengaturan dipulihkan")
                    }
                }.start()
            }
        ))
        a.addView(row(
            btn("Bersihkan RAM", Color.parseColor("#2A2A36")) {
                Thread {
                    Boost.cleanRam()
                    ui.post { toast("RAM dibersihkan") }
                }.start()
            },
            btn("Stop app latar", Color.parseColor("#2A2A36")) {
                Thread {
                    val n = Boost.killBackground(this, store.game)
                    ui.post { toast("$n aplikasi dihentikan") }
                }.start()
            }
        ))
        root.addView(a)

        // Fitur
        val f = box()
        f.addView(text("Fitur boost", 13f, Color.GRAY))
        val all = Boost.FLAGS.map { it.first to it.second } + ("overlay" to "Monitor overlay (CPU/RAM/suhu/FPS)")
        all.forEach { (k, label) ->
            val sw = Switch(this)
            sw.text = label
            sw.setTextColor(Color.WHITE)
            sw.isChecked = store.flag(k)
            sw.setPadding(0, dp(6), 0, dp(6))
            sw.setOnCheckedChangeListener { _, c -> store.setFlag(k, c) }
            f.addView(sw)
        }
        root.addView(f)

        // Game
        val g = box()
        g.addView(text("Daftar game", 13f, Color.GRAY))
        gameList = LinearLayout(this)
        gameList.orientation = LinearLayout.VERTICAL
        g.addView(gameList)
        g.addView(btn("+ Tambah game", Color.parseColor("#2A2A36")) { pickGames() })
        root.addView(g)

        root.addView(text("Butuh akses root (Magisk/KernelSU). Beberapa fitur bergantung pada HP dan versi Android.", 11f, Color.GRAY))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun renderGames() {
        gameList.removeAllViews()
        val pm = packageManager
        val games = store.games
        if (games.isEmpty()) gameList.addView(text("Belum ada game. Tekan Tambah game.", 13f, Color.GRAY))
        games.forEach { pkg ->
            val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { return@forEach }
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dp(6), 0, dp(6))
            val ic = ImageView(this)
            try { ic.setImageDrawable(pm.getApplicationIcon(pkg)) } catch (e: Exception) {}
            r.addView(ic, LinearLayout.LayoutParams(dp(40), dp(40)))
            val name = text(label, 15f)
            name.setPadding(dp(10), 0, dp(10), 0)
            r.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(btn("Main", red) { play(pkg) }, LinearLayout.LayoutParams(-2, -2))
            r.addView(btn("✕", Color.parseColor("#2A2A36")) {
                store.games = store.games - pkg
                renderGames()
            }, LinearLayout.LayoutParams(-2, -2))
            gameList.addView(r)
        }
    }

    private fun play(pkg: String) {
        val li = packageManager.getLaunchIntentForPackage(pkg)
        if (li == null) { toast("Game tidak bisa dibuka"); return }
        if (store.flag("overlay") && !Settings.canDrawOverlays(this)) {
            toast("Izinkan tampil di atas aplikasi lain untuk monitor")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        toast("Menyiapkan boost...")
        Thread {
            Boost.on(this, pkg)
            ui.post {
                if (store.flag("overlay") && Settings.canDrawOverlays(this)) {
                    val si = Intent(this, OverlayService::class.java).putExtra("pkg", pkg)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(si) else startService(si)
                }
                startActivity(li)
            }
        }.start()
    }

    private fun pickGames() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val chosen = store.games.toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].first in chosen }
        AlertDialog.Builder(this)
            .setTitle("Pilih game")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, c ->
                if (c) chosen.add(apps[i].first) else chosen.remove(apps[i].first)
            }
            .setPositiveButton("Simpan") { _, _ -> store.games = chosen; renderGames() }
            .setNegativeButton("Batal", null)
            .show()
    }
}
