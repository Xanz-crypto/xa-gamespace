package com.xa.gamespace

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    lateinit var store: Store
    lateinit var ui: Ui
    @Volatile var rootOk: Boolean? = null
    @Volatile var selinux = "-"

    private lateinit var content: FrameLayout
    private val pages = ArrayList<Page>()
    private val views = arrayOfNulls<View>(4)
    private val navIcon = ArrayList<TextView>()
    private val navText = ArrayList<TextView>()
    private var tab = 0
    @Volatile private var polling = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        Theme.apply(store.str("accent", "Hijau"))
        ui = Ui(this)
        window.statusBarColor = Theme.bg
        window.navigationBarColor = Theme.bg
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val rootL = ui.vbox()
        rootL.setBackgroundColor(Theme.bg)
        content = FrameLayout(this)
        rootL.addView(content, ui.lp(-1, 0, 1f))
        rootL.addView(buildNav(), ui.lp(-1, -2))
        setContentView(rootL)

        pages.add(HomePage(this))
        pages.add(GamePage(this))
        pages.add(ToolsPage(this))
        pages.add(SettingsPage(this))
        show(intent.getIntExtra("tab", 0).coerceIn(0, 3))

        Thread {
            rootOk = Root.available()
            selinux = Sys.sh("getenforce").ifBlank { "-" }
        }.start()
    }

    private fun buildNav(): View {
        val bar = ui.hbox()
        bar.setBackgroundColor(Theme.card)
        bar.setPadding(0, ui.dp(8), 0, ui.dp(8))
        val icons = listOf("🏠", "🎮", "🧰", "⚙")
        val names = listOf("Beranda", "Game", "Alat", "Setelan")
        for (i in 0..3) {
            val item = ui.vbox()
            item.gravity = Gravity.CENTER
            val ic = ui.label(icons[i], 20f)
            ic.gravity = Gravity.CENTER
            val tx = ui.label(names[i], 10f, Theme.sub, true)
            tx.gravity = Gravity.CENTER
            item.addView(ic)
            item.addView(tx)
            item.setOnClickListener { show(i) }
            navIcon.add(ic)
            navText.add(tx)
            bar.addView(item, ui.lp(0, -2, 1f))
        }
        return bar
    }

    private fun show(i: Int) {
        tab = i
        content.removeAllViews()
        val v = views[i] ?: pages[i].build().also { views[i] = it }
        content.addView(v)
        for (k in 0..3) {
            val on = k == i
            navIcon[k].alpha = if (on) 1f else 0.45f
            navText[k].setTextColor(if (on) Theme.accent else Theme.sub)
        }
    }

    override fun onResume() {
        super.onResume()
        polling = true
        if (store.bool("autorestore", false) && store.active) Launcher.restore(this) {}
        val stats = Stats(this)
        Thread {
            while (polling) {
                val s = stats.read(selectedGame(), true)
                runOnUiThread { if (tab < pages.size) pages[tab].update(s) }
                try { Thread.sleep(2500) } catch (e: InterruptedException) { break }
            }
        }.start()
    }

    override fun onPause() {
        polling = false
        super.onPause()
    }

    fun selectedGame(): String? {
        val s = store.selected
        val g = store.games
        return if (s != null && s in g) s else g.firstOrNull()
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun async(work: () -> String, done: (String) -> Unit) {
        Thread {
            val r = work()
            runOnUiThread { done(r) }
        }.start()
    }

    fun play(pkg: String) = Launcher.play(this, pkg)

    fun boost() {
        toast("Menyiapkan boost...")
        async({ Boost.on(this, selectedGame()); "Boost aktif" }) { toast(it) }
    }

    fun restore() = Launcher.restore(this) { toast("Pengaturan dipulihkan") }

    fun openSpace() = startActivity(Intent(this, GameSpaceActivity::class.java))

    fun pickGames(after: () -> Unit) {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val chosen = store.games.toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].first in chosen }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Pilih game")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, c ->
                if (c) chosen.add(apps[i].first) else chosen.remove(apps[i].first)
            }
            .setPositiveButton("Simpan") { _, _ ->
                store.games = chosen
                val s = store.selected
                if (s == null || s !in chosen) store.selected = chosen.firstOrNull()
                after()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
