package com.xa.gamespace

import android.app.Activity
import android.app.AlertDialog
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class Tile(u: Ui, icon: String, title: String, tag: String? = null, tagOk: Boolean = true, click: () -> Unit) {
    val view: LinearLayout = u.vbox()
    private val sub = u.label("", 10f, Theme.sub, true)
    private val ui = u

    init {
        view.gravity = Gravity.CENTER
        view.setPadding(u.dp(6), u.dp(6), u.dp(6), u.dp(10))
        val tg = u.label(tag ?: " ", 8f, if (tagOk) Theme.good else Theme.warn, true)
        tg.gravity = Gravity.END
        view.addView(tg, u.lp(-1, -2))
        val ic = u.label(icon, 22f)
        ic.gravity = Gravity.CENTER
        val t = u.label(title, 12f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        sub.gravity = Gravity.CENTER
        view.addView(ic)
        view.addView(t, u.lp(t = 4))
        view.addView(sub, u.lp(t = 2))
        view.background = u.glass()
        view.setOnClickListener { Sfx.tap(); click() }
    }

    fun text(s: String) { sub.text = s }

    fun set(on: Boolean) {
        sub.text = if (on) "AKTIF" else "MATI"
        sub.setTextColor(if (on) Theme.good else Theme.sub)
        view.background = if (on) ui.glass(16, Color.argb(160, 10, 40, 60), Hud.cyan) else ui.glass()
    }
}

class MainActivity : Activity() {
    lateinit var store: Store
    lateinit var u: Ui
    private lateinit var video: VideoBg
    private lateinit var panelHost: FrameLayout
    private lateinit var carousel: GameCarousel
    private lateinit var ramChip: TextView
    private lateinit var accessChip: TextView
    private lateinit var tempChip: TextView
    private lateinit var netDown: TextView
    private lateinit var netUp: TextView
    private var lastRx = -1L
    private var lastTx = -1L
    private var lastNetT = 0L
    private lateinit var esports: TextView
    private var bottomBar: LinearLayout? = null
    private lateinit var rootView: FrameLayout
    private lateinit var uiLayer: FrameLayout
    private var opening = false
    private val h = Handler(Looper.getMainLooper())
    private var ticking = false
    private var splashDone = false
    private var pendingOverlay = false

    private val shizukuBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refreshAccess() } }
    private val shizukuResult = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refreshAccess() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        makeFullScreen()
        store = Store(this)
        handleIntent(intent)
        u = Ui(this)
        Sfx.init(this)
        Music.load(this)
        Ads.init(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val root = FrameLayout(this)
        rootView = root
        root.setBackgroundColor(Color.BLACK)
        video = VideoBg(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1))

        val shade = View(this)
        shade.setBackgroundColor(Color.argb(150, 3, 5, 12))
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))

        // seluruh isi beranda ada di uiLayer: tersembunyi saat intro, muncul setelah tombol OPEN GAME SPACE ditekan
        val content = FrameLayout(this)
        uiLayer = content
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        carousel = GameCarousel(this)
        carousel.info = { g -> if (g.pkg == Games.ADD_PKG) "Ketuk untuk tambah game" else "Siap boost · ${Access.mode.name}" }
        carousel.onStart = { g -> if (g.pkg == Games.ADD_PKG) showAddGame() else play(g.pkg) }
        carousel.onTexture = { g -> if (g.pkg != Games.ADD_PKG) showPanel("TEXTURE · ${g.label}", TexturePanel(this, g.pkg).root) }
        carousel.onSelect = { g -> if (g.pkg != Games.ADD_PKG) store.put("last_game", g.pkg) }
        // gelembung/tetesan di belakang kartu: tidak lagi menutupi kartu, jadi gerak kartu dan isinya satu arah
        content.addView(WetGlowView(this, 24, false, 1f, false), FrameLayout.LayoutParams(-1, -1))
        content.addView(carousel, FrameLayout.LayoutParams(-1, -1))

        val tb = buildTop()
        topBar = tb
        content.addView(tb, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        buildBottom(content)

        // efek basah: tetesan air, kilau cahaya, dan cahaya tepi yang berganti warna
        content.addView(WetGlowView(this, 0, true, 1f), FrameLayout.LayoutParams(-1, -1))

        panelHost = FrameLayout(this)
        panelHost.visibility = View.GONE
        content.addView(panelHost, FrameLayout.LayoutParams(-1, -1))

        // latar tetap sampai ujung layar (termasuk area kamera); hanya tombol/teks yang digeser menjauhi kamera
        root.setOnApplyWindowInsetsListener { _, ins ->
            var l = 0; var t = 0; var r = 0
            if (Build.VERSION.SDK_INT >= 28) {
                ins.displayCutout?.let { l = it.safeInsetLeft; t = it.safeInsetTop; r = it.safeInsetRight }
            }
            applyCutout(l, t, r)
            ins
        }
        setContentView(root)
        root.requestApplyInsets()
        startIntro()

        renderGames()
        refreshTags()

        try {
            Shizuku.addBinderReceivedListenerSticky(shizukuBinder)
            Shizuku.addRequestPermissionResultListener(shizukuResult)
        } catch (t: Throwable) {}

        Thread {
            val ok = Access.checkRoot()
            if (ok) Root.run("appops set $packageName SYSTEM_ALERT_WINDOW allow")
            if (ok && !store.active && store.get("cpu_default").isBlank()) {
                store.put("cpu_default", Cpu.serialize(Cpu.read()))
            }
            runOnUiThread {
                refreshAccess()
                if (!ok) {
                    if (Access.shizukuGranted()) {
                        toast("Mode Shizuku aktif. Fitur khusus root dinonaktifkan.")
                    } else if (Access.shizukuRunning()) {
                        Access.requestShizuku(100)
                    } else {
                        toast("Root & Shizuku belum aktif. Ketuk chip AKSES di atas untuk mengatur.")
                    }
                }
                if (splashDone) ensureOverlay() else pendingOverlay = true
            }
        }.start()

        if (store.auto || store.active) GameService.start(this)
    }

    private var splashView: View? = null
    private var topBar: View? = null

    // seluruh layar dipakai: di bawah status bar, bilah navigasi, dan area kamera (punch-hole)
    private fun makeFullScreen() {
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 28) {
            val a = window.attributes
            a.layoutInDisplayCutoutMode =
                if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = a
        }
    }

    private fun applyCutout(l: Int, t: Int, r: Int) {
        (topBar?.layoutParams as? FrameLayout.LayoutParams)?.let {
            it.leftMargin = l; it.rightMargin = r; it.topMargin = t
            topBar?.layoutParams = it
        }
        (esports.layoutParams as? FrameLayout.LayoutParams)?.let {
            it.rightMargin = u.dp(24) + r
            esports.layoutParams = it
        }
        (bottomBar?.layoutParams as? FrameLayout.LayoutParams)?.let {
            it.leftMargin = u.dp(24) + l
            bottomBar?.layoutParams = it
        }
    }

    // Intro: layar neon yang terus bergerak + tombol OPEN GAME SPACE
    private fun startIntro() {
        if (splashView != null) return
        splashDone = false
        opening = false
        uiLayer.alpha = 0f
        val intro = HomeIntro(this) { openHome() }
        splashView = intro
        rootView.addView(intro, FrameLayout.LayoutParams(-1, -1))
    }

    // tombol ditekan: intro membesar lalu pudar, beranda muncul dari sedikit membesar ke ukuran normal
    private fun openHome() {
        val intro = splashView ?: return
        if (opening) return
        opening = true
        Sfx.play("open", 0.8f)
        uiLayer.scaleX = 1.07f
        uiLayer.scaleY = 1.07f
        uiLayer.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(650)
            .setInterpolator(DecelerateInterpolator()).start()
        intro.animate().alpha(0f).scaleX(1.2f).scaleY(1.2f).setDuration(650)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction {
                rootView.removeView(intro)
                splashView = null
                splashDone = true
                if (pendingOverlay) { pendingOverlay = false; ensureOverlay() }
            }.start()
    }

    private fun ensureOverlay() {
        if (GameOverlay.canDraw(this)) return
        toast("Izinkan 'Tampil di atas aplikasi lain' agar Game Panel muncul di dalam game")
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {}
    }

    // ---------- tampilan ----------
    private fun buildTop(): View {
        val top = u.hbox()
        top.setPadding(u.dp(24), u.dp(8), u.dp(24), u.dp(4))
        val tb = u.vbox()
        val brand = u.label("XAGameSpace", 11f, Hud.cyan, true)
        brand.letterSpacing = 0.2f
        tb.addView(brand)
        tb.addView(u.label("Performa maksimal", 18f, Color.WHITE, true))
        top.addView(tb, u.lp(0, -2, 1f))

        accessChip = u.chip("AKSES  …", Theme.sub)
        accessChip.setOnClickListener { Sfx.tap(); showAccessDialog() }
        top.addView(accessChip, u.lp(-2, -2, r = 8))
        tempChip = u.chip("SUHU  -", Color.WHITE)
        top.addView(tempChip, u.lp(-2, -2, r = 8))
        ramChip = u.chip("RAM  -", Color.WHITE)
        top.addView(ramChip, u.lp(-2, -2, r = 12))
        val clk = TextClock(this)
        clk.format24Hour = "HH:mm"
        clk.format12Hour = "HH:mm"
        clk.textSize = 17f
        clk.setTextColor(Color.WHITE)
        clk.typeface = Typeface.DEFAULT_BOLD
        top.addView(clk, u.lp(-2, -2, r = 12))
        // kecepatan jaringan (unduh / unggah) menggantikan tombol titik tiga; ketuk untuk membuka menu Jaringan
        val net = u.vbox()
        net.gravity = Gravity.CENTER_VERTICAL
        net.setPadding(u.dp(10), u.dp(3), u.dp(10), u.dp(3))
        net.background = u.glass(14, Color.argb(130, 8, 9, 14), Hud.cyanDim)
        netDown = u.label("↓ 0 KB/s", 10f, Color.parseColor("#38E8A5"), true)
        netUp = u.label("↑ 0 KB/s", 10f, Color.parseColor("#FF6FD8"), true)
        netDown.minWidth = u.dp(66)
        netUp.minWidth = u.dp(66)
        net.addView(netDown)
        net.addView(netUp)
        net.setOnClickListener {
            Sfx.tap()
            showPanel("Optimal Jaringan", NetSheet(this, { showPanel("Scan aplikasi latar belakang", ScanPanel(this).root) }) { closePanel() }.root)
        }
        top.addView(net)
        return top
    }

    private fun buildBottom(root: FrameLayout) {
        val boost = u.label("▲   HIGH BOOST", 12f, Color.WHITE, true)
        boost.letterSpacing = 0.15f
        boost.gravity = Gravity.CENTER
        boost.setPadding(u.dp(26), u.dp(6), u.dp(26), u.dp(6))
        boost.background = u.glass(14, Color.argb(190, 40, 14, 70), Color.parseColor("#B04CFF"))
        boost.setOnClickListener {
            Sfx.tap()
            boost.animate().cancel()
            boost.animate().scaleX(0.93f).scaleY(0.93f).setDuration(80).withEndAction {
                boost.animate().scaleX(1f).scaleY(1f).setDuration(220)
                    .setInterpolator(android.view.animation.OvershootInterpolator(2.2f)).start()
            }.start()
            showFeatures()
        }
        // HIGH BOOST di kiri bawah, SHELL di sebelahnya
        val bar = u.hbox()
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.addView(boost, u.lp(-2, -2, r = 10))
        val shell = u.label("⌘   SHELL", 12f, Color.WHITE, true)
        shell.letterSpacing = 0.15f
        shell.gravity = Gravity.CENTER
        shell.setPadding(u.dp(22), u.dp(6), u.dp(22), u.dp(6))
        shell.background = u.glass(14, Color.argb(190, 8, 40, 60), Hud.cyan)
        shell.setOnClickListener { Sfx.tap(); showPanel("SHELL", ShellPanel(this).root) }
        bar.addView(shell, u.lp(-2, -2, l = 10))
        val music = u.label("♫   MUSIK", 12f, Color.WHITE, true)
        music.letterSpacing = 0.15f
        music.gravity = Gravity.CENTER
        music.setPadding(u.dp(22), u.dp(6), u.dp(22), u.dp(6))
        music.background = u.glass(14, Color.argb(190, 8, 40, 60), Hud.cyan)
        music.setOnClickListener { Sfx.tap(); showMusic() }
        bar.addView(music, u.lp(-2, -2, l = 10))
        val unlockBtn = u.label("★   UNLOCK ALL", 12f, Color.WHITE, true)
        unlockBtn.letterSpacing = 0.15f
        unlockBtn.gravity = Gravity.CENTER
        unlockBtn.setPadding(u.dp(22), u.dp(6), u.dp(22), u.dp(6))
        unlockBtn.background = u.glass(14, Color.argb(190, 60, 40, 8), Color.parseColor("#FFB300"))
        unlockBtn.setOnClickListener { Sfx.tap(); showUnlock() }
        bar.addView(unlockBtn, u.lp(-2, -2, l = 10))
        val bp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START)
        bp.bottomMargin = u.dp(6)
        bp.leftMargin = u.dp(24)
        root.addView(bar, bp)
        bottomBar = bar

        esports = u.label("ESPORTS »", 16f, Color.WHITE, true)
        esports.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        esports.setPadding(u.dp(14), u.dp(6), u.dp(14), u.dp(6))
        esports.setOnClickListener { Sfx.tap(); showModes() }
        val ep = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END)
        ep.bottomMargin = u.dp(26); ep.rightMargin = u.dp(24)
        root.addView(esports, ep)
    }

    private var openMusic = false
    private var openNewPlaylist = false
    private var pendingPick: String? = null
    private var pickTarget = Music.MANUAL_NAME
    private var musicPanel: MusicPanel? = null

    private fun handleIntent(i: android.content.Intent?) {
        if (i == null) return
        if (i.getBooleanExtra("open_music", false)) openMusic = true
        i.getStringExtra("pick_target")?.let { pendingPick = it }
        if (i.getBooleanExtra("new_playlist", false)) openNewPlaylist = true
    }

    fun showMusic() {
        musicPanel = MusicPanel(this, { pickSong(it) }, { showNewPlaylistDialog() })
        showPanel("MUSIK", musicPanel!!.root)
    }

    fun showNewPlaylistDialog() {
        val input = android.widget.EditText(this).apply { hint = "Nama playlist" }
        android.app.AlertDialog.Builder(this)
            .setTitle("Buat playlist")
            .setView(input)
            .setPositiveButton("Buat") { _, _ ->
                val name = input.text.toString().trim()
                if (Music.createPlaylist(this, name)) musicPanel?.refresh()
                else toast("Nama kosong atau sudah dipakai")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    override fun onNewIntent(i: android.content.Intent?) {
        super.onNewIntent(i)
        handleIntent(i)
    }

    fun showModes() = showPanel("MODE", ModePanel(this).root)

    // menu UNLOCK ALL: 1 hari = 1 iklan, 5 hari = 3 iklan
    fun showUnlock() {
        val v = u.vbox()
        v.addView(u.label("UNLOCK ALL", 18f, Color.WHITE, true), u.lp(-1, -2, b = 4))
        v.addView(u.label(Unlock.remainingText(this), 12f, Color.parseColor("#FFB300"), true), u.lp(-1, -2, b = 12))
        v.addView(u.label("Membuka semua fitur terkunci (mode Performa, Esport, Stabil, dan lainnya).", 12f, Theme.sub), u.lp(-1, -2, b = 14))
        v.addView(u.btn("1 HARI  ·  tonton 1 iklan") { watchAds(1, Unlock.ONE_DAY) }, u.lp(-1, -2, b = 8))
        v.addView(u.btn("5 HARI  ·  tonton 3 iklan") { watchAds(3, Unlock.FIVE_DAYS) }, u.lp(-1, -2, b = 8))
        showPanel("UNLOCK ALL", v)
    }

    // tonton iklan berurutan; hadiah hanya diberikan kalau semua iklan ditonton sampai selesai
    private fun watchAds(total: Int, ms: Long) {
        var done = 0
        fun next() {
            var earned = false
            Ads.show(this,
                onReward = { earned = true },
                onDismissed = {
                    if (!earned) {
                        toast("Iklan harus ditonton sampai selesai")
                    } else {
                        done++
                        if (done >= total) {
                            Unlock.grant(this, ms)
                            toast("Unlock aktif")
                        } else {
                            toast("Iklan $done dari $total selesai")
                            next()
                        }
                    }
                },
                onFail = { toast("Iklan belum siap, coba lagi sebentar") })
        }
        next()
    }

    fun updateMusicLabel() { }

    // buka pemilih file lagu dari HP
    fun pickSong(target: String = Music.MANUAL_NAME) {
        pickTarget = target
        val i = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(android.content.Intent.CATEGORY_OPENABLE)
        i.type = "audio/*"
        startActivityForResult(i, REQ_SONG)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SONG && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {}
            Music.addTo(this, pickTarget, uri.toString())
            toast("Lagu ditambahkan")
        }
    }

    companion object { const val REQ_SONG = 4101 }

    fun applyMode(m: Modes.Mode) {
        if (m.key in listOf("performa", "esport", "stabil") && !Unlock.active(this)) {
            toast("Mode ${m.name} terkunci. Buka dengan UNLOCK ALL.")
            return
        }
        Modes.apply(this, m)
        toast("Mode ${m.name} aktif")
        refreshTags()
        reapply()
    }

    private fun refreshTags() {
        carousel.tags = listOf("Stabil FPS" to store.stabil, "Smooth FPS" to store.smooth, "Auto Game" to store.auto)
        esports.text = Modes.current(store).name.uppercase() + " »"
        val on = store.stabil && store.smooth
        esports.setTextColor(if (on) Hud.cyan else Color.WHITE)
    }

    private fun toggleEsports() {
        val on = !(store.stabil && store.smooth)
        store.smooth = on
        store.stabil = on && Access.isRoot
        if (on && !Access.isRoot) Access.requires(this, "Stabil FPS", true)
        if (on && !Access.hasAny()) Access.requires(this, "Smooth FPS", false)
        toast(if (on) "Mode Esports aktif" else "Mode Esports mati")
        refreshTags()
        reapply()
    }

    fun refreshAccess() {
        val m = Access.mode
        val (txt, col) = when (m) {
            Access.Mode.ROOT -> "ROOT  ✓" to Theme.good
            Access.Mode.SHIZUKU -> "SHIZUKU  ✓" to Theme.warn
            Access.Mode.NONE -> "AKSES  ✗" to Theme.bad
        }
        accessChip.text = txt
        accessChip.setTextColor(col)
        carousel.invalidate()
    }

    private fun showAccessDialog() {
        val root = if (Access.isRoot) "aktif ✓" else "tidak terdeteksi ✗"
        val sh = when {
            Access.shizukuGranted() -> "aktif & diizinkan ✓"
            Access.shizukuRunning() -> "berjalan, izin belum diberikan"
            else -> "belum berjalan / belum terpasang"
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Akses sistem")
            .setMessage("Root: $root\nShizuku: $sh\n\n" +
                "• Khusus ROOT: Stabil FPS, CPU/GPU Tuning, tweak TCP kernel, jalur touch panel.\n" +
                "• ROOT atau SHIZUKU: Smooth FPS, Touch Optimizer/Smooth, Boost Jaringan, Bersihkan RAM, Stop App, Scan App, Auto Game, WiFi/Data/DND.")
            .setPositiveButton("Minta izin root") { _, _ ->
                toast("Menunggu izin root...")
                Thread {
                    val ok = Access.checkRoot()
                    if (ok) Root.run("appops set $packageName SYSTEM_ALERT_WINDOW allow")
                    runOnUiThread { refreshAccess(); toast(if (ok) "Root diizinkan" else "Root ditolak / tidak ada") }
                }.start()
            }
            .setNeutralButton("Izin Shizuku") { _, _ ->
                if (Access.shizukuGranted()) { toast("Shizuku sudah diizinkan"); refreshAccess() }
                else if (Access.shizukuRunning()) Access.requestShizuku(100)
                else {
                    toast("Shizuku belum berjalan. Buka aplikasi Shizuku lalu tekan Start.")
                    try {
                        packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
                    } catch (e: Exception) {}
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun showFeatures() {
        val col = u.vbox()
        col.gravity = Gravity.CENTER

        val tStabil = Tile(u, "🎯", "Stabil FPS", Access.tagFor(true), Access.satisfied(true)) {}
        val tSmooth = Tile(u, "🌊", "Smooth FPS", Access.tagFor(false), Access.satisfied(false)) {}
        val tRam = Tile(u, "🧹", "Bersihkan RAM", Access.tagFor(false), Access.satisfied(false)) {}
        val tAuto = Tile(u, "🤖", "Auto Game", Access.tagFor(false), Access.satisfied(false)) {}
        val tScan = Tile(u, "🔍", "Scan App", Access.tagFor(false), Access.satisfied(false)) {}
        val tCpu = Tile(u, "⚙", "CPU Governor", Access.tagFor(true), Access.satisfied(true)) {}
        val tGame = Tile(u, "🎬", "Game CMD", Access.tagFor(false), Access.satisfied(false)) {}
        val tSnd = Tile(u, "🔊", "Suara") {}
        val tTouch = Tile(u, "👆", "Touch", Access.tagFor(false), Access.satisfied(false)) {}
        val tNet = Tile(u, "📶", "Jaringan", Access.tagFor(false), Access.satisfied(false)) {}
        val tRate = Tile(u, "🖥", "Render Rate", Access.tagFor(true), Access.satisfied(true)) {}
        val tGpuVs = Tile(u, "🎮", "GPU VSync", Access.tagFor(true), Access.satisfied(true)) {}
        tRate.text("60 · 120 · 240 Hz"); tGpuVs.text("Vsync · FPS")
        tRate.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Render Rate", true)) return@setOnClickListener
            showPanel("Render / VSync Rate", RatePanel(this, 0).root)
        }
        tGpuVs.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "GPU VSync", true)) return@setOnClickListener
            showPanel("GPU Rate / VSync FPS", RatePanel(this, 1).root)
        }
        tTouch.set(store.touch || store.touchSmooth); tNet.text("Wi-Fi · TCP")
        tTouch.view.setOnClickListener {
            Sfx.tap()
            showPanel("Touch Optimizer", TouchSheet(this) { closePanel() }.root)
        }
        tNet.view.setOnClickListener {
            Sfx.tap()
            showPanel("Optimal Jaringan", NetSheet(this, { showPanel("Scan aplikasi latar belakang", ScanPanel(this).root) }) { closePanel() }.root)
        }
        tGame.text("FPS · Downscale"); tSnd.text("Klik · Mixer")
        tGame.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Game CMD", false)) return@setOnClickListener
            showPanel("Game CMD · mode, downscale, FPS", GameCmdPanel(this).root)
        }
        tSnd.view.setOnClickListener {
            Sfx.tap()
            showPanel("Suara", SoundHub(this).root)
        }

        tStabil.set(store.stabil); tSmooth.set(store.smooth); tAuto.set(store.auto)
        tRam.text("Sekali tap"); tScan.text("User + sistem"); tCpu.text("Lengkap")

        tStabil.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Stabil FPS", true)) return@setOnClickListener
            store.stabil = !store.stabil; tStabil.set(store.stabil); refreshTags(); reapply()
        }
        tSmooth.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Smooth FPS", false)) return@setOnClickListener
            store.smooth = !store.smooth; tSmooth.set(store.smooth); refreshTags(); reapply()
        }
        tRam.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Bersihkan RAM", false)) return@setOnClickListener
            cleanRam(tRam)
        }
        tAuto.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Auto Game", false)) return@setOnClickListener
            store.auto = !store.auto; tAuto.set(store.auto); refreshTags()
            if (store.auto) GameService.start(this)
        }
        tScan.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Scan App", false)) return@setOnClickListener
            showPanel("Scan aplikasi latar belakang", ScanPanel(this).root)
        }
        tCpu.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "CPU Governor", true)) return@setOnClickListener
            showPanel("CPU Governor", CpuPanel(this).root)
        }

        val tUltra = Tile(u, "🧨", "Clear RAM Ultra", Access.tagFor(false), Access.satisfied(false)) {}
        tUltra.text("80% · + sistem")
        tUltra.view.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(this, "Bersihkan RAM", false)) return@setOnClickListener
            ultraRam(tUltra)
        }

        // semua fitur dalam grid 3 kolom; panel bisa digulir ke bawah
        val all = listOf(tStabil, tSmooth, tTouch, tRam, tUltra, tAuto, tScan, tCpu, tGame, tNet, tSnd, tRate, tGpuVs)
        all.chunked(3).forEach { rowTiles ->
            val row = u.hbox()
            rowTiles.forEachIndexed { k, t -> row.addView(t.view, u.lp(0, -2, 1f, r = if (k < 2) 8 else 0)) }
            // kolom kosong di baris terakhir supaya ukuran tetap sama
            repeat(3 - rowTiles.size) { row.addView(View(this), u.lp(0, 0, 1f)) }
            col.addView(row, u.lp(b = 8))
        }
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(col)
        showPanel("HIGH BOOST", sv)
    }

    private fun reapply() {
        if (store.active) Thread { Boost.refresh(this) }.start()
    }

    private fun ultraRam(t: Tile) {
        toast("Clear RAM Ultra: membersihkan sampai 80%...")
        t.text("Memproses...")
        Thread {
            val keep = Store(this).get("last_game").ifBlank { null }
            val msg = Boost.optimizeRam(this, keep, 80, includeSystem = true)
            runOnUiThread {
                t.text("80% · selesai")
                toast(msg)
                updateRam()
            }
        }.start()
    }

    private fun cleanRam(t: Tile) {
        toast("Membersihkan RAM...")
        t.text("Memproses...")
        Thread {
            val freed = Boost.cleanRam(this)
            runOnUiThread {
                t.text("+$freed MB")
                toast("RAM dibebaskan $freed MB")
                updateRam()
            }
        }.start()
    }

    private fun showAddGame() {
        showPanel("Tambah game", AddGamePanel(this).root)
    }

    fun renderGames() {
        Thread {
            val g = Games.detect(this)
            runOnUiThread { carousel.setItems(g + GameApp(Games.ADD_PKG, "Tambah Game", null), store.get("last_game")) }
        }.start()
    }

    private fun play(pkg: String) {
        val li = packageManager.getLaunchIntentForPackage(pkg)
        if (li == null) { toast("Game tidak bisa dibuka"); return }
        Thread {
            val ok = Root.available()
            runOnUiThread {
                if (ok) GameService.start(this, pkg) else toast("Tanpa root/Shizuku: game dibuka tanpa boost")
                startActivity(li)
            }
        }.start()
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- Panel ----------
    fun showPanel(title: String, body: View) {
        panelHost.removeAllViews()
        val shade = View(this)
        shade.setBackgroundColor(Color.argb(170, 0, 0, 0))
        shade.setOnClickListener { closePanel() }
        panelHost.addView(shade, FrameLayout.LayoutParams(-1, -1))

        val card = u.vbox()
        card.background = u.glass(20, Color.argb(235, 8, 14, 26), Hud.cyanDim)
        card.setPadding(u.dp(18), u.dp(12), u.dp(18), u.dp(12))
        val head = u.hbox()
        head.addView(u.label(title, 16f, Color.WHITE, true), u.lp(0, -2, 1f))
        val x = u.label("✕", 18f, Color.WHITE, true)
        x.setPadding(u.dp(12), u.dp(4), u.dp(4), u.dp(4))
        x.setOnClickListener { Sfx.tap(); closePanel() }
        head.addView(x)
        card.addView(head, u.lp(b = 8))
        val boostPanel = title == "HIGH BOOST"
        card.addView(body, u.lp(-1, 0, 1f))
        panelToken++
        val tok = panelToken
        val p = FrameLayout.LayoutParams(-1, -1)
        if (title == "HIGH BOOST") {
            p.setMargins(u.dp(120), u.dp(40), u.dp(120), u.dp(40))
        } else {
            p.setMargins(u.dp(56), u.dp(12), u.dp(56), u.dp(12))
        }
        if (title == "HIGH BOOST") { p.height = (resources.displayMetrics.heightPixels * 0.80f).toInt(); p.gravity = Gravity.CENTER }
        // ---- animasi buka: tirai memudar, kartu naik dari tombol HIGH BOOST sambil membesar, ikon muncul bergantian ----
        val ease = android.view.animation.PathInterpolator(0.16f, 1f, 0.3f, 1f)
        shade.alpha = 0f
        card.alpha = 0f
        panelHost.addView(card, p)
        panelHost.visibility = View.VISIBLE
        Sfx.play("open", 0.8f)
        shade.animate().alpha(1f).setDuration(320).start()
        val tiles = ArrayList<View>()
        if (boostPanel) {
            val inner = if (body is ScrollView) body.getChildAt(0) as ViewGroup else body as ViewGroup
            for (i in 0 until inner.childCount) {
                val c = inner.getChildAt(i)
                if (c is LinearLayout && c.orientation == LinearLayout.HORIZONTAL) for (j in 0 until c.childCount) tiles.add(c.getChildAt(j))
                else tiles.add(c)
            }
            for (t in tiles) { t.alpha = 0f; t.translationY = u.dp(16).toFloat(); t.scaleX = 0.86f; t.scaleY = 0.86f }
        }
        card.post {
            if (tok != panelToken) return@post
            card.pivotX = card.width / 2f
            card.pivotY = if (boostPanel) card.height.toFloat() else card.height / 2f
            card.scaleX = if (boostPanel) 0.80f else 0.94f
            card.scaleY = card.scaleX
            card.translationY = u.dp(if (boostPanel) 70 else 18).toFloat()
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(520).setInterpolator(ease).start()
            tiles.forEachIndexed { i, t ->
                t.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                    .setStartDelay(170L + i * 45L).setDuration(420).setInterpolator(ease).start()
            }
        }
    }

    private var panelToken = 0

    fun closePanel() {
        if (panelHost.visibility != View.VISIBLE) return
        val shade = panelHost.getChildAt(0)
        val card = panelHost.getChildAt(1)
        if (shade == null || card == null) { panelHost.visibility = View.GONE; panelHost.removeAllViews(); return }
        panelToken++
        val tok = panelToken
        shade.animate().cancel(); card.animate().cancel()
        shade.animate().alpha(0f).setDuration(260).start()
        card.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).translationY(u.dp(26).toFloat())
            .setDuration(260).setInterpolator(android.view.animation.PathInterpolator(0.4f, 0f, 0.6f, 1f))
            .withEndAction {
                if (tok == panelToken) { panelHost.visibility = View.GONE; panelHost.removeAllViews() }
            }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panelHost.visibility == View.VISIBLE) closePanel() else super.onBackPressed()
    }

    // ---------- chip RAM & suhu ----------
    private fun updateRam() {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val pct = if (mi.totalMem > 0) (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt() else 0
        ramChip.text = "RAM  $pct%"
        try {
            val i = registerReceiver(null as BroadcastReceiver?, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            if (t > 0) tempChip.text = "SUHU  ${t / 10}°"
        } catch (e: Exception) {}
    }

    private fun fmtSpeed(bps: Double): String = when {
        bps >= 1024.0 * 1024.0 -> String.format(java.util.Locale.US, "%.1f MB/s", bps / (1024.0 * 1024.0))
        bps >= 1024.0 -> String.format(java.util.Locale.US, "%d KB/s", (bps / 1024.0).toInt())
        else -> "0 KB/s"
    }

    // kecepatan jaringan real-time dari total byte yang masuk/keluar, diperbarui tiap 1 detik
    private val netTick = object : Runnable {
        override fun run() {
            if (!ticking) return
            val rx = android.net.TrafficStats.getTotalRxBytes()
            val tx = android.net.TrafficStats.getTotalTxBytes()
            val now = android.os.SystemClock.elapsedRealtime()
            if (rx >= 0 && tx >= 0 && lastRx >= 0 && now > lastNetT) {
                val dt = (now - lastNetT) / 1000.0
                netDown.text = "↓ " + fmtSpeed(((rx - lastRx).coerceAtLeast(0L)) / dt)
                netUp.text = "↑ " + fmtSpeed(((tx - lastTx).coerceAtLeast(0L)) / dt)
            }
            lastRx = rx; lastTx = tx; lastNetT = now
            h.postDelayed(this, 1000)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!ticking) return
            updateRam()
            refreshAccess()
            h.postDelayed(this, 3000)
        }
    }

    override fun onResume() {
        super.onResume()
        if (openMusic) { openMusic = false; showMusic() }
        if (openNewPlaylist) { openNewPlaylist = false; showNewPlaylistDialog() }
        pendingPick?.let { pendingPick = null; pickSong(it) }
        video.resume()
        ticking = true
        lastRx = -1L
        h.post(tick)
        h.post(netTick)
    }

    override fun onPause() {
        ticking = false
        h.removeCallbacks(tick)
        h.removeCallbacks(netTick)
        video.pause()
        super.onPause()
    }

    override fun onDestroy() {
        try {
            Shizuku.removeBinderReceivedListener(shizukuBinder)
            Shizuku.removeRequestPermissionResultListener(shizukuResult)
        } catch (t: Throwable) {}
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            if (Build.VERSION.SDK_INT >= 30) {
                window.setDecorFitsSystemWindows(false)
                window.insetsController?.let {
                    it.hide(WindowInsets.Type.systemBars())
                    it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            }
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }
}
