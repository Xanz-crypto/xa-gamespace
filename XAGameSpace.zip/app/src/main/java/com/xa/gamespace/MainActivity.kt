package com.xa.gamespace

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

class Tile(u: Ui, icon: String, title: String, click: () -> Unit) {
    val view: LinearLayout = u.vbox()
    private val sub = u.label("", 10f, Theme.sub, true)
    private val ui = u

    init {
        view.gravity = Gravity.CENTER
        view.setPadding(u.dp(6), u.dp(10), u.dp(6), u.dp(10))
        val ic = u.label(icon, 22f)
        ic.gravity = Gravity.CENTER
        val t = u.label(title, 12f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        sub.gravity = Gravity.CENTER
        view.addView(ic)
        view.addView(t, u.lp(t = 4))
        view.addView(sub, u.lp(t = 2))
        view.background = u.glass()
        view.setOnClickListener { click() }
    }

    fun text(s: String) { sub.text = s }

    fun set(on: Boolean) {
        sub.text = if (on) "AKTIF" else "MATI"
        sub.setTextColor(if (on) Theme.good else Theme.sub)
        view.background = if (on) ui.glass(16, Color.argb(160, 40, 22, 10), Theme.accent) else ui.glass()
    }
}

class MainActivity : Activity() {
    lateinit var store: Store
    lateinit var u: Ui
    private lateinit var video: VideoBg
    private lateinit var panelHost: FrameLayout
    private lateinit var gameRow: LinearLayout
    private lateinit var ramChip: TextView
    private lateinit var rootChip: TextView
    private lateinit var tStabil: Tile
    private lateinit var tSmooth: Tile
    private lateinit var tAuto: Tile
    private val h = Handler(Looper.getMainLooper())
    private var ticking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        u = Ui(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        video = VideoBg(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1))

        val left = View(this)
        left.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.argb(210, 5, 6, 10), Color.argb(90, 5, 6, 10), Color.argb(0, 5, 6, 10)))
        root.addView(left, FrameLayout.LayoutParams(-1, -1))
        val bottom = View(this)
        bottom.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
            intArrayOf(Color.argb(230, 4, 5, 8), Color.argb(0, 4, 5, 8)))
        root.addView(bottom, FrameLayout.LayoutParams(-1, -1))

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.isFillViewport = true
        sv.addView(buildMain())
        root.addView(sv, FrameLayout.LayoutParams(-1, -1))

        panelHost = FrameLayout(this)
        panelHost.visibility = View.GONE
        root.addView(panelHost, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        renderGames()
        tStabil.set(store.stabil)
        tSmooth.set(store.smooth)
        tAuto.set(store.auto)

        Thread {
            val ok = Root.check()
            if (ok && !store.active && store.get("cpu_default").isBlank()) {
                store.put("cpu_default", Cpu.serialize(Cpu.read()))
            }
            runOnUiThread {
                rootChip.text = if (ok) "ROOT  ✓" else "ROOT  ✗"
                rootChip.setTextColor(if (ok) Theme.good else Theme.bad)
                if (!ok) toast("Root tidak terdeteksi. Fitur boost butuh akses root.")
            }
        }.start()

        if (store.auto || store.active) GameService.start(this)
    }

    private fun buildMain(): View {
        val col = u.vbox()
        col.setPadding(u.dp(28), u.dp(12), u.dp(28), u.dp(12))

        val top = u.hbox()
        val tb = u.vbox()
        val brand = u.label("XA  GAME  SPACE", 11f, Theme.accent, true)
        brand.letterSpacing = 0.2f
        tb.addView(brand)
        tb.addView(u.label("Siap main?", 24f, Color.WHITE, true))
        top.addView(tb, u.lp(0, -2, 1f))
        rootChip = u.chip("ROOT  …", Theme.sub)
        top.addView(rootChip, u.lp(-2, -2, r = 8))
        ramChip = u.chip("RAM  -", Color.WHITE)
        top.addView(ramChip, u.lp(-2, -2, r = 14))
        val clk = TextClock(this)
        clk.format24Hour = "HH:mm"
        clk.format12Hour = "HH:mm"
        clk.textSize = 18f
        clk.setTextColor(Color.WHITE)
        clk.typeface = android.graphics.Typeface.DEFAULT_BOLD
        top.addView(clk)
        col.addView(top)

        col.addView(View(this), u.lp(1, 0, 1f))

        val gl = u.label("GAME TERDETEKSI", 11f, Theme.sub, true)
        gl.letterSpacing = 0.15f
        col.addView(gl, u.lp(b = 6))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        gameRow = u.hbox()
        hs.addView(gameRow)
        col.addView(hs, u.lp(b = 14))

        tStabil = Tile(u, "🎯", "Stabil FPS") {
            store.stabil = !store.stabil
            tStabil.set(store.stabil)
            reapply()
        }
        tSmooth = Tile(u, "🌊", "Smooth FPS") {
            store.smooth = !store.smooth
            tSmooth.set(store.smooth)
            reapply()
        }
        val tRam = Tile(u, "🧹", "Bersihkan RAM") {}
        tRam.text("Sekali tap")
        tRam.view.setOnClickListener { cleanRam(tRam) }
        tAuto = Tile(u, "🤖", "Auto Game") {
            store.auto = !store.auto
            tAuto.set(store.auto)
            if (store.auto) GameService.start(this)
        }
        val tScan = Tile(u, "🔍", "Scan App") { showPanel("Scan aplikasi latar belakang", ScanPanel(this).root) }
        tScan.text("User + sistem")
        val tCpu = Tile(u, "⚙", "CPU Governor") { showPanel("CPU Governor", CpuPanel(this).root) }
        tCpu.text("Lengkap")

        val row = u.hbox()
        val all = listOf(tStabil, tSmooth, tRam, tAuto, tScan, tCpu)
        all.forEachIndexed { i, t ->
            row.addView(t.view, u.lp(0, -2, 1f, r = if (i < all.size - 1) 8 else 0))
        }
        col.addView(row)
        return col
    }

    private fun reapply() {
        if (store.active) Thread { Boost.refresh(this) }.start()
    }

    private fun cleanRam(t: Tile) {
        toast("Membersihkan RAM...")
        t.text("Memproses...")
        Thread {
            val freed = Boost.cleanRam(this)
            runOnUiThread {
                t.text("+$freed MB")
                toast("RAM dibebaskan $freed MB")
                updateRam()
            }
        }.start()
    }

    fun renderGames() {
        gameRow.removeAllViews()
        Thread {
            val g = Games.detect(this)
            runOnUiThread {
                gameRow.removeAllViews()
                if (g.isEmpty()) {
                    gameRow.addView(u.label("Belum ada game terdeteksi di HP ini.", 13f, Theme.sub))
                }
                g.forEach { gameRow.addView(gameCard(it), u.lp(u.dp(92), u.dp(104), r = 10)) }
            }
        }.start()
    }

    private fun gameCard(g: GameApp): View {
        val c = u.vbox()
        c.gravity = Gravity.CENTER
        c.setPadding(u.dp(6), u.dp(8), u.dp(6), u.dp(8))
        c.background = u.glass()
        val iv = ImageView(this)
        iv.setImageDrawable(g.icon)
        c.addView(iv, u.lp(u.dp(52), u.dp(52)))
        val t = u.label(g.label, 11f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        c.addView(t, u.lp(t = 6))
        c.setOnClickListener { play(g.pkg) }
        return c
    }

    private fun play(pkg: String) {
        val li = packageManager.getLaunchIntentForPackage(pkg)
        if (li == null) { toast("Game tidak bisa dibuka"); return }
        Thread {
            val ok = Root.available()
            runOnUiThread {
                if (ok) GameService.start(this, pkg) else toast("Tanpa root: game dibuka tanpa boost")
                startActivity(li)
            }
        }.start()
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- Panel ----------
    fun showPanel(title: String, body: View) {
        panelHost.removeAllViews()
        val shade = View(this)
        shade.setBackgroundColor(Color.argb(170, 0, 0, 0))
        shade.setOnClickListener { closePanel() }
        panelHost.addView(shade, FrameLayout.LayoutParams(-1, -1))

        val card = u.vbox()
        card.background = u.glass(20, Color.argb(235, 12, 13, 20), Color.argb(80, 255, 255, 255))
        card.setPadding(u.dp(18), u.dp(12), u.dp(18), u.dp(12))
        val head = u.hbox()
        head.addView(u.label(title, 16f, Color.WHITE, true), u.lp(0, -2, 1f))
        val x = u.label("✕", 18f, Color.WHITE, true)
        x.setPadding(u.dp(12), u.dp(4), u.dp(4), u.dp(4))
        x.setOnClickListener { closePanel() }
        head.addView(x)
        card.addView(head, u.lp(b = 8))
        card.addView(body, u.lp(-1, 0, 1f))
        val p = FrameLayout.LayoutParams(-1, -1)
        p.setMargins(u.dp(56), u.dp(12), u.dp(56), u.dp(12))
        panelHost.addView(card, p)
        panelHost.visibility = View.VISIBLE
    }

    fun closePanel() {
        panelHost.visibility = View.GONE
        panelHost.removeAllViews()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panelHost.visibility == View.VISIBLE) closePanel() else super.onBackPressed()
    }

    // ---------- RAM chip ----------
    private fun updateRam() {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val pct = if (mi.totalMem > 0) (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt() else 0
        ramChip.text = "RAM  $pct%"
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!ticking) return
            updateRam()
            h.postDelayed(this, 3000)
        }
    }

    override fun onResume() {
        super.onResume()
        video.resume()
        ticking = true
        h.post(tick)
    }

    override fun onPause() {
        ticking = false
        h.removeCallbacks(tick)
        video.pause()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }
}
