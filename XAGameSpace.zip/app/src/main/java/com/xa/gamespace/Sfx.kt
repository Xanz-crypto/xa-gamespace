package com.xa.gamespace

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.util.concurrent.ConcurrentHashMap

// Efek suara (file WAV di res/raw) lewat SoundPool
object Sfx {
    private var sp: SoundPool? = null
    private val ids = HashMap<String, Int>()
    private val ready: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    @Volatile var enabled = true

    fun init(ctx: Context) {
        if (sp != null) return
        val a = ctx.applicationContext
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { _, id, status -> if (status == 0) ready.add(id) }
        ids["tap"] = p.load(a, R.raw.sfx_tap, 1)
        ids["swipe"] = p.load(a, R.raw.sfx_swipe, 1)
        ids["open"] = p.load(a, R.raw.sfx_open, 1)
        ids["zap"] = p.load(a, R.raw.sfx_zap, 1)
        sp = p
    }

    fun play(key: String, vol: Float = 1f) {
        if (!enabled) return
        val p = sp ?: return
        val id = ids[key] ?: return
        if (id !in ready) return
        try { p.play(id, vol, vol, 1, 0, 1f) } catch (e: Exception) {}
    }

    fun tap() = play("tap", 0.8f)
}
