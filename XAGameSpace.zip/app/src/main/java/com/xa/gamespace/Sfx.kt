package com.xa.gamespace

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.util.concurrent.ConcurrentHashMap

// Efek suara (file WAV di res/raw) lewat SoundPool
object Sfx {
    private var sp: SoundPool? = null
    private val ids = HashMap<String, Int>()
    private val ready: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    @Volatile var enabled = true
    private var app: Context? = null

    fun init(ctx: Context) {
        if (sp != null) return
        val a = ctx.applicationContext
        app = a
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { _, id, status -> if (status == 0) ready.add(id) }
        ids["tap"] = p.load(a, R.raw.sfx_tap, 1)
        ids["swipe"] = p.load(a, R.raw.sfx_swipe, 1)
        ids["open"] = p.load(a, R.raw.sfx_open, 1)
        ids["zap"] = p.load(a, R.raw.sfx_zap, 1)
        ids["water"] = p.load(a, R.raw.sfx_water, 1)
        ids["nubia"] = p.load(a, R.raw.sfx_nubia, 1)
        ids["redmi"] = p.load(a, R.raw.sfx_redmi, 1)
        ids["xiaomi"] = p.load(a, R.raw.sfx_xiaomi, 1)
        ids["realme"] = p.load(a, R.raw.sfx_realme, 1)
        ids["meow"] = p.load(a, R.raw.sfx_meow, 1)
        ids["lick"] = p.load(a, R.raw.sfx_lick, 1)
        ids["mature"] = p.load(a, R.raw.sfx_click_mature, 1)
        sp = p
    }

    fun play(key: String, vol: Float = 1f) {
        if (!enabled) return
        val p = sp ?: return
        val id = ids[key] ?: return
        if (id !in ready) return
        try { p.play(id, vol, vol, 1, 0, 1f) } catch (e: Exception) {}
    }

    fun tap() {
        val c = app ?: return
        val st = Store(c)
        if (!st.soundEnabled) return
        play(st.soundStyle.ifBlank { "mature" }, 0.72f)
    }

    fun event(key: String, vol: Float = 0.9f) {
        val c = app ?: return
        if (!Store(c).soundEnabled) return
        play(key, vol)
    }
}
