package com.xa.gamespace

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.SoundPool
import java.util.concurrent.ConcurrentHashMap

// Efek suara UI. Tiap kejadian (klik / geser / buka panel) bisa dimatikan atau diganti paket suaranya.
object Sfx {
    val packs = listOf(
        "off" to "Mati",
        "classic" to "Klasik",
        "water" to "Air jatuh",
        "cat" to "Kucing meow",
        "nubia" to "Nubia",
        "xiaomi" to "Xiaomi",
        "redmi" to "Redmi",
        "realme" to "Realme",
        "clean" to "Klik bersih"
    )
    val events = listOf("tap" to "Klik fitur", "swipe" to "Geser", "open" to "Buka panel")

    private var sp: SoundPool? = null
    private var prefs: SharedPreferences? = null
    private val ids = HashMap<String, Int>()
    private val ready: MutableSet<Int> = ConcurrentHashMap.newKeySet()

    var enabled: Boolean
        get() = prefs?.getBoolean("master", true) ?: true
        set(v) { prefs?.edit()?.putBoolean("master", v)?.apply() }

    fun init(ctx: Context) {
        if (sp != null) return
        val a = ctx.applicationContext
        prefs = a.getSharedPreferences("xa_sfx", Context.MODE_PRIVATE)
        // suara bawaan sekarang "Air jatuh": pengaturan lama yang masih "Klasik" dikembalikan ke bawaan sekali saja
        if (prefs!!.getInt("default_v", 0) < 2) {
            val ed = prefs!!.edit()
            for ((ev, _) in events) if (prefs!!.getString("pack_$ev", null) == "classic") ed.remove("pack_$ev")
            ed.putInt("default_v", 2).apply()
        }
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { _, id, status ->
            if (status == 0) {
                ready.add(id)
                // suara kipas diminta sebelum selesai dimuat: mulai sekarang
                if (id == fanId && fanWanted) fanStart()
            }
        }
        val fanRes = a.resources.getIdentifier("sfx_fan_loop", "raw", a.packageName)
        if (fanRes != 0) fanId = p.load(a, fanRes, 1)
        for ((pk, _) in packs) {
            if (pk == "off") continue
            for ((ev, _) in events) {
                val res = a.resources.getIdentifier("sfx_${pk}_$ev", "raw", a.packageName)
                if (res != 0) ids["${pk}_$ev"] = p.load(a, res, 1)
            }
        }
        sp = p
    }

    fun pack(ev: String): String = prefs?.getString("pack_$ev", "water") ?: "water"

    fun setPack(ev: String, pk: String) { prefs?.edit()?.putString("pack_$ev", pk)?.apply() }

    private fun fire(id: Int?, vol: Float) {
        val p = sp ?: return
        if (id == null || id !in ready) return
        try { p.play(id, vol, vol, 1, 0, 1f) } catch (e: Exception) {}
    }

    // key: tap | swipe | open (ikut pengaturan paket suara)
    fun play(key: String, vol: Float = 1f) {
        if (!enabled) return
        val pk = pack(key)
        if (pk == "off") return
        fire(ids["${pk}_$key"], vol)
    }

    // contoh suara saat memilih paket (tetap bunyi walau paket lain dimatikan)
    fun preview(ev: String, pk: String) {
        if (pk == "off") return
        fire(ids["${pk}_$ev"], 1f)
    }

    fun tap() = play("tap", 0.8f)

    // ---------- suara kipas (loop ringan, bisa di-on/off dengan mengetuk kipas) ----------
    private var fanId = -1
    private var fanStream = 0
    private var fanWanted = false      // kipas sedang tampil dan ingin berbunyi
    private var fanRate = 1f

    // pilihan pengguna: suara kipas menyala / mati (bawaan: menyala)
    var fanSound: Boolean
        get() = prefs?.getBoolean("fan_sound", true) ?: true
        set(v) { prefs?.edit()?.putBoolean("fan_sound", v)?.apply() }

    private const val FAN_VOL = 0.28f   // sengaja pelan

    fun fanStart() {
        fanWanted = true
        val p = sp ?: return
        if (fanStream != 0 || !enabled || !fanSound) return
        if (fanId < 0 || fanId !in ready) return     // belum selesai dimuat; dimulai dari listener
        try { fanStream = p.play(fanId, FAN_VOL, FAN_VOL, 1, -1, fanRate) } catch (e: Exception) {}
    }

    fun fanStop() {
        fanWanted = false
        fanHalt()
    }

    private fun fanHalt() {
        val p = sp
        if (p != null && fanStream != 0) { try { p.stop(fanStream) } catch (e: Exception) {} }
        fanStream = 0
    }

    // dipanggil saat pengguna mengetuk kipas; mengembalikan keadaan baru (true = bersuara)
    fun fanToggle(): Boolean {
        val on = !fanSound
        fanSound = on
        if (on) { fanStart() } else fanHalt()
        return on
    }

    // makin cepat kipas, makin tinggi nada (0.8x - 1.5x)
    fun fanSpeed(speedDegPerSec: Float) {
        val r = (0.8f + (speedDegPerSec - 260f) / 840f * 0.7f).coerceIn(0.8f, 1.5f)
        if (kotlin.math.abs(r - fanRate) < 0.03f) return
        fanRate = r
        val p = sp ?: return
        if (fanStream != 0) { try { p.setRate(fanStream, r) } catch (e: Exception) {} }
    }
}
