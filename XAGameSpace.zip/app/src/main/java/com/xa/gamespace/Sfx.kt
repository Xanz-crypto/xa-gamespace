package com.xa.gamespace

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.SoundPool
import java.util.concurrent.ConcurrentHashMap

// Efek suara UI. Tiap kejadian (klik / geser / buka panel) bisa dimatikan atau diganti paket suaranya.
object Sfx {
    val packs = listOf(
        "off" to "Mati",
        "classic" to "Klasik",
        "water" to "Air jatuh",
        "cat" to "Kucing meow",
        "nubia" to "Nubia",
        "xiaomi" to "Xiaomi",
        "redmi" to "Redmi",
        "realme" to "Realme",
        "clean" to "Klik bersih"
    )
    val events = listOf("tap" to "Klik fitur", "swipe" to "Geser", "open" to "Buka panel")

    private var sp: SoundPool? = null
    private var prefs: SharedPreferences? = null
    private val ids = HashMap<String, Int>()
    private val ready: MutableSet<Int> = ConcurrentHashMap.newKeySet()

    var enabled: Boolean
        get() = prefs?.getBoolean("master", true) ?: true
        set(v) { prefs?.edit()?.putBoolean("master", v)?.apply() }

    fun init(ctx: Context) {
        if (sp != null) return
        val a = ctx.applicationContext
        prefs = a.getSharedPreferences("xa_sfx", Context.MODE_PRIVATE)
        // suara bawaan sekarang "Air jatuh": pengaturan lama yang masih "Klasik" dikembalikan ke bawaan sekali saja
        if (prefs!!.getInt("default_v", 0) < 2) {
            val ed = prefs!!.edit()
            for ((ev, _) in events) if (prefs!!.getString("pack_$ev", null) == "classic") ed.remove("pack_$ev")
            ed.putInt("default_v", 2).apply()
        }
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { _, id, status -> if (status == 0) ready.add(id) }
        for ((pk, _) in packs) {
            if (pk == "off") continue
            for ((ev, _) in events) {
                val res = a.resources.getIdentifier("sfx_${pk}_$ev", "raw", a.packageName)
                if (res != 0) ids["${pk}_$ev"] = p.load(a, res, 1)
            }
        }
        sp = p
    }

    fun pack(ev: String): String = prefs?.getString("pack_$ev", "water") ?: "water"

    fun setPack(ev: String, pk: String) { prefs?.edit()?.putString("pack_$ev", pk)?.apply() }

    private fun fire(id: Int?, vol: Float) {
        val p = sp ?: return
        if (id == null || id !in ready) return
        try { p.play(id, vol, vol, 1, 0, 1f) } catch (e: Exception) {}
    }

    // key: tap | swipe | open (ikut pengaturan paket suara)
    fun play(key: String, vol: Float = 1f) {
        if (!enabled) return
        val pk = pack(key)
        if (pk == "off") return
        fire(ids["${pk}_$key"], vol)
    }

    // contoh suara saat memilih paket (tetap bunyi walau paket lain dimatikan)
    fun preview(ev: String, pk: String) {
        if (pk == "off") return
        fire(ids["${pk}_$ev"], 1f)
    }

    fun tap() = play("tap", 0.8f)
}
