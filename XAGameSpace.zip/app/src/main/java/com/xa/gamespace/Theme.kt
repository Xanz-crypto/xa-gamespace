package com.xa.gamespace

import android.graphics.Color

object Theme {
    var accent = Color.parseColor("#00E58F")
    var accent2 = Color.parseColor("#00B8FF")
    val bg = Color.parseColor("#07080D")
    val card = Color.parseColor("#12141C")
    val tile = Color.parseColor("#181B25")
    val stroke = Color.parseColor("#252A3A")
    val text = Color.WHITE
    val sub = Color.parseColor("#8A90A6")
    val good = Color.parseColor("#2BE3A0")
    val warn = Color.parseColor("#FFC24B")
    val bad = Color.parseColor("#FF4D6D")
    val onAccent = Color.parseColor("#04110C")

    val palettes = linkedMapOf(
        "Hijau" to ("#00E58F" to "#00B8FF"),
        "Ungu" to ("#B388FF" to "#6C63FF"),
        "Merah" to ("#FF4D6D" to "#FF8A4B"),
        "Emas" to ("#FFC24B" to "#FF8A4B")
    )

    fun apply(name: String) {
        val p = palettes[name] ?: palettes["Hijau"]!!
        accent = Color.parseColor(p.first)
        accent2 = Color.parseColor(p.second)
    }
}
