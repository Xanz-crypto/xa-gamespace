package com.xa.gamespace

import android.content.Context

// Buka kunci sementara: semua fitur terkunci aktif sampai waktu tertentu
object Unlock {
    private const val KEY = "unlock_until"
    const val ONE_DAY = 24L * 60 * 60 * 1000
    const val FIVE_DAYS = 5L * 24 * 60 * 60 * 1000

    fun until(ctx: Context): Long = Store(ctx).get(KEY).toLongOrNull() ?: 0L

    fun active(ctx: Context): Boolean = System.currentTimeMillis() < until(ctx)

    // tambah durasi dari waktu sekarang (atau dari sisa waktu yang masih aktif)
    fun grant(ctx: Context, ms: Long) {
        val base = maxOf(System.currentTimeMillis(), until(ctx))
        Store(ctx).put(KEY, (base + ms).toString())
    }

    fun remainingText(ctx: Context): String {
        val left = until(ctx) - System.currentTimeMillis()
        if (left <= 0) return "Belum aktif"
        val h = left / 3600000
        val m = (left % 3600000) / 60000
        return "Aktif: sisa ${h} jam ${m} menit"
    }
}
