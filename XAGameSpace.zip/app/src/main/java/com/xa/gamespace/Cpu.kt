package com.xa.gamespace

data class Policy(
    val path: String,
    val name: String,
    val govs: List<String>,
    val freqs: List<Long>,
    val gov: String,
    val min: Long,
    val max: Long,
    val cur: Long,
    val hwMin: Long,
    val hwMax: Long
)

object Cpu {
    private const val READ = """
L=/sys/devices/system/cpu/cpufreq/policy*
[ -d /sys/devices/system/cpu/cpufreq/policy0 ] || L=/sys/devices/system/cpu/cpu[0-9]*/cpufreq
for p in §L; do
  [ -d §p ] || continue
  echo "P|§p|§(cat §p/related_cpus 2>/dev/null)|§(cat §p/scaling_available_governors 2>/dev/null)|§(cat §p/scaling_available_frequencies 2>/dev/null)|§(cat §p/scaling_governor 2>/dev/null)|§(cat §p/scaling_min_freq 2>/dev/null)|§(cat §p/scaling_max_freq 2>/dev/null)|§(cat §p/scaling_cur_freq 2>/dev/null)|§(cat §p/cpuinfo_min_freq 2>/dev/null)|§(cat §p/cpuinfo_max_freq 2>/dev/null)"
done
"""

    fun read(): List<Policy> {
        val out = Root.run(READ.replace('§', '$'))
        val list = ArrayList<Policy>()
        for (line in out.lines()) {
            if (!line.startsWith("P|")) continue
            val f = line.split("|")
            if (f.size < 11) continue
            val path = f[1]
            val cpus = f[2].trim().split(Regex("\\s+")).mapNotNull { it.toIntOrNull() }.sorted()
            val name = when {
                cpus.size > 1 -> "CPU ${cpus.first()}-${cpus.last()}"
                cpus.size == 1 -> "CPU ${cpus[0]}"
                else -> "CPU " + (Regex("cpu(\\d+)").find(path)?.groupValues?.get(1) ?: path.substringAfterLast("policy"))
            }
            val hwMin = f[9].trim().toLongOrNull() ?: 0L
            val hwMax = f[10].trim().toLongOrNull() ?: 0L
            var freqs = f[4].trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }.distinct().sorted()
            if (freqs.isEmpty() && hwMax > 0) freqs = listOf(hwMin, hwMax).distinct().sorted()
            list.add(
                Policy(
                    path, name,
                    f[3].trim().split(Regex("\\s+")).filter { it.isNotEmpty() },
                    freqs, f[5].trim(),
                    f[6].trim().toLongOrNull() ?: 0L,
                    f[7].trim().toLongOrNull() ?: 0L,
                    f[8].trim().toLongOrNull() ?: 0L,
                    hwMin, hwMax
                )
            )
        }
        return list.sortedBy { it.hwMax }
    }

    private fun w(file: String, v: Any) = "chmod 0644 $file 2>/dev/null; echo $v > $file"

    // urutan max-min-max supaya aman saat menaikkan atau menurunkan rentang
    fun rangeCmd(path: String, min: Long, max: Long): String =
        listOf(w("$path/scaling_max_freq", max), w("$path/scaling_min_freq", min), w("$path/scaling_max_freq", max))
            .joinToString("; ")

    fun govCmd(path: String, gov: String): String = w("$path/scaling_governor", gov)

    fun apply(cmds: List<String>) {
        if (cmds.isNotEmpty()) Root.run(cmds.joinToString("; "))
    }

    // simpan / pulihkan kondisi awal CPU
    fun serialize(l: List<Policy>): String =
        l.joinToString(";") { "${it.path}|${it.gov}|${it.min}|${it.max}" }

    fun restoreCmds(saved: String): List<String> = saved.split(";").mapNotNull {
        val p = it.split("|")
        if (p.size == 4 && p[0].isNotBlank()) {
            val mn = p[2].toLongOrNull()
            val mx = p[3].toLongOrNull()
            val c = ArrayList<String>()
            if (p[1].isNotBlank()) c.add(govCmd(p[0], p[1]))
            if (mn != null && mx != null) c.add(rangeCmd(p[0], mn, mx))
            c.joinToString("; ")
        } else null
    }

    fun fmt(khz: Long): String =
        if (khz >= 1_000_000) String.format("%.2f GHz", khz / 1_000_000.0) else "${khz / 1000} MHz"
}
