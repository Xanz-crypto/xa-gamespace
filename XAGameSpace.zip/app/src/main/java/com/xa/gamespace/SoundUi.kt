package com.xa.gamespace

import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView

// Pengaturan suara UI: klik, geser, buka panel -> mati / ganti paket suara
class SoundSettingsPanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box = u.vbox()

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        render()
    }

    private fun chips(opts: List<Pair<String, String>>, cur: String, pick: (String) -> Unit): View {
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        val l = u.hbox()
        for ((v, label) in opts) {
            val on = v == cur
            val t = u.label(label, 12f, if (on) Color.parseColor("#04141F") else Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(u.dp(12), u.dp(7), u.dp(12), u.dp(7))
            t.background = if (on) u.glass(20, Hud.cyan, Hud.cyan)
            else u.glass(20, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
            t.setOnClickListener { pick(v) }
            l.addView(t, u.lp(-2, -2, r = 6))
        }
        hs.addView(l)
        return hs
    }

    private fun render() {
        box.removeAllViews()
        val master = Sfx.enabled
        box.addView(chips(listOf("on" to "Semua suara: AKTIF", "off" to "Semua suara: MATI"),
            if (master) "on" else "off") {
            Sfx.enabled = it == "on"
            if (Sfx.enabled) Sfx.tap()
            render()
        }, u.lp(b = 10))
        for ((ev, title) in Sfx.events) {
            box.addView(u.label(title.uppercase(), 11f, Theme.sub, true), u.lp(b = 4))
            box.addView(chips(Sfx.packs, Sfx.pack(ev)) { pk ->
                Sfx.setPack(ev, pk)
                Sfx.preview(ev, pk)
                render()
            }, u.lp(b = 10))
        }
        box.addView(u.label("Ketuk pilihan untuk mendengar contohnya. Suara Nubia, Xiaomi, Redmi, dan Realme " +
            "adalah suara buatan sendiri bergaya game booster, bukan rekaman asli merek tersebut.", 10f, Theme.sub))
    }
}

// Satu menu "Suara": tab Suara UI dan tab Mixer volume
class SoundHub(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val body = FrameLayout(a)
    private val tabs = u.hbox()
    private val names = listOf("Suara UI", "Mixer volume")
    private var cur = -1
    private var ui: SoundSettingsPanel? = null
    private var mixer: SoundPanel? = null

    init {
        root.addView(tabs, u.lp(b = 8))
        root.addView(body, u.lp(-1, 0, 1f))
        show(0)
    }

    private fun show(i: Int) {
        if (cur == i) return
        cur = i
        tabs.removeAllViews()
        names.forEachIndexed { k, n ->
            val on = k == i
            val t = u.label(n, 12f, if (on) Color.parseColor("#04141F") else Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(u.dp(14), u.dp(7), u.dp(14), u.dp(7))
            t.background = if (on) u.glass(20, Hud.cyan, Hud.cyan)
            else u.glass(20, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
            t.setOnClickListener { Sfx.tap(); show(k) }
            tabs.addView(t, u.lp(-2, -2, r = 8))
        }
        body.removeAllViews()
        val v: View = if (i == 0) {
            if (ui == null) ui = SoundSettingsPanel(a)
            ui!!.root
        } else {
            if (mixer == null) mixer = SoundPanel(a)
            mixer!!.root
        }
        (v.parent as? android.view.ViewGroup)?.removeView(v)
        body.addView(v, FrameLayout.LayoutParams(-1, -1))
    }
}
