package com.xa.gamespace

import android.content.Context
import android.content.Intent

object Boost {
    // key, label, default
    val FLAGS = listOf(
        Triple("cpu", "CPU mode performa", true),
        Triple("gpu", "GPU mode performa", true),
        Triple("fixed", "Fixed performance mode (Android 12+)", true),
        Triple("gamemode", "Game mode sistem (Android 12+)", true),
        Triple("ram", "Bersihkan RAM saat boost", true),
        Triple("bg", "Hentikan aplikasi latar belakang", true),
        Triple("dnd", "Jangan ganggu (DND)", true),
        Triple("lowpower", "Matikan mode hemat baterai", true),
        Triple("anim", "Matikan animasi sistem", false)
    )

    private const val CPU = "/sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor"
    private const val GPU = "/sys/class/kgsl/kgsl-3d0/devfreq/governor /sys/class/devfreq/*gpu*/governor /sys/class/devfreq/*mali*/governor"
    private val ANIMS = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")

    private fun readGov(glob: String): String =
        Root.run("for f in $glob; do [ -f \$f ] && echo \"\$f \$(cat \$f)\"; done")

    private fun setGov(glob: String, value: String): String =
        "for f in $glob; do [ -f \$f ] && echo $value > \$f; done"

    private fun restoreGov(saved: String): String =
        saved.lines().mapNotNull {
            val p = it.trim().split(" ")
            if (p.size == 2) "echo ${p[1]} > ${p[0]}" else null
        }.joinToString("; ")

    private fun clean(v: String, def: String) = if (v.isBlank() || v == "null") def else v

    fun on(ctx: Context, game: String?) {
        val s = Store(ctx)
        if (!s.active) {
            s.save("cpu", readGov(CPU))
            s.save("gpu", readGov(GPU))
            s.save("zen", clean(Root.run("settings get global zen_mode"), "0"))
            s.save("lp", clean(Root.run("settings get global low_power"), "0"))
            s.save("anim", ANIMS.joinToString(";") { it + "=" + clean(Root.run("settings get global $it"), "1.0") })
        }
        s.active = true
        s.game = game

        val c = ArrayList<String>()
        if (s.flag("cpu")) c.add(setGov(CPU, "performance"))
        if (s.flag("gpu")) c.add(setGov(GPU, "performance"))
        if (s.flag("fixed")) c.add("cmd power set-fixed-performance-mode-enabled true")
        if (s.flag("gamemode") && game != null) c.add("cmd game mode performance $game")
        if (s.flag("dnd")) c.add("settings put global zen_mode 1")
        if (s.flag("lowpower")) c.add("settings put global low_power 0")
        if (s.flag("anim")) ANIMS.forEach { c.add("settings put global $it 0") }
        if (c.isNotEmpty()) Root.run(c.joinToString("; "))

        if (s.flag("bg")) killBackground(ctx, game)
        if (s.flag("ram")) cleanRam()
    }

    fun off(ctx: Context) {
        val s = Store(ctx)
        if (!s.active) return
        val c = ArrayList<String>()
        c.add(restoreGov(s.saved("cpu")))
        c.add(restoreGov(s.saved("gpu")))
        c.add("cmd power set-fixed-performance-mode-enabled false")
        s.game?.let { c.add("cmd game mode standard $it") }
        c.add("settings put global zen_mode ${s.saved("zen").ifBlank { "0" }}")
        c.add("settings put global low_power ${s.saved("lp").ifBlank { "0" }}")
        s.saved("anim").split(";").forEach {
            val p = it.split("=")
            if (p.size == 2) c.add("settings put global ${p[0]} ${p[1]}")
        }
        Root.run(c.filter { it.isNotBlank() }.joinToString("; "))
        s.active = false
        s.game = null
    }

    fun cleanRam() {
        Root.run("sync; echo 3 > /proc/sys/vm/drop_caches; am kill-all")
    }

    fun killBackground(ctx: Context, keepGame: String?): Int {
        val pm = ctx.packageManager
        val running = Root.run("ps -A -o NAME").lines().map { it.trim() }
        val third = Root.run("pm list packages -3").lines()
            .map { it.removePrefix("package:").trim() }.filter { it.isNotEmpty() }
        val ime = Root.run("settings get secure default_input_method").substringBefore('/').trim()
        val home = pm.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName ?: ""
        val skip = Store(ctx).games + setOf(ctx.packageName, ime, home, keepGame ?: "")
        val targets = third.filter { p ->
            p !in skip && running.any { it == p || it.startsWith("$p:") }
        }
        if (targets.isNotEmpty()) Root.run(targets.joinToString("; ") { "am force-stop $it" })
        return targets.size
    }
}
