package com.xa.gamespace

import android.content.Context
import android.content.Intent

object Boost {
    // key, label, default
    val FLAGS = listOf(
        Triple("cpu", "CPU mode performa", true),
        Triple("gpu", "GPU mode performa", true),
        Triple("fixed", "Fixed performance mode", true),
        Triple("gamemode", "Game mode sistem", true),
        Triple("ram", "Bersihkan RAM", true),
        Triple("bg", "Hentikan aplikasi latar", true),
        Triple("dnd", "Jangan ganggu (DND)", true),
        Triple("lowpower", "Matikan hemat baterai", true),
        Triple("anim", "Matikan animasi sistem", false)
    )
    val DESC = mapOf(
        "cpu" to "Governor semua core ke performance",
        "gpu" to "Governor GPU ke performance (jika didukung)",
        "fixed" to "Android 12+, kunci performa tetap",
        "gamemode" to "Android 12+, profil game bawaan sistem",
        "ram" to "Kosongkan cache dan proses cache",
        "bg" to "Force stop aplikasi pihak ketiga yang berjalan",
        "dnd" to "Blokir notifikasi pengganggu saat main",
        "lowpower" to "Pastikan hemat baterai tidak membatasi CPU",
        "anim" to "Animasi 0x supaya UI terasa lebih cepat"
    )
    val MODES = listOf("Hemat", "Seimbang", "Performa", "Kustom")

    private const val CPU = "/sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor"
    private const val GPU = "/sys/class/kgsl/kgsl-3d0/devfreq/governor /sys/class/devfreq/*gpu*/governor /sys/class/devfreq/*mali*/governor"
    private val ANIMS = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")

    fun enabled(s: Store, mode: String, k: String): Boolean = when (mode) {
        "Hemat" -> k == "ram" || k == "dnd"
        "Seimbang" -> k in setOf("ram", "bg", "dnd", "lowpower", "fixed")
        "Performa" -> k != "anim"
        else -> s.flag(k)
    }

    private fun readGov(glob: String): String =
        Root.run("for f in $glob; do [ -f \$f ] && echo \"\$f \$(cat \$f)\"; done")

    private fun setGov(glob: String, value: String): String =
        "for f in $glob; do [ -f \$f ] && echo $value > \$f; done"

    private fun restoreGov(saved: String): String =
        saved.lines().mapNotNull {
            val p = it.trim().split(" ")
            if (p.size == 2) "echo ${p[1]} > ${p[0]}" else null
        }.joinToString("; ")

    private fun clean(v: String, def: String) = if (v.isBlank() || v == "null") def else v

    fun on(ctx: Context, game: String?) {
        val s = Store(ctx)
        val mode = game?.let { s.gameMode(it) } ?: "Kustom"
        fun en(k: String) = enabled(s, mode, k)

        if (!s.active) {
            s.save("cpu", readGov(CPU))
            s.save("gpu", readGov(GPU))
            s.save("zen", clean(Root.run("settings get global zen_mode"), "0"))
            s.save("lp", clean(Root.run("settings get global low_power"), "0"))
            s.save("anim", ANIMS.joinToString(";") { it + "=" + clean(Root.run("settings get global $it"), "1.0") })
        }
        s.active = true
        s.game = game

        val c = ArrayList<String>()
        if (en("cpu")) c.add(setGov(CPU, "performance"))
        if (en("gpu")) c.add(setGov(GPU, "performance"))
        if (en("fixed")) c.add("cmd power set-fixed-performance-mode-enabled true")
        if (en("gamemode") && game != null) c.add("cmd game mode performance $game")
        if (en("dnd")) c.add("settings put global zen_mode 1")
        if (en("lowpower")) c.add("settings put global low_power 0")
        if (en("anim")) ANIMS.forEach { c.add("settings put global $it 0") }
        if (c.isNotEmpty()) Root.run(c.joinToString("; "))

        if (en("bg")) killBackground(ctx, game)
        if (en("ram")) cleanRam()
    }

    fun off(ctx: Context) {
        val s = Store(ctx)
        if (!s.active) return
        val c = ArrayList<String>()
        c.add(restoreGov(s.saved("cpu")))
        c.add(restoreGov(s.saved("gpu")))
        c.add("cmd power set-fixed-performance-mode-enabled false")
        s.game?.let { c.add("cmd game mode standard $it") }
        c.add("settings put global zen_mode ${s.saved("zen").ifBlank { "0" }}")
        c.add("settings put global low_power ${s.saved("lp").ifBlank { "0" }}")
        s.saved("anim").split(";").forEach {
            val p = it.split("=")
            if (p.size == 2) c.add("settings put global ${p[0]} ${p[1]}")
        }
        Root.run(c.filter { it.isNotBlank() }.joinToString("; "))
        s.active = false
        s.game = null
    }

    fun cleanRam() {
        Root.run("sync; echo 3 > /proc/sys/vm/drop_caches; am kill-all")
    }

    fun killBackground(ctx: Context, keepGame: String?): Int {
        val pm = ctx.packageManager
        val running = Root.run("ps -A -o NAME").lines().map { it.trim() }
        val third = Root.run("pm list packages -3").lines()
            .map { it.removePrefix("package:").trim() }.filter { it.isNotEmpty() }
        val ime = Root.run("settings get secure default_input_method").substringBefore('/').trim()
        val home = pm.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName ?: ""
        val skip = Store(ctx).games + setOf(ctx.packageName, ime, home, keepGame ?: "")
        val targets = third.filter { p ->
            p !in skip && running.any { it == p || it.startsWith("$p:") }
        }
        if (targets.isNotEmpty()) Root.run(targets.joinToString("; ") { "am force-stop $it" })
        return targets.size
    }
}
