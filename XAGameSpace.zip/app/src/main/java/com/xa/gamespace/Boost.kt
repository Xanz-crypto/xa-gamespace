package com.xa.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.WindowManager

data class RunApp(val pkg: String, val label: String, val system: Boolean, val memMb: Int, var selected: Boolean)

object Boost {
    private val lock = Any()

    private val PROTECT = listOf(
        "com.android.systemui", "com.android.phone", "com.android.providers.", "com.android.server.",
        "com.android.bluetooth", "com.android.nfc", "com.android.shell", "com.android.inputmethod",
        "com.android.networkstack", "com.android.permissioncontroller", "com.android.location",
        "com.android.settings", "com.android.launcher", "com.android.cellbroadcast",
        "com.android.carrierconfig", "com.android.stk", "com.android.se", "com.android.vending",
        "com.google.android.gms", "com.google.android.gsf", "com.google.android.inputmethod",
        "com.google.android.permissioncontroller", "com.google.android.networkstack",
        "com.google.android.ext", "com.qualcomm", "com.qti", "org.codeaurora", "com.mediatek",
        "vendor.", "com.miui.core", "com.miui.system", "com.miui.home", "com.miui.powerkeeper",
        "com.xiaomi.xmsf", "com.samsung.android.incallui", "com.samsung.android.dialer",
        "com.sec.android.app.launcher", "com.samsung.android.app.telephonyui"
    )

    private fun fixedProtect(ctx: Context): Set<String> {
        val s = HashSet<String>()
        s.add(ctx.packageName)
        val pm = ctx.packageManager
        try {
            pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
                ?.activityInfo?.packageName?.let { s.add(it) }
        } catch (e: Exception) {}
        try {
            val ime = android.provider.Settings.Secure.getString(ctx.contentResolver, "default_input_method")
            ime?.substringBefore('/')?.let { s.add(it) }
        } catch (e: Exception) {}
        try {
            (ctx.getSystemService(Context.TELECOM_SERVICE) as? android.telecom.TelecomManager)
                ?.defaultDialerPackage?.let { s.add(it) }
        } catch (e: Exception) {}
        return s
    }

    private fun isProtected(p: String, fixed: Set<String>): Boolean =
        p in fixed || p == "android" || p.startsWith("android.") || PROTECT.any { p.startsWith(it) }

    // ---------- Scan aplikasi berjalan (user + sistem) ----------
    fun scan(ctx: Context, keep: String?): List<RunApp> {
        val pm = ctx.packageManager
        val installed = HashMap<String, android.content.pm.ApplicationInfo>()
        try { pm.getInstalledApplications(0).forEach { installed[it.packageName] = it } } catch (e: Exception) {}
        var out = Root.run("ps -A -o NAME,RSS 2>/dev/null")
        val mem = HashMap<String, Long>()
        if (out.isBlank() || !out.contains(Regex("\\d"))) {
            out = Root.run("ps")
            for (l in out.lines()) {
                val t = l.trim().split(Regex("\\s+"))
                if (t.size >= 8) mem[t.last().substringBefore(':')] =
                    (mem[t.last().substringBefore(':')] ?: 0L) + (t[4].toLongOrNull() ?: 0L)
            }
        } else {
            for (l in out.lines()) {
                val t = l.trim().split(Regex("\\s+"))
                if (t.size >= 2) {
                    val n = t[0].substringBefore(':')
                    mem[n] = (mem[n] ?: 0L) + (t[1].toLongOrNull() ?: 0L)
                }
            }
        }
        val fixed = fixedProtect(ctx)
        val list = ArrayList<RunApp>()
        for ((p, kb) in mem) {
            val ai = installed[p] ?: continue
            if (isProtected(p, fixed) || p == keep) continue
            val sys = (ai.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
            list.add(RunApp(p, ai.loadLabel(pm).toString(), sys, (kb / 1024).toInt(), true))
        }
        return list.sortedByDescending { it.memMb }
    }

    fun stop(pkgs: List<String>) {
        if (pkgs.isNotEmpty()) Root.run(pkgs.joinToString("; ") { "am force-stop $it" })
    }

    fun killBackground(ctx: Context, keep: String?): Int {
        val t = scan(ctx, keep)
        stop(t.map { it.pkg })
        return t.size
    }

    // ---------- Bersihkan RAM ----------
    private fun availMb(ctx: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.availMem / 1048576
    }

    fun cleanRam(ctx: Context, keep: String? = null): Long {
        val before = availMb(ctx)
        Root.run("sync; echo 3 > /proc/sys/vm/drop_caches; am kill-all")
        val user = scan(ctx, keep).filter { !it.system }
        stop(user.map { it.pkg })
        try { Thread.sleep(800) } catch (e: InterruptedException) {}
        return (availMb(ctx) - before).coerceAtLeast(0)
    }

    // ---------- GPU ----------
    private const val GPU_READ = """
for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*gpu* /sys/class/devfreq/*mali*; do
  [ -f §d/min_freq ] || continue
  echo "G|§d|§(cat §d/min_freq 2>/dev/null)|§(cat §d/max_freq 2>/dev/null)|§(cat §d/available_frequencies 2>/dev/null)"
done
"""

    private fun readGpu(): List<List<String>> =
        Root.run(GPU_READ.replace('§', '$')).lines().filter { it.startsWith("G|") }.map { it.split("|") }

    private fun refreshMax(ctx: Context): Int {
        return try {
            if (Build.VERSION.SDK_INT >= 23) {
                val d = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay
                d.supportedModes.maxOf { it.refreshRate }.toInt().coerceAtLeast(60)
            } else 60
        } catch (e: Exception) { 60 }
    }

    private val REFRESH_KEYS = listOf("min_refresh_rate", "peak_refresh_rate", "user_refresh_rate")

    private fun readSettings(): String = Root.run(
        REFRESH_KEYS.joinToString("; ") { "echo \"system|$it|\$(settings get system $it)\"" } +
            "; echo \"global|low_power|\$(settings get global low_power)\""
    )

    private fun restoreSettings(saved: String): List<String> = saved.lines().mapNotNull {
        val p = it.trim().split("|")
        if (p.size == 3) {
            if (p[2].isBlank() || p[2] == "null") "settings delete ${p[0]} ${p[1]}"
            else "settings put ${p[0]} ${p[1]} ${p[2]}"
        } else null
    }

    // ---------- Boost ON / OFF ----------
    fun on(ctx: Context, game: String?) { synchronized(lock) {
        val s = Store(ctx)
        val cpu = Cpu.read()
        val gpu = readGpu()
        if (!s.active) {
            s.put("snap_cpu", Cpu.serialize(cpu))
            s.put("snap_gpu", gpu.joinToString(";") { "${it[1]}|${it[2]}" })
            s.put("snap_set", readSettings())
            s.put("snap_gpu2", Gpu.serialize(Gpu.read()))
        }
        s.active = true
        s.game = game

        val c = ArrayList<String>()
        if (s.stabil && Access.isRoot) {
            // Stabil FPS (khusus root): kunci batas bawah frekuensi supaya clock tidak naik turun
            val top = cpu.maxByOrNull { it.hwMax }?.path
            for (p in cpu) {
                val usable = p.freqs.filter { it <= p.max }
                if (usable.isEmpty()) continue
                val ratio = if (p.path == top && cpu.size > 2) 0.5 else 0.65
                val floor = usable[((usable.size - 1) * ratio + 0.5).toInt().coerceIn(0, usable.size - 1)]
                c.add(Cpu.rangeCmd(p.path, floor, p.max))
            }
            for (g in gpu) {
                val mx = g[3].trim().toLongOrNull() ?: continue
                val fr = g.getOrElse(4) { "" }.trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }
                    .filter { it <= mx }.sorted()
                if (fr.isEmpty()) continue
                val floor = fr[((fr.size - 1) * 0.5 + 0.5).toInt().coerceIn(0, fr.size - 1)]
                c.add("chmod 0644 ${g[1]}/min_freq 2>/dev/null; echo $floor > ${g[1]}/min_freq")
            }
            c.add("cmd power set-fixed-performance-mode-enabled true")
        }
        if (s.smooth) {
            // Smooth FPS: refresh rate maksimum, game mode performa, hemat baterai mati
            val hz = refreshMax(ctx)
            c.add("settings put system min_refresh_rate $hz")
            c.add("settings put system peak_refresh_rate $hz")
            c.add("settings put system user_refresh_rate $hz")
            c.add("settings put global low_power 0")
            if (game != null) c.add("cmd game mode performance $game")
        }
        if (game != null) {
            val gc = s.get("gc_$game")
            if (gc.isNotBlank()) c.add(gc)
            val tx = s.get("tex_$game")
            if (tx.isNotBlank()) c.add(Texture.applyCmd(ctx, game, tx))
        }
        if (c.isNotEmpty()) Root.run(c.joinToString("\n"))
        if (s.touch || s.touchSmooth) TouchOpt.apply(ctx, s.touch, s.touchSmooth, s.touchAnim)
        if (s.get("wifi_lock") != "0") NetOpt.holdWifi(ctx, true)
        // RAM TIDAK dibersihkan otomatis saat game dibuka.
        // Pembersihan hanya manual (tombol Clean RAM / Stop App di Game Panel atau menu utama).
    } }

    fun off(ctx: Context) { synchronized(lock) {
        val s = Store(ctx)
        if (!s.active) return@synchronized
        val c = ArrayList<String>()
        c.addAll(Cpu.restoreCmds(s.get("snap_cpu")))
        s.get("snap_gpu").split(";").forEach {
            val p = it.split("|")
            if (p.size == 2 && p[1].isNotBlank()) c.add("chmod 0644 ${p[0]}/min_freq 2>/dev/null; echo ${p[1]} > ${p[0]}/min_freq")
        }
        c.addAll(Gpu.restoreCmds(s.get("snap_gpu2")))
        c.add("cmd power set-fixed-performance-mode-enabled false")
        c.addAll(restoreSettings(s.get("snap_set")))
        s.game?.let {
            if (s.get("gc_$it").isNotBlank()) c.add("cmd game reset $it")
            if (s.get("tex_$it").isNotBlank()) c.add(Texture.resetCmd(ctx, it))
            c.add("cmd game mode standard $it")
        }
        Root.run(c.filter { it.isNotBlank() }.joinToString("\n"))
        TouchOpt.restore(ctx)
        NetOpt.holdWifi(ctx, false)
        NetOpt.idle(ctx, false)
        s.active = false
        s.game = null
    } }

    // dipanggil saat toggle Stabil/Smooth diubah ketika boost sedang aktif
    fun refresh(ctx: Context) {
        val s = Store(ctx)
        if (!s.active) return
        val g = s.game
        off(ctx)
        on(ctx, g)
    }
}
