package com.xa.gamespace

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var tv: TextView? = null
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var pkg: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        pkg = intent?.getStringExtra("pkg")
        startFg()
        val st = Store(this)
        if (tv == null) addView(st)
        if (!running) {
            running = true
            val stats = Stats(this)
            Thread {
                while (running) {
                    val s = stats.read(pkg, st.bool("ov_ping", false))
                    val parts = ArrayList<String>()
                    if (st.bool("ov_cpu", true)) parts.add("CPU ${s.cpu}%")
                    if (st.bool("ov_ram", true)) parts.add("RAM ${s.ramPct}%")
                    if (st.bool("ov_temp", true)) parts.add(String.format("%.0f°C", s.temp))
                    if (st.bool("ov_fps", true)) parts.add("FPS ${s.fps}")
                    if (st.bool("ov_ping", false) && s.ping >= 0) parts.add("${s.ping}ms")
                    val t = parts.joinToString("  ·  ")
                    ui.post { tv?.text = t }
                    try { Thread.sleep(1000) } catch (e: InterruptedException) { break }
                }
            }.start()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("gs", "Game Space", NotificationManager.IMPORTANCE_LOW))
            b = Notification.Builder(this, "gs")
        } else {
            @Suppress("DEPRECATION")
            b = Notification.Builder(this)
        }
        val n = b.setContentTitle("XA Game Space aktif")
            .setContentText("Monitor performa berjalan")
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .build()
        startForeground(1, n)
    }

    private fun addView(st: Store) {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = st.int("ov_size", 11).toFloat()
        val a = (255 * st.int("ov_alpha", 60) / 100).coerceIn(0, 255)
        t.setBackgroundColor(Color.argb(a, 0, 0, 0))
        t.setPadding(16, 8, 16, 8)
        t.text = "..."
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = when (st.int("ov_pos", 0)) {
            1 -> Gravity.TOP or Gravity.END
            2 -> Gravity.BOTTOM or Gravity.START
            3 -> Gravity.BOTTOM or Gravity.END
            else -> Gravity.TOP or Gravity.START
        }
        lp.x = 12
        lp.y = 48
        try {
            wm?.addView(t, lp)
            tv = t
        } catch (e: Exception) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        running = false
        try { tv?.let { wm?.removeView(it) } } catch (e: Exception) {}
        tv = null
        super.onDestroy()
    }
}
