package com.xa.gamespace

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var tv: TextView? = null
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var pkg: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        pkg = intent?.getStringExtra("pkg")
        startFg()
        if (tv == null) addView()
        if (!running) {
            running = true
            val stats = Stats(this)
            Thread {
                while (running) {
                    val t = stats.read(pkg)
                    ui.post { tv?.text = t }
                    try { Thread.sleep(1000) } catch (e: InterruptedException) { break }
                }
            }.start()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("gs", "Game Space", NotificationManager.IMPORTANCE_LOW))
            b = Notification.Builder(this, "gs")
        } else {
            @Suppress("DEPRECATION")
            b = Notification.Builder(this)
        }
        val n = b.setContentTitle("XA Game Space aktif")
            .setContentText("Monitor performa berjalan")
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .build()
        startForeground(1, n)
    }

    private fun addView() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = 11f
        t.setBackgroundColor(Color.parseColor("#99000000"))
        t.setPadding(14, 8, 14, 8)
        t.text = "..."
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 12
        lp.y = 48
        try {
            wm?.addView(t, lp)
            tv = t
        } catch (e: Exception) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        running = false
        try { tv?.let { wm?.removeView(it) } } catch (e: Exception) {}
        tv = null
        super.onDestroy()
    }
}
