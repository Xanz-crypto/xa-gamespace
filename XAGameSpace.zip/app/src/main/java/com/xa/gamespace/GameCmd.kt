package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.media.AudioManager
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

// ================= Game CMD: mode, downscale, FPS (cmd game) =================
class GameCmdPanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box = u.vbox()
    private val out = u.label("", 11f, Theme.sub)
    private var games: List<GameApp> = emptyList()
    private var pkg: String? = a.store.get("last_game").ifBlank { null }
    private var mode = 2
    private var scale = "disable"
    private var fps = "disable"

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        Thread {
            val g = Games.detect(a)
            a.runOnUiThread {
                games = g
                if (pkg == null || g.none { it.pkg == pkg }) pkg = g.firstOrNull()?.pkg
                loadSaved()
                render()
            }
        }.start()
        render()
    }

    private fun loadSaved() {
        val p = pkg ?: return
        val s = a.store.get("gcv_$p").split("|")
        if (s.size == 3) { mode = s[0].toIntOrNull() ?: 2; scale = s[1]; fps = s[2] }
    }

    private fun chips(opts: List<Pair<String, String>>, cur: String, pick: (String) -> Unit): View {
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        val l = u.hbox()
        opts.forEach { (label, v) ->
            val on = v == cur
            val t = u.label(label, 12f, if (on) Color.parseColor("#04141F") else Color.WHITE, true)
            t.gravity = android.view.Gravity.CENTER
            t.setPadding(u.dp(12), u.dp(7), u.dp(12), u.dp(7))
            t.background = if (on) u.glass(20, Hud.cyan, Hud.cyan)
            else u.glass(20, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
            t.setOnClickListener { Sfx.tap(); pick(v) }
            l.addView(t, u.lp(-2, -2, r = 6))
        }
        hs.addView(l)
        return hs
    }

    private fun section(title: String, body: View) {
        box.addView(u.label(title, 11f, Theme.sub, true), u.lp(b = 4))
        box.addView(body, u.lp(b = 10))
    }

    private fun render() {
        box.removeAllViews()
        if (games.isEmpty()) {
            box.addView(u.label("Belum ada game terdeteksi.", 13f, Theme.sub))
            return
        }
        section("GAME", chips(games.map { it.label to it.pkg }, pkg ?: "") { p ->
            pkg = p; loadSaved(); render()
        })
        section("MODE GAME", chips(listOf("Standar" to "1", "Performa" to "2", "Baterai" to "3", "Kustom" to "4"), mode.toString()) {
            mode = it.toInt(); render()
        })
        section("DOWNSCALE (resolusi)", chips(
            listOf("Mati" to "disable") + listOf("1.0", "0.9", "0.8", "0.7", "0.6", "0.5", "0.4", "0.3").map { it to it },
            scale) { scale = it; render() })
        section("BATAS FPS", chips(
            listOf("Mati" to "disable") + listOf("30", "45", "60", "90", "120").map { it to it },
            fps) { fps = it; render() })

        val bar = u.hbox()
        bar.addView(u.btn("Terapkan", true) { apply(false) }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn("Terapkan + auto saat main") { apply(true) }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn("Reset") { reset() }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn("Lihat config") { info() })
        box.addView(bar, u.lp(b = 8))
        box.addView(out)
    }

    private fun setCmd(p: String) = "cmd game set --mode $mode --downscale $scale --fps $fps $p"

    private fun show(s: String) = a.runOnUiThread { out.text = s.ifBlank { "(tidak ada output)" } }

    private fun apply(auto: Boolean) {
        val p = pkg ?: return
        if (!Access.requires(a, "Game CMD", false)) return
        out.text = "Menerapkan..."
        Thread {
            val r = Access.run(setCmd(p) + "; cmd game mode $mode $p")
            if (auto) a.store.put("gc_$p", setCmd(p) + "; cmd game mode $mode $p")
            a.store.put("gcv_$p", "$mode|$scale|$fps")
            show((if (auto) "Disimpan: otomatis dipakai saat game ini dibuka.\n" else "") + r)
        }.start()
    }

    private fun reset() {
        val p = pkg ?: return
        if (!Access.requires(a, "Game CMD", false)) return
        Thread {
            val r = Access.run("cmd game reset $p; cmd game mode 1 $p")
            a.store.put("gc_$p", "")
            a.store.put("gcv_$p", "")
            show("Direset ke standar.\n$r")
            a.runOnUiThread { mode = 2; scale = "disable"; fps = "disable"; render() }
        }.start()
    }

    private fun info() {
        val p = pkg ?: return
        if (!Access.requires(a, "Game CMD", false)) return
        out.text = "Membaca..."
        Thread { show(Access.run("cmd game list-modes $p; cmd game list-configs $p")) }.start()
    }
}

// ================= Mixer suara (root / Shizuku) =================
class SoundPanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val am = a.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val seeks = HashMap<Int, SeekBar>()

    private val streams = listOf(
        Triple("🎵", "Media / Game", AudioManager.STREAM_MUSIC),
        Triple("🔔", "Dering", AudioManager.STREAM_RING),
        Triple("⏰", "Alarm", AudioManager.STREAM_ALARM),
        Triple("📣", "Notifikasi", AudioManager.STREAM_NOTIFICATION),
        Triple("📞", "Panggilan", AudioManager.STREAM_VOICE_CALL),
        Triple("⚙", "Sistem", AudioManager.STREAM_SYSTEM)
    )

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        val col = u.vbox()
        sv.addView(col)
        root.addView(sv, u.lp(-1, 0, 1f))

        val presets = u.hbox()
        presets.addView(u.btn("Mode Game", true) { preset("game") }, u.lp(-2, -2, r = 8))
        presets.addView(u.btn("Senyap") { preset("mute") }, u.lp(-2, -2, r = 8))
        presets.addView(u.btn("Normal") { preset("normal") })
        col.addView(presets, u.lp(b = 10))

        streams.forEach { (g, name, st) ->
            val row = u.hbox()
            row.addView(u.label("$g  $name", 12f, Color.WHITE, true), u.lp(u.dp(130), -2))
            val sb = SeekBar(a)
            sb.max = am.getStreamMaxVolume(st)
            sb.progress = am.getStreamVolume(st)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { setVol(st, s.progress) }
            })
            seeks[st] = sb
            row.addView(sb, u.lp(0, -2, 1f))
            col.addView(row, u.lp(b = 6))
        }
        col.addView(u.label("Butuh root atau Shizuku. Dering/notifikasi bisa ikut mode Jangan Ganggu.", 10f, Theme.sub))
    }

    private fun setVol(st: Int, v: Int) {
        if (!Access.requires(a, "Mixer suara", false)) {
            seeks[st]?.progress = am.getStreamVolume(st)
            return
        }
        Thread { Access.run("cmd media_session volume --stream $st --set $v") }.start()
    }

    private fun preset(kind: String) {
        if (!Access.requires(a, "Mixer suara", false)) return
        Sfx.tap()
        streams.forEach { (_, _, st) ->
            val mx = am.getStreamMaxVolume(st)
            val v = when (kind) {
                "game" -> when (st) { AudioManager.STREAM_MUSIC -> mx; AudioManager.STREAM_RING, AudioManager.STREAM_NOTIFICATION -> 0; else -> am.getStreamVolume(st) }
                "mute" -> 0
                else -> (mx * 0.6f).toInt()
            }
            seeks[st]?.progress = v
            Thread { Access.run("cmd media_session volume --stream $st --set $v") }.start()
        }
    }
}
