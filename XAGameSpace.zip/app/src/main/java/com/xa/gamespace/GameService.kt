package com.xa.gamespace

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder

class GameService : Service() {
    @Volatile private var running = false
    @Volatile private var pending: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg("Mendeteksi game otomatis")
        intent?.getStringExtra("pkg")?.let { pending = it }
        if (!running) {
            running = true
            Thread { loop() }.start()
        }
        return START_STICKY
    }

    private fun startFg(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("xa", "XA Game Space", NotificationManager.IMPORTANCE_LOW))
            b = Notification.Builder(this, "xa")
        } else {
            @Suppress("DEPRECATION")
            b = Notification.Builder(this)
        }
        val n = b.setContentTitle("XA Game Space")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setOngoing(true)
            .build()
        startForeground(1, n)
    }

    private fun foreground(): String? {
        val rx = Regex("u\\d+\\s+([A-Za-z0-9_.]+)/")
        var o = Root.run("dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity' | head -n 2")
        rx.find(o)?.let { return it.groupValues[1] }
        o = Root.run("dumpsys window | grep mCurrentFocus | head -n 1")
        return rx.find(o)?.groupValues?.get(1)
    }

    private fun loop() {
        var games: Set<String> = emptySet()
        var gamesAt = 0L
        var current: String? = null
        var since = 0L
        var seen = false
        var away = 0
        val st = Store(this)
        Access.ensure()

        // sisa boost dari sesi sebelumnya (misal app di-kill)
        if (st.active && st.game != null) {
            current = st.game; since = System.currentTimeMillis(); seen = true
            GameOverlay.show(this)
        }

        while (running) {
            val now = System.currentTimeMillis()
            if (now - gamesAt > 60000) { games = Games.packages(this); gamesAt = now }
            val fg = foreground()
            val manual = pending

            if (manual != null) {
                pending = null
                current = manual; since = now; seen = false; away = 0
                GameOverlay.show(this)
                Boost.on(this, manual)
                startFg("Boost aktif · " + Access.label())
            } else if (current == null) {
                if (st.auto && fg != null && fg in games && Access.hasAny()) {
                    current = fg; since = now; seen = true; away = 0
                    GameOverlay.show(this)
                    Boost.on(this, fg)
                    startFg("Boost aktif · " + Access.label())
                }
            } else {
                if (fg == current) { seen = true; away = 0 }
                else if (fg != null && (seen || now - since > 25000)) away++
                if (away >= 2) {
                    GameOverlay.hide()
                    Boost.off(this)
                    current = null; away = 0
                    startFg("Mendeteksi game otomatis")
                }
            }

            if (current == null && !st.auto && pending == null) {
                running = false
                stopForeground(true)
                stopSelf()
                break
            }
            try { Thread.sleep(3000) } catch (e: InterruptedException) { break }
        }
    }

    override fun onDestroy() {
        running = false
        GameOverlay.hide()
        super.onDestroy()
    }

    companion object {
        fun start(ctx: Context, pkg: String? = null) {
            val i = Intent(ctx, GameService::class.java)
            if (pkg != null) i.putExtra("pkg", pkg)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
    }
}
