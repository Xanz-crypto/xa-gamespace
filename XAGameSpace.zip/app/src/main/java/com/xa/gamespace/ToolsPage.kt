package com.xa.gamespace

import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class ToolsPage(private val a: MainActivity) : Page {
    private val u = a.ui
    private lateinit var state: TextView
    private lateinit var result: TextView
    private lateinit var checkBox: LinearLayout

    override fun build(): View {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        val col = u.vbox()
        col.setPadding(u.dp(16), u.dp(22), u.dp(16), u.dp(24))
        sv.addView(col)

        col.addView(u.label("Alat", 24f, Theme.text, true))
        col.addView(u.label("Aksi cepat dan uji dukungan perangkat.", 12f, Theme.sub), u.lp(b = 14))

        // Status
        val c0 = u.card()
        state = u.pill("Boost nonaktif", Theme.sub)
        c0.addView(u.cardHeader("🛡", "Status Boost", "Pengaturan asli disimpan sebelum boost", state))
        c0.addView(u.gradBtn("Pulihkan Pengaturan") { a.restore() }, u.lp(t = 12))
        col.addView(c0)

        // Aksi
        val c1 = u.card()
        c1.addView(u.cardHeader("🧹", "Pembersih", "Bebaskan memori sebelum main"))
        result = u.label("", 12f, Theme.sub)
        val b1 = u.ghostBtn("Bersihkan RAM") {
            a.async({ Boost.cleanRam(); "RAM dan cache sudah dibersihkan" }) { result.text = it }
        }
        val b2 = u.ghostBtn("Stop app latar") {
            a.async({ val n = Boost.killBackground(a, a.selectedGame()); "$n aplikasi dihentikan" }) { result.text = it }
        }
        c1.addView(u.row(b1, b2), u.lp(t = 12))
        c1.addView(result, u.lp(t = 8))
        col.addView(c1)

        // Uji kompatibilitas
        val c2 = u.card()
        c2.addView(u.cardHeader("🔬", "Uji Kompatibilitas", "Cek fitur apa saja yang jalan di HP ini"))
        checkBox = u.vbox()
        c2.addView(checkBox, u.lp(t = 8))
        c2.addView(u.ghostBtn("Jalankan Uji") {
            checkBox.removeAllViews()
            checkBox.addView(u.label("Menguji...", 12f, Theme.sub))
            Thread {
                val res = Compat.run(a)
                a.runOnUiThread {
                    checkBox.removeAllViews()
                    res.forEach { (t, ok, d) ->
                        val r = u.vbox()
                        r.setPadding(0, u.dp(6), 0, u.dp(6))
                        r.addView(u.label((if (ok) "✓  " else "✗  ") + t, 13f, if (ok) Theme.good else Theme.bad, true))
                        r.addView(u.label(d, 11f, Theme.sub))
                        checkBox.addView(r)
                    }
                }
            }.start()
        }, u.lp(t = 8))
        col.addView(c2)
        return sv
    }

    override fun update(s: Snap) {
        if (!::state.isInitialized) return
        if (a.store.active) u.setPill(state, "Boost aktif", Theme.good) else u.setPill(state, "Boost nonaktif", Theme.sub)
    }
}
