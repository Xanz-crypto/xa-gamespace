package com.xa.gamespace

import android.app.AlertDialog
import android.view.View
import android.widget.ScrollView

class SettingsPage(private val a: MainActivity) : Page {
    private val u = a.ui
    private val st = a.store

    override fun build(): View {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        val col = u.vbox()
        col.setPadding(u.dp(16), u.dp(22), u.dp(16), u.dp(24))
        sv.addView(col)

        col.addView(u.label("Setelan", 24f, Theme.text, true))
        col.addView(u.label("Atur tampilan, profil boost, dan monitor.", 12f, Theme.sub), u.lp(b = 10))

        // Tampilan
        col.addView(u.section("Tampilan"))
        val c1 = u.card()
        c1.addView(u.label("Warna aksen", 14f))
        c1.addView(u.label("Aplikasi dimuat ulang saat warna diganti.", 11f, Theme.sub))
        val names = Theme.palettes.keys.toList()
        c1.addView(u.segmented(names, names.indexOf(st.str("accent", "Hijau")).coerceAtLeast(0)) {
            st.setStr("accent", names[it])
            a.recreate()
        }, u.lp(t = 10))
        col.addView(c1)

        // Profil kustom
        col.addView(u.section("Profil boost kustom"))
        val c2 = u.card()
        c2.addView(u.label("Dipakai saat mode game = KUSTOM. Mode Hemat, Seimbang, dan Performa memakai paket bawaan.", 11f, Theme.sub), u.lp(b = 4))
        Boost.FLAGS.forEach { (k, label, _) ->
            c2.addView(u.switchRow(label, Boost.DESC[k] ?: "", st.flag(k)) { st.setFlag(k, it) })
        }
        col.addView(c2)

        // Overlay
        col.addView(u.section("Monitor overlay"))
        val c3 = u.card()
        c3.addView(u.switchRow("Tampilkan overlay", "Muncul di atas game saat dijalankan dari sini", st.flag("overlay")) { st.setFlag("overlay", it) })
        c3.addView(u.label("Posisi", 14f), u.lp(t = 8, b = 8))
        c3.addView(u.segmented(listOf("Kiri atas", "Kanan atas", "Kiri bawah", "Kanan bawah"), st.int("ov_pos", 0)) { st.setInt("ov_pos", it) })
        c3.addView(u.slider("Ukuran teks", 9, 16, st.int("ov_size", 11), { "$it sp" }) { st.setInt("ov_size", it) })
        c3.addView(u.slider("Kepekatan latar", 20, 100, st.int("ov_alpha", 60), { "$it%" }) { st.setInt("ov_alpha", it) })
        c3.addView(u.label("Tampilkan data", 14f), u.lp(t = 8))
        c3.addView(u.switchRow("CPU", "", st.bool("ov_cpu", true)) { st.setBool("ov_cpu", it) })
        c3.addView(u.switchRow("RAM", "", st.bool("ov_ram", true)) { st.setBool("ov_ram", it) })
        c3.addView(u.switchRow("Suhu", "", st.bool("ov_temp", true)) { st.setBool("ov_temp", it) })
        c3.addView(u.switchRow("FPS", "Perkiraan, tidak semua game terbaca", st.bool("ov_fps", true)) { st.setBool("ov_fps", it) })
        c3.addView(u.switchRow("Ping", "Ke 8.8.8.8, butuh internet", st.bool("ov_ping", false)) { st.setBool("ov_ping", it) })
        col.addView(c3)

        // Perilaku
        col.addView(u.section("Perilaku"))
        val c4 = u.card()
        c4.addView(u.switchRow("Pulihkan otomatis", "Kembalikan pengaturan asli saat aplikasi ini dibuka lagi", st.bool("autorestore", false)) { st.setBool("autorestore", it) })
        c4.addView(u.switchRow("Layar tetap menyala", "Saat Game Space terbuka", st.bool("keepon", true)) { st.setBool("keepon", it) })
        col.addView(c4)

        // Data
        col.addView(u.section("Data"))
        val c5 = u.card()
        c5.addView(u.ghostBtn("Reset semua setelan") {
            AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Reset setelan?")
                .setMessage("Daftar game tetap disimpan. Mode dan setelan lain kembali ke bawaan.")
                .setPositiveButton("Reset") { _, _ ->
                    st.resetSettings()
                    a.recreate()
                }
                .setNegativeButton("Batal", null)
                .show()
        })
        col.addView(c5)

        // Tentang
        val c6 = u.card()
        c6.addView(u.cardHeader("ℹ", "XA Game Space v2.0", "Butuh root (Magisk atau KernelSU). Semua perubahan bisa dipulihkan."))
        col.addView(c6)
        return sv
    }
}
