package com.xa.gamespace

import android.content.Context
import android.os.Build
import android.provider.Settings

object Compat {
    // judul, lulus, detail
    fun run(ctx: Context): List<Triple<String, Boolean, String>> {
        val l = ArrayList<Triple<String, Boolean, String>>()
        val root = Root.available()
        l.add(Triple("Akses root", root, if (root) "Diizinkan" else "Tidak ada atau ditolak"))
        if (root) {
            val govs = Root.run("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors")
            l.add(Triple("CPU governor performance", govs.contains("performance"),
                if (govs.isBlank()) "Tidak terbaca" else govs.take(70)))
            val gpu = Root.run("for f in /sys/class/kgsl/kgsl-3d0/devfreq/governor /sys/class/devfreq/*gpu*/governor /sys/class/devfreq/*mali*/governor; do [ -f \$f ] && echo \$f; done")
            l.add(Triple("GPU governor", gpu.isNotBlank(), if (gpu.isBlank()) "Tidak ditemukan di HP ini" else "Ditemukan"))
            val fp = Root.run("cmd power help 2>&1").contains("fixed-performance")
            l.add(Triple("Fixed performance mode", fp, if (fp) "Didukung" else "Tidak didukung"))
            val gm = Root.run("cmd -l 2>&1").lines().any { it.trim() == "game" }
            l.add(Triple("Game mode sistem", gm, if (gm) "Didukung" else "Tidak didukung"))
        }
        val ov = Settings.canDrawOverlays(ctx)
        l.add(Triple("Izin overlay monitor", ov, if (ov) "Diizinkan" else "Belum diizinkan"))
        l.add(Triple("Versi Android", Build.VERSION.SDK_INT >= 21, "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"))
        return l
    }
}
