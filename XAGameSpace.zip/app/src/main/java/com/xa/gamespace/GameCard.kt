package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

// Kartu game di Game Panel (di sebelah kanan RAM / CPU / SUHU), gaya Game Space tanpa tombol Start
class GameCardView(private val ctx: Context, store: Store) : LinearLayout(ctx) {
    private fun px(v: Int) = ctx.px(v)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(px(9), px(10), px(9), px(10))
        background = Hud.rounded(Color.argb(150, 12, 36, 70), Hud.cyan, ctx.pxf(14f), 1.5f)

        val pkg = store.game
        val pm = ctx.packageManager
        var icon: android.graphics.drawable.Drawable? = null
        var name = ""
        if (pkg != null) {
            try {
                icon = pm.getApplicationIcon(pkg)
                name = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                icon = null
            }
        }
        if (icon == null) {
            visibility = View.GONE
        } else {
            val iv = ImageView(ctx)
            iv.setImageDrawable(icon)
            addView(iv, LayoutParams(px(58), px(58)))

            val t = TextView(ctx)
            t.text = name
            t.textSize = 12f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(Color.WHITE)
            t.maxLines = 1
            t.ellipsize = android.text.TextUtils.TruncateAt.END
            t.gravity = Gravity.CENTER
            addView(t, LayoutParams(-1, -2).also { it.topMargin = px(6) })

            val s = TextView(ctx)
            s.text = "Performa maksimal · ${Access.mode.name}"
            s.textSize = 9.5f
            s.setTextColor(Hud.sub)
            s.gravity = Gravity.CENTER
            addView(s, LayoutParams(-1, -2).also { it.topMargin = px(2) })

            val row = LinearLayout(ctx)
            row.orientation = HORIZONTAL
            row.gravity = Gravity.CENTER
            val chips = listOf("Stabil" to store.stabil, "Smooth" to store.smooth, "Auto" to store.auto)
            for ((label, on) in chips) {
                val c = TextView(ctx)
                c.text = label
                c.textSize = 8.5f
                c.typeface = Typeface.DEFAULT_BOLD
                c.setTextColor(if (on) Color.WHITE else Color.parseColor("#B8C6DA"))
                c.setPadding(px(5), px(2), px(5), px(2))
                c.background = Hud.rounded(
                    if (on) Color.argb(200, 40, 150, 220) else Color.argb(110, 60, 80, 120),
                    Color.TRANSPARENT, ctx.pxf(9f), 0f)
                row.addView(c, LayoutParams(-2, -2).also { it.leftMargin = px(1); it.rightMargin = px(1) })
            }
            addView(row, LayoutParams(-2, -2).also { it.topMargin = px(8) })
        }
    }
}
