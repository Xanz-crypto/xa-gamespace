package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import kotlin.math.max

// Monitor melayang: FPS real-time + grafik 60 sampel + status sistem (seperti Kernel Manager)
class MonitorView(ctx: Context) : View(ctx) {
    private val n = 60
    private val buf = IntArray(n) { -1 }
    private var cur = -1
    private var ram = 0
    private var cpu = 0
    private var hz = 60
    private var temp = 0f

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val area = Path()
    private val rect = RectF()

    private fun dp(v: Float) = context.pxf(v)

    fun pushFps(v: Int) {
        cur = v
        System.arraycopy(buf, 1, buf, 0, n - 1)
        buf[n - 1] = v
        invalidate()
    }

    fun setStats(s: SysStats.Sample) {
        ram = s.ramPct; cpu = s.cpuPct; hz = s.hz; temp = s.tempC
        invalidate()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(dp(184f).toInt(), dp(88f).toInt())
    }

    private fun colorFor(v: Int): Int = when {
        v < 0 -> Color.parseColor("#9FB8D0")
        v >= 55 -> Color.parseColor("#38E8A5")
        v >= 30 -> Color.parseColor("#FFC24B")
        else -> Color.parseColor("#FF5D5D")
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        rect.set(0f, 0f, w, h)
        bg.color = Color.argb(165, 4, 12, 22)
        cv.drawRoundRect(rect, dp(10f), dp(10f), bg)
        line.color = Hud.cyanDim; line.strokeWidth = dp(1f)
        rect.set(dp(0.5f), dp(0.5f), w - dp(0.5f), h - dp(0.5f))
        cv.drawRoundRect(rect, dp(10f), dp(10f), line)

        // angka FPS besar
        val col = colorFor(cur)
        txt.color = col
        txt.textSize = dp(28f)
        cv.drawText(if (cur >= 0) cur.toString() else "--", dp(10f), dp(31f), txt)
        val numW = txt.measureText(if (cur >= 0) cur.toString() else "--")
        txt.textSize = dp(9f)
        txt.color = Hud.sub
        cv.drawText("FPS", dp(12f) + numW, dp(31f), txt)

        // rata-rata / minimum dari sampel valid
        val valid = buf.filter { it >= 0 }
        val avg = if (valid.isEmpty()) -1 else valid.sum() / valid.size
        val mn = if (valid.isEmpty()) -1 else valid.min()
        val mx = if (valid.isEmpty()) -1 else valid.max()
        txt.textSize = dp(9.5f)
        txt.color = Color.WHITE
        val tx = dp(98f)
        cv.drawText("AVG  ${if (avg >= 0) avg else "--"}", tx, dp(14f), txt)
        cv.drawText("MIN  ${if (mn >= 0) mn else "--"}", tx, dp(26f), txt)
        cv.drawText("MAX  ${if (mx >= 0) mx else "--"}", tx, dp(38f), txt)

        // status sistem
        txt.textSize = dp(8.5f)
        txt.color = Hud.cyan
        cv.drawText("RAM $ram%  CPU $cpu%  ${hz}Hz  ${temp.toInt()}°C", dp(10f), dp(50f), txt)

        // grafik
        val gl = dp(8f)
        val gr = w - dp(8f)
        val gt = dp(56f)
        val gb = h - dp(8f)
        val maxY = max(max(hz, 60), mx).toFloat()
        path.reset()
        area.reset()
        var started = false
        var lastX = gl
        for (i in 0 until n) {
            val v = buf[i]
            if (v < 0) { started = false; continue }
            val x = gl + (gr - gl) * i / (n - 1f)
            val y = gb - (gb - gt) * (v / maxY).coerceIn(0f, 1f)
            if (!started) {
                path.moveTo(x, y)
                area.moveTo(x, gb); area.lineTo(x, y)
                started = true
            } else {
                path.lineTo(x, y)
                area.lineTo(x, y)
            }
            lastX = x
        }
        if (started) {
            area.lineTo(lastX, gb)
            area.close()
            fillP.shader = LinearGradient(0f, gt, 0f, gb,
                Color.argb(110, Color.red(col), Color.green(col), Color.blue(col)),
                Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)), Shader.TileMode.CLAMP)
            cv.drawPath(area, fillP)
            fillP.shader = null
            line.color = col
            line.strokeWidth = dp(1.6f)
            cv.drawPath(path, line)
        } else {
            txt.textSize = dp(8.5f)
            txt.color = Hud.sub
            cv.drawText("FPS butuh root / Shizuku", gl, (gt + gb) / 2f + dp(3f), txt)
        }
    }
}
