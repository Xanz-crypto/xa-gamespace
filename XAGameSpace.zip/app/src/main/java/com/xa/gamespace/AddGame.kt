package com.xa.gamespace

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

// Tambah game: daftar semua aplikasi. Ketuk untuk menambah (✓), ketuk lagi untuk menghapus dari daftar game.
class AddGamePanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val list = u.vbox()

    init {
        root.addView(u.label("Ketuk aplikasi untuk menambah (✓) atau menghapus dari daftar game. Game yang sudah terdeteksi otomatis tetap muncul.", 11f, Theme.sub), u.lp(b = 8))
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        root.addView(sv, u.lp(-1, 0, 1f))
        list.addView(u.label("Memuat aplikasi...", 12f, Theme.sub))
        Thread {
            val pm = a.packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(q, 0)
                .map { Triple(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .distinctBy { it.first }
                .filter { it.first != a.packageName }
                .sortedBy { it.second.lowercase() }
            a.runOnUiThread {
                list.removeAllViews()
                for ((pkg, label, icon) in apps) list.addView(row(pkg, label, icon))
            }
        }.start()
    }

    private fun extras(): MutableSet<String> =
        a.store.get("extra_games").split(",").filter { it.isNotBlank() }.toMutableSet()

    private fun row(pkg: String, label: String, icon: Drawable): View {
        val r = LinearLayout(a)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(u.dp(4), u.dp(6), u.dp(4), u.dp(6))
        val iv = ImageView(a)
        iv.setImageDrawable(icon)
        r.addView(iv, LinearLayout.LayoutParams(u.dp(30), u.dp(30)))
        val n = u.label(label, 12f, Color.WHITE, false)
        n.maxLines = 1
        n.ellipsize = android.text.TextUtils.TruncateAt.END
        r.addView(n, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = u.dp(10) })
        val c = u.label("", 15f, Hud.cyan, true)
        fun paint() {
            val on = pkg in extras()
            c.text = if (on) "✓" else "＋"
            c.setTextColor(if (on) Color.parseColor("#38E8A5") else Hud.cyan)
        }
        paint()
        r.addView(c)
        r.setOnClickListener {
            Sfx.tap()
            val s = extras()
            if (!s.add(pkg)) s.remove(pkg)
            a.store.put("extra_games", s.joinToString(","))
            paint()
            a.renderGames()
        }
        return r
    }
}
