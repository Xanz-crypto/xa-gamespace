package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

// ============================================================
//  AI AUTO SETTING
//  1) deteksi HP: model, RAM, jumlah core, versi Android -> kelas HP (LOW / MID / HIGH)
//  2) pilih paket setelan yang paling cocok untuk kelas itu
//  3) terapkan otomatis lewat ROOT atau SHIZUKU (sesuai akses yang tersedia)
//  4) cek ulang hasilnya dan tampilkan apa yang benar-benar terbaca di HP
// Catatan: AI memilih berdasarkan kemampuan HP, bukan membaca FPS game secara langsung.
// ============================================================
object AiTune {
    data class Dev(val model: String, val ramMb: Int, val cores: Int, val sdk: Int, val ver: String, val tier: String)

    fun detect(): Dev {
        val ram = try {
            File("/proc/meminfo").readLines().first { it.startsWith("MemTotal") }
                .filter { it.isDigit() }.toInt() / 1024
        } catch (e: Exception) { 4096 }
        val cores = Runtime.getRuntime().availableProcessors()
        val tier = when {
            ram >= 7000 && cores >= 8 -> "HIGH"
            ram >= 5000 -> "MID"
            else -> "LOW"
        }
        val model = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}"
        return Dev(model, ram, cores, android.os.Build.VERSION.SDK_INT, android.os.Build.VERSION.RELEASE ?: "?", tier)
    }

    // paket setelan per kelas HP: (label, perintah)
    fun plan(d: Dev, root: Boolean): List<Pair<String, String>> {
        val hz = when (d.tier) { "HIGH" -> "120"; "MID" -> "90"; else -> "60" }
        val tex = if (d.tier == "LOW") "2" else "1"
        val steps = ArrayList<Pair<String, String>>()
        steps.add("Texture LV$tex" to Texture.applyCmd(tex))
        steps.add("Render $hz Hz" to RateCmd.renderCmd(hz))
        if (root) {
            steps.add("GPU render vsync hidup" to RateCmd.gpuVsyncCmd(true))
            steps.add("VSync FPS $hz" to RateCmd.vsyncFpsCmd(hz))
        }
        return steps
    }
}

class AiTuneSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val log = TextView(ctx)
    private val dev = AiTune.detect()
    @Volatile private var busy = false

    private fun px(v: Int) = ctx.px(v)

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        return v
    }

    private fun btn(t: String, primary: Boolean = false, click: () -> Unit): TextView {
        val v = tv(t, 12f, if (primary) Color.parseColor("#04141F") else Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.setPadding(px(14), px(8), px(14), px(8))
        v.background = if (primary) Hud.rounded(Hud.neon, Hud.neon, ctx.pxf(6f), 1f)
        else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(60, 255, 255, 255), ctx.pxf(6f), 1f)
        v.setOnClickListener { Sfx.tap(); click() }
        return v
    }

    private fun mode(): String = when {
        Access.isRoot -> "ROOT"
        Access.hasAny() -> "SHIZUKU"
        else -> "TIDAK ADA AKSES"
    }

    private fun setLog(t: String) { log.post { log.text = t } }

    private fun run() {
        if (busy) return
        if (!Access.isRoot && !Access.hasAny()) {
            setLog("Tidak ada akses. Pasang root atau jalankan Shizuku dulu.")
            return
        }
        busy = true
        val useRoot = Access.isRoot
        Thread {
            val sb = StringBuilder()
            sb.append("Mode: ${if (useRoot) "ROOT" else "SHIZUKU"} · kelas ${dev.tier}\n\n")
            val steps = AiTune.plan(dev, useRoot)
            for ((label, cmd) in steps) {
                setLog(sb.toString() + "Menerapkan $label...")
                Access.run(cmd)
                sb.append("✓ $label\n")
            }
            setLog(sb.toString() + "\nMengatur jaringan (Wi-Fi & data)...")
            val net = NetOpt.boost(ctx, useRoot) { setLog(sb.toString() + "Jaringan: $it") }
            sb.append("✓ Jaringan diatur\n")

            setLog(sb.toString() + "\nMengecek hasil...")
            val check = Access.run(Texture.STATUS_CMD)
            val rate = Access.run(RateCmd.VERIFY_RENDER)
            sb.append("\nTexture terbaca: ${Texture.detectLevel(check)}\n")
            val rLines = rate.lines().map { it.trim() }.filter { it.isNotBlank() }
            val minHz = rLines.getOrNull(0)?.takeIf { it != "null" } ?: "bawaan"
            val peakHz = rLines.getOrNull(1)?.takeIf { it != "null" } ?: "bawaan"
            sb.append("Render: min $minHz · peak $peakHz\n")
            sb.append("\nDetail jaringan:\n").append(net.lines().take(4).joinToString("\n"))
            busy = false
            setLog(sb.toString().trim())
        }.start()
    }

    private fun restore() {
        if (busy) return
        busy = true
        Thread {
            Access.run(Texture.resetCmd() + "\n" + RateCmd.renderDefaultCmd())
            val net = NetOpt.resetAll(ctx)
            busy = false
            setLog("Setelan AI dikembalikan.\n$net")
        }.start()
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.neon, ctx.pxf(12f), 1.2f)
        root.setPadding(px(16), px(12), px(16), px(12))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("AI AUTO SETTING", 15f, Hud.neon, true), LinearLayout.LayoutParams(0, -2, 1f))
        val x = tv("✕", 18f)
        x.setPadding(px(10), px(2), px(4), px(2))
        x.setOnClickListener { Sfx.tap(); onClose() }
        head.addView(x)
        root.addView(head)

        val info = tv(
            "HP: ${dev.model}\n" +
                "RAM ${dev.ramMb} MB · CPU ${dev.cores} core · Android ${dev.ver} (API ${dev.sdk})\n" +
                "Kelas HP: ${dev.tier}   ·   Akses: ${mode()}",
            11f, Hud.sub
        )
        info.setPadding(0, px(8), 0, px(8))
        root.addView(info)

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        val body = LinearLayout(ctx)
        body.orientation = LinearLayout.VERTICAL
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        body.addView(tv("Deteksi setelan yang cocok untuk HP ini: texture, render rate, GPU vsync (root), dan jaringan. " +
            "Hasilnya dicek ulang setelah diterapkan.", 11f, Hud.sub))

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(btn("Mulai AI", true) { run() }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(8) })
        row.addView(btn("Kembalikan") { restore() })
        body.addView(row, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(10) })

        log.textSize = 11f
        log.setTextColor(Hud.sub)
        log.typeface = Typeface.MONOSPACE
        log.setTextIsSelectable(true)
        log.text = "Tekan \"Mulai AI\" untuk menerapkan setelan."
        body.addView(log, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(10) })
    }
}
