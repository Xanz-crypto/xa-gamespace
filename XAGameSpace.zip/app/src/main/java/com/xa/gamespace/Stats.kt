package com.xa.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter

class Stats(private val ctx: Context) {
    private var lastTotal = 0L
    private var lastIdle = 0L
    private var lastFrames = -1L
    private var lastT = 0L
    private var lastPkg: String? = null

    fun read(pkg: String?): String {
        val sep = "@@"
        val cmd = "head -n1 /proc/stat; echo $sep; cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null; echo $sep; " +
            (if (pkg != null) "dumpsys gfxinfo $pkg | grep 'Total frames rendered'" else "")
        val parts = Root.run(cmd).split(sep)

        // CPU
        var cpu = 0
        val n = parts.getOrNull(0)?.trim()?.split(Regex("\\s+"))?.drop(1)?.mapNotNull { it.toLongOrNull() } ?: emptyList()
        if (n.size >= 5) {
            val idle = n[3] + n[4]
            val total = n.take(8).sum()
            val dT = total - lastTotal
            val dI = idle - lastIdle
            if (lastTotal != 0L && dT > 0) cpu = (100 * (dT - dI) / dT).toInt().coerceIn(0, 100)
            lastTotal = total
            lastIdle = idle
        }

        // Suhu
        val temps = (parts.getOrNull(1) ?: "").lines().mapNotNull { it.trim().toFloatOrNull() }
            .map { if (it > 1000f) it / 1000f else it }.filter { it in 10f..120f }
        val temp = temps.maxOrNull() ?: batteryTemp()

        // FPS
        var fps = 0
        if (pkg != null) {
            if (pkg != lastPkg) { lastFrames = -1L; lastPkg = pkg }
            val m = Regex("Total frames rendered:\\s*(\\d+)").find(parts.getOrNull(2) ?: "")
            val frames = m?.groupValues?.get(1)?.toLongOrNull()
            val now = System.currentTimeMillis()
            if (frames != null) {
                if (lastFrames >= 0 && now > lastT && frames >= lastFrames)
                    fps = ((frames - lastFrames) * 1000 / (now - lastT)).toInt()
                lastFrames = frames
                lastT = now
            }
        }

        // RAM
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val used = (mi.totalMem - mi.availMem) / 1024.0 / 1024 / 1024
        val tot = mi.totalMem / 1024.0 / 1024 / 1024

        return String.format("CPU %d%%  RAM %.1f/%.1f GB\nSuhu %.0f°C  FPS %s", cpu, used, tot, temp,
            if (pkg == null) "-" else fps.toString())
    }

    private fun batteryTemp(): Float {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra("temperature", 0) ?: 0) / 10f
    }
}
