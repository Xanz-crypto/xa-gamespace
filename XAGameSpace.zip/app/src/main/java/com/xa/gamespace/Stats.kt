package com.xa.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import java.io.File

data class Snap(
    val cpu: Int = 0,
    val freq: Float = 0f,
    val ramUsed: Double = 0.0,
    val ramTotal: Double = 0.0,
    val swapUsed: Double = 0.0,
    val swapTotal: Double = 0.0,
    val cacheMb: Int = 0,
    val temp: Float = 0f,
    val fps: Int = 0,
    val ping: Int = -1,
    val batt: Int = 0,
    val battTemp: Float = 0f,
    val volt: Float = 0f,
    val charging: Boolean = false,
    val healthOk: Boolean = true
) {
    val ramPct: Int get() = if (ramTotal > 0) (100 * ramUsed / ramTotal).toInt() else 0
}

object Sys {
    fun storage(): Pair<Double, Double> {
        val sf = StatFs(Environment.getDataDirectory().path)
        val total = sf.blockCountLong * sf.blockSizeLong / 1e9
        val free = sf.availableBlocksLong * sf.blockSizeLong / 1e9
        return total to free
    }

    fun uptimeText(): String {
        val h = SystemClock.elapsedRealtime() / 3600000
        return if (h >= 24) "${h / 24}h ${h % 24}j" else "$h jam"
    }

    fun soc(): String =
        if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() && Build.SOC_MODEL != "unknown") Build.SOC_MODEL
        else Build.HARDWARE

    fun sh(cmd: String): String = try {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        val o = p.inputStream.bufferedReader().readText()
        p.waitFor()
        o.trim()
    } catch (e: Exception) {
        ""
    }
}

class Stats(private val ctx: Context) {
    private var lastTotal = 0L
    private var lastIdle = 0L
    private var lastFrames = -1L
    private var lastT = 0L
    private var lastPkg: String? = null
    private var n = 0
    private var lastPing = -1

    fun read(pkg: String?, withPing: Boolean): Snap {
        val sep = "@@"
        val gfx = if (pkg != null) "dumpsys gfxinfo $pkg | grep 'Total frames rendered'" else "true"
        val cmd = "head -n1 /proc/stat; echo $sep; cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null; echo $sep; " +
            "$gfx; echo $sep; cat /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq 2>/dev/null"
        val parts = Root.run(cmd).split(sep)

        // CPU
        var cpu = 0
        val nums = parts.getOrNull(0)?.trim()?.split(Regex("\\s+"))?.drop(1)?.mapNotNull { it.toLongOrNull() } ?: emptyList()
        if (nums.size >= 5) {
            val idle = nums[3] + nums[4]
            val total = nums.take(8).sum()
            val dT = total - lastTotal
            val dI = idle - lastIdle
            if (lastTotal != 0L && dT > 0) cpu = (100 * (dT - dI) / dT).toInt().coerceIn(0, 100)
            lastTotal = total
            lastIdle = idle
        }

        // Suhu
        val temps = (parts.getOrNull(1) ?: "").lines().mapNotNull { it.trim().toFloatOrNull() }
            .map { if (it > 1000f) it / 1000f else it }.filter { it in 10f..120f }
        val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val battTemp = (bi?.getIntExtra("temperature", 0) ?: 0) / 10f
        val temp = temps.maxOrNull() ?: battTemp

        // FPS
        var fps = 0
        if (pkg != null) {
            if (pkg != lastPkg) { lastFrames = -1L; lastPkg = pkg }
            val m = Regex("Total frames rendered:\\s*(\\d+)").find(parts.getOrNull(2) ?: "")
            val frames = m?.groupValues?.get(1)?.toLongOrNull()
            val now = System.currentTimeMillis()
            if (frames != null) {
                if (lastFrames >= 0 && now > lastT && frames >= lastFrames)
                    fps = ((frames - lastFrames) * 1000 / (now - lastT)).toInt()
                lastFrames = frames
                lastT = now
            }
        }

        // Frekuensi CPU
        val maxKhz = (parts.getOrNull(3) ?: "").lines().mapNotNull { it.trim().toLongOrNull() }.maxOrNull() ?: 0L

        // RAM dan swap
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ramTotal = mi.totalMem / 1073741824.0
        val ramUsed = (mi.totalMem - mi.availMem) / 1073741824.0
        val mem = HashMap<String, Long>()
        try {
            File("/proc/meminfo").forEachLine {
                val p = it.trim().split(Regex("\\s+"))
                if (p.size >= 2) mem[p[0].removeSuffix(":")] = p[1].toLongOrNull() ?: 0L
            }
        } catch (e: Exception) {}
        val swapTotal = (mem["SwapTotal"] ?: 0L) / 1048576.0
        val swapUsed = swapTotal - (mem["SwapFree"] ?: 0L) / 1048576.0
        val cacheMb = ((mem["Cached"] ?: 0L) / 1024).toInt()

        // Ping
        if (withPing && n++ % 3 == 0) lastPing = ping()

        // Baterai
        val level = bi?.getIntExtra("level", 0) ?: 0
        val scale = bi?.getIntExtra("scale", 100) ?: 100
        val status = bi?.getIntExtra("status", 0) ?: 0

        return Snap(
            cpu = cpu,
            freq = maxKhz / 1e6f,
            ramUsed = ramUsed,
            ramTotal = ramTotal,
            swapUsed = swapUsed,
            swapTotal = swapTotal,
            cacheMb = cacheMb,
            temp = temp,
            fps = fps,
            ping = lastPing,
            batt = if (scale > 0) level * 100 / scale else level,
            battTemp = battTemp,
            volt = (bi?.getIntExtra("voltage", 0) ?: 0) / 1000f,
            charging = status == 2 || status == 5,
            healthOk = (bi?.getIntExtra("health", 2) ?: 2) == 2
        )
    }

    private fun ping(): Int = try {
        val p = ProcessBuilder("ping", "-c", "1", "-W", "1", "8.8.8.8").redirectErrorStream(true).start()
        val o = p.inputStream.bufferedReader().readText()
        p.waitFor()
        Regex("time=([0-9.]+)").find(o)?.groupValues?.get(1)?.toFloat()?.toInt() ?: -1
    } catch (e: Exception) {
        -1
    }
}
