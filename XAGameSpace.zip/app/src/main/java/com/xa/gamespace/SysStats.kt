package com.xa.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.WindowManager

object SysStats {
    data class Sample(val ramPct: Int, val cpuPct: Int, val tempC: Float, val hz: Int)

    private var lastTotal = 0L
    private var lastIdle = 0L

    private fun cpu(): Int {
        val l = Root.run("head -n 1 /proc/stat")
        val t = l.trim().split(Regex("\\s+"))
        if (t.size < 8 || t[0] != "cpu") return 0
        val v = t.drop(1).take(8).map { it.toLongOrNull() ?: 0L }
        val total = v.sum()
        val idle = v[3] + v[4]
        val dT = total - lastTotal
        val dI = idle - lastIdle
        val first = lastTotal == 0L
        lastTotal = total
        lastIdle = idle
        if (first || dT <= 0) return 0
        return (100L * (dT - dI) / dT).toInt().coerceIn(0, 100)
    }

    @Suppress("DEPRECATION")
    fun sample(ctx: Context): Sample {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ram = if (mi.totalMem > 0) (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt() else 0
        val temp = try {
            (ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                ?.getIntExtra("temperature", 0) ?: 0) / 10f
        } catch (e: Exception) { 0f }
        val hz = try {
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.refreshRate.toInt()
        } catch (e: Exception) { 60 }
        return Sample(ram, cpu(), temp, hz)
    }
}
