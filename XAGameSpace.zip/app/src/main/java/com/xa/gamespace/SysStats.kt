package com.xa.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.WindowManager

object SysStats {
    data class Sample(val ramPct: Int, val cpuPct: Int, val tempC: Float, val hz: Int, val fps: Int)

    // Statistik frame 1 detik terakhir: fps, jeda frame terpanjang (ms), jumlah frame patah (jeda > 50 ms dan > 2x median)
    data class Frame(val fps: Int, val maxGapMs: Int, val janks: Int)

    private var lastTotal = 0L
    private var lastIdle = 0L

    private var layerPkg: String? = null
    private var layerName: String? = null

    private fun findLayer(pkg: String): String? {
        val l = Root.run("dumpsys SurfaceFlinger --list").lines().map { it.trim() }.filter { it.contains(pkg) }
        return l.firstOrNull { it.startsWith("SurfaceView") && !it.contains("Background") }
            ?: l.firstOrNull { !it.contains("Background") && !it.contains("Bounds") }
            ?: l.firstOrNull()
    }

    private fun measure(layer: String): Int {
        val out = Root.run("dumpsys SurfaceFlinger --latency '$layer'")
        val ts = out.lines().drop(1).mapNotNull { ln ->
            val t = ln.trim().split(Regex("\\s+"))
            if (t.size >= 3) t[1].toLongOrNull() else null
        }.filter { it > 0L && it != Long.MAX_VALUE }
        if (ts.size < 2) return -1
        var last = 0L
        for (x in ts) if (x > last) last = x
        if (System.nanoTime() - last > 1_500_000_000L) return 0
        val win = ts.filter { it >= last - 1_000_000_000L }.sorted()
        if (win.size < 2) return 0
        val span = (win.last() - win.first()) / 1e9
        if (span <= 0.0) return -1
        return Math.round((win.size - 1) / span).toInt()
    }

    // FPS game nyata via SurfaceFlinger (butuh root). -1 jika tidak terbaca di HP ini.
    private fun fps(pkg: String?): Int {
        if (pkg.isNullOrBlank()) return -1
        if (layerPkg != pkg) { layerPkg = pkg; layerName = null }
        var name = layerName
        if (name == null) { name = findLayer(pkg); layerName = name }
        if (name == null) return -1
        var r = measure(name)
        if (r < 0) {
            val n2 = findLayer(pkg)
            layerName = n2
            r = if (n2 != null) measure(n2) else -1
        }
        return r
    }

    private fun measureFrame(layer: String): Frame {
        val out = Root.run("dumpsys SurfaceFlinger --latency '$layer'")
        val ts = out.lines().drop(1).mapNotNull { ln ->
            val t = ln.trim().split(Regex("\\s+"))
            if (t.size >= 3) t[1].toLongOrNull() else null
        }.filter { it > 0L && it != Long.MAX_VALUE }
        if (ts.size < 2) return Frame(-1, 0, 0)
        var last = 0L
        for (x in ts) if (x > last) last = x
        if (System.nanoTime() - last > 1_500_000_000L) return Frame(0, 1500, 0)
        val win = ts.filter { it >= last - 1_000_000_000L }.sorted()
        if (win.size < 2) return Frame(0, 1000, 0)
        val span = (win.last() - win.first()) / 1e9
        if (span <= 0.0) return Frame(-1, 0, 0)
        val fps = Math.round((win.size - 1) / span).toInt()
        val gaps = ArrayList<Long>()
        for (i in 1 until win.size) gaps.add(win[i] - win[i - 1])
        val med = gaps.sorted()[gaps.size / 2]
        var maxGap = 0L
        var jank = 0
        for (g in gaps) {
            if (g > maxGap) maxGap = g
            if (g > 50_000_000L && g > 2 * med) jank++
        }
        return Frame(fps, (maxGap / 1_000_000L).toInt(), jank)
    }

    // FPS + kestabilan frame, untuk monitor real-time
    fun frameNow(ctx: Context): Frame {
        val pkg = Store(ctx).game
        if (pkg.isNullOrBlank()) return Frame(-1, 0, 0)
        if (layerPkg != pkg) { layerPkg = pkg; layerName = null }
        var name = layerName
        if (name == null) { name = findLayer(pkg); layerName = name }
        if (name == null) return Frame(-1, 0, 0)
        var r = measureFrame(name)
        if (r.fps < 0) {
            val n2 = findLayer(pkg)
            layerName = n2
            r = if (n2 != null) measureFrame(n2) else Frame(-1, 0, 0)
        }
        return r
    }

    fun fpsNow(ctx: Context): Int = frameNow(ctx).fps

    private fun cpu(): Int {
        val l = Root.run("head -n 1 /proc/stat")
        val t = l.trim().split(Regex("\\s+"))
        if (t.size < 8 || t[0] != "cpu") return 0
        val v = t.drop(1).take(8).map { it.toLongOrNull() ?: 0L }
        val total = v.sum()
        val idle = v[3] + v[4]
        val dT = total - lastTotal
        val dI = idle - lastIdle
        val first = lastTotal == 0L
        lastTotal = total
        lastIdle = idle
        if (first || dT <= 0) return 0
        return (100L * (dT - dI) / dT).toInt().coerceIn(0, 100)
    }

    @Suppress("DEPRECATION")
    fun sample(ctx: Context, withFps: Boolean = true): Sample {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ram = if (mi.totalMem > 0) (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt() else 0
        val temp = try {
            (ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                ?.getIntExtra("temperature", 0) ?: 0) / 10f
        } catch (e: Exception) { 0f }
        val hz = try {
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.refreshRate.toInt()
        } catch (e: Exception) { 60 }
        return Sample(ram, cpu(), temp, hz, if (withFps) fps(Store(ctx).game) else -1)
    }
}
