package com.xa.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.WindowManager

object SysStats {
    data class Sample(val ramPct: Int, val cpuPct: Int, val tempC: Float, val hz: Int, val fps: Int)

    // Statistik frame 1 detik terakhir: fps, jeda frame terpanjang (ms), jumlah frame patah (jeda > 50 ms dan > 2x median)
    data class Frame(val fps: Int, val maxGapMs: Int, val janks: Int, val est: Boolean = false)

    private var lastTotal = 0L
    private var lastIdle = 0L

    private var layerPkg: String? = null
    private var layerName: String? = null
    private var layerRetryAt = 0L
    private var cntLast = -1L
    private var cntAt = 0L

    // semua layer milik game, urut dari yang paling mungkin (SurfaceView dulu)
    private fun candidates(pkg: String): List<String> {
        val l = Root.run("dumpsys SurfaceFlinger --list").lines().map { it.trim() }.filter { it.contains(pkg) }
        val first = l.filter { it.startsWith("SurfaceView") && !it.contains("Background") }
        val second = l.filter { !it.startsWith("SurfaceView") && !it.contains("Background") && !it.contains("Bounds") }
        val third = l.filter { it.contains("Background") }
        return (first + second + third).distinct().take(6)
    }

    // pilih layer yang benar-benar mengeluarkan data frame
    private fun pickLayer(pkg: String): String? {
        for (c in candidates(pkg)) if (measureFrame(c).fps > 0) return c
        return null
    }

    // Cadangan: laju komposisi SurfaceFlinger (perkiraan FPS) bila data per-layer tidak diberikan HP ini
    private fun sfCounter(): Long {
        val o = Root.run("service call SurfaceFlinger 1013")
        val m = Regex("Parcel\\(\\s*[0-9a-fA-F]{8}\\s+([0-9a-fA-F]{8})").find(o) ?: return -1L
        return m.groupValues[1].toLongOrNull(16) ?: -1L
    }

    private fun estimateFps(): Frame {
        val c = sfCounter()
        val now = System.nanoTime()
        if (c < 0) return Frame(-1, 0, 0)
        val pc = cntLast
        val pt = cntAt
        cntLast = c
        cntAt = now
        if (pc < 0 || c < pc) return Frame(-1, 0, 0)
        val dt = (now - pt) / 1e9
        if (dt < 0.3) return Frame(-1, 0, 0)
        return Frame(Math.round((c - pc) / dt).toInt().coerceIn(0, 240), 0, 0, true)
    }

    private fun foregroundPkg(): String? {
        val rx = Regex("u\\d+\\s+([A-Za-z0-9_.]+)/")
        var o = Root.run("dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity' | head -n 2")
        rx.find(o)?.let { return it.groupValues[1] }
        o = Root.run("dumpsys window | grep mCurrentFocus | head -n 1")
        return rx.find(o)?.groupValues?.get(1)
    }

    private fun measureFrame(layer: String): Frame {
        val out = Root.run("dumpsys SurfaceFlinger --latency '$layer'")
        val ts = out.lines().drop(1).mapNotNull { ln ->
            val t = ln.trim().split(Regex("\\s+"))
            if (t.size >= 3) t[1].toLongOrNull() else null
        }.filter { it > 0L && it != Long.MAX_VALUE }
        if (ts.size < 2) return Frame(-1, 0, 0)
        var last = 0L
        for (x in ts) if (x > last) last = x
        if (System.nanoTime() - last > 1_500_000_000L) return Frame(0, 1500, 0)
        val win = ts.filter { it >= last - 1_000_000_000L }.sorted()
        if (win.size < 2) return Frame(0, 1000, 0)
        val span = (win.last() - win.first()) / 1e9
        if (span <= 0.0) return Frame(-1, 0, 0)
        val fps = Math.round((win.size - 1) / span).toInt()
        val gaps = ArrayList<Long>()
        for (i in 1 until win.size) gaps.add(win[i] - win[i - 1])
        val med = gaps.sorted()[gaps.size / 2]
        var maxGap = 0L
        var jank = 0
        for (g in gaps) {
            if (g > maxGap) maxGap = g
            if (g > 50_000_000L && g > 2 * med) jank++
        }
        return Frame(fps, (maxGap / 1_000_000L).toInt(), jank)
    }

    // FPS + kestabilan frame, untuk monitor real-time
    fun frameNow(ctx: Context): Frame {
        var pkg = Store(ctx).game
        if (pkg.isNullOrBlank()) pkg = foregroundPkg()
        if (pkg.isNullOrBlank()) return Frame(-1, 0, 0)
        if (layerPkg != pkg) { layerPkg = pkg; layerName = null; layerRetryAt = 0L }
        val now = System.currentTimeMillis()
        var name = layerName
        if (name == null && now >= layerRetryAt) {
            name = pickLayer(pkg)
            layerName = name
            if (name == null) layerRetryAt = now + 10000L
        }
        if (name != null) {
            val r = measureFrame(name)
            if (r.fps >= 0) return r
            layerName = null
            layerRetryAt = 0L
        }
        return estimateFps()
    }

    fun fpsNow(ctx: Context): Int = frameNow(ctx).fps

    private fun cpu(): Int {
        val l = Root.run("head -n 1 /proc/stat")
        val t = l.trim().split(Regex("\\s+"))
        if (t.size < 8 || t[0] != "cpu") return 0
        val v = t.drop(1).take(8).map { it.toLongOrNull() ?: 0L }
        val total = v.sum()
        val idle = v[3] + v[4]
        val dT = total - lastTotal
        val dI = idle - lastIdle
        val first = lastTotal == 0L
        lastTotal = total
        lastIdle = idle
        if (first || dT <= 0) return 0
        return (100L * (dT - dI) / dT).toInt().coerceIn(0, 100)
    }

    @Suppress("DEPRECATION")
    fun sample(ctx: Context, withFps: Boolean = true): Sample {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ram = if (mi.totalMem > 0) (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt() else 0
        val temp = try {
            (ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                ?.getIntExtra("temperature", 0) ?: 0) / 10f
        } catch (e: Exception) { 0f }
        val hz = try {
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.refreshRate.toInt()
        } catch (e: Exception) { 60 }
        return Sample(ram, cpu(), temp, hz, if (withFps) frameNow(ctx).fps else -1)
    }
}
