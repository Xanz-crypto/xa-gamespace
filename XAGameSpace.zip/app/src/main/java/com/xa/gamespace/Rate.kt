package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

// ================= Render / VSync Rate & GPU Render Vsync (dari module SkiaPerf) =================
// Perintah GPU render vsync persis sama dengan gpu-render-vsync-enable/disable.js di module SkiaPerf.
// VSync FPS memakai setprop debug.sf.sw_vsync_fps + resetprop seperti bagian VSYNC FPS di module.
// Render rate memakai kunci refresh-rate sistem (sama dengan Smooth FPS di aplikasi ini).
object RateCmd {
    const val KEY_RENDER = "render_rate"   // "" = bawaan, atau angka Hz
    const val KEY_GPU    = "gpu_vsync"     // "1" hidup, "0" mati, "" belum diatur
    const val KEY_VFPS   = "vsync_fps"    // "" belum diatur, atau angka FPS

    val RENDER_HZ  = listOf("60", "90", "120", "144", "165", "185", "240")
    val VSYNC_FPS  = listOf("0", "60", "90", "120", "144", "165", "185", "240")

    const val VERIFY_RENDER = "settings get system min_refresh_rate; settings get system peak_refresh_rate"
    const val VERIFY_GPU    = "getprop debug.gpurend.vsync; getprop debug.hwc.force_gpu_vsync; getprop debug.sf.sw_vsync_fps"

    fun renderCmd(hz: String): String = listOf(
        "settings put system min_refresh_rate $hz",
        "settings put system peak_refresh_rate $hz",
        "settings put system user_refresh_rate $hz"
    ).joinToString("\n")

    fun renderDefaultCmd(): String = listOf(
        "settings delete system min_refresh_rate",
        "settings delete system peak_refresh_rate",
        "settings delete system user_refresh_rate"
    ).joinToString("\n")

    // Persis sama dengan gpu-render-vsync-enable/disable.js di module SkiaPerf
    fun gpuVsyncCmd(on: Boolean): String =
        "setprop debug.gpurend.vsync $on\nsetprop debug.hwc.force_gpu_vsync $on"

    // VSync FPS: setprop + resetprop multi-key seperti bagian VSYNC FPS module
    fun vsyncFpsCmd(fps: String): String = listOf(
        "setprop debug.sf.sw_vsync_fps $fps",
        "resetprop -n androidboot.qemu.vsync $fps",
        "resetprop -n hw.lcd.vsync $fps",
        "resetprop -n ro.boot.qemu.vsync $fps",
        "resetprop -n qemu.vsync $fps",
        "resetprop -n vendor.debug.sf.sw_vsync_fps $fps",
        "resetprop -n ro.vendor.magt.mtk_magt_support.vsync.maxfps $fps"
    ).joinToString("\n")
}

// ============================================================
//  RateOverlaySheet — slider mini untuk VSync FPS atau GPU
//  Render Vsync, muncul di dalam Game Panel (showAux / openHz)
//  mode: MODE_VSYNC = VSync FPS slider
//        MODE_GPU   = GPU Render Vsync ON/OFF slider
// ============================================================
class RateOverlaySheet(
    private val ctx: Context,
    private val store: Store,
    private val mode: Int,
    private val onClose: () -> Unit
) {
    companion object {
        const val MODE_VSYNC = 0
        const val MODE_GPU   = 1
    }

    val root: LinearLayout = LinearLayout(ctx).also {
        it.orientation = LinearLayout.VERTICAL
        it.setPadding(ctx.px(16), ctx.px(14), ctx.px(16), ctx.px(14))
        it.background = Hud.rounded(Color.argb(240, 8, 22, 42), Hud.neon, ctx.pxf(14f), 1.4f)
    }

    private val out = TextView(ctx).also {
        it.textSize = 10f
        it.setTextColor(Hud.sub)
        it.typeface = Typeface.DEFAULT_BOLD
    }

    init {
        if (mode == MODE_VSYNC) buildVsync() else buildGpu()
        // baris output status + tombol tutup
        root.addView(out, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(8) })
        root.addView(closeBtn())
    }

    // ---------- VSync FPS ----------
    private fun buildVsync() {
        val list  = RateCmd.VSYNC_FPS          // ["0","60","90","120","144","165","185","240"]
        val cur   = list.indexOf(store.get(RateCmd.KEY_VFPS)).coerceAtLeast(0)

        val head  = neonLabel("VSync FPS  ·  GESER")
        val value = bigLabel(labelVsync(list[cur]))

        val sb = seekBar(list.size - 1, cur)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                value.text = labelVsync(list[p])
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {
                val v = list[s.progress]
                store.put(RateCmd.KEY_VFPS, v)
                apply(RateCmd.vsyncFpsCmd(v), "VSync FPS $v", RateCmd.VERIFY_GPU)
            }
        })
        root.addView(head)
        root.addView(value, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(4) })
        root.addView(sb,    LinearLayout.LayoutParams(ctx.px(320), -2).also { it.topMargin = ctx.px(8) })
    }

    // ---------- GPU Render Vsync ----------
    private fun buildGpu() {
        // 0 = Mati, 1 = Hidup  (slider 2 posisi)
        val cur   = if (store.get(RateCmd.KEY_GPU) == "1") 1 else 0

        val head  = neonLabel("GPU Render Vsync  ·  GESER")
        val value = bigLabel(labelGpu(cur))

        val sb = seekBar(1, cur)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                value.text = labelGpu(p)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {
                val on = s.progress == 1
                store.put(RateCmd.KEY_GPU, if (on) "1" else "0")
                apply(RateCmd.gpuVsyncCmd(on), "GPU Render Vsync ${if (on) "HIDUP" else "MATI"}", RateCmd.VERIFY_GPU)
            }
        })
        root.addView(head)
        root.addView(value, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(4) })
        root.addView(sb,    LinearLayout.LayoutParams(ctx.px(200), -2).also { it.topMargin = ctx.px(8) })
    }

    // ---------- helpers ----------
    private fun labelVsync(v: String) = if (v == "0") "Off  (0)" else "$v FPS"
    private fun labelGpu(p: Int)      = if (p == 1)   "HIDUP ✓" else "MATI"

    private fun neonLabel(t: String): TextView {
        val v = TextView(ctx)
        v.text = t; v.textSize = 11f; v.setTextColor(Hud.neon)
        v.typeface = Typeface.DEFAULT_BOLD; v.letterSpacing = 0.2f
        return v
    }

    private fun bigLabel(t: String): TextView {
        val v = TextView(ctx)
        v.text = t; v.textSize = 18f; v.setTextColor(Color.WHITE)
        v.typeface = Typeface.DEFAULT_BOLD; v.gravity = Gravity.CENTER
        return v
    }

    private fun seekBar(max: Int, cur: Int): SeekBar {
        val sb = SeekBar(ctx)
        sb.max = max; sb.progress = cur
        val tint = android.content.res.ColorStateList.valueOf(Hud.neon)
        sb.progressTintList = tint; sb.thumbTintList = tint
        sb.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(80, 46, 245, 160))
        return sb
    }

    private fun closeBtn(): TextView {
        val v = TextView(ctx)
        v.text = "TUTUP"; v.textSize = 11f; v.setTextColor(Color.WHITE)
        v.gravity = Gravity.CENTER; v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(ctx.px(12), ctx.px(6), ctx.px(12), ctx.px(6))
        v.background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
        v.setOnClickListener { Sfx.tap(); onClose() }
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = Gravity.END; lp.topMargin = ctx.px(8)
        v.layoutParams = lp
        return v
    }

    private fun apply(cmd: String, label: String, verify: String) {
        if (!Access.requires(ctx, label, true)) return
        out.text = "Menerapkan $label…"
        Thread {
            val r = Access.run(cmd)
            val chk = Access.run(verify)
            out.post {
                out.text = "$label\n${r.ifBlank { "(tanpa output)" }}\n\nCek: ${chk.ifBlank { "(kosong)" }}"
            }
        }.start()
    }
}

// ============================================================
//  RatePanel — dipakai di HIGH BOOST menu MainActivity (mode 0/1)
// ============================================================
class RatePanel(private val a: MainActivity, private val mode: Int) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box  = u.vbox()
    private val out  = u.label("", 11f, Theme.sub)
    private var rate = a.store.get(RateCmd.KEY_RENDER)
    private var gpu  = a.store.get(RateCmd.KEY_GPU)
    private var vfps = a.store.get(RateCmd.KEY_VFPS)

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        draw()
    }

    private fun chips(opts: List<Pair<String, String>>, cur: String, pick: (String) -> Unit): View {
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        val l = u.hbox()
        opts.forEach { (label, v) ->
            val on = v == cur
            val t = u.label(label, 12f, if (on) Color.parseColor("#04141F") else Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(u.dp(12), u.dp(7), u.dp(12), u.dp(7))
            t.background = if (on) u.glass(20, Hud.cyan, Hud.cyan)
            else u.glass(20, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
            t.setOnClickListener { Sfx.tap(); pick(v) }
            l.addView(t, u.lp(-2, -2, r = 6))
        }
        hs.addView(l)
        return hs
    }

    private fun section(title: String, body: View) {
        box.addView(u.label(title, 11f, Theme.sub, true), u.lp(b = 4))
        box.addView(body, u.lp(b = 10))
    }

    private fun draw() {
        box.removeAllViews()
        if (mode == 0) {
            section("RENDER / VSYNC RATE (Hz)", chips(
                listOf("Bawaan" to "") + RateCmd.RENDER_HZ.map { "$it Hz" to it }, rate
            ) { v ->
                if (!Access.requires(a, "Render rate", true)) return@chips
                rate = v; a.store.put(RateCmd.KEY_RENDER, v); draw()
                if (v.isBlank()) run(RateCmd.renderDefaultCmd(), "Render rate bawaan", RateCmd.VERIFY_RENDER)
                else run(RateCmd.renderCmd(v), "Render rate $v Hz", RateCmd.VERIFY_RENDER)
            })
        } else {
            section("GPU RENDER VSYNC", chips(
                listOf("Mati" to "0", "Hidup" to "1"), gpu
            ) { v ->
                if (!Access.requires(a, "GPU render vsync", true)) return@chips
                gpu = v; a.store.put(RateCmd.KEY_GPU, v); draw()
                run(RateCmd.gpuVsyncCmd(v == "1"), "GPU render vsync ${if (v == "1") "hidup" else "mati"}", RateCmd.VERIFY_GPU)
            })
            section("VSYNC FPS (Frame Per Second)", chips(
                RateCmd.VSYNC_FPS.map { (if (it == "0") "0 (Off)" else "$it FPS") to it }, vfps
            ) { v ->
                if (!Access.requires(a, "VSync FPS", true)) return@chips
                vfps = v; a.store.put(RateCmd.KEY_VFPS, v); draw()
                run(RateCmd.vsyncFpsCmd(v), "VSync FPS $v", RateCmd.VERIFY_GPU)
            })
        }
        box.addView(u.label(
            "Perubahan langsung diterapkan. Butuh root. Hasil tiap perangkat bergantung ROM dan kernel.",
            10f, Theme.sub), u.lp(b = 8))
        box.addView(out)
    }

    private fun run(cmd: String, label: String, verify: String) {
        if (!Access.requires(a, label, true)) return
        out.text = "Menerapkan $label..."
        Thread {
            val r = Access.run(cmd)
            val chk = Access.run(verify)
            a.runOnUiThread {
                out.text = "$label\n${r.ifBlank { "(tanpa output)" }}\n\nCek:\n${chk.ifBlank { "(kosong)" }}"
            }
        }.start()
    }
}
