package com.xa.gamespace

import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView

// ================= Render / VSync Rate & GPU Rate / VSync FPS (dari module SkiaPerf) =================
// Perintah VSync FPS & GPU render vsync sama dengan gpu-render-vsync-*.js dan bagian VSYNC FPS di index.html module.
// Catatan: script render-rate-*.js di module memanggil 60hz.sh..240hz.sh yang TIDAK ada di zip module,
// jadi render rate memakai kunci refresh-rate sistem yang juga dipakai Smooth FPS di aplikasi ini.
object RateCmd {
    const val KEY_RENDER = "render_rate"   // "" = bawaan, atau angka Hz
    const val KEY_GPU = "gpu_vsync"        // "1" hidup, "0" mati, "" belum diatur
    const val KEY_VFPS = "vsync_fps"       // "" belum diatur, atau angka FPS

    val RENDER_HZ = listOf("60", "90", "120", "144", "165", "185", "240")
    val VSYNC_FPS = listOf("0", "60", "90", "120", "144", "165", "185", "240")

    const val VERIFY_RENDER = "settings get system min_refresh_rate; settings get system peak_refresh_rate"
    const val VERIFY_GPU = "getprop debug.gpurend.vsync; getprop debug.hwc.force_gpu_vsync; getprop debug.sf.sw_vsync_fps"

    fun renderCmd(hz: String): String = listOf(
        "settings put system min_refresh_rate $hz",
        "settings put system peak_refresh_rate $hz",
        "settings put system user_refresh_rate $hz"
    ).joinToString("\n")

    fun renderDefaultCmd(): String = listOf(
        "settings delete system min_refresh_rate",
        "settings delete system peak_refresh_rate",
        "settings delete system user_refresh_rate"
    ).joinToString("\n")

    fun gpuVsyncCmd(on: Boolean): String =
        "setprop debug.gpurend.vsync $on\nsetprop debug.hwc.force_gpu_vsync $on"

    fun vsyncFpsCmd(fps: String): String = listOf(
        "setprop debug.sf.sw_vsync_fps $fps",
        "resetprop -n androidboot.qemu.vsync $fps",
        "resetprop -n hw.lcd.vsync $fps",
        "resetprop -n ro.boot.qemu.vsync $fps",
        "resetprop -n qemu.vsync $fps",
        "resetprop -n vendor.debug.sf.sw_vsync_fps $fps",
        "resetprop -n ro.vendor.magt.mtk_magt_support.vsync.maxfps $fps"
    ).joinToString("\n")
}

// mode 0 = Render / VSync Rate (Hz), mode 1 = GPU Rate / VSync FPS
class RatePanel(private val a: MainActivity, private val mode: Int) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box = u.vbox()
    private val out = u.label("", 11f, Theme.sub)
    private var rate = a.store.get(RateCmd.KEY_RENDER)
    private var gpu = a.store.get(RateCmd.KEY_GPU)
    private var vfps = a.store.get(RateCmd.KEY_VFPS)

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        draw()
    }

    private fun chips(opts: List<Pair<String, String>>, cur: String, pick: (String) -> Unit): View {
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        val l = u.hbox()
        opts.forEach { (label, v) ->
            val on = v == cur
            val t = u.label(label, 12f, if (on) Color.parseColor("#04141F") else Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(u.dp(12), u.dp(7), u.dp(12), u.dp(7))
            t.background = if (on) u.glass(20, Hud.cyan, Hud.cyan)
            else u.glass(20, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
            t.setOnClickListener { Sfx.tap(); pick(v) }
            l.addView(t, u.lp(-2, -2, r = 6))
        }
        hs.addView(l)
        return hs
    }

    private fun section(title: String, body: View) {
        box.addView(u.label(title, 11f, Theme.sub, true), u.lp(b = 4))
        box.addView(body, u.lp(b = 10))
    }

    private fun draw() {
        box.removeAllViews()
        if (mode == 0) {
            section("RENDER / VSYNC RATE (Hz)", chips(
                listOf("Bawaan" to "") + RateCmd.RENDER_HZ.map { "$it Hz" to it }, rate
            ) { v ->
                if (!Access.requires(a, "Render rate", true)) return@chips
                rate = v
                a.store.put(RateCmd.KEY_RENDER, v)
                draw()
                if (v.isBlank()) run(RateCmd.renderDefaultCmd(), "Render rate bawaan", RateCmd.VERIFY_RENDER)
                else run(RateCmd.renderCmd(v), "Render rate $v Hz", RateCmd.VERIFY_RENDER)
            })
        } else {
            section("GPU RENDER VSYNC", chips(
                listOf("Mati" to "0", "Hidup" to "1"), gpu
            ) { v ->
                if (!Access.requires(a, "GPU render vsync", true)) return@chips
                gpu = v
                a.store.put(RateCmd.KEY_GPU, v)
                draw()
                run(RateCmd.gpuVsyncCmd(v == "1"), "GPU render vsync ${if (v == "1") "hidup" else "mati"}", RateCmd.VERIFY_GPU)
            })
            section("VSYNC FPS (Frame Per Second)", chips(
                RateCmd.VSYNC_FPS.map { (if (it == "0") "0 (Off)" else "$it FPS") to it }, vfps
            ) { v ->
                if (!Access.requires(a, "VSync FPS", true)) return@chips
                vfps = v
                a.store.put(RateCmd.KEY_VFPS, v)
                draw()
                run(RateCmd.vsyncFpsCmd(v), "VSync FPS $v", RateCmd.VERIFY_GPU)
            })
        }
        box.addView(u.label(
            "Perubahan langsung diterapkan. Butuh root. Hasil tiap perangkat bergantung ROM dan kernel.",
            10f, Theme.sub), u.lp(b = 8))
        box.addView(out)
    }

    private fun run(cmd: String, label: String, verify: String) {
        if (!Access.requires(a, label, true)) return
        out.text = "Menerapkan $label..."
        Thread {
            val r = Access.run(cmd)
            val check = Access.run(verify)
            a.runOnUiThread {
                out.text = "$label\n" +
                    (r.ifBlank { "(tanpa output)" }) + "\n\nCek:\n" +
                    check.ifBlank { "(kosong)" }
            }
        }.start()
    }
}
