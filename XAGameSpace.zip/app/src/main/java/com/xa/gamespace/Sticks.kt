package com.xa.gamespace

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.animation.LinearInterpolator

// Menggambar satu stik cahaya (garis neon): lapisan cahaya lebar, lapisan warna, inti putih.
// angle = derajat dari posisi tegak; k = penguat cahaya; pulse = denyut cahaya luar.
internal class StickPainter(private val ctx: Context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    // stik berbentuk garis patah (mengikuti sudut terpotong bingkai panel)
    fun drawPath(cv: Canvas, path: Path, col: Int, k: Float = 1f, alpha: Float = 1f, pulse: Float = 1f) {
        if (alpha <= 0.01f) return
        val r = Color.red(col); val g = Color.green(col); val b = Color.blue(col)
        p.color = Color.argb((70 * pulse * k * alpha).toInt().coerceIn(0, 255), r, g, b)
        p.strokeWidth = ctx.pxf(9f) * k
        cv.drawPath(path, p)
        p.color = Color.argb((150 * alpha).toInt().coerceIn(0, 255), r, g, b)
        p.strokeWidth = ctx.pxf(5f)
        cv.drawPath(path, p)
        p.color = Color.argb((245 * alpha).toInt().coerceIn(0, 255), 235, 250, 255)
        p.strokeWidth = ctx.pxf(2.6f)
        cv.drawPath(path, p)
    }

    fun draw(cv: Canvas, x: Float, y: Float, half: Float, angle: Float, col: Int,
             k: Float = 1f, alpha: Float = 1f, pulse: Float = 1f) {
        if (half <= 0f || alpha <= 0.01f) return
        val r = Color.red(col); val g = Color.green(col); val b = Color.blue(col)
        cv.save()
        if (angle != 0f) cv.rotate(angle, x, y)
        p.color = Color.argb((70 * pulse * k * alpha).toInt().coerceIn(0, 255), r, g, b)
        p.strokeWidth = ctx.pxf(9f) * k
        cv.drawLine(x, y - half, x, y + half, p)
        p.color = Color.argb((150 * alpha).toInt().coerceIn(0, 255), r, g, b)
        p.strokeWidth = ctx.pxf(5f)
        cv.drawLine(x, y - half, x, y + half, p)
        p.color = Color.argb((245 * alpha).toInt().coerceIn(0, 255), 235, 250, 255)
        p.strokeWidth = ctx.pxf(2.6f)
        cv.drawLine(x, y - half, x, y + half, p)
        cv.restore()
    }
}

// Dua stik yang menempel di sisi kiri dan kanan panel; dipakai PanelUi saat panel membuka / menutup
class SticksView(c: Context) : View(c) {
    private val sp = StickPainter(c)
    private var lx = 0f
    private var rx = 0f
    private var cy = 0f
    private var half = 0f
    private var dx = 0f      // jarak tekuk ujung stik ke arah dalam panel (px)
    private var dy = 0f      // tinggi bagian miring di ujung stik (px)
    private var aR = 1f      // keterlihatan stik kanan (0 = menyatu jadi satu stik di sisi layar)
    private val path = Path()
    private var anim: ValueAnimator? = null

    fun set(lx: Float, rx: Float, cy: Float, half: Float, dx: Float, dy: Float, aR: Float) {
        this.lx = lx; this.rx = rx; this.cy = cy; this.half = half
        this.dx = dx; this.dy = dy; this.aR = aR
        invalidate()
    }

    // dir = +1 untuk stik kiri (ujung menekuk ke kanan), -1 untuk stik kanan (menekuk ke kiri)
    private fun build(x: Float, dir: Float): Path {
        path.reset()
        path.moveTo(x + dir * dx, cy - half)
        path.lineTo(x, cy - half + dy)
        path.lineTo(x, cy + half - dy)
        path.lineTo(x + dir * dx, cy + half)
        return path
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1000
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { invalidate() }
        anim = a
        a.start()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val t = animNow()
        val col = Wet.cycle(t, 6f)
        val pulse = 0.7f + 0.3f * kotlin.math.sin(t * 3f)
        sp.drawPath(cv, build(lx, 1f), col, 1f, 1f, pulse)
        sp.drawPath(cv, build(rx, -1f), col, 1f, aR, pulse)
    }
}
