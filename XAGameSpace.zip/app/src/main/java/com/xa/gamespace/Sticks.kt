package com.xa.gamespace

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator

// Menggambar satu stik cahaya (garis neon): lapisan cahaya lebar, lapisan warna, inti putih.
// angle = derajat dari posisi tegak; k = penguat cahaya; pulse = denyut cahaya luar.
internal class StickPainter(private val ctx: Context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }

    fun draw(cv: Canvas, x: Float, y: Float, half: Float, angle: Float, col: Int,
             k: Float = 1f, alpha: Float = 1f, pulse: Float = 1f) {
        if (half <= 0f || alpha <= 0.01f) return
        val r = Color.red(col); val g = Color.green(col); val b = Color.blue(col)
        cv.save()
        if (angle != 0f) cv.rotate(angle, x, y)
        p.color = Color.argb((70 * pulse * k * alpha).toInt().coerceIn(0, 255), r, g, b)
        p.strokeWidth = ctx.pxf(9f) * k
        cv.drawLine(x, y - half, x, y + half, p)
        p.color = Color.argb((150 * alpha).toInt().coerceIn(0, 255), r, g, b)
        p.strokeWidth = ctx.pxf(5f)
        cv.drawLine(x, y - half, x, y + half, p)
        p.color = Color.argb((245 * alpha).toInt().coerceIn(0, 255), 235, 250, 255)
        p.strokeWidth = ctx.pxf(2.6f)
        cv.drawLine(x, y - half, x, y + half, p)
        cv.restore()
    }
}

// Dua stik yang menempel di sisi kiri dan kanan panel; dipakai PanelUi saat panel membuka / menutup
class SticksView(c: Context) : View(c) {
    private val sp = StickPainter(c)
    private var lx = 0f
    private var rx = 0f
    private var cy = 0f
    private var half = 0f
    private var anim: ValueAnimator? = null

    fun set(lx: Float, rx: Float, cy: Float, half: Float) {
        this.lx = lx; this.rx = rx; this.cy = cy; this.half = half
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1000
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { invalidate() }
        anim = a
        a.start()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val t = animNow()
        val col = Wet.cycle(t, 6f)
        val pulse = 0.7f + 0.3f * kotlin.math.sin(t * 3f)
        sp.draw(cv, lx, cy, half, 0f, col, 1f, 1f, pulse)
        sp.draw(cv, rx, cy, half, 0f, col, 1f, 1f, pulse)
    }
}
