package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextUtils
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// Menu awal: kartu game di atas panggung neon. Geser kiri/kanan untuk ganti game, tombol Start untuk main.
class GameCarousel(ctx: Context) : View(ctx) {
    var items: List<GameApp> = emptyList()
    var onStart: (GameApp) -> Unit = {}
    var onSelect: (GameApp) -> Unit = {}
    var info: (GameApp) -> String = { "" }
    var tags: List<Pair<String, Boolean>> = emptyList()
        set(v) { field = v; invalidate() }

    private var pos = 0f
    private var lastIdx = 0
    private var anim: ValueAnimator? = null
    private var vt: VelocityTracker? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var spacing = 1f
    private var cardCx = 0f
    private var cardW = 0f
    private val startRect = RectF()
    private var now = 0f
    private val clip = android.graphics.Path()
    private val sheen = Paint()
    private val auroraP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gm = Matrix()
    private val bodyShader = LinearGradient(0f, 0f, 0f, 1f,
        Color.rgb(18, 44, 86), Color.rgb(6, 12, 28), Shader.TileMode.CLAMP)
    private val unitRad = RadialGradient(0f, 0f, 1f,
        intArrayOf(Color.WHITE, Color.argb(0, 255, 255, 255)), null, Shader.TileMode.CLAMP)
    private val strCache = HashMap<String, String>()
    private val tp = android.text.TextPaint()

    private fun fit(s: String, w: Float): String {
        val key = s + "|" + w.toInt() + "|" + text.textSize.toInt() + "|" + (if (text.typeface == Typeface.DEFAULT_BOLD) 1 else 0)
        return strCache.getOrPut(key) {
            tp.set(text)
            TextUtils.ellipsize(s, tp, w, TextUtils.TruncateAt.END).toString()
        }
    }

    // lingkaran cahaya berwarna: satu shader dipakai ulang
    private fun glow(cv: Canvas, x: Float, y: Float, rad: Float, color: Int, a: Int) {
        if (a <= 0) return
        gm.setScale(rad, rad)
        gm.postTranslate(x, y)
        unitRad.setLocalMatrix(gm)
        auroraP.shader = unitRad
        auroraP.colorFilter = android.graphics.PorterDuffColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN)
        auroraP.alpha = a.coerceIn(0, 255)
        cv.drawCircle(x, y, rad, auroraP)
        auroraP.shader = null
        auroraP.colorFilter = null
        auroraP.alpha = 255
    }
    private val smat = Matrix()
    private val sheenShader = LinearGradient(0f, 0f, 1f, 0f,
        intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(95, 215, 245, 255), Color.argb(0, 255, 255, 255)),
        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)

    private val cam = Camera()
    private val mat = Matrix()
    private val rect = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun dp(v: Float) = context.pxf(v)

    fun setItems(list: List<GameApp>, selectPkg: String?) {
        items = list
        val i = list.indexOfFirst { it.pkg == selectPkg }.let { if (it < 0) 0 else it }
        pos = i.toFloat()
        lastIdx = i
        invalidate()
    }

    fun current(): GameApp? = items.getOrNull(pos.roundToInt().coerceIn(0, max(0, items.size - 1)))

    private fun tick() {
        val idx = pos.roundToInt().coerceIn(0, max(0, items.size - 1))
        if (idx != lastIdx) {
            lastIdx = idx
            Sfx.play("swipe", 0.7f)
            items.getOrNull(idx)?.let { onSelect(it) }
        }
    }

    private fun snap(target: Int) {
        if (items.isEmpty()) return
        val t = target.coerceIn(0, items.size - 1).toFloat()
        anim?.cancel()
        val a = ValueAnimator.ofFloat(pos, t)
        a.duration = (380 + 140 * abs(t - pos).coerceAtMost(2f)).toLong()
        a.interpolator = android.view.animation.PathInterpolator(0.22f, 1f, 0.36f, 1f)
        a.addUpdateListener { pos = it.animatedValue as Float; tick(); invalidate() }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { pos = t; tick(); invalidate() }
        })
        anim = a
        a.start()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (items.isEmpty()) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                anim?.cancel()
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(e)
                downX = e.x; downY = e.y; lastX = e.x
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (!dragging && abs(e.x - downX) > slop) dragging = true
                if (dragging) {
                    pos -= (e.x - lastX) / spacing
                    pos = pos.coerceIn(-0.35f, items.size - 1 + 0.35f)
                    tick()
                    invalidate()
                }
                lastX = e.x
            }
            MotionEvent.ACTION_UP -> {
                vt?.addMovement(e)
                vt?.computeCurrentVelocity(1000)
                val vx = vt?.xVelocity ?: 0f
                vt?.recycle(); vt = null
                if (dragging) {
                    snap((pos - vx / spacing * 0.22f).roundToInt())
                } else {
                    val idx = pos.roundToInt().coerceIn(0, items.size - 1)
                    when {
                        abs(pos - idx) < 0.06f && startRect.contains(e.x, e.y) -> {
                            Sfx.play("open")
                            onStart(items[idx])
                        }
                        e.x < cardCx - cardW / 2 -> snap(idx - 1)
                        e.x > cardCx + cardW / 2 -> snap(idx + 1)
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                vt?.recycle(); vt = null
                snap(pos.roundToInt())
            }
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        now = animNow()
        if (isAttachedToWindow) postInvalidateOnAnimation()
        cardW = min(w * 0.34f, dp(290f))
        val ch = cardW * 0.66f
        cardCx = w / 2f
        val cy = h * 0.47f
        spacing = cardW * 0.95f

        drawStage(cv, cardCx, cy + ch / 2f, cardW)

        if (items.isEmpty()) {
            text.reset(); text.isAntiAlias = true
            text.color = Color.parseColor("#9FB8D0"); text.textSize = dp(14f); text.textAlign = Paint.Align.CENTER
            cv.drawText("Belum ada game terdeteksi di HP ini.", cardCx, cy, text)
            startRect.setEmpty()
            return
        }

        val from = floor(pos).toInt() - 2
        val to = ceil(pos).toInt() + 2
        val order = (from..to).filter { it in items.indices }.sortedByDescending { abs(it - pos) }
        startRect.setEmpty()
        for (i in order) {
            val d = i - pos
            val ad = abs(d)
            if (ad > 2.3f) continue
            val sc = 1f - 0.2f * min(ad, 1f) - 0.08f * (min(ad, 2f) - min(ad, 1f))
            val al = (255 * (1f - 0.5f * min(ad, 1.5f))).toInt().coerceIn(40, 255)
            val x = cardCx + d * spacing
            val focus = 1f - min(ad, 1f)
            // kartu melayang pelan; kartu aktif paling terasa
            val y = cy + min(ad, 1.5f) * ch * 0.06f + sin(now * 1.6f + i * 0.9f) * dp(2.6f) * (0.35f + 0.65f * focus)
            val rot = (-d * 32f).coerceIn(-40f, 40f)
            cam.save()
            cam.rotateY(rot)
            cam.getMatrix(mat)
            cam.restore()
            mat.preTranslate(-x, -y)
            mat.postTranslate(x, y)
            cv.save()
            cv.concat(mat)
            cv.scale(sc, sc, x, y)
            drawCard(cv, items[i], x, y, cardW, ch, focus, al, ad < 0.06f)
            cv.restore()
        }
    }

    private fun drawStage(cv: Canvas, cx: Float, y: Float, cw: Float) {
        val py = y + cw * 0.10f
        // cahaya di bawah kartu
        fill.shader = RadialGradient(cx, py, cw * 0.95f,
            intArrayOf(Color.argb(150, 60, 120, 255), Color.argb(0, 20, 30, 90)), null, Shader.TileMode.CLAMP)
        cv.save(); cv.scale(1f, 0.28f, cx, py); cv.drawCircle(cx, py, cw * 0.95f, fill); cv.restore()
        fill.shader = null
        stroke.shader = null
        val cols = intArrayOf(Color.parseColor("#3CC8FF"), Color.parseColor("#4F6BFF"), Color.parseColor("#B04CFF"))
        val pulse = 0.65f + 0.35f * sin(now * 2.4f)
        for (k in 0 until 3) {
            val rx = cw * (0.62f + 0.2f * k)
            val ry = rx * 0.16f
            rect.set(cx - rx, py - ry, cx + rx, py + ry)
            val cc = Wet.mix(cols[k], Wet.cycle(now + k * 2.5f, 9f), 0.5f)
            stroke.color = Color.argb((95 * pulse).toInt(), Color.red(cc), Color.green(cc), Color.blue(cc))
            stroke.strokeWidth = dp(8f)
            cv.drawOval(rect, stroke)
            stroke.color = cc
            stroke.strokeWidth = dp(1.8f)
            cv.drawOval(rect, stroke)
        }
        // berkas cahaya dari panggung naik ke kartu: kartu terasa menyatu dengan panggung
        val bc = Wet.cycle(now, 8f)
        val btop = py - cw * 0.70f
        fill.shader = LinearGradient(0f, py, 0f, btop,
            Color.argb((60 + 30 * pulse).toInt(), Color.red(bc), Color.green(bc), Color.blue(bc)),
            Color.argb(0, Color.red(bc), Color.green(bc), Color.blue(bc)), Shader.TileMode.CLAMP)
        beam.reset()
        beam.moveTo(cx - cw * 0.46f, py)
        beam.lineTo(cx + cw * 0.46f, py)
        beam.lineTo(cx + cw * 0.30f, btop)
        beam.lineTo(cx - cw * 0.30f, btop)
        beam.close()
        cv.drawPath(beam, fill)
        fill.shader = null
        // riak air yang melebar dari bawah kartu
        for (k in 0 until 3) {
            val ph = ((now * 0.32f) + k / 3f) % 1f
            val rx = cw * (0.25f + 0.85f * ph)
            val ry = rx * 0.16f
            rect.set(cx - rx, py - ry, cx + rx, py + ry)
            val a = (1f - ph) * (1f - ph)
            stroke.color = Color.argb((170 * a).toInt(), 190, 235, 255)
            stroke.strokeWidth = dp(2.2f) * (1f - ph * 0.5f)
            cv.drawOval(rect, stroke)
        }
    }

    private val beam = android.graphics.Path()
    private val bPath = android.graphics.Path()
    private val bSeg = android.graphics.Path()
    private val bMeasure = android.graphics.PathMeasure()
    private val bubP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val cometP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val bubX = floatArrayOf(0.12f, 0.30f, 0.47f, 0.63f, 0.80f, 0.92f, 0.22f, 0.72f)
    private val bubS = floatArrayOf(0.11f, 0.17f, 0.09f, 0.14f, 0.19f, 0.10f, 0.13f, 0.16f)
    private val bubR = floatArrayOf(3.2f, 2.2f, 3.8f, 2.6f, 2.0f, 3.0f, 2.4f, 3.4f)

    private fun withA(c: Int, k: Float) =
        Color.argb((Color.alpha(c) * k).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    // f = seberapa aktif kartu (1 = di tengah, 0 = di samping). Semua efek dan teks berubah halus mengikuti f,
    // jadi kartu yang bergeser tidak "loncat" dan terasa menyatu.
    private fun drawCard(cv: Canvas, g: GameApp, cx: Float, cy: Float, cw: Float, ch: Float,
                         f: Float, alpha: Int, exact: Boolean) {
        rect.set(cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2)
        val r = dp(14f)
        val ak = alpha / 255f
        val rc = Wet.cycle(now, 8f)
        val rr = Color.red(rc); val rg = Color.green(rc); val rb = Color.blue(rc)

        // badan kaca: agak tembus supaya panggung dan wallpaper terlihat dari belakang
        val bodyK = 0.74f + 0.10f * f
        gm.setScale(1f, ch)
        gm.postTranslate(0f, rect.top)
        bodyShader.setLocalMatrix(gm)
        fill.shader = bodyShader
        fill.alpha = (alpha * bodyK).toInt().coerceIn(0, 255)
        cv.drawRoundRect(rect, r, r, fill)
        fill.shader = null
        fill.alpha = 255

        // ---- efek bergerak di dalam kartu (dipotong mengikuti bentuk kartu) ----
        cv.save()
        clip.reset()
        clip.addRoundRect(rect, r, r, android.graphics.Path.Direction.CW)
        cv.clipPath(clip)

        // aurora: dua gumpalan cahaya mengorbit pelan, warna berganti
        val aur = (0.35f + 0.65f * f) * ak
        for (k in 0 until 2) {
            val ph = now * (0.55f + 0.2f * k) + k * 3.1f
            val bx = cx + kotlin.math.cos(ph) * cw * 0.30f
            val by = cy + sin(ph * 1.3f) * ch * 0.26f
            val cc = Wet.cycle(now + k * 4f, 8f)
            glow(cv, bx, by, cw * 0.62f, cc, (105 * aur).toInt())
        }

        // gelembung kecil naik dari dasar kartu
        for (k in bubX.indices) {
            val ph = (now * bubS[k] + k * 0.37f) % 1f
            val bx = rect.left + cw * bubX[k] + sin(now * 1.4f + k * 1.7f) * dp(4f)
            val by = rect.bottom - ph * ch * 1.08f
            val fa = sin(ph * PIf)
            bubP.strokeWidth = dp(1f)
            bubP.color = Color.argb((150 * fa * aur).toInt().coerceIn(0, 255), 200, 238, 255)
            cv.drawCircle(bx, by, dp(bubR[k]), bubP)
        }
        cv.restore()

        // ---- bingkai ----
        if (f > 0.02f) {
            val pl = 0.6f + 0.4f * sin(now * 2.2f)
            stroke.color = Color.argb(((55 * pl + 20) * f * ak).toInt(), rr, rg, rb); stroke.strokeWidth = dp(12f); cv.drawRoundRect(rect, r, r, stroke)
            stroke.color = Color.argb(((120 * pl + 40) * f * ak).toInt(), rr, rg, rb); stroke.strokeWidth = dp(5f); cv.drawRoundRect(rect, r, r, stroke)
            stroke.color = withA(Wet.mix(Color.parseColor("#9FE6FF"), Color.WHITE, 0.3f * pl), f * ak); stroke.strokeWidth = dp(1.6f); cv.drawRoundRect(rect, r, r, stroke)

            // kilat cahaya berlari mengelilingi tepi kartu
            bPath.reset()
            bPath.addRoundRect(rect, r, r, android.graphics.Path.Direction.CW)
            bMeasure.setPath(bPath, true)
            val len = bMeasure.length
            val head = ((now * 0.30f) % 1f) * len
            val sl = len * 0.045f
            for (k in 0 until 6) {
                val a = (1f - k / 6f) * f * ak
                val s0 = head - (k + 1) * sl
                val s1 = head - k * sl
                cometP.strokeWidth = dp(7f) * (1f - k / 6f)
                cometP.color = Color.argb((90 * a).toInt(), rr, rg, rb)
                segment(cv, s0, s1, len)
                cometP.strokeWidth = dp(2.2f)
                cometP.color = Color.argb((255 * a).toInt(), 235, 250, 255)
                segment(cv, s0, s1, len)
            }
        }
        stroke.color = Color.argb((alpha * (1f - f)).toInt(), 120, 90, 220)
        stroke.strokeWidth = dp(1.2f)
        if (f < 0.98f) cv.drawRoundRect(rect, r, r, stroke)

        // ---- ikon game: menempel di blok kartu (ikut bergerak/berputar persis sama, posisi desimal tanpa jitter) ----
        val isz = ch * 0.40f
        val ix = cx - isz / 2
        val iy = rect.top + ch * 0.10f
        if (f > 0.02f) glow(cv, cx, iy + isz / 2, isz * 0.95f, Color.rgb(rr, rg, rb), (95 * f * ak).toInt())
        g.icon?.let {
            val u = 128
            it.setBounds(0, 0, u, u)
            it.alpha = alpha
            cv.save()
            cv.translate(ix, iy)
            cv.scale(isz / u, isz / u)
            it.draw(cv)
            cv.restore()
        }

        // ---- teks menempel di kartu: tata letak SAMA untuk semua kartu, ikut bergerak/berputar bersama kartunya ----
        text.reset(); text.isAntiAlias = true
        text.typeface = Typeface.DEFAULT_BOLD
        // ---- judul + info ----
        val lx = rect.left + cw * 0.08f
        text.color = Color.argb((255 * ak).toInt(), 255, 255, 255)
        text.textSize = ch * 0.105f
        text.textAlign = Paint.Align.LEFT
        val title = fit(g.label, cw * 0.46f)
        cv.drawText(title, lx, rect.top + ch * 0.64f, text)
        text.typeface = Typeface.DEFAULT
        text.color = Color.argb((255 * ak).toInt(), 159, 184, 208)
        text.textSize = ch * 0.068f
        cv.drawText(fit(info(g), cw * 0.46f), lx, rect.top + ch * 0.74f, text)

        // chip fitur
        var tx = lx
        val ty = rect.bottom - ch * 0.13f
        val th = ch * 0.105f
        text.typeface = Typeface.DEFAULT_BOLD
        text.textSize = ch * 0.058f
        for ((label, on) in tags) {
            val tw = text.measureText(label) + dp(10f)
            if (tx + tw > rect.right - cw * 0.06f) break
            fill.color = if (on) Color.argb((200 * ak).toInt(), 40, 150, 220) else Color.argb((120 * ak).toInt(), 60, 80, 120)
            cv.drawRoundRect(tx, ty, tx + tw, ty + th, th / 2, th / 2, fill)
            text.color = if (on) Color.argb((255 * ak).toInt(), 255, 255, 255) else Color.argb((255 * ak).toInt(), 184, 198, 218)
            cv.drawText(label, tx + dp(5f), ty + th * 0.72f, text)
            tx += tw + dp(4f)
        }

        wetCard(cv, rect, r, (0.3f + 0.7f * f) * ak)

        // ---- tombol Start (di dalam kartu), berdenyut halus ----
        val bw = cw * 0.30f
        val bh = ch * 0.17f
        val bx = rect.right - bw - cw * 0.06f        // seluruhnya di dalam kartu
        val by = rect.top + ch * 0.58f
        val bp = 0.5f + 0.5f * sin(now * 2.6f)
        stroke.color = Color.argb((80 * bp * ak).toInt(), 190, 235, 255)
        stroke.strokeWidth = dp(4f)
        cv.drawRoundRect(bx, by, bx + bw, by + bh, bh * 0.35f, bh * 0.35f, stroke)
        fill.shader = LinearGradient(bx, by, bx + bw, by, Color.parseColor("#FFFFFF"), Color.parseColor("#9ED4FF"), Shader.TileMode.CLAMP)
        fill.alpha = (255 * ak).toInt().coerceIn(0, 255)
        cv.drawRoundRect(bx, by, bx + bw, by + bh, bh * 0.35f, bh * 0.35f, fill)
        fill.shader = null
        fill.alpha = 255
        text.color = Color.argb((255 * ak).toInt(), 10, 42, 74)
        text.textSize = min(ch * 0.085f, bh * 0.58f)
        text.textAlign = Paint.Align.CENTER
        cv.drawText("Start", bx + bw / 2, by + bh * 0.68f, text)
        if (exact) startRect.set(bx, by, bx + bw, by + bh)
    }

    private fun segment(cv: Canvas, a: Float, b: Float, len: Float) {
        if (b <= a) return
        if (a < 0f) { part(cv, a + len, len); part(cv, 0f, b) } else part(cv, a, b)
    }

    private fun part(cv: Canvas, a: Float, b: Float) {
        bSeg.reset()
        bMeasure.getSegment(a, b, bSeg, true)
        cv.drawPath(bSeg, cometP)
    }

    // kartu tampak basah: kilau menyapu + tetesan air
    private fun wetCard(cv: Canvas, r: RectF, rad: Float, k: Float = 1f) {
        cv.save()
        clip.reset()
        clip.addRoundRect(r, rad, rad, android.graphics.Path.Direction.CW)
        cv.clipPath(clip)

        val bw = r.width() * 0.55f
        val travel = r.width() + bw * 2f
        val bx = r.left - bw + ((now * 0.16f) % 1f) * travel
        cv.save()
        cv.rotate(-18f, r.centerX(), r.centerY())
        smat.reset()
        smat.setScale(bw, 1f)
        smat.postTranslate(bx, 0f)
        sheenShader.setLocalMatrix(smat)
        sheen.shader = sheenShader
        sheen.alpha = (255 * k).toInt().coerceIn(0, 255)
        cv.drawRect(bx, r.top - r.height(), bx + bw, r.bottom + r.height(), sheen)
        cv.restore()

        // tetesan air tetap di kartu, sebagian berkilau berdenyut
        val pts = floatArrayOf(0.12f, 0.16f, 3.2f, 0.34f, 0.10f, 2.2f, 0.55f, 0.20f, 2.8f,
            0.78f, 0.12f, 3.6f, 0.90f, 0.30f, 2.4f, 0.20f, 0.46f, 2.0f, 0.62f, 0.52f, 2.6f,
            0.08f, 0.82f, 2.8f, 0.46f, 0.88f, 2.2f, 0.72f, 0.84f, 3.0f)
        var i = 0
        while (i < pts.size) {
            val n = i / 3
            val q = (pts[i + 1] + now * (0.03f + 0.012f * (n % 4))) % 1f
            val gx = r.left + r.width() * pts[i] + sin(now * 0.9f + n) * dp(3f)
            val gy = r.bottom - q * r.height() * 1.05f
            val fa = sin(q * PIf).coerceIn(0f, 1f)
            Wet.droplet(cv, gx, gy, dp(pts[i + 2]), (0.6f + 0.4f * sin(now * 1.6f + i)) * fa * k)
            i += 3
        }
        // satu tetes meluncur turun
        val sx = r.left + r.width() * 0.66f
        val sy = r.top + r.height() * (((now * 0.09f) % 1.1f) - 0.05f)
        Wet.trail(cv, sx, sy, dp(2.6f), k)
        Wet.droplet(cv, sx, sy, dp(2.6f), k)
        cv.restore()
    }
}
