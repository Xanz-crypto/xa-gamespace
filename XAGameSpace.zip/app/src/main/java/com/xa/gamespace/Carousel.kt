package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextUtils
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// Menu awal: kartu game di atas panggung neon. Geser kiri/kanan untuk ganti game, tombol Start untuk main.
class GameCarousel(ctx: Context) : View(ctx) {
    var items: List<GameApp> = emptyList()
    var onStart: (GameApp) -> Unit = {}
    var onSelect: (GameApp) -> Unit = {}
    var info: (GameApp) -> String = { "" }
    var tags: List<Pair<String, Boolean>> = emptyList()
        set(v) { field = v; invalidate() }

    private var pos = 0f
    private var lastIdx = 0
    private var anim: ValueAnimator? = null
    private var vt: VelocityTracker? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var spacing = 1f
    private var cardCx = 0f
    private var cardW = 0f
    private val startRect = RectF()
    private var now = 0f
    private val clip = android.graphics.Path()
    private val sheen = Paint()
    private val smat = Matrix()
    private val sheenShader = LinearGradient(0f, 0f, 1f, 0f,
        intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(95, 215, 245, 255), Color.argb(0, 255, 255, 255)),
        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)

    private val cam = Camera()
    private val mat = Matrix()
    private val rect = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun dp(v: Float) = context.pxf(v)

    fun setItems(list: List<GameApp>, selectPkg: String?) {
        items = list
        val i = list.indexOfFirst { it.pkg == selectPkg }.let { if (it < 0) 0 else it }
        pos = i.toFloat()
        lastIdx = i
        invalidate()
    }

    fun current(): GameApp? = items.getOrNull(pos.roundToInt().coerceIn(0, max(0, items.size - 1)))

    private fun tick() {
        val idx = pos.roundToInt().coerceIn(0, max(0, items.size - 1))
        if (idx != lastIdx) {
            lastIdx = idx
            Sfx.play("swipe", 0.7f)
            items.getOrNull(idx)?.let { onSelect(it) }
        }
    }

    private fun snap(target: Int) {
        if (items.isEmpty()) return
        val t = target.coerceIn(0, items.size - 1).toFloat()
        anim?.cancel()
        val a = ValueAnimator.ofFloat(pos, t)
        a.duration = 280
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { pos = it.animatedValue as Float; tick(); invalidate() }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { pos = t; tick(); invalidate() }
        })
        anim = a
        a.start()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (items.isEmpty()) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                anim?.cancel()
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(e)
                downX = e.x; downY = e.y; lastX = e.x
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (!dragging && abs(e.x - downX) > slop) dragging = true
                if (dragging) {
                    pos -= (e.x - lastX) / spacing
                    pos = pos.coerceIn(-0.35f, items.size - 1 + 0.35f)
                    tick()
                    invalidate()
                }
                lastX = e.x
            }
            MotionEvent.ACTION_UP -> {
                vt?.addMovement(e)
                vt?.computeCurrentVelocity(1000)
                val vx = vt?.xVelocity ?: 0f
                vt?.recycle(); vt = null
                if (dragging) {
                    snap((pos - vx / spacing * 0.22f).roundToInt())
                } else {
                    val idx = pos.roundToInt().coerceIn(0, items.size - 1)
                    when {
                        abs(pos - idx) < 0.06f && startRect.contains(e.x, e.y) -> {
                            Sfx.play("open")
                            onStart(items[idx])
                        }
                        e.x < cardCx - cardW / 2 -> snap(idx - 1)
                        e.x > cardCx + cardW / 2 -> snap(idx + 1)
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                vt?.recycle(); vt = null
                snap(pos.roundToInt())
            }
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        now = catNow()
        if (isAttachedToWindow) postInvalidateDelayed(33)
        cardW = min(w * 0.34f, dp(290f))
        val ch = cardW * 0.66f
        cardCx = w / 2f
        val cy = h * 0.47f
        spacing = cardW * 0.95f

        drawStage(cv, cardCx, cy + ch / 2f, cardW)

        if (items.isEmpty()) {
            text.reset(); text.isAntiAlias = true
            text.color = Color.parseColor("#9FB8D0"); text.textSize = dp(14f); text.textAlign = Paint.Align.CENTER
            cv.drawText("Belum ada game terdeteksi di HP ini.", cardCx, cy, text)
            startRect.setEmpty()
            return
        }

        val from = floor(pos).toInt() - 2
        val to = ceil(pos).toInt() + 2
        val order = (from..to).filter { it in items.indices }.sortedByDescending { abs(it - pos) }
        startRect.setEmpty()
        for (i in order) {
            val d = i - pos
            val ad = abs(d)
            if (ad > 2.3f) continue
            val sc = 1f - 0.2f * min(ad, 1f) - 0.08f * (min(ad, 2f) - min(ad, 1f))
            val al = (255 * (1f - 0.5f * min(ad, 1.5f))).toInt().coerceIn(40, 255)
            val x = cardCx + d * spacing
            val y = cy + min(ad, 1.5f) * ch * 0.06f
            val rot = (-d * 32f).coerceIn(-40f, 40f)
            cam.save()
            cam.rotateY(rot)
            cam.getMatrix(mat)
            cam.restore()
            mat.preTranslate(-x, -y)
            mat.postTranslate(x, y)
            cv.save()
            cv.concat(mat)
            cv.scale(sc, sc, x, y)
            drawCard(cv, items[i], x, y, cardW, ch, ad < 0.5f, al, ad < 0.06f)
            cv.restore()
        }
    }

    private fun drawStage(cv: Canvas, cx: Float, y: Float, cw: Float) {
        val py = y + cw * 0.10f
        // cahaya di bawah kartu
        fill.shader = RadialGradient(cx, py, cw * 0.95f,
            intArrayOf(Color.argb(150, 60, 120, 255), Color.argb(0, 20, 30, 90)), null, Shader.TileMode.CLAMP)
        cv.save(); cv.scale(1f, 0.28f, cx, py); cv.drawCircle(cx, py, cw * 0.95f, fill); cv.restore()
        fill.shader = null
        stroke.shader = null
        val cols = intArrayOf(Color.parseColor("#3CC8FF"), Color.parseColor("#4F6BFF"), Color.parseColor("#B04CFF"))
        val pulse = 0.65f + 0.35f * sin(now * 2.4f)
        for (k in 0 until 3) {
            val rx = cw * (0.62f + 0.2f * k)
            val ry = rx * 0.16f
            rect.set(cx - rx, py - ry, cx + rx, py + ry)
            val cc = Wet.mix(cols[k], Wet.cycle(now + k * 2.5f, 9f), 0.5f)
            stroke.color = Color.argb((95 * pulse).toInt(), Color.red(cc), Color.green(cc), Color.blue(cc))
            stroke.strokeWidth = dp(8f)
            cv.drawOval(rect, stroke)
            stroke.color = cc
            stroke.strokeWidth = dp(1.8f)
            cv.drawOval(rect, stroke)
        }
        // riak air yang melebar dari bawah kartu
        for (k in 0 until 3) {
            val ph = ((now * 0.32f) + k / 3f) % 1f
            val rx = cw * (0.25f + 0.85f * ph)
            val ry = rx * 0.16f
            rect.set(cx - rx, py - ry, cx + rx, py + ry)
            val a = (1f - ph) * (1f - ph)
            stroke.color = Color.argb((170 * a).toInt(), 190, 235, 255)
            stroke.strokeWidth = dp(2.2f) * (1f - ph * 0.5f)
            cv.drawOval(rect, stroke)
        }
    }

    private fun drawCard(cv: Canvas, g: GameApp, cx: Float, cy: Float, cw: Float, ch: Float,
                         center: Boolean, alpha: Int, exact: Boolean) {
        rect.set(cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2)
        val r = dp(14f)
        fill.shader = LinearGradient(0f, rect.top, 0f, rect.bottom,
            Color.argb(alpha, 18, 44, 86), Color.argb(alpha, 6, 12, 28), Shader.TileMode.CLAMP)
        cv.drawRoundRect(rect, r, r, fill)
        fill.shader = null

        if (center) {
            val rc = Wet.cycle(now, 8f)
            val rr = Color.red(rc); val rg = Color.green(rc); val rb = Color.blue(rc)
            val pl = 0.6f + 0.4f * sin(now * 2.2f)
            stroke.color = Color.argb((55 * pl + 20).toInt(), rr, rg, rb); stroke.strokeWidth = dp(12f); cv.drawRoundRect(rect, r, r, stroke)
            stroke.color = Color.argb((120 * pl + 40).toInt(), rr, rg, rb); stroke.strokeWidth = dp(5f); cv.drawRoundRect(rect, r, r, stroke)
            stroke.color = Wet.mix(Color.parseColor("#9FE6FF"), Color.WHITE, 0.3f * pl); stroke.strokeWidth = dp(1.6f); cv.drawRoundRect(rect, r, r, stroke)
        } else {
            stroke.color = Color.argb(alpha, 120, 90, 220); stroke.strokeWidth = dp(1.2f); cv.drawRoundRect(rect, r, r, stroke)
        }

        // ikon game
        val isz = ch * (if (center) 0.40f else 0.46f)
        val ix = cx - isz / 2
        val iy = rect.top + ch * (if (center) 0.10f else 0.18f)
        g.icon?.let {
            it.setBounds(ix.toInt(), iy.toInt(), (ix + isz).toInt(), (iy + isz).toInt())
            it.alpha = alpha
            it.draw(cv)
        }

        text.reset(); text.isAntiAlias = true
        text.typeface = Typeface.DEFAULT_BOLD
        if (!center) {
            text.color = Color.argb(alpha, 220, 230, 245)
            text.textSize = ch * 0.085f
            text.textAlign = Paint.Align.CENTER
            val s = TextUtils.ellipsize(g.label, android.text.TextPaint(text), cw * 0.85f, TextUtils.TruncateAt.END).toString()
            cv.drawText(s, cx, rect.bottom - ch * 0.12f, text)
            return
        }

        // judul + info
        val lx = rect.left + cw * 0.08f
        text.color = Color.WHITE
        text.textSize = ch * 0.105f
        text.textAlign = Paint.Align.LEFT
        val title = TextUtils.ellipsize(g.label, android.text.TextPaint(text), cw * 0.46f, TextUtils.TruncateAt.END).toString()
        cv.drawText(title, lx, rect.top + ch * 0.64f, text)
        text.typeface = Typeface.DEFAULT
        text.color = Color.parseColor("#9FB8D0")
        text.textSize = ch * 0.068f
        cv.drawText(TextUtils.ellipsize(info(g), android.text.TextPaint(text), cw * 0.46f, TextUtils.TruncateAt.END).toString(), lx, rect.top + ch * 0.74f, text)

        // chip fitur
        var tx = lx
        val ty = rect.bottom - ch * 0.13f
        val th = ch * 0.105f
        text.typeface = Typeface.DEFAULT_BOLD
        text.textSize = ch * 0.058f
        for ((label, on) in tags) {
            val tw = text.measureText(label) + dp(10f)
            if (tx + tw > rect.right - cw * 0.06f) break
            fill.color = if (on) Color.argb(200, 40, 150, 220) else Color.argb(120, 60, 80, 120)
            cv.drawRoundRect(tx, ty, tx + tw, ty + th, th / 2, th / 2, fill)
            text.color = if (on) Color.WHITE else Color.parseColor("#B8C6DA")
            cv.drawText(label, tx + dp(5f), ty + th * 0.72f, text)
            tx += tw + dp(4f)
        }

        wetCard(cv, rect, r)

        // tombol Start (di dalam kartu)
        val bw = cw * 0.30f
        val bh = ch * 0.17f
        val bx = rect.right - bw - cw * 0.06f        // seluruhnya di dalam kartu
        val by = rect.top + ch * 0.58f
        fill.shader = LinearGradient(bx, by, bx + bw, by, Color.parseColor("#FFFFFF"), Color.parseColor("#9ED4FF"), Shader.TileMode.CLAMP)
        cv.drawRoundRect(bx, by, bx + bw, by + bh, bh * 0.35f, bh * 0.35f, fill)
        fill.shader = null
        text.color = Color.parseColor("#0A2A4A")
        text.textSize = min(ch * 0.085f, bh * 0.58f)
        text.textAlign = Paint.Align.CENTER
        cv.drawText("Start", bx + bw / 2, by + bh * 0.68f, text)
        if (exact) startRect.set(bx, by, bx + bw, by + bh)
    }

    // kartu tampak basah: kilau menyapu + tetesan air
    private fun wetCard(cv: Canvas, r: RectF, rad: Float) {
        cv.save()
        clip.reset()
        clip.addRoundRect(r, rad, rad, android.graphics.Path.Direction.CW)
        cv.clipPath(clip)

        val bw = r.width() * 0.55f
        val travel = r.width() + bw * 2f
        val bx = r.left - bw + ((now * 0.16f) % 1f) * travel
        cv.save()
        cv.rotate(-18f, r.centerX(), r.centerY())
        smat.reset()
        smat.setScale(bw, 1f)
        smat.postTranslate(bx, 0f)
        sheenShader.setLocalMatrix(smat)
        sheen.shader = sheenShader
        cv.drawRect(bx, r.top - r.height(), bx + bw, r.bottom + r.height(), sheen)
        cv.restore()

        // tetesan air tetap di kartu, sebagian berkilau berdenyut
        val pts = floatArrayOf(0.12f, 0.16f, 3.2f, 0.34f, 0.10f, 2.2f, 0.55f, 0.20f, 2.8f,
            0.78f, 0.12f, 3.6f, 0.90f, 0.30f, 2.4f, 0.20f, 0.46f, 2.0f, 0.62f, 0.52f, 2.6f,
            0.08f, 0.82f, 2.8f, 0.46f, 0.88f, 2.2f, 0.72f, 0.84f, 3.0f)
        var i = 0
        while (i < pts.size) {
            val tw = 0.75f + 0.25f * sin(now * 1.6f + i)
            Wet.droplet(cv, r.left + r.width() * pts[i], r.top + r.height() * pts[i + 1], dp(pts[i + 2]), tw)
            i += 3
        }
        // satu tetes meluncur turun
        val sx = r.left + r.width() * 0.66f
        val sy = r.top + r.height() * (((now * 0.09f) % 1.1f) - 0.05f)
        Wet.trail(cv, sx, sy, dp(2.6f), 1f)
        Wet.droplet(cv, sx, sy, dp(2.6f), 1f)
        cv.restore()
    }
}
