package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextUtils
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// Menu awal: kartu game di atas panggung neon. Geser kiri/kanan untuk ganti game, tombol Start untuk main.
class GameCarousel(ctx: Context) : View(ctx) {
    var items: List<GameApp> = emptyList()
    var onStart: (GameApp) -> Unit = {}
    var onSelect: (GameApp) -> Unit = {}
    var info: (GameApp) -> String = { "" }
    var tags: List<Pair<String, Boolean>> = emptyList()
        set(v) { field = v; invalidate() }

    private var pos = 0f
    private var lastIdx = 0
    private var anim: ValueAnimator? = null
    private var vt: VelocityTracker? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var spacing = 1f
    private var cardCx = 0f
    private var cardW = 0f
    private val startRect = RectF()

    private val cam = Camera()
    private val mat = Matrix()
    private val rect = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun dp(v: Float) = context.pxf(v)

    fun setItems(list: List<GameApp>, selectPkg: String?) {
        items = list
        val i = list.indexOfFirst { it.pkg == selectPkg }.let { if (it < 0) 0 else it }
        pos = i.toFloat()
        lastIdx = i
        invalidate()
    }

    fun current(): GameApp? = items.getOrNull(pos.roundToInt().coerceIn(0, max(0, items.size - 1)))

    private fun tick() {
        val idx = pos.roundToInt().coerceIn(0, max(0, items.size - 1))
        if (idx != lastIdx) {
            lastIdx = idx
            Sfx.play("swipe", 0.7f)
            items.getOrNull(idx)?.let { onSelect(it) }
        }
    }

    private fun snap(target: Int) {
        if (items.isEmpty()) return
        val t = target.coerceIn(0, items.size - 1).toFloat()
        anim?.cancel()
        val a = ValueAnimator.ofFloat(pos, t)
        a.duration = 280
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { pos = it.animatedValue as Float; tick(); invalidate() }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { pos = t; tick(); invalidate() }
        })
        anim = a
        a.start()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (items.isEmpty()) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                anim?.cancel()
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(e)
                downX = e.x; downY = e.y; lastX = e.x
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (!dragging && abs(e.x - downX) > slop) dragging = true
                if (dragging) {
                    pos -= (e.x - lastX) / spacing
                    pos = pos.coerceIn(-0.35f, items.size - 1 + 0.35f)
                    tick()
                    invalidate()
                }
                lastX = e.x
            }
            MotionEvent.ACTION_UP -> {
                vt?.addMovement(e)
                vt?.computeCurrentVelocity(1000)
                val vx = vt?.xVelocity ?: 0f
                vt?.recycle(); vt = null
                if (dragging) {
                    snap((pos - vx / spacing * 0.22f).roundToInt())
                } else {
                    val idx = pos.roundToInt().coerceIn(0, items.size - 1)
                    when {
                        abs(pos - idx) < 0.06f && startRect.contains(e.x, e.y) -> {
                            Sfx.play("open")
                            onStart(items[idx])
                        }
                        e.x < cardCx - cardW / 2 -> snap(idx - 1)
                        e.x > cardCx + cardW / 2 -> snap(idx + 1)
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                vt?.recycle(); vt = null
                snap(pos.roundToInt())
            }
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        cardW = min(w * 0.34f, dp(290f))
        val ch = cardW * 0.66f
        cardCx = w / 2f
        val cy = h * 0.47f
        spacing = cardW * 0.95f

        drawStage(cv, cardCx, cy + ch / 2f, cardW)

        if (items.isEmpty()) {
            text.reset(); text.isAntiAlias = true
            text.color = Color.parseColor("#9FB8D0"); text.textSize = dp(14f); text.textAlign = Paint.Align.CENTER
            cv.drawText("Belum ada game terdeteksi di HP ini.", cardCx, cy, text)
            startRect.setEmpty()
            return
        }

        val from = floor(pos).toInt() - 2
        val to = ceil(pos).toInt() + 2
        val order = (from..to).filter { it in items.indices }.sortedByDescending { abs(it - pos) }
        startRect.setEmpty()
        for (i in order) {
            val d = i - pos
            val ad = abs(d)
            if (ad > 2.3f) continue
            val sc = 1f - 0.2f * min(ad, 1f) - 0.08f * (min(ad, 2f) - min(ad, 1f))
            val al = (255 * (1f - 0.5f * min(ad, 1.5f))).toInt().coerceIn(40, 255)
            val x = cardCx + d * spacing
            val y = cy + min(ad, 1.5f) * ch * 0.06f
            val rot = (-d * 32f).coerceIn(-40f, 40f)
            cam.save()
            cam.rotateY(rot)
            cam.getMatrix(mat)
            cam.restore()
            mat.preTranslate(-x, -y)
            mat.postTranslate(x, y)
            cv.save()
            cv.concat(mat)
            cv.scale(sc, sc, x, y)
            drawCard(cv, items[i], x, y, cardW, ch, ad < 0.5f, al, ad < 0.06f)
            cv.restore()
        }
    }

    private fun drawStage(cv: Canvas, cx: Float, y: Float, cw: Float) {
        val py = y + cw * 0.10f
        // cahaya di bawah kartu
        fill.shader = RadialGradient(cx, py, cw * 0.95f,
            intArrayOf(Color.argb(150, 60, 120, 255), Color.argb(0, 20, 30, 90)), null, Shader.TileMode.CLAMP)
        cv.save(); cv.scale(1f, 0.28f, cx, py); cv.drawCircle(cx, py, cw * 0.95f, fill); cv.restore()
        fill.shader = null
        stroke.shader = null
        val cols = intArrayOf(Color.parseColor("#3CC8FF"), Color.parseColor("#4F6BFF"), Color.parseColor("#B04CFF"))
        for (k in 0 until 3) {
            val rx = cw * (0.62f + 0.2f * k)
            val ry = rx * 0.16f
            rect.set(cx - rx, py - ry, cx + rx, py + ry)
            stroke.color = Color.argb(70, Color.red(cols[k]), Color.green(cols[k]), Color.blue(cols[k]))
            stroke.strokeWidth = dp(7f)
            cv.drawOval(rect, stroke)
            stroke.color = cols[k]
            stroke.strokeWidth = dp(1.6f)
            cv.drawOval(rect, stroke)
        }
    }

    private fun drawCard(cv: Canvas, g: GameApp, cx: Float, cy: Float, cw: Float, ch: Float,
                         center: Boolean, alpha: Int, exact: Boolean) {
        rect.set(cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2)
        val r = dp(14f)
        fill.shader = LinearGradient(0f, rect.top, 0f, rect.bottom,
            Color.argb(alpha, 18, 44, 86), Color.argb(alpha, 6, 12, 28), Shader.TileMode.CLAMP)
        cv.drawRoundRect(rect, r, r, fill)
        fill.shader = null

        if (center) {
            stroke.color = Color.argb(50, 60, 200, 255); stroke.strokeWidth = dp(9f); cv.drawRoundRect(rect, r, r, stroke)
            stroke.color = Color.argb(120, 60, 200, 255); stroke.strokeWidth = dp(4f); cv.drawRoundRect(rect, r, r, stroke)
            stroke.color = Color.parseColor("#9FE6FF"); stroke.strokeWidth = dp(1.5f); cv.drawRoundRect(rect, r, r, stroke)
        } else {
            stroke.color = Color.argb(alpha, 120, 90, 220); stroke.strokeWidth = dp(1.2f); cv.drawRoundRect(rect, r, r, stroke)
        }

        // ikon game
        val isz = ch * (if (center) 0.40f else 0.46f)
        val ix = cx - isz / 2
        val iy = rect.top + ch * (if (center) 0.10f else 0.18f)
        g.icon?.let {
            it.setBounds(ix.toInt(), iy.toInt(), (ix + isz).toInt(), (iy + isz).toInt())
            it.alpha = alpha
            it.draw(cv)
        }

        text.reset(); text.isAntiAlias = true
        text.typeface = Typeface.DEFAULT_BOLD
        if (!center) {
            text.color = Color.argb(alpha, 220, 230, 245)
            text.textSize = ch * 0.085f
            text.textAlign = Paint.Align.CENTER
            val s = TextUtils.ellipsize(g.label, android.text.TextPaint(text), cw * 0.85f, TextUtils.TruncateAt.END).toString()
            cv.drawText(s, cx, rect.bottom - ch * 0.12f, text)
            return
        }

        // judul + info
        val lx = rect.left + cw * 0.08f
        text.color = Color.WHITE
        text.textSize = ch * 0.105f
        text.textAlign = Paint.Align.LEFT
        val title = TextUtils.ellipsize(g.label, android.text.TextPaint(text), cw * 0.52f, TextUtils.TruncateAt.END).toString()
        cv.drawText(title, lx, rect.top + ch * 0.64f, text)
        text.typeface = Typeface.DEFAULT
        text.color = Color.parseColor("#9FB8D0")
        text.textSize = ch * 0.068f
        cv.drawText(info(g), lx, rect.top + ch * 0.74f, text)

        // chip fitur
        var tx = lx
        val ty = rect.bottom - ch * 0.13f
        val th = ch * 0.105f
        text.typeface = Typeface.DEFAULT_BOLD
        text.textSize = ch * 0.058f
        for ((label, on) in tags) {
            val tw = text.measureText(label) + dp(10f)
            if (tx + tw > rect.right - cw * 0.05f) break
            fill.color = if (on) Color.argb(200, 40, 150, 220) else Color.argb(120, 60, 80, 120)
            cv.drawRoundRect(tx, ty, tx + tw, ty + th, th / 2, th / 2, fill)
            text.color = if (on) Color.WHITE else Color.parseColor("#B8C6DA")
            cv.drawText(label, tx + dp(5f), ty + th * 0.72f, text)
            tx += tw + dp(4f)
        }

        // tombol Start (menjorok keluar kanan kartu)
        val bw = cw * 0.34f
        val bh = ch * 0.17f
        val bx = rect.right - bw + cw * 0.04f
        val by = rect.top + ch * 0.58f
        fill.shader = LinearGradient(bx, by, bx + bw, by, Color.parseColor("#FFFFFF"), Color.parseColor("#9ED4FF"), Shader.TileMode.CLAMP)
        cv.drawRoundRect(bx, by, bx + bw, by + bh, bh * 0.35f, bh * 0.35f, fill)
        fill.shader = null
        text.color = Color.parseColor("#0A2A4A")
        text.textSize = ch * 0.085f
        text.textAlign = Paint.Align.CENTER
        cv.drawText("Start", bx + bw / 2, by + bh * 0.68f, text)
        if (exact) startRect.set(bx, by, bx + bw, by + bh)
    }
}
