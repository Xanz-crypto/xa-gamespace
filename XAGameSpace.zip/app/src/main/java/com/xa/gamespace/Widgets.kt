package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View

class BarView(ctx: Context) : View(ctx) {
    private var pct = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(v: Float) {
        pct = v.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2
        p.shader = null
        p.color = Theme.stroke
        c.drawRoundRect(0f, 0f, w, h, r, r, p)
        val fw = w * pct
        if (fw > 0f) {
            p.shader = LinearGradient(0f, 0f, fw, 0f, Theme.accent, Theme.accent2, Shader.TileMode.CLAMP)
            c.drawRoundRect(0f, 0f, maxOf(fw, h), h, r, r, p)
            p.shader = null
        }
    }
}

class Toggle(ctx: Context, var on: Boolean, private val cb: (Boolean) -> Unit) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    init {
        setOnClickListener {
            on = !on
            invalidate()
            cb(on)
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((46 * d).toInt(), (26 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = if (on) Theme.accent else Theme.stroke
        c.drawRoundRect(0f, 0f, w, h, h / 2, h / 2, p)
        p.color = Color.WHITE
        val r = h / 2 - 4 * d
        c.drawCircle(if (on) w - h / 2 else h / 2, h / 2, r, p)
    }
}
