package com.xa.gamespace

import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// ================= Scan aplikasi latar belakang =================
class ScanPanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val list = u.vbox()
    private val status = u.label("Memindai...", 12f, Theme.sub)
    private val stopBtn: TextView
    private var items: List<RunApp> = emptyList()

    init {
        val bar = u.hbox()
        bar.addView(u.btn("🔍 Scan") { scan() }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn("Pilih semua") { setAll(true) }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn("Kosongkan") { setAll(false) }, u.lp(-2, -2, r = 8))
        bar.addView(u.space(), u.lp(0, 1, 1f))
        stopBtn = u.btn("Hentikan (0)", true) { stopSelected() }
        bar.addView(stopBtn)
        root.addView(bar, u.lp(b = 6))
        root.addView(status, u.lp(b = 6))
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        root.addView(sv, u.lp(-1, 0, 1f))
        scan()
    }

    private fun scan() {
        status.text = "Memindai aplikasi yang berjalan..."
        Thread {
            val r = Boost.scan(a, a.store.game)
            a.runOnUiThread { items = r; render() }
        }.start()
    }

    private fun setAll(v: Boolean) {
        items.forEach { it.selected = v }
        render()
    }

    private fun render() {
        list.removeAllViews()
        val total = items.sumOf { it.memMb }
        status.text = if (items.isEmpty()) "Tidak ada aplikasi latar belakang yang bisa dihentikan."
        else "${items.size} aplikasi aktif · ${total} MB  (komponen penting sistem otomatis dilindungi)"
        items.forEach { app ->
            val row = u.hbox()
            row.setPadding(u.dp(4), u.dp(6), u.dp(4), u.dp(6))
            val cb = CheckBox(a)
            cb.isChecked = app.selected
            cb.buttonTintList = ColorStateList.valueOf(Theme.accent)
            cb.setOnCheckedChangeListener { _, v -> app.selected = v; count() }
            row.addView(cb)
            val nm = u.vbox()
            nm.addView(u.label(app.label, 13f, Color.WHITE, true).also { it.maxLines = 1 })
            nm.addView(u.label(app.pkg, 10f, Theme.sub).also { it.maxLines = 1 })
            row.addView(nm, u.lp(0, -2, 1f))
            row.addView(u.label(if (app.system) "SISTEM" else "USER", 10f, if (app.system) Theme.warn else Theme.good, true),
                u.lp(-2, -2, r = 14))
            row.addView(u.label("${app.memMb} MB", 12f, Color.WHITE, true))
            row.setOnClickListener { cb.isChecked = !cb.isChecked }
            list.addView(row)
            list.addView(View(a).also { it.setBackgroundColor(Color.argb(30, 255, 255, 255)) }, u.lp(-1, 1))
        }
        count()
    }

    private fun count() {
        stopBtn.text = "Hentikan (${items.count { it.selected }})"
    }

    private fun stopSelected() {
        val sel = items.filter { it.selected }.map { it.pkg }
        if (sel.isEmpty()) { a.toast("Belum ada yang dipilih"); return }
        status.text = "Menghentikan ${sel.size} aplikasi..."
        Thread {
            Boost.stop(sel)
            try { Thread.sleep(600) } catch (e: InterruptedException) {}
            a.runOnUiThread { a.toast("${sel.size} aplikasi dihentikan") }
            scan()
        }.start()
    }
}

// ================= CPU Governor lengkap =================
class CpuPanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box = u.vbox()
    private var pols: List<Policy> = emptyList()

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        load()
    }

    private fun load() {
        Thread {
            val r = Cpu.read()
            a.runOnUiThread { pols = r; render() }
        }.start()
    }

    private fun exec(cmds: List<String>) {
        Thread {
            Cpu.apply(cmds)
            try { Thread.sleep(250) } catch (e: InterruptedException) {}
            load()
        }.start()
    }

    private fun chips(options: List<String>, current: String, pick: (String) -> Unit): View {
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        val l = u.hbox()
        options.forEach { g ->
            val on = g == current
            val t = u.label(g, 12f, if (on) Color.parseColor("#1A0C04") else Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(u.dp(12), u.dp(7), u.dp(12), u.dp(7))
            t.background = if (on) u.glass(20, Theme.accent, Theme.accent)
            else u.glass(20, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
            t.setOnClickListener { pick(g) }
            l.addView(t, u.lp(-2, -2, r = 6))
        }
        hs.addView(l)
        return hs
    }

    private fun render() {
        box.removeAllViews()
        if (pols.isEmpty()) {
            box.addView(u.label("CPU tidak bisa dibaca. Pastikan akses root diizinkan.", 13f, Theme.sub))
            box.addView(u.btn("Coba lagi") { load() }, u.lp(-2, -2, t = 8))
            return
        }

        // Semua cluster sekaligus
        val allCard = u.vbox()
        allCard.background = u.glass(14, Color.argb(90, 255, 255, 255))
        allCard.setPadding(u.dp(12), u.dp(10), u.dp(12), u.dp(10))
        val ah = u.hbox()
        ah.addView(u.label("Semua cluster", 14f, Color.WHITE, true), u.lp(0, -2, 1f))
        ah.addView(u.btn("Perbarui") { load() }, u.lp(-2, -2, r = 6))
        ah.addView(u.btn("Reset awal") { resetDefault() })
        allCard.addView(ah, u.lp(b = 8))
        val union = pols.flatMap { it.govs }.distinct()
        val common = union.firstOrNull { g -> pols.all { it.gov == g } } ?: ""
        allCard.addView(chips(union, common) { g ->
            exec(pols.filter { g in it.govs }.map { Cpu.govCmd(it.path, g) })
        })
        box.addView(allCard, u.lp(b = 10))

        pols.forEach { p ->
            val c = u.vbox()
            c.background = u.glass(14, Color.argb(60, 255, 255, 255))
            c.setPadding(u.dp(12), u.dp(10), u.dp(12), u.dp(10))
            val h = u.hbox()
            h.addView(u.label(p.name, 14f, Color.WHITE, true), u.lp(0, -2, 1f))
            h.addView(u.label("sekarang ${Cpu.fmt(p.cur)}", 12f, Theme.accent2, true))
            c.addView(h, u.lp(b = 8))
            c.addView(chips(p.govs, p.gov) { g -> exec(listOf(Cpu.govCmd(p.path, g))) }, u.lp(b = 8))

            val fr = u.hbox()
            fr.addView(u.btn("Min  ${Cpu.fmt(p.min)}") { pickFreq(p, true) }, u.lp(-2, -2, r = 8))
            fr.addView(u.btn("Max  ${Cpu.fmt(p.max)}") { pickFreq(p, false) })
            c.addView(fr)
            box.addView(c, u.lp(b = 10))
        }
    }

    private fun pickFreq(p: Policy, isMin: Boolean) {
        val fr = p.freqs.sortedDescending()
        if (fr.isEmpty()) { a.toast("Daftar frekuensi tidak tersedia"); return }
        AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle((if (isMin) "Frekuensi minimum · " else "Frekuensi maksimum · ") + p.name)
            .setItems(fr.map { Cpu.fmt(it) }.toTypedArray()) { _, i ->
                val v = fr[i]
                val mn = if (isMin) v else minOf(p.min, v)
                val mx = if (isMin) maxOf(p.max, v) else v
                exec(listOf(Cpu.rangeCmd(p.path, mn, mx)))
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun resetDefault() {
        val saved = a.store.get("cpu_default")
        if (saved.isBlank()) { a.toast("Data awal belum tersimpan"); return }
        exec(Cpu.restoreCmds(saved))
        a.toast("CPU dikembalikan ke pengaturan awal")
    }
}
