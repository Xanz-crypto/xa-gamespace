package com.xa.gamespace

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder

// Service foreground pemutar musik: menjaga musik GameSpace tetap hidup
// walau keluar dari game atau berada di beranda.
class MusicService : Service() {

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Musik GameSpace", NotificationManager.IMPORTANCE_LOW))
        }
        startForeground(NOTIF_ID, build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, build())
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun build(): Notification {
        val title = Music.list.getOrNull(Music.idx)?.let { Music.title(this, it) } ?: "Musik"
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        return b.setContentTitle(title)
            .setContentText(if (Music.isPlaying()) "GameSpace · sedang diputar" else "GameSpace · berhenti")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val CH = "gs_music"
        const val NOTIF_ID = 77
        fun start(ctx: Context) {
            try { ctx.startForegroundService(Intent(ctx, MusicService::class.java)) } catch (e: Exception) {}
        }
    }
}
