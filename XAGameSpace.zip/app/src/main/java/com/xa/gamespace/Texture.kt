package com.xa.gamespace

import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView

// ================= ANGLE Vulkan Low Texture (dari module SkiaPerf) =================
// Level 1-4 = forceTextureLodOffset1..4, perintahnya sama dengan angle-vulkan-texture-levelN.js di module.
// "0" = Mati (kembali ke bawaan). Butuh ROOT (resetprop).
// Pembersihan cache/log dari module TIDAK dijalankan di sini (menghapus file data sistem).
object Texture {
    const val KEY_LEVEL = "tex_level"      // level yang dipilih: "0".."4"
    const val KEY_AUTO = "tex_auto"        // "1" = terapkan otomatis saat boost game
    const val KEY_APPLIED = "tex_applied"  // "1" = dipasang otomatis oleh boost, dikembalikan saat boost selesai

    // texture disimpan per game (tiap game punya level sendiri)
    fun levelKey(pkg: String) = "tex_lv_$pkg"

    val LEVELS = listOf("0" to "Mati", "1" to "LV 1", "2" to "LV 2", "3" to "LV 3", "4" to "LV 4")

    const val VERIFY = "settings get global angle_egl_features; getprop debug.angle.feature_overrides_enabled"

    private fun feature(level: String) = "forceNearestFiltering:forceNearestMipFiltering:forceTextureLodOffset$level"

    // Alur SAMA dengan angle-vulkan-texture-levelN.js di module SkiaPerf:
    // 1) bersihkan cache (sama dengan blok KILL di module)
    // 2) pasang setelan ANGLE (settings + setprop + resetprop + device_config)
    // refresh-angle.sh dari module hanya menampilkan notif AxManager, tidak mengubah setelan, jadi tidak dipakai di sini
    // Level 1..4 hanya beda angka forceTextureLodOffsetN.
    private val CLEAN = """su -c rm -rf /data/media/0/DCIM/.thumbnails
su -c rm -rf /data/media/0/Pictures/.thumbnails
su -c rm -rf /data/media/0/Music/.thumbnails
su -c rm -rf /data/media/0/mtklog
su -c rm -f /data/cache/*.*
su -c rm -f /data/backup/pending/*.tmp
su -c rm -rf /data/system/usagestats/*
su -c rm -rf /cache/*.apk
su -c rm -rf /data/cache/*
su -c rm -rf /data/tombstones/*
su -c rm -rf /data/system/dropbox/*"""


    fun applyCmd(level: String): String {
        val f = feature(level)
        return listOf(
            CLEAN,
            "settings put --user 0 global angle_gl_driver_all_angle 1",
            "settings put --user 0 global angle_egl_features '$f'",
            "setprop debug.angle.feature_overrides_enabled '$f'",
            "setprop debug.angle.feature_overrides_disabled ''",
            "resetprop -n ro.boot.hardware.angle_feature_overrides_enabled '$f' >/dev/null 2>&1 || true",
            "resetprop --delete ro.boot.hardware.angle_feature_overrides_disabled >/dev/null 2>&1 || true",
            "device_config put gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides true >/dev/null 2>&1 || true"
        ).joinToString("\n")
    }

    fun resetCmd(): String {
        val f = "forceNearestFiltering:forceNearestMipFiltering"
        return listOf(
            CLEAN,
            "settings put --user 0 global angle_gl_driver_all_angle 0",
            "settings delete --user 0 global angle_egl_features >/dev/null 2>&1 || true",
            "setprop debug.angle.feature_overrides_enabled ''",
            "setprop debug.angle.feature_overrides_disabled '$f'",
            "resetprop --delete ro.boot.hardware.angle_feature_overrides_enabled >/dev/null 2>&1 || true",
            "resetprop -n ro.boot.hardware.angle_feature_overrides_disabled '$f' >/dev/null 2>&1 || true",
            "device_config put gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides false >/dev/null 2>&1 || true"
        ).joinToString("\n")
    }

    // Deteksi seperti di module: 4 tweak utama + hardware (hardware bisa dibaca tanpa root, hanya penulisannya yang butuh root)
    const val STATUS_CMD = """echo "ANGLE EGL FEATURES: ${'$'}(settings get global angle_egl_features)"
echo "DEVICE CONFIG: ${'$'}(device_config get gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides)"
echo "FEATURE OVERRIDES ENABLED: ${'$'}(getprop debug.angle.feature_overrides_enabled)"
echo "FEATURE OVERRIDES DISABLED: ${'$'}(getprop debug.angle.feature_overrides_disabled)"
echo "HARDWARE ENABLED: ${'$'}(getprop ro.boot.hardware.angle_feature_overrides_enabled)"
echo "HARDWARE DISABLED: ${'$'}(getprop ro.boot.hardware.angle_feature_overrides_disabled)""""

    // Ambil level dari baris ENABLED: forceTextureLodOffsetN -> "LV N", kosong -> "Mati"
    fun detectLevel(output: String): String {
        val line = output.lines().firstOrNull { it.startsWith("FEATURE OVERRIDES ENABLED:") } ?: return "Tidak terbaca"
        val m = Regex("forceTextureLodOffset(\\d)").find(line) ?: return "Mati"
        return "LV ${m.groupValues[1]}"
    }

    // Cek hasil: tampilkan nilai nyata properti dan setelan, supaya terlihat apakah berhasil.
    const val VERIFY_OK = "echo enabled=\$(getprop debug.angle.feature_overrides_enabled); echo disabled=\$(getprop debug.angle.feature_overrides_disabled); echo egl=\$(settings get global angle_egl_features)"

    // Siklus untuk tombol di Game Panel: 0 -> 1 -> 2 -> 3 -> 4 -> 0
    fun nextLevel(cur: String): String {
        val i = LEVELS.indexOfFirst { it.first == cur }
        return LEVELS[(i + 1 + LEVELS.size) % LEVELS.size].first
    }
}

class TexturePanel(private val a: MainActivity, private val pkg: String) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box = u.vbox()
    private val out = u.label("", 11f, Theme.sub)
    private val lvKey = Texture.levelKey(pkg)
    private var level = a.store.get(lvKey).ifBlank { "0" }
    private var auto = a.store.get(Texture.KEY_AUTO) != "0"

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        draw()
    }

    private fun chips(opts: List<Pair<String, String>>, cur: String, pick: (String) -> Unit): View {
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        val l = u.hbox()
        opts.forEach { (label, v) ->
            val on = v == cur
            val t = u.label(label, 12f, if (on) Color.parseColor("#04141F") else Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(u.dp(12), u.dp(7), u.dp(12), u.dp(7))
            t.background = if (on) u.glass(20, Hud.cyan, Hud.cyan)
            else u.glass(20, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
            t.setOnClickListener { Sfx.tap(); pick(v) }
            l.addView(t, u.lp(-2, -2, r = 6))
        }
        hs.addView(l)
        return hs
    }

    private fun section(title: String, body: View) {
        box.addView(u.label(title, 11f, Theme.sub, true), u.lp(b = 4))
        box.addView(body, u.lp(b = 10))
    }

    private fun draw() {
        box.removeAllViews()
        section("LEVEL TEKSTUR LOW · ANGLE VULKAN (module SkiaPerf)", chips(Texture.LEVELS, level) {
            level = it
            a.store.put(lvKey, it)
            draw()
        })
        val bar = u.hbox()
        bar.addView(u.btn("Terapkan", true) { apply() }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn(if (auto) "Auto saat main: ON" else "Auto saat main: OFF") {
            auto = !auto
            a.store.put(Texture.KEY_AUTO, if (auto) "1" else "0")
            draw()
        }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn("Reset") { reset() })
        bar.addView(u.btn("Deteksi") { detect() }, u.lp(-2, -2, l = 8))
        box.addView(bar, u.lp(b = 8))
        box.addView(u.label(
            "Ketika texture tidak bekerja / tidak work, disarankan menggunakan texture yang ada di menu SHELL!! " +
                "Efek ANGLE berlaku global ke aplikasi yang memakai ANGLE. " +
                "Auto: dipasang saat boost game dan dikembalikan saat boost selesai. Butuh root.",
            10f, Theme.sub), u.lp(b = 8))
        box.addView(out)
    }

    private fun apply() {
        if (!Access.requires(a, "Texture", false)) return
        val lv = level
        a.store.put(lvKey, lv)
        val name = Texture.LEVELS.firstOrNull { it.first == lv }?.second ?: lv
        val base = if (lv == "0") Texture.resetCmd() else Texture.applyCmd(lv)
        val game = a.store.game
        val restart = if (!game.isNullOrBlank()) "\nam force-stop $game" else ""
        run(base + restart, "Texture $name")
    }

    private fun reset() {
        if (!Access.requires(a, "Texture", false)) return
        level = "0"
        a.store.put(lvKey, "0")
        a.store.put(Texture.KEY_APPLIED, "")
        draw()
        run(Texture.resetCmd(), "Reset texture ke bawaan")
    }

    private fun detect() {
        if (!Access.requires(a, "Texture", false)) return
        out.text = "Mendeteksi..."
        Thread {
            val check = Access.run(Texture.STATUS_CMD)
            a.runOnUiThread {
                out.text = "Terdeteksi: ${Texture.detectLevel(check)}\n\n" + (check.ifBlank { "(kosong)" })
            }
        }.start()
    }

    private fun run(cmd: String, label: String) {
        out.text = "Menerapkan $label..."
        Thread {
            val r = Access.run(cmd)
            val check = Access.run(Texture.STATUS_CMD)
            a.runOnUiThread {
                out.text = "$label\nTerdeteksi: ${Texture.detectLevel(check)}\n\n" +
                    (check.ifBlank { "(kosong)" }) + "\n\n" + (r.ifBlank { "" })
            }
        }.start()
    }
}
