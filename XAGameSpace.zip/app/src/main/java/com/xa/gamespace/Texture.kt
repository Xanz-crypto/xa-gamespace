package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView

// ================= Texture level 1-4 (lewat cmd game, butuh root atau Shizuku) =================
// Level 1 = paling ringan (render 50%), level 4 = paling tajam (render 100%).
// Mengubah skala render game. Efek ke tekstur terasa lewat resolusi render.
object Texture {
    val LEVELS = listOf("1" to "0.5", "2" to "0.6", "3" to "0.8", "4" to "1.0")

    fun scale(level: String): String = LEVELS.firstOrNull { it.first == level }?.second ?: "disable"

    // mode & fps yang tersimpan di Game CMD, dipakai ulang supaya pengaturan lain tidak tertimpa
    private fun saved(ctx: Context, pkg: String): Pair<String, String>? {
        val s = Store(ctx).get("gcv_$pkg").split("|")
        return if (s.size == 3) s[0] to s[2] else null
    }

    fun applyCmd(ctx: Context, pkg: String, level: String): String {
        val (mode, fps) = saved(ctx, pkg) ?: ("1" to "disable")
        return "cmd game set --mode $mode --downscale ${scale(level)} --fps $fps $pkg"
    }

    fun resetCmd(ctx: Context, pkg: String): String {
        val cur = saved(ctx, pkg) ?: return "cmd game reset $pkg"
        return "cmd game set --mode ${cur.first} --downscale disable --fps ${cur.second} $pkg"
    }
}

class TexturePanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box = u.vbox()
    private val out = u.label("", 11f, Theme.sub)
    private var games: List<GameApp> = emptyList()
    private var pkg: String? = a.store.get("last_game").ifBlank { null }
    private var level = ""

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        Thread {
            val g = Games.detect(a)
            a.runOnUiThread {
                games = g
                if (pkg == null || g.none { it.pkg == pkg }) pkg = g.firstOrNull()?.pkg
                loadSaved()
                render()
            }
        }.start()
        render()
    }

    private fun loadSaved() {
        val p = pkg ?: return
        level = a.store.get("tex_$p")
    }

    private fun chips(opts: List<Pair<String, String>>, cur: String, pick: (String) -> Unit): View {
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        val l = u.hbox()
        opts.forEach { (label, v) ->
            val on = v == cur
            val t = u.label(label, 12f, if (on) Color.parseColor("#04141F") else Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(u.dp(12), u.dp(7), u.dp(12), u.dp(7))
            t.background = if (on) u.glass(20, Hud.cyan, Hud.cyan)
            else u.glass(20, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
            t.setOnClickListener { Sfx.tap(); pick(v) }
            l.addView(t, u.lp(-2, -2, r = 6))
        }
        hs.addView(l)
        return hs
    }

    private fun section(title: String, body: View) {
        box.addView(u.label(title, 11f, Theme.sub, true), u.lp(b = 4))
        box.addView(body, u.lp(b = 10))
    }

    private fun name(p: String): String = games.firstOrNull { it.pkg == p }?.label ?: p

    private fun show(s: String) = a.runOnUiThread { out.text = s }

    private fun render() {
        box.removeAllViews()
        if (games.isEmpty()) {
            box.addView(u.label("Belum ada game terdeteksi. Tambah game lewat kartu + di menu awal.", 13f, Theme.sub))
            box.addView(out)
            return
        }
        section("GAME", chips(games.map { it.label to it.pkg }, pkg ?: "") { p ->
            pkg = p; loadSaved(); render()
        })
        section("LEVEL TEKSTUR (1 = paling ringan, 4 = paling tajam)",
            chips(Texture.LEVELS.map { (l, s) -> "LV$l · $s" to l }, level) { level = it; render() })

        val bar = u.hbox()
        bar.addView(u.btn("Terapkan", true) { apply(false) }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn("Terapkan + auto saat main") { apply(true) }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn("Reset") { reset() }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn("Cek config") { info() })
        box.addView(bar, u.lp(b = 8))
        box.addView(out)
    }

    private fun apply(auto: Boolean) {
        val p = pkg ?: return
        if (level.isBlank()) { out.text = "Pilih level tekstur dulu."; return }
        if (!Access.requires(a, "Texture", false)) return
        val lv = level
        out.text = "Menerapkan..."
        Thread {
            val r = Access.run(Texture.applyCmd(a, p, lv))
            if (auto) a.store.put("tex_$p", lv)
            val head = "Level $lv (skala ${Texture.scale(lv)}) → ${name(p)}" +
                (if (auto) "\nOtomatis dipakai saat game dibuka." else "")
            show(head + "\n" + (r.ifBlank {
                "Tidak ada output. Perangkat mungkin tidak mendukung 'cmd game set' (butuh Android 12+ dan game terdaftar di Game Mode)."
            }))
        }.start()
    }

    private fun reset() {
        val p = pkg ?: return
        if (!Access.requires(a, "Texture", false)) return
        out.text = "Mereset..."
        Thread {
            val r = Access.run(Texture.resetCmd(a, p))
            a.store.put("tex_$p", "")
            a.runOnUiThread { level = ""; render() }
            show("Texture ${name(p)} direset ke bawaan.\n" + r)
        }.start()
    }

    private fun info() {
        val p = pkg ?: return
        if (!Access.requires(a, "Texture", false)) return
        out.text = "Membaca..."
        Thread { show(Access.run("cmd game list-modes $p; cmd game list-configs $p")) }.start()
    }
}
