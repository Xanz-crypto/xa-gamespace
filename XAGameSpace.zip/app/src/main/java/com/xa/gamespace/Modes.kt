package com.xa.gamespace

import android.content.Context
import android.widget.LinearLayout
import android.widget.ScrollView

// Mode performa: Normal, Better, Performa, Esport, Stabil
object Modes {
    data class Mode(
        val key: String,
        val name: String,
        val desc: String,
        val stabil: Boolean,
        val smooth: Boolean,
        val touch: Boolean
    )

    val ALL = listOf(
        Mode("normal", "Normal", "Pengaturan bawaan HP, tanpa tweak.", false, false, false),
        Mode("better", "Better", "Sentuhan lebih responsif, beban tetap ringan.", false, false, true),
        Mode("performa", "Performa", "Refresh rate dan FPS maksimum, sentuhan responsif.", false, true, true),
        Mode("esport", "Esport", "Performa maksimum dengan FPS stabil dan sentuhan cepat.", true, true, true),
        Mode("stabil", "Stabil", "FPS rata 60 tanpa lonjakan. Clock CPU dan GPU dibatasi agar hemat panas.", true, false, true)
    )

    fun current(s: Store): Mode = ALL.firstOrNull { it.key == s.get("mode") } ?: ALL[0]

    fun apply(ctx: Context, m: Mode) {
        val s = Store(ctx)
        s.put("mode", m.key)
        s.stabil = m.stabil
        s.smooth = m.smooth
        s.touch = m.touch
        s.touchSmooth = false
        if (s.active) Boost.refresh(ctx)
    }

    val ROOT_TWEAKS = listOf(
        "Clock CPU dibatasi 70 sampai 85 persen dari maksimum: tidak turun tiba-tiba, tidak memanas",
        "Clock GPU minimum 60 persen dari maksimum: render tidak tersendat",
        "Fixed performance mode dimatikan: clock tidak dipaksa tinggi terus",
        "FPS dikunci 60 lewat cmd game set --fps 60",
        "Refresh rate dikunci 60 Hz: frame rata",
        "Wi-Fi latensi rendah dan power save mati",
        "Doze dimatikan selama game berjalan"
    )

    val SHIZUKU_TWEAKS = listOf(
        "Refresh rate dikunci 60 Hz",
        "FPS dikunci 60 lewat cmd game",
        "Wi-Fi latensi rendah dan kunci Wi-Fi saat game",
        "Scan Wi-Fi dan BLE di latar dimatikan",
        "Clock CPU dan GPU tidak bisa diatur tanpa root, jadi batasnya hanya lewat FPS 60"
    )
}

class ModePanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box = u.vbox()

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        build()
    }

    private fun build() {
        box.removeAllViews()
        val cur = Modes.current(a.store)
        Modes.ALL.forEach { m ->
            val on = m.key == cur.key
            box.addView(u.btn((if (on) "✓  " else "") + m.name + "\n" + m.desc, on) {
                a.applyMode(m)
                build()
            }, u.lp(-1, -2, b = 8))
        }
        if (cur.key == "stabil") {
            box.addView(u.label("TWEAK STABIL · ROOT", 12f, Hud.cyan, true), u.lp(-1, -2, t = 14))
            Modes.ROOT_TWEAKS.forEach { box.addView(u.label("• $it", 11f, Theme.sub), u.lp(-1, -2, t = 4)) }
            box.addView(u.label("TWEAK STABIL · NON-ROOT (SHIZUKU)", 12f, Hud.cyan, true), u.lp(-1, -2, t = 14))
            Modes.SHIZUKU_TWEAKS.forEach { box.addView(u.label("• $it", 11f, Theme.sub), u.lp(-1, -2, t = 4)) }
            box.addView(u.label("Target suhu di bawah 40°C tergantung game dan suhu ruangan. Cek dengan DevCheck.", 11f, Theme.sub), u.lp(-1, -2, t = 14))
        }
    }
}
