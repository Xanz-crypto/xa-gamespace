package com.xa.gamespace

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import kotlin.math.sin

// Kipas cooler yang berputar di Game Panel (di sebelah kartu game).
// Makin panas / makin berat CPU, kipas makin cepat. Cincin RGB ikut berputar.
class FanView(ctx: Context) : View(ctx) {
    private val blades = 7
    private var angle = 0f
    private var speed = 260f          // derajat per detik (yang digambar)
    private var targetSpeed = 260f
    private var lastT = 0L
    private var temp = 0f

    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bladeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val box = RectF()
    private val blade = Path()
    private val spk = Path()
    private var sweep: SweepGradient? = null

    // bilah kipas digambar SEKALI ke bitmap; tiap frame cukup diputar (jauh lebih ringan dari menggambar ulang 7 path)
    private var bladeBmp: Bitmap? = null
    private var bladeKey = -1
    private val bmpP = Paint(Paint.FILTER_BITMAP_FLAG)
    private var hubShader: RadialGradient? = null
    private var hubKey = -1
    private var tempStr = "--"

    init {
        // satu bilah dalam koordinat satuan (radius 1), melengkung seperti bilah kipas PC
        blade.moveTo(0.12f, 0f)
        blade.cubicTo(0.55f, -0.34f, 0.98f, -0.30f, 0.94f, 0.10f)
        blade.cubicTo(0.72f, -0.02f, 0.40f, 0.12f, 0.12f, 0.10f)
        blade.close()
    }

    // dipanggil tiap statistik baru: beban CPU (%) dan suhu (C)
    fun setLoad(cpuPct: Int, tempC: Float) {
        temp = tempC
        tempStr = if (tempC > 0f) "${tempC.toInt()}°C" else "--"
        val hot = (tempC - 34f).coerceAtLeast(0f)
        targetSpeed = (260f + cpuPct * 5f + hot * 22f).coerceAtMost(1100f)
    }

    init {
        // kotak yang sama dengan kartu game (ukuran diatur lewat LayoutParams)
        background = Hud.rounded(Color.argb(150, 12, 36, 70), Hud.cyan, ctx.pxf(14f), 1.5f)
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize(context.px(150), w), resolveSize(context.px(140), h))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        sweep = SweepGradient(0f, 0f, Wet.palette + Wet.palette[0], null)
    }

    init {
        // ketuk kipas = suara kipas on / off
        isClickable = true
        setOnClickListener {
            val on = Sfx.fanToggle()
            if (on) Sfx.tap()
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastT = System.nanoTime()
        Sfx.fanStart()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        Sfx.fanStop()
        bladeBmp?.recycle()
        bladeBmp = null
        bladeKey = -1
        super.onDetachedFromWindow()
    }

    private fun ensureBlades(r: Float) {
        val key = r.toInt()
        if (bladeBmp != null && bladeKey == key) return
        bladeBmp?.recycle()
        val sz = (r * 2f + 6f).toInt().coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.translate(sz / 2f, sz / 2f)
        c.scale(r, r)
        for (i in 0 until blades) {
            c.save()
            c.rotate(i * 360f / blades)
            bladeP.style = Paint.Style.FILL
            bladeP.color = Color.argb(255, 70, 190, 245)
            c.drawPath(blade, bladeP)
            bladeP.style = Paint.Style.STROKE
            bladeP.strokeWidth = 0.035f
            bladeP.color = Color.argb(235, 205, 238, 255)
            c.drawPath(blade, bladeP)
            c.restore()
        }
        bladeBmp = bmp
        bladeKey = key
    }

    // ikon speaker kecil di pojok kanan atas kotak: bergelombang = bersuara, tercoret = senyap
    private fun drawSpeaker(cv: Canvas, x: Float, y: Float, on: Boolean) {
        val u = context.pxf(1f)
        val c = if (on) Color.argb(235, 160, 230, 255) else Color.argb(170, 150, 170, 190)
        fill.shader = null
        fill.style = Paint.Style.FILL
        fill.color = c
        spk.reset()
        spk.moveTo(x - 5f * u, y - 2.2f * u)
        spk.lineTo(x - 2.4f * u, y - 2.2f * u)
        spk.lineTo(x + 0.8f * u, y - 5f * u)
        spk.lineTo(x + 0.8f * u, y + 5f * u)
        spk.lineTo(x - 2.4f * u, y + 2.2f * u)
        spk.lineTo(x - 5f * u, y + 2.2f * u)
        spk.close()
        cv.drawPath(spk, fill)
        frame.color = c
        frame.strokeWidth = 1.3f * u
        frame.strokeCap = Paint.Cap.ROUND
        if (on) {
            box.set(x - 2.5f * u, y - 3.6f * u, x + 3.5f * u, y + 3.6f * u)
            cv.drawArc(box, -50f, 100f, false, frame)
            box.set(x - 4.8f * u, y - 6.2f * u, x + 6.6f * u, y + 6.2f * u)
            cv.drawArc(box, -50f, 100f, false, frame)
        } else {
            cv.drawLine(x + 2.6f * u, y - 3f * u, x + 7.2f * u, y + 3f * u, frame)
            cv.drawLine(x + 7.2f * u, y - 3f * u, x + 2.6f * u, y + 3f * u, frame)
        }
        frame.strokeCap = Paint.Cap.BUTT
    }

    override fun onDraw(cv: Canvas) {
        val nowN = System.nanoTime()
        val dt = ((nowN - lastT) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastT = nowN
        speed += (targetSpeed - speed) * (1f - Math.exp((-3f * dt).toDouble()).toFloat())
        angle = (angle + speed * dt) % 360f

        val t = animNow()
        // kipas di tengah-atas kotak, teks COOLER dan suhu di bawahnya
        val s = minOf(width - context.pxf(24f), height * 0.62f)
        val oy = context.pxf(12f)
        val cx = width / 2f
        val cy = oy + s / 2f
        val half = s / 2f - context.pxf(2f)
        val col = Wet.cycle(t, 6f)
        val cr = Color.red(col); val cg = Color.green(col); val cb = Color.blue(col)

        // rumah kipas (kotak membulat) + cahaya tepi
        box.set(cx - half, cy - half, cx + half, cy + half)
        val rad = context.pxf(10f)
        fill.shader = null
        fill.color = Color.argb(150, 8, 22, 40)
        cv.drawRoundRect(box, rad, rad, fill)
        frame.strokeWidth = context.pxf(5f)
        frame.color = Color.argb(60, cr, cg, cb)
        cv.drawRoundRect(box, rad, rad, frame)
        frame.strokeWidth = context.pxf(1.4f)
        frame.color = Wet.mix(Hud.cyan, col, 0.5f)
        cv.drawRoundRect(box, rad, rad, frame)

        // empat sekrup kecil di sudut
        fill.color = Color.argb(140, 150, 200, 235)
        val sc = half - context.pxf(5f)
        for (sx in floatArrayOf(-1f, 1f)) for (sy in floatArrayOf(-1f, 1f)) {
            cv.drawCircle(cx + sx * sc, cy + sy * sc, context.pxf(1.4f), fill)
        }

        val r = half - context.pxf(6f)

        // cincin RGB berputar
        sweep?.let {
            cv.save()
            cv.translate(cx, cy)
            cv.rotate(angle * 0.35f)
            ringP.shader = it
            ringP.strokeWidth = context.pxf(2.6f)
            ringP.alpha = 255
            cv.drawCircle(0f, 0f, r, ringP)
            ringP.strokeWidth = context.pxf(7f)
            ringP.alpha = 55
            cv.drawCircle(0f, 0f, r, ringP)
            ringP.shader = null
            cv.restore()
        }

        // hembusan angin: bilah bayangan di belakang (makin cepat makin jelas)
        val blur = ((speed - 260f) / 700f).coerceIn(0f, 1f)
        val inner = r - context.pxf(3f)
        ensureBlades(inner)
        val bmp = bladeBmp
        if (bmp != null) {
            for (g in 3 downTo 0) {
                val a = if (g == 0) 1f else blur * (0.22f / g)
                if (a <= 0.02f) continue
                bmpP.alpha = (215 * a).toInt().coerceIn(0, 255)
                cv.save()
                cv.translate(cx, cy)
                cv.rotate(angle - g * 9f)
                cv.drawBitmap(bmp, -bmp.width / 2f, -bmp.height / 2f, bmpP)
                cv.restore()
            }
        }

        // hub tengah (shader dibuat sekali per ukuran, bukan tiap frame)
        val hk = inner.toInt()
        if (hubShader == null || hubKey != hk) {
            hubShader = RadialGradient(-inner * 0.08f, -inner * 0.08f, inner * 0.3f,
                Color.parseColor("#BFEFFF"), Color.parseColor("#1A5C8C"), Shader.TileMode.CLAMP)
            hubKey = hk
        }
        cv.save()
        cv.translate(cx, cy)
        fill.shader = hubShader
        cv.drawCircle(0f, 0f, inner * 0.26f, fill)
        fill.shader = null
        fill.color = Color.argb(230, 10, 30, 50)
        cv.drawCircle(0f, 0f, inner * 0.1f, fill)
        cv.restore()

        // penanda suara kipas on/off (pojok kanan atas kotak kipas)
        Sfx.fanSpeed(speed)
        drawSpeaker(cv, cx + half - context.pxf(11f), cy - half + context.pxf(10f), Sfx.fanSound && Sfx.enabled)

        // teks suhu di bawah kipas
        txt.textSize = context.pxf(9f)
        txt.color = Wet.mix(Color.parseColor("#9FE6FF"), col, 0.35f + 0.15f * sin(t * 2f))
        cv.drawText("COOLER", cx, oy + s + context.pxf(14f), txt)
        txt.textSize = context.pxf(9.5f)
        txt.color = Color.WHITE
        cv.drawText(tempStr, cx, oy + s + context.pxf(26f), txt)

        Gate.later(this, 33)
    }
}
