package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

// ================= GPU =================
data class GpuInfo(
    val path: String,
    val name: String,
    val govs: List<String>,
    val freqs: List<Long>,
    val gov: String,
    val min: Long,
    val max: Long,
    val cur: Long
)

object Gpu {
    private const val READ = """
for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*gpu* /sys/class/devfreq/*mali* /sys/class/devfreq/*kgsl*; do
  [ -f §d/max_freq ] || continue
  echo "G|§d|§(readlink -f §d 2>/dev/null)|§(cat §d/available_governors 2>/dev/null)|§(cat §d/available_frequencies 2>/dev/null)|§(cat §d/governor 2>/dev/null)|§(cat §d/min_freq 2>/dev/null)|§(cat §d/max_freq 2>/dev/null)|§(cat §d/cur_freq 2>/dev/null)"
done
"""

    fun read(): List<GpuInfo> {
        val out = Root.run(READ.replace('§', '$'))
        val seen = HashSet<String>()
        val raw = ArrayList<List<String>>()
        for (line in out.lines()) {
            if (!line.startsWith("G|")) continue
            val f = line.split("|")
            if (f.size < 9) continue
            val key = f[2].trim().ifBlank { f[1] }
            if (!seen.add(key)) continue
            raw.add(f)
        }
        return raw.map { f ->
            val min = f[6].trim().toLongOrNull() ?: 0L
            val max = f[7].trim().toLongOrNull() ?: 0L
            var fr = f[4].trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }.distinct().sorted()
            if (fr.isEmpty() && max > 0) fr = listOf(min, max).distinct().sorted()
            val nm = if (raw.size > 1) "GPU " + f[2].trim().substringAfterLast('/') else "GPU"
            GpuInfo(
                f[1], nm,
                f[3].trim().split(Regex("\\s+")).filter { it.isNotEmpty() },
                fr, f[5].trim(), min, max,
                f[8].trim().toLongOrNull() ?: 0L
            )
        }
    }

    private fun w(file: String, v: Any) = "chmod 0644 $file 2>/dev/null; echo $v > $file"

    fun rangeCmd(path: String, min: Long, max: Long): String =
        listOf(w("$path/max_freq", max), w("$path/min_freq", min), w("$path/max_freq", max)).joinToString("; ")

    fun govCmd(path: String, gov: String): String = w("$path/governor", gov)

    fun serialize(l: List<GpuInfo>): String = l.joinToString(";") { "${it.path}|${it.gov}|${it.min}|${it.max}" }

    fun restoreCmds(saved: String): List<String> = saved.split(";").mapNotNull {
        val p = it.split("|")
        if (p.size == 4 && p[0].isNotBlank()) {
            val mn = p[2].toLongOrNull()
            val mx = p[3].toLongOrNull()
            val c = ArrayList<String>()
            if (p[1].isNotBlank()) c.add(govCmd(p[0], p[1]))
            if (mn != null && mx != null && mx > 0) c.add(rangeCmd(p[0], mn, mx))
            c.joinToString("; ")
        } else null
    }

    fun fmt(hz: Long): String = "${hz / 1_000_000} MHz"
}

// ================= Sheet tuning di dalam Game Panel =================
class TuneSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val store = Store(ctx)
    private val sv = ScrollView(ctx)
    private val body = LinearLayout(ctx)
    private val tabViews = ArrayList<TextView>()
    private var tab = 0

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = Hud.rounded(Color.argb(247, 7, 19, 34), Hud.cyanDim, ctx.pxf(12f), 1f)
        root.setPadding(ctx.px(12), ctx.px(10), ctx.px(12), ctx.px(8))
        root.isClickable = true

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        listOf("CPU", "GPU", "FPS").forEachIndexed { i, n ->
            val t = TextView(ctx)
            t.text = n
            t.textSize = 12f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setPadding(ctx.px(16), ctx.px(6), ctx.px(16), ctx.px(6))
            t.setOnClickListener { select(i) }
            tabViews.add(t)
            head.addView(t, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = ctx.px(6) })
        }
        head.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        val back = TextView(ctx)
        back.text = "‹ Kembali"
        back.textSize = 12f
        back.typeface = Typeface.DEFAULT_BOLD
        back.setTextColor(Color.WHITE)
        back.setPadding(ctx.px(10), ctx.px(6), ctx.px(10), ctx.px(6))
        back.setOnClickListener { onClose() }
        head.addView(back)
        root.addView(head, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = ctx.px(8) })

        sv.isVerticalScrollBarEnabled = false
        body.orientation = LinearLayout.VERTICAL
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    fun select(i: Int) {
        tab = i
        tabViews.forEachIndexed { k, t ->
            val on = k == i
            t.setTextColor(if (on) Color.parseColor("#04141F") else Color.WHITE)
            t.background = Hud.rounded(if (on) Hud.cyan else Color.argb(50, 255, 255, 255), Hud.cyanDim, ctx.pxf(14f), 1f)
        }
        body.removeAllViews()
        body.addView(msg("Memuat..."))
        when (i) { 0 -> loadCpu(); 1 -> loadGpu(); else -> loadFps() }
    }

    // ---------- helper UI ----------
    private fun bg(b: () -> Unit) { Thread { b() }.start() }
    private fun ui(b: () -> Unit) { root.post { b() } }

    private fun txt(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = true): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun msg(t: String) = txt(t, 12f, Hud.sub, false)

    private fun card(): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.background = Hud.rounded(Color.argb(70, 20, 60, 100), Hud.cyanDim, ctx.pxf(10f), 1f)
        c.setPadding(ctx.px(10), ctx.px(8), ctx.px(10), ctx.px(8))
        return c
    }

    private fun titleRow(title: String, right: View?): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(txt(title, 13f), LinearLayout.LayoutParams(0, -2, 1f))
        if (right != null) r.addView(right)
        return r
    }

    private fun small(t: String): TextView {
        val v = txt(t, 10f, Hud.cyan)
        v.letterSpacing = 0.2f
        v.setPadding(0, ctx.px(6), 0, ctx.px(3))
        return v
    }

    private fun actionBtn(t: String, onClick: () -> Unit): TextView {
        val v = txt(t, 11f)
        v.setPadding(ctx.px(10), ctx.px(5), ctx.px(10), ctx.px(5))
        v.background = Hud.rounded(Color.argb(60, 255, 255, 255), Hud.cyanDim, ctx.pxf(10f), 1f)
        v.setOnClickListener { onClick() }
        return v
    }

    private fun chips(items: List<String>, sel: Int, pick: (Int) -> Unit): View {
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.HORIZONTAL
        items.forEachIndexed { i, s ->
            val on = i == sel
            val t = txt(s, 11f, if (on) Color.parseColor("#04141F") else Color.WHITE)
            t.gravity = Gravity.CENTER
            t.setPadding(ctx.px(11), ctx.px(6), ctx.px(11), ctx.px(6))
            t.background = Hud.rounded(
                if (on) Hud.cyan else Color.argb(45, 255, 255, 255),
                if (on) Hud.cyan else Color.argb(60, 120, 200, 255), ctx.pxf(14f), 1f)
            t.setOnClickListener { pick(i) }
            l.addView(t, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = ctx.px(5) })
        }
        hs.addView(l)
        return hs
    }

    private fun render(block: () -> Unit) {
        val y = sv.scrollY
        body.removeAllViews()
        block()
        sv.post { sv.scrollTo(0, y) }
    }

    private fun toast(s: String) { ui { Toast.makeText(ctx.applicationContext, s, Toast.LENGTH_SHORT).show() } }

    private fun short(khz: Long): String =
        if (khz >= 1_000_000) String.format("%.2fG", khz / 1_000_000.0) else "${khz / 1000}M"

    // ---------- CPU ----------
    private fun loadCpu() {
        bg {
            val r = Cpu.read()
            ui { if (tab == 0) renderCpu(r) }
        }
    }

    private fun execCpu(cmds: List<String>) {
        bg {
            Cpu.apply(cmds)
            try { Thread.sleep(250) } catch (e: InterruptedException) {}
            loadCpu()
        }
    }

    private fun renderCpu(pols: List<Policy>) = render {
        if (pols.isEmpty()) {
            body.addView(msg("CPU tidak bisa dibaca. Pastikan akses root diizinkan."))
            return@render
        }
        val all = card()
        all.addView(titleRow("Semua cluster", actionBtn("Reset awal") {
            val saved = if (store.active) store.get("snap_cpu") else store.get("cpu_default")
            if (saved.isBlank()) toast("Data awal belum tersimpan")
            else { execCpu(Cpu.restoreCmds(saved)); toast("CPU dikembalikan") }
        }))
        all.addView(small("GOVERNOR"))
        val union = pols.flatMap { it.govs }.distinct()
        val common = union.indexOfFirst { g -> pols.all { it.gov == g } }
        all.addView(chips(union, common) { i ->
            val g = union[i]
            execCpu(pols.filter { g in it.govs }.map { Cpu.govCmd(it.path, g) })
        })
        body.addView(all, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = ctx.px(8) })

        for (p in pols) {
            val c = card()
            c.addView(titleRow(p.name, txt("sekarang ${Cpu.fmt(p.cur)}", 11f, Hud.cyan)))
            c.addView(small("GOVERNOR"))
            c.addView(chips(p.govs, p.govs.indexOf(p.gov)) { i -> execCpu(listOf(Cpu.govCmd(p.path, p.govs[i]))) })
            val labels = p.freqs.map { short(it) }
            c.addView(small("FREKUENSI MIN"))
            c.addView(chips(labels, p.freqs.indexOf(p.min)) { i ->
                val v = p.freqs[i]
                execCpu(listOf(Cpu.rangeCmd(p.path, v, maxOf(p.max, v))))
            })
            c.addView(small("FREKUENSI MAX"))
            c.addView(chips(labels, p.freqs.indexOf(p.max)) { i ->
                val v = p.freqs[i]
                execCpu(listOf(Cpu.rangeCmd(p.path, minOf(p.min, v), v)))
            })
            body.addView(c, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = ctx.px(8) })
        }
    }

    // ---------- GPU ----------
    private fun loadGpu() {
        bg {
            val r = Gpu.read()
            ui { if (tab == 1) renderGpu(r) }
        }
    }

    private fun execGpu(cmds: List<String>) {
        bg {
            Cpu.apply(cmds)
            try { Thread.sleep(250) } catch (e: InterruptedException) {}
            loadGpu()
        }
    }

    private fun renderGpu(list: List<GpuInfo>) = render {
        if (list.isEmpty()) {
            body.addView(msg("GPU tidak terbaca (jalur devfreq tidak ditemukan di HP ini)."))
            return@render
        }
        for (g in list) {
            val c = card()
            val reset = actionBtn("Reset awal") {
                val saved = if (store.active) store.get("snap_gpu2") else ""
                if (saved.isBlank()) toast("Data awal belum tersimpan")
                else { execGpu(Gpu.restoreCmds(saved)); toast("GPU dikembalikan") }
            }
            c.addView(titleRow(g.name + "  ·  " + Gpu.fmt(g.cur), reset))
            if (g.govs.isNotEmpty()) {
                c.addView(small("GOVERNOR"))
                c.addView(chips(g.govs, g.govs.indexOf(g.gov)) { i -> execGpu(listOf(Gpu.govCmd(g.path, g.govs[i]))) })
            }
            val labels = g.freqs.map { "${it / 1_000_000}" }
            c.addView(small("FREKUENSI MIN (MHz)"))
            c.addView(chips(labels, g.freqs.indexOf(g.min)) { i ->
                val v = g.freqs[i]
                execGpu(listOf(Gpu.rangeCmd(g.path, v, maxOf(g.max, v))))
            })
            c.addView(small("FREKUENSI MAX (MHz)"))
            c.addView(chips(labels, g.freqs.indexOf(g.max)) { i ->
                val v = g.freqs[i]
                execGpu(listOf(Gpu.rangeCmd(g.path, minOf(g.min, v), v)))
            })
            body.addView(c, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = ctx.px(8) })
        }
    }

    // ---------- FPS (refresh rate layar) ----------
    @Suppress("DEPRECATION")
    private fun rates(): List<Int> = try {
        val d = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay
        d.supportedModes.map { Math.round(it.refreshRate) }.distinct().sorted()
    } catch (e: Exception) { listOf(60) }

    private fun loadFps() {
        bg {
            val rs = rates()
            val cur = Root.run("settings get system peak_refresh_rate").trim().toFloatOrNull()
            val mn = Root.run("settings get system min_refresh_rate").trim().toFloatOrNull()
            ui { if (tab == 2) renderFps(rs, cur, mn) }
        }
    }

    private fun renderFps(rs: List<Int>, peak: Float?, min: Float?) = render {
        val c = card()
        c.addView(titleRow("Batas FPS layar", null))
        c.addView(small("REFRESH RATE"))
        val top = rs.maxOrNull() ?: 60
        // terpilih manual jika min dan peak sama; selain itu dianggap Auto
        val pr = peak?.let { Math.round(it) }
        val mr = min?.let { Math.round(it) }
        val sel = if (pr != null && mr != null && pr == mr && pr in rs) rs.indexOf(pr) + 1 else 0
        val items = listOf("Auto") + rs.map { "$it Hz" }
        c.addView(chips(items, sel) { i ->
            bg {
                if (i == 0) {
                    Root.run("settings delete system min_refresh_rate; settings put system peak_refresh_rate $top; settings delete system user_refresh_rate")
                } else {
                    val r = rs[i - 1]
                    Root.run("settings put system min_refresh_rate $r; settings put system peak_refresh_rate $r; settings put system user_refresh_rate $r")
                }
                toast(if (i == 0) "Refresh rate: Auto" else "Refresh rate: ${rs[i - 1]} Hz")
                loadFps()
            }
        })
        val note = txt("Ini membatasi/mengunci FPS maksimum yang bisa ditampilkan layar. " +
            "FPS di dalam game tetap mengikuti batas dari game itu sendiri. " +
            "Nilai FPS live tampil di gauge tengah dan Monitor (jika terbaca).", 10f, Hud.sub, false)
        note.setPadding(0, ctx.px(8), 0, 0)
        c.addView(note)
        body.addView(c, LinearLayout.LayoutParams(-1, -2))
    }
}
