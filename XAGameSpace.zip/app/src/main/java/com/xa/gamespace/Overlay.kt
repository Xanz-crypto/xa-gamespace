package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min

// =====================================================================
//  Game Panel overlay
//  Alur: masuk game -> animasi "X" -> X berjalan ke sisi kiri jadi garis
//        -> geser garis ke kanan -> Game Panel terbuka
// =====================================================================
object GameOverlay {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var app: Context
    private lateinit var ui: Context
    private lateinit var wm: WindowManager

    private var shown = false
    private var entry: View? = null
    private var handle: HandleView? = null
    private var panel: PanelUi? = null
    private var panelAnim: ValueAnimator? = null
    private var crosshair: CrosshairView? = null
    private var monitor: MonitorView? = null
    private var fpsThread: Thread? = null
    @Volatile private var lastFps = -1

    @Volatile private var samplerOn = false
    private var sampler: Thread? = null

    fun canDraw(c: Context): Boolean =
        Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c.applicationContext)

    // ---------- show / hide ----------
    fun show(c: Context) {
        h.post {
            if (shown) return@post
            val a = c.applicationContext
            if (!canDraw(a)) return@post
            app = a
            Sfx.init(a)
            ui = ContextThemeWrapper(a, android.R.style.Theme_Material)
            wm = a.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            shown = true

            // video intro (xa_intro.mp4, ada suara); selesai -> handle panel muncul
            val iv = IntroVideo(ui) {
                h.post {
                    if (!shown) return@post
                    val cur = entry ?: return@post
                    entry = null
                    removeSafe(cur)
                    addHandle()
                }
            }
            entry = iv
            wm.addView(iv, lp(-1, -1, Gravity.START or Gravity.TOP, false))
            applyCrosshair()
            applyMonitor()
        }
    }

    fun hide() {
        h.post {
            if (!shown) return@post
            shown = false
            samplerOn = false
            panelAnim?.cancel()
            entry?.let { val e = it; entry = null; removeSafe(e) }
            handle?.let { removeSafe(it) }
            panel?.let { removeSafe(it.root) }
            crosshair?.let { removeSafe(it) }
            monitor?.let { removeSafe(it) }
            handle = null; panel = null; crosshair = null; monitor = null
        }
    }

    private fun removeSafe(v: View) {
        try { wm.removeView(v) } catch (e: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun lp(w: Int, hh: Int, gravity: Int, touchable: Boolean): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        f = if (touchable) f or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        else f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val p = WindowManager.LayoutParams(w, hh, type, f, PixelFormat.TRANSLUCENT)
        p.gravity = gravity
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return p
    }

    // ---------- handle (garis di tepi layar) ----------
    @Suppress("DEPRECATION")
    private fun screen(): IntArray {
        val m = android.util.DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return intArrayOf(m.widthPixels, m.heightPixels)
    }

    // posisi pojok kiri-atas jendela handle: [x, y]
    private fun handleXY(): IntArray {
        val sc = screen()
        val hw = ui.px(Hud.HANDLE_W)
        val hh = ui.px(Hud.HANDLE_H)
        val x = Store(ui).get("handle_x").toIntOrNull() ?: ((sc[0] - hw) / 2).coerceAtLeast(0)
        // garis digambar di tengah view (setengah tinggi = HANDLE_H/2 dp dari atas jendela).
        // Jendela dinaikkan supaya garis berada ~2 dp dari tepi atas layar (dipasang mentok atas,
        // tidak lagi memakai posisi lama yang tersimpan sehingga tidak "turun" sendiri).
        val y = -ui.px(Hud.HANDLE_H / 2 - 2)
        return intArrayOf(x, y)
    }

    private fun addHandle() {
        val hv = HandleView(ui)
        hv.alpha = 0f
        handle = hv
        val hw = ui.px(Hud.HANDLE_W)
        val hh = ui.px(Hud.HANDLE_H)
        val wlp = lp(hw, hh, Gravity.START or Gravity.TOP, true)
        val xy = handleXY()
        wlp.x = xy[0]; wlp.y = xy[1]
        wm.addView(hv, wlp)
        hv.animate().alpha(1f).setDuration(180).start()

        val slop = ui.pxf(10f)
        val dist = ui.pxf(200f)
        val longPressMs = 450L
        var x0 = 0f
        var y0 = 0f
        var startX = 0
        var startY = 0
        var p = 0f
        var mode = 0           // 0 belum jelas | 1 tarik ke bawah (buka panel) | 2 pindahkan handle
        val longPress = Runnable {
            if (mode == 0) {
                mode = 2
                hv.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                hv.alpha = 0.6f
            }
        }
        hv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    x0 = e.rawX; y0 = e.rawY; mode = 0; p = 0f
                    startX = wlp.x; startY = wlp.y
                    hv.touchOn = true
                    hv.postDelayed(longPress, longPressMs)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = e.rawY - y0
                    val dx = e.rawX - x0
                    if (mode == 0 && (abs(dx) > slop || abs(dy) > slop)) hv.removeCallbacks(longPress)
                    // geser ke atas: handle gepeng
                    if (mode == 0 && dy < -slop && -dy > abs(dx)) mode = 3
                    if (mode == 3) {
                        val s = (-dy / ui.pxf(90f)).coerceIn(0f, 1f)
                        hv.squash = s
                        // digeser kembali ke bawah: normal lagi, lalu bisa lanjut menarik panel
                        if (dy > -slop) { mode = 0; hv.squash = 0f }
                    }
                    if (mode == 0 && dy > slop && dy > abs(dx)) { mode = 1; beginPanel() }
                    if (mode == 1) { p = (dy / dist).coerceIn(0f, 1f); panel?.setProgress(p) }
                    if (mode == 2) {
                        // hanya kiri-kanan, tinggi tetap, dan tidak keluar dari layar
                        val sc = screen()
                        val maxX = (sc[0] - ui.px(Hud.HANDLE_W)).coerceAtLeast(0)
                        wlp.x = (startX + (e.rawX - x0)).toInt().coerceIn(0, maxX)
                        wm.updateViewLayout(hv, wlp)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    hv.removeCallbacks(longPress)
                    hv.touchOn = false
                    when (mode) {
                        1 -> animatePanel(if (p > 0.35f) 1f else 0f)
                        3 -> {
                            // dilepas saat masih gepeng: kembali normal (panel tidak terbuka)
                            hv.squash = 0f
                        }
                        2 -> {
                            Store(ui).put("handle_x", wlp.x.toString())
                            hv.alpha = 1f
                        }
                        else -> if (e.actionMasked == MotionEvent.ACTION_UP && abs(e.rawX - x0) < slop && abs(e.rawY - y0) < slop) openPanel()
                    }
                    mode = 0
                    true
                }
                else -> true
            }
        }
    }

    // ---------- panel ----------
    private fun beginPanel() {
        if (!shown || panel != null) return
        panelAnim?.cancel()
        Sfx.play("open")
        val pn = PanelUi(ui, false)
        pn.setProgress(0f)
        panel = pn
        wm.addView(pn.root, lp(-1, -1, Gravity.START or Gravity.TOP, true))
        ensureSampler()
    }

    fun openPanel() {
        h.post {
            if (!shown) return@post
            beginPanel()
            animatePanel(1f)
        }
    }

    fun closePanel() {
        h.post { animatePanel(0f) }
    }

    private fun animatePanel(to: Float) {
        val pn = panel ?: return
        panelAnim?.cancel()
        val a = ValueAnimator.ofFloat(pn.progress, to)
        a.duration = if (to >= 1f) 950L else 520L
        a.interpolator = if (to >= 1f) android.view.animation.PathInterpolator(0.16f, 1f, 0.3f, 1f)
        else android.view.animation.PathInterpolator(0.45f, 0f, 0.55f, 1f)
        a.addUpdateListener { pn.setProgress(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) { cancelled = true }
            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled && to == 0f && panel === pn) {
                    removeSafe(pn.root)
                    panel = null
                }
            }
        })
        panelAnim = a
        a.start()
    }

    fun launch(pkg: String) {
        closePanel()
        if (pkg == Store(app).game) return
        val li = app.packageManager.getLaunchIntentForPackage(pkg) ?: return
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { app.startActivity(li) } catch (e: Exception) { return }
        GameService.start(app, pkg)
    }

    // ---------- crosshair ----------
    fun applyCrosshair() {
        h.post {
            if (!shown) return@post
            val st = Store(app)
            val cur = crosshair
            if (st.crossOn && cur == null) {
                val v = CrosshairView(ui, st.crossStyle)
                crosshair = v
                wm.addView(v, lp(ui.px(80), ui.px(80), Gravity.CENTER, false))
            } else if (!st.crossOn && cur != null) {
                removeSafe(cur)
                crosshair = null
            } else if (cur != null) {
                cur.kind = st.crossStyle
                cur.invalidate()
            }
        }
    }

    // ---------- monitor ----------
    fun applyMonitor() {
        h.post {
            if (!shown) return@post
            val on = Store(app).monitorOn
            val cur = monitor
            if (on && cur == null) {
                val t = MonitorView(ui)
                monitor = t
                val p = lp(-2, -2, Gravity.START or Gravity.TOP, false)
                p.x = ui.px(48); p.y = ui.px(6)
                wm.addView(t, p)
                ensureFps()
                ensureSampler()
            } else if (!on && cur != null) {
                removeSafe(cur)
                monitor = null
            }
        }
    }

    // ---------- FPS real-time untuk monitor ----------
    private fun ensureFps() {
        if (fpsThread != null) return
        val t = Thread {
            while (shown && monitor != null) {
                val f = SysStats.frameNow(app)
                lastFps = f.fps
                val fastMon = monitor != null
                h.post {
                    monitor?.estimate = f.est
                    monitor?.pushFps(f.fps)
                }
                try { Thread.sleep(if (fastMon) 500L else 1000L) } catch (e: InterruptedException) { break }
            }
            fpsThread = null
        }
        fpsThread = t
        t.start()
    }

    // ---------- sampler status sistem ----------
    private fun ensureSampler() {
        samplerOn = true
        if (sampler != null) return
        val t = Thread {
            while (samplerOn && shown && (panel != null || monitor != null)) {
                val fast = fpsThread != null
                val s0 = SysStats.sample(app, !fast)
                val s = if (fast) s0.copy(fps = lastFps) else s0
                h.post {
                    panel?.onStats(s)
                    monitor?.setStats(s)
                }
                try { Thread.sleep(2000) } catch (e: InterruptedException) { break }
            }
            sampler = null
        }
        sampler = t
        t.start()
    }
}

// =====================================================================
//  Isi Game Panel
//  Kiri   : daftar game (geser atas-bawah)
//  Tengah : jam, status, menu pengaturan performa (bawah)
//  Kanan  : drawer (geser ke kiri) pengaturan panel
// =====================================================================
class PanelUi(private val ctx: Context, private val fromRight: Boolean = false) {
    companion object {
        // statistik terakhir, supaya animasi gauge/bar langsung punya nilai saat panel dibuka
        private var last: SysStats.Sample? = null
    }

    private val store = Store(ctx)
    val root = FrameLayout(ctx)
    private val dim = View(ctx)
    private val card = HudFrame(ctx)
    private val wrap = FrameLayout(ctx)
    private var wrapTop = 0f
    private var screenH = 0
    var progress = 0f
        private set

    private val scale: Float
    private val cardW: Int
    private val cardH: Int
    private val sideMargin: Int
    private val drawerW = ctx.px(220)
    private val tabW = ctx.px(28)
    private val ease = android.view.animation.PathInterpolator(0.22f, 1f, 0.36f, 1f)
    private val gridW = ctx.px(3 * 62)

    private lateinit var drawer: LinearLayout
    private lateinit var tab: TabView
    private lateinit var statView: HudStatView
    private lateinit var drawerBody: View
    private lateinit var popCol: LinearLayout

    private lateinit var pWifi: Pill
    private lateinit var pData: Pill
    private lateinit var pDnd: Pill

    private var lastB = 0L

    init {
        val dm = ctx.resources.displayMetrics
        // ukuran layar sebenarnya; panel dirancang 800x340 dp lalu diperkecil (PANEL_SCALE) seperti panel Xiaomi
        val real = android.util.DisplayMetrics()
        try { (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(real) } catch (e: Exception) {}
        val sw = if (real.widthPixels > 0) real.widthPixels else dm.widthPixels
        val sh = if (real.heightPixels > 0) real.heightPixels else dm.heightPixels
        // ukuran awal (800x340 dp, diperkecil PANEL_SCALE), tetap di tengah vertikal, hanya digeser ke tepi kiri
        // (atau tepi kanan bila handle di kanan)
        val S = Hud.PANEL_SCALE
        scale = S
        cardW = min(ctx.px(940), (sw * 0.98f / S).toInt())
        cardH = min(ctx.px(Hud.PANEL_H_DP), (sh * 0.98f / S).toInt())
        sideMargin = ctx.px(8)
        wrapTop = ctx.px(10).toFloat()
        screenH = sh

        dim.setBackgroundColor(Color.argb(165, 0, 0, 0))
        dim.alpha = 0f
        dim.setOnClickListener { GameOverlay.closePanel() }
        root.addView(dim, FrameLayout.LayoutParams(-1, -1))

        wrap.clipChildren = false
        wrap.scaleX = S
        wrap.scaleY = S
        wrap.addView(card, FrameLayout.LayoutParams(cardW, cardH))
        // pojok kiri layar: titik skala di tepi kiri supaya hasil perkecilan tetap menempel ke tepi
        // panel di tengah atas layar, membesar dari atas
        wrap.pivotX = cardW / 2f
        wrap.pivotY = 0f
        val wlp = FrameLayout.LayoutParams(cardW, cardH, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        wlp.topMargin = ctx.px(10)
        root.addView(wrap, wlp)

        buildMain()
        buildDrawer()

        val x = TextView(ctx)
        x.text = "✕"
        x.textSize = 16f
        x.setTextColor(Color.WHITE)
        x.gravity = Gravity.CENTER
        x.setOnClickListener { GameOverlay.closePanel() }
        val xp = FrameLayout.LayoutParams(ctx.px(40), ctx.px(30), Gravity.TOP or Gravity.START)
        xp.topMargin = ctx.px(6); xp.leftMargin = cardW / 2 + ctx.px(70)
        card.addView(x, xp)

        loadPopups()
        loadToggles()
        // tetesan air + kilau cahaya di atas panel (tidak menangkap sentuhan)
        // efek hidup: aurora + gelembung + ombak di belakang isi, percikan air + riak di depan
        val fxBack = PanelFxView(ctx, false)
        fxBack.clip = card.shape
        card.addView(fxBack, 0, FrameLayout.LayoutParams(-1, -1))
        val wet = WetGlowView(ctx, 14, false, 0.85f)
        wet.clip = card.shape
        card.addView(wet, FrameLayout.LayoutParams(-1, -1))
        val fxFront = PanelFxView(ctx, true)
        fxFront.clip = card.shape
        card.addView(fxFront, FrameLayout.LayoutParams(-1, -1))
        card.onTouchDown = { x, y -> fxFront.burst(x, y) }

        // gauge, RAM, CPU, suhu terisi satu per satu setelah panel selesai membesar
        last?.let { onStats(it) }
    }

    fun setProgress(p: Float) {
        progress = p
        dim.alpha = p
        // muncul dari tepi (tempat handle), kecil lalu membesar
        val s = 0.06f + 0.94f * p
        card.pivotX = cardW / 2f
        card.pivotY = 0f
        card.scaleX = s
        card.scaleY = s
        card.alpha = (p * 2.2f).coerceAtMost(1f)
        card.translationX = 0f
        card.translationY = -ctx.px(12) * (1f - p)
    }

    fun onStats(s: SysStats.Sample) {
        last = s
        if (s.fps >= 0) statView.update(s.fps.toFloat(), "FPS", s.ramPct.toFloat(), s.cpuPct.toFloat(), s.tempC)
        else statView.update(s.hz.toFloat(), "LAYAR Hz", s.ramPct.toFloat(), s.cpuPct.toFloat(), s.tempC)
    }

    // ---------- helper ----------
    private fun bg(b: () -> Unit) { Thread { b() }.start() }
    private fun ui(b: () -> Unit) { root.post { b() } }
    private fun toast(s: String) { ui { Toast.makeText(ctx.applicationContext, s, Toast.LENGTH_SHORT).show() } }

    private fun label(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = true): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun header(t: String): TextView {
        val v = label(t, 10f, Hud.cyan)
        v.letterSpacing = 0.25f
        return v
    }

    // ---------- bagian utama (gaya HUD: ikon bulat kiri & kanan, modul status di tengah, dock setelan di bawah tengah) ----------
    private fun buildMain() {
        val main = LinearLayout(ctx)
        main.orientation = LinearLayout.VERTICAL
        main.setPadding(ctx.px(26), ctx.px(42), tabW + ctx.px(6), ctx.px(40))
        card.band = true
        card.addView(main, FrameLayout.LayoutParams(-1, -1))

        val clk = TextClock(ctx)
        clk.format12Hour = "hh:mm a"
        clk.format24Hour = "hh:mm a"
        clk.textSize = 14f
        clk.typeface = Typeface.DEFAULT_BOLD
        clk.letterSpacing = 0.15f
        clk.setTextColor(Color.WHITE)
        // jam di dataran tengah atas, seperti referensi
        card.addView(clk, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).also { it.topMargin = ctx.px(8) })

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        main.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))

        // ----- tile fitur -----
        val tStabil = RingTile(ctx, "🎯", "Stabil FPS", true)
        tStabil.on = store.stabil
        tStabil.setOnClickListener {
            if (!Access.requires(ctx, "Stabil FPS", true)) return@setOnClickListener
            store.stabil = !store.stabil
            tStabil.on = store.stabil
            bg { Boost.refresh(ctx) }
        }
        val tSmooth = RingTile(ctx, "🌊", "Smooth FPS", true)
        tSmooth.on = store.smooth
        tSmooth.setOnClickListener {
            if (!Access.requires(ctx, "Smooth FPS", false)) return@setOnClickListener
            store.smooth = !store.smooth
            tSmooth.on = store.smooth
            bg { Boost.refresh(ctx) }
        }
        val tRam = RingTile(ctx, "🧹", "Clean RAM")
        tRam.setOnClickListener {
            if (!Access.requires(ctx, "Clean RAM", false)) return@setOnClickListener
            toast("Membersihkan RAM...")
            bg {
                val freed = Boost.cleanRam(ctx, store.game)
                toast("RAM dibebaskan $freed MB")
            }
        }
        val tKill = RingTile(ctx, "⛔", "Stop App")
        tKill.setOnClickListener {
            if (!Access.requires(ctx, "Stop App", false)) return@setOnClickListener
            openStop()
        }
        val tAuto = RingTile(ctx, "🤖", "Auto Game", true)
        tAuto.on = store.auto
        tAuto.setOnClickListener {
            if (!Access.requires(ctx, "Auto Game", false)) return@setOnClickListener
            store.auto = !store.auto
            tAuto.on = store.auto
            if (store.auto) GameService.start(ctx)
        }
        val tCpu = RingTile(ctx, "⚙", "CPU")
        tCpu.setOnClickListener { if (Access.requires(ctx, "CPU Tuning", true)) openSheet(0) }
        val tGpu = RingTile(ctx, "🎮", "GPU")
        tGpu.setOnClickListener { if (Access.requires(ctx, "GPU Tuning", true)) openSheet(1) }
        val tNet = RingTile(ctx, "📶", "Jaringan")
        tNet.setOnClickListener { openNet() }
        val tTouch = RingTile(ctx, "👆", "Touch", true)
        tTouch.on = store.touch || store.touchSmooth
        tTouch.setOnClickListener { openTouch() }
        val tVsync = RingTile(ctx, "🔄", "VSync FPS", true)
        tVsync.on = store.get(RateCmd.KEY_VFPS).let { it.isNotBlank() && it != "0" }
        tVsync.setOnClickListener { if (Access.requires(ctx, "VSync FPS", false)) openVsyncSlider() }
        val tGpuRend = RingTile(ctx, "🧹", "Clear RAM", true)
        tGpuRend.on = false
        tGpuRend.setOnClickListener {
            if (!Access.requires(ctx, "Clear RAM", false)) return@setOnClickListener
            openRamMenu()
        }
        val tFps = RingTile(ctx, "🎞", "FPS")
        tFps.setOnClickListener { if (Access.requires(ctx, "FPS Tuning", true)) openSheet(2) }
        val tMore = RingTile(ctx, "🧩", "Pop Up APK")
        tMore.setOnClickListener { setDock(!dockOpen) }
        for (t in listOf(tStabil, tCpu, tGpu, tFps)) { t.tag = "ROOT"; t.tagOk = Access.satisfied(true) }
        for (t in listOf(tSmooth, tRam, tKill, tAuto, tNet, tTouch)) { t.tag = "ROOT/SHIZUKU"; t.tagOk = Access.satisfied(false) }

        fun grid(a: List<View>): LinearLayout {
            val g = LinearLayout(ctx)
            g.orientation = LinearLayout.VERTICAL
            for (r in 0 until 2) {
                val rr = LinearLayout(ctx)
                rr.orientation = LinearLayout.HORIZONTAL
                for (c in 0 until 3) {
                    val i = r * 3 + c
                    if (i < a.size) rr.addView(a[i]) else rr.addView(View(ctx), LinearLayout.LayoutParams(ctx.px(62), ctx.px(90)))
                }
                g.addView(rr)
            }
            return g
        }
        val leftTiles = listOf<View>(tStabil, tSmooth, tTouch, tGpuRend, tVsync, tNet)
        val tHz = RingTile(ctx, "🖥", "Render Hz")
        tHz.setOnClickListener { if (Access.requires(ctx, "Render Hz", false)) openHzSlider() }
        tHz.tag = "ROOT"; tHz.tagOk = Access.satisfied(true)
        val rightTiles = listOf<View>(tCpu, tGpu, tFps, tKill, tMore, tHz)
        row.addView(grid(leftTiles), LinearLayout.LayoutParams(gridW, -2))

        // ----- tengah (meniru HUD referensi): modul status di atas, kartu game + kipas + lubang angin di bawahnya -----
        val midCol = LinearLayout(ctx)
        midCol.orientation = LinearLayout.VERTICAL
        midCol.gravity = Gravity.CENTER_HORIZONTAL
        statView = HudStatView(ctx)
        midCol.addView(statView)
        // tombol AI AUTO: kotak, lebar = garis atas monitor (172 dp), tinggi mengikuti teks
        val aiBtn = TextView(ctx).apply {
            text = "AI AUTO"
            textSize = 11f
            setTextColor(Hud.neon)
            typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
            letterSpacing = 0.25f
            gravity = Gravity.CENTER
            setPadding(ctx.px(6), ctx.px(5), ctx.px(6), ctx.px(5))
            background = Hud.rounded(Color.argb(60, 8, 40, 60), Hud.neon, ctx.pxf(4f), 1.4f)
            setOnClickListener { Sfx.tap(); openAi() }
        }
        midCol.addView(aiBtn, LinearLayout.LayoutParams(ctx.px(172), -2).also { it.topMargin = ctx.px(6) })
        // tombol MY MUSIC di bawah AI AUTO: buka menu musik lengkap (sama seperti di GameSpace)
        val myMusic = TextView(ctx).apply {
            text = "♫  MY MUSIC"
            textSize = 11f
            setTextColor(Hud.neon)
            typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
            letterSpacing = 0.25f
            gravity = Gravity.CENTER
            setPadding(ctx.px(6), ctx.px(5), ctx.px(6), ctx.px(5))
            background = Hud.rounded(Color.argb(60, 8, 40, 60), Hud.neon, ctx.pxf(4f), 1.4f)
            setOnClickListener { Sfx.tap(); openMusicAux() }
        }
        midCol.addView(myMusic, LinearLayout.LayoutParams(ctx.px(172), -2).also { it.topMargin = ctx.px(6) })
        row.addView(midCol, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = ctx.px(8); it.rightMargin = ctx.px(8) })

        row.addView(grid(rightTiles), LinearLayout.LayoutParams(gridW, -2))

        // ----- slider bawah: KECERAHAN (kiri) dan VOLUME (kanan), tengah dikosongkan untuk dock SETELAN -----
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val curB = try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (e: Exception) { 128 }
        val maxV = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
        val curV = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
        val sliders = LinearLayout(ctx)
        sliders.orientation = LinearLayout.HORIZONTAL
        sliders.gravity = Gravity.CENTER_VERTICAL
        sliders.addView(miniSlider("☀", "KECERAHAN", 255, curB) { v, fin ->
            val now = System.currentTimeMillis()
            if (fin || now - lastB > 250) {
                lastB = now
                bg { Root.run("settings put system screen_brightness_mode 0; settings put system screen_brightness ${v.coerceAtLeast(1)}") }
            }
        }, LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = ctx.px(120) })
        sliders.addView(miniSlider("🔊", "VOLUME", maxV, curV) { v, _ ->
            try { am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, v, 0) } catch (e: Exception) {}
        }, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = ctx.px(120) })
        main.addView(sliders, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(4) })

        buildDock()

        // ikon muncul bergantian pelan-pelan setelah panel terbuka
        val tiles = leftTiles + rightTiles + listOf<View>(statView)
        for (t in tiles) { t.alpha = 0f; t.translationY = ctx.px(14).toFloat() }
        root.post {
            tiles.forEachIndexed { i, t ->
                t.animate().alpha(1f).translationY(0f).setStartDelay(300L + i * 70L).setDuration(700).setInterpolator(ease).start()
            }
        }
    }

    // ---------- dock setelan lanjutan (bawah tengah) ----------
    private var dockOpen = false
    private lateinit var dockBody: LinearLayout
    private lateinit var dockTab: TextView

    private fun buildDock() {
        val bodyH = ctx.px(112)
        dockBody = LinearLayout(ctx)
        dockBody.orientation = LinearLayout.VERTICAL
        dockBody.setPadding(ctx.px(14), ctx.px(8), ctx.px(14), ctx.px(8))
        dockBody.background = Hud.rounded(Color.argb(225, 8, 22, 42), Hud.cyan, ctx.pxf(14f), 1.4f)
        dockBody.addView(header("POP UP APK · SETELAN LANJUTAN"), LinearLayout.LayoutParams(-2, -2).also { it.bottomMargin = ctx.px(4) })
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        popCol = LinearLayout(ctx)
        popCol.orientation = LinearLayout.HORIZONTAL
        hs.addView(popCol)
        r.addView(hs, LinearLayout.LayoutParams(0, -1, 1f))
        dockBody.addView(r, LinearLayout.LayoutParams(-1, 0, 1f))
        val bl = FrameLayout.LayoutParams(ctx.px(560), bodyH, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        bl.bottomMargin = ctx.px(36)
        dockBody.visibility = View.INVISIBLE
        dockBody.translationY = (bodyH + ctx.px(10)).toFloat()
        card.addView(dockBody, bl)

        // tab kecil di bawah tengah: ketuk atau geser ke atas untuk membuka
        dockTab = label("▲  SETELAN", 9.5f, Hud.cyan)
        dockTab.letterSpacing = 0.2f
        dockTab.gravity = Gravity.CENTER
        dockTab.background = Hud.rounded(Color.argb(200, 8, 22, 42), Hud.cyanDim, ctx.pxf(11f), 1.2f)
        var y0 = 0f
        dockTab.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { y0 = e.rawY; true }
                MotionEvent.ACTION_UP -> {
                    val d = e.rawY - y0
                    if (d < -ctx.px(10)) setDock(true) else if (d > ctx.px(10)) setDock(false) else setDock(!dockOpen)
                    true
                }
                else -> true
            }
        }
        val tl = FrameLayout.LayoutParams(ctx.px(120), ctx.px(22), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        tl.bottomMargin = ctx.px(8)
        card.addView(dockTab, tl)
    }

    private fun setDock(open: Boolean) {
        if (open == dockOpen) return
        dockOpen = open
        Sfx.play("swipe", 0.8f)
        dockTab.text = if (open) "▼  TUTUP" else "▲  SETELAN"
        val h = dockBody.height.takeIf { it > 0 } ?: ctx.px(112)
        dockBody.animate().cancel()
        if (open) {
            dockBody.visibility = View.VISIBLE
            dockBody.alpha = 0f
            dockBody.animate().translationY(0f).alpha(1f).setDuration(650).setInterpolator(ease).start()
            dockTab.animate().translationY(-ctx.px(0).toFloat()).setDuration(650).start()
        } else {
            dockBody.animate().translationY((h + ctx.px(10)).toFloat()).alpha(0f).setDuration(480)
                .setInterpolator(android.view.animation.PathInterpolator(0.4f, 0f, 0.6f, 1f))
                .withEndAction { if (!dockOpen) dockBody.visibility = View.INVISIBLE }.start()
        }
    }

    // ---------- sheet tuning CPU / GPU / FPS ----------
    private var sheet: TuneSheet? = null

    // ---------- menu Clear RAM ----------
    private fun openRamMenu() {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.px(12), ctx.px(10), ctx.px(12), ctx.px(10))
        col.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        val head = TextView(ctx)
        head.text = "CLEAR RAM"
        head.textSize = 12f
        head.setTypeface(null, android.graphics.Typeface.BOLD)
        head.setTextColor(Hud.cyan)
        col.addView(head)
        fun opt(title: String, desc: String, click: () -> Unit) {
            val b = LinearLayout(ctx)
            b.orientation = LinearLayout.VERTICAL
            b.setPadding(ctx.px(12), ctx.px(9), ctx.px(12), ctx.px(9))
            b.background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(60, 255, 255, 255), ctx.pxf(12f), 1f)
            val t = TextView(ctx)
            t.text = title
            t.textSize = 12.5f
            t.setTypeface(null, android.graphics.Typeface.BOLD)
            t.setTextColor(Color.WHITE)
            val d = TextView(ctx)
            d.text = desc
            d.textSize = 9.5f
            d.setTextColor(Hud.sub)
            b.addView(t)
            b.addView(d)
            b.setOnClickListener { Sfx.tap(); click() }
            col.addView(b, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(8) })
        }
        opt("Clear RAM", "Cepat: hentikan aplikasi latar pengguna dan bersihkan cache. Aplikasi yang dikecualikan tetap jalan.") {
            closeAux(); runRam(false)
        }
        opt("Optimasi RAM 50%", "Bertahap sampai RAM bebas 50%. Menghentikan aplikasi latar pengguna, lalu sistem non-inti bila perlu. Game yang sedang dimainkan tidak disentuh.") {
            closeAux(); runRam(true)
        }
        opt("Pilih aplikasi yang tidak di-clear", "Centang aplikasi yang harus tetap berjalan. Berlaku untuk kedua mode.") {
            openRamKeep()
        }
        showAux(col)
    }

    private fun runRam(deep: Boolean) {
        toast(if (deep) "Optimasi RAM berjalan..." else "Membersihkan RAM...")
        bg {
            val msg = if (deep) Boost.optimizeRam(ctx, store.game, 50)
            else "RAM dibebaskan ${Boost.cleanRam(ctx, store.game)} MB"
            toast(msg)
        }
    }

    // daftar aplikasi berjalan untuk dicentang sebagai pengecualian (disimpan permanen)
    private fun openRamKeep() {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.px(12), ctx.px(10), ctx.px(12), ctx.px(10))
        col.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        val head = TextView(ctx)
        head.text = "TIDAK DI-CLEAR"
        head.textSize = 11f
        head.setTypeface(null, android.graphics.Typeface.BOLD)
        head.setTextColor(Hud.cyan)
        col.addView(head)
        val hint = TextView(ctx)
        hint.text = "Ketuk untuk mengecualikan. Pilihan ini diingat sampai kamu mengubahnya."
        hint.textSize = 9.5f
        hint.setTextColor(Hud.sub)
        col.addView(hint)
        val list = LinearLayout(ctx)
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        col.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val loading = TextView(ctx)
        loading.text = "Memindai aplikasi..."
        loading.textSize = 10f
        loading.setTextColor(Hud.sub)
        list.addView(loading)
        showAux(col)

        bg {
            val apps = Boost.scan(ctx, store.game)
            ui {
                list.removeAllViews()
                if (apps.isEmpty()) {
                    val none = TextView(ctx)
                    none.text = "Tidak ada aplikasi latar."
                    none.textSize = 10f
                    none.setTextColor(Hud.sub)
                    list.addView(none)
                }
                for (a in apps) {
                    val row = TextView(ctx)
                    fun paint() {
                        val on = a.pkg in Boost.protectedSet(ctx)
                        row.text = (if (on) "☑  " else "☐  ") + a.label + "   " + a.memMb + " MB"
                        row.setTextColor(if (on) Hud.cyan else Color.WHITE)
                    }
                    row.textSize = 11f
                    row.setPadding(ctx.px(4), ctx.px(7), ctx.px(4), ctx.px(7))
                    paint()
                    row.setOnClickListener {
                        Sfx.tap()
                        val set = Boost.protectedSet(ctx).toMutableSet()
                        if (!set.remove(a.pkg)) set.add(a.pkg)
                        store.put("ram_keep", set.joinToString(","))
                        paint()
                    }
                    list.addView(row)
                }
            }
        }
    }

    private fun openSheet(tab: Int) {
        closeAuxNow()
        if (sheet == null) {
            val s = TuneSheet(ctx) { closeSheet() }
            val lp = FrameLayout.LayoutParams(-1, -1)
            lp.leftMargin = ctx.px(26 + 3 * 62 + 8)
            lp.topMargin = ctx.px(44)
            lp.bottomMargin = ctx.px(44)
            lp.rightMargin = tabW + ctx.px(6)
            card.addView(s.root, 2, lp)
            s.root.alpha = 0f
            s.root.animate().alpha(1f).setDuration(160).start()
            sheet = s
        }
        sheet?.select(tab)
    }

    private fun closeSheet() {
        val s = sheet ?: return
        sheet = null
        s.root.animate().alpha(0f).setDuration(140).withEndAction { card.removeView(s.root) }.start()
    }

    // ---------- Pop Up APK ----------
    private var aux: View? = null

    private fun showAux(v: View) {
        closeAuxNow()
        closeSheet()
        val lp = FrameLayout.LayoutParams(-1, -1)
        lp.leftMargin = ctx.px(24 + 104 + 14)
        lp.topMargin = ctx.px(14)
        lp.bottomMargin = ctx.px(14)
        lp.rightMargin = tabW + ctx.px(6)
        card.addView(v, 2, lp)
        v.alpha = 0f
        v.animate().alpha(1f).setDuration(160).start()
        aux = v
    }

    private fun closeAux() {
        val v = aux ?: return
        aux = null
        v.animate().alpha(0f).setDuration(140).withEndAction { card.removeView(v) }.start()
    }

    private var rateView: View? = null

    // Panel geser kecil untuk VSync FPS / GPU Render Vsync (muncul dari tile kiri)
    private fun openVsyncSlider() = showRateSheet(RateOverlaySheet.MODE_VSYNC)
    private fun openGpuRenderSlider() = showRateSheet(RateOverlaySheet.MODE_GPU)

    private fun showRateSheet(mode: Int) {
        closeAuxNow()
        rateView?.let { card.removeView(it) }
        val sheet = RateOverlaySheet(ctx, store, mode) {
            rateView?.let { card.removeView(it) }
            rateView = null
        }
        card.addView(sheet.root, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        rateView = sheet.root
    }

    private var hzView: View? = null

    // Panel geser untuk Render Hz: geser lalu lepas untuk menerapkan. Index 0 = Bawaan.
    // blok geser: judul + nilai + SeekBar
    private fun sliderBlock(title: String, labels: List<String>, cur: Int, drag: View.OnTouchListener, onRelease: (Int) -> Unit): LinearLayout {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val head = label(title, 12f, Hud.cyan)
        head.setOnTouchListener(drag)
        val value = label(labels[cur], 20f)
        value.setOnTouchListener(drag)
        value.gravity = Gravity.CENTER
        val sb = SeekBar(ctx)
        sb.max = labels.size - 1
        sb.progress = cur
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { value.text = labels[p] }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { onRelease(sb.progress) }
        })
        col.addView(head)
        col.addView(value, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(4) })
        col.addView(sb, LinearLayout.LayoutParams(ctx.px(290), -2).also { it.topMargin = ctx.px(6) })
        return col
    }

    // satu menu: Render Hz + GPU Render Vsync (digeser)
    private fun openHzSlider() {
        closeAuxNow()
        hzView?.let { card.removeView(it) }
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.px(20), ctx.px(16), ctx.px(20), ctx.px(16))
        box.background = Hud.rounded(Color.argb(235, 8, 22, 42), Hud.cyan, ctx.pxf(14f), 1.4f)
        // geser popup dengan jari (judul, nilai, atau area kosong kotak)
        var dx0 = 0f; var dy0 = 0f; var tx0 = 0f; var ty0 = 0f
        val drag = View.OnTouchListener { _, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> { dx0 = e.rawX; dy0 = e.rawY; tx0 = box.translationX; ty0 = box.translationY; true }
                android.view.MotionEvent.ACTION_MOVE -> {
                    box.translationX = tx0 + (e.rawX - dx0)
                    box.translationY = ty0 + (e.rawY - dy0)
                    true
                }
                else -> true
            }
        }
        box.setOnTouchListener(drag)

        val hzVals = listOf("") + RateCmd.RENDER_HZ
        val hzLabels = hzVals.map { if (it.isBlank()) "Bawaan" else "$it Hz" }
        val curHz = hzVals.indexOf(store.get(RateCmd.KEY_RENDER)).coerceAtLeast(0)
        box.addView(sliderBlock("RENDER HZ · GESER", hzLabels, curHz, drag) { i ->
            val v = hzVals[i]
            store.put(RateCmd.KEY_RENDER, v)
            bg {
                Access.run(if (v.isBlank()) RateCmd.renderDefaultCmd() else RateCmd.renderCmd(v))
                toast("Render ${if (v.isBlank()) "bawaan" else "$v Hz"}")
            }
        })

        val curGpu = if (store.get(RateCmd.KEY_GPU) == "1") 1 else 0
        box.addView(sliderBlock("GPU RENDER VSYNC · GESER", listOf("Mati", "Hidup"), curGpu, drag) { i ->
            val on = i == 1
            store.put(RateCmd.KEY_GPU, if (on) "1" else "0")
            bg {
                Access.run(RateCmd.gpuVsyncCmd(on))
                toast("GPU render vsync ${if (on) "hidup" else "mati"}")
            }
        }, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(12) })

        val close = label("TUTUP", 11f, Color.WHITE)
        close.gravity = Gravity.CENTER
        close.setPadding(ctx.px(12), ctx.px(6), ctx.px(12), ctx.px(6))
        close.background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
        close.setOnClickListener { hzView?.let { card.removeView(it) }; hzView = null }
        box.addView(close, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = ctx.px(10); it.gravity = Gravity.END })
        card.addView(box, FrameLayout.LayoutParams(ctx.px(340), -2, Gravity.CENTER))
        hzView = box
    }

    private fun closeAuxNow() {
        aux?.let { card.removeView(it) }
        aux = null
    }

    private fun openPicker() {
        showAux(AppPickerView(ctx, store, { loadPopups() }, { closeAux() }).root)
    }

    private fun openStop() {
        showAux(StopSheet(ctx, store.game) { closeAux() }.root)
    }

    // menu musik lengkap (sama seperti di GameSpace) muncul di panel overlay
    private fun openMusicAux() {
        showAux(MusicPanel(ctx,
            { target -> gsLaunch { putExtra("pick_target", target) } },
            { gsLaunch { putExtra("new_playlist", true) } }).root)
    }

    // buka GameSpace untuk hal yang butuh Activity (pilih file, dialog nama)
    private fun gsLaunch(extra: android.content.Intent.() -> Unit) {
        val it2 = android.content.Intent(ctx, MainActivity::class.java)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP)
        it2.extra()
        ctx.startActivity(it2)
    }

    private fun openAi() {
        showAux(AiTuneSheet(ctx) { closeAux() }.root)
    }

    private fun openNet() {
        showAux(NetSheet(ctx, { openStop() }) { closeAux() }.root)
    }

    private fun openTouch() {
        showAux(TouchSheet(ctx) { closeAux() }.root)
    }

    private fun loadPopups() {
        popCol.removeAllViews()
        val pm = ctx.packageManager
        val add = LinearLayout(ctx)
        add.orientation = LinearLayout.VERTICAL
        add.gravity = Gravity.CENTER_HORIZONTAL
        add.setPadding(ctx.px(4), ctx.px(8), ctx.px(4), ctx.px(6))
        add.background = Hud.rounded(Color.argb(60, 60, 200, 255), Hud.cyan, ctx.pxf(10f), 1f)
        add.addView(label("＋", 20f, Hud.cyan))
        val at = label("Tambah APK", 9f)
        at.gravity = Gravity.CENTER
        add.addView(at)
        add.setOnClickListener { Sfx.tap(); openPicker() }
        popCol.addView(add, LinearLayout.LayoutParams(ctx.px(70), -2).also { it.rightMargin = ctx.px(8) })

        val list = Popup.list(store)
        if (list.isEmpty()) {
            val hint = label("Belum ada. Ketuk ＋ untuk menambah.", 9f, Hud.sub, false)
            popCol.addView(hint)
            return
        }
        for (pkg in list) {
            val icon = try { pm.getApplicationIcon(pkg) } catch (e: Exception) { continue }
            val name = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
            popCol.addView(popItem(pkg, name, icon), LinearLayout.LayoutParams(ctx.px(70), -2).also { it.rightMargin = ctx.px(8) })
        }
    }

    private fun popItem(pkg: String, name: String, icon: android.graphics.drawable.Drawable): View {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.setPadding(ctx.px(4), ctx.px(8), ctx.px(4), ctx.px(6))
        c.background = Hud.rounded(Color.argb(50, 15, 40, 70), Hud.cyanDim, ctx.pxf(10f), 1f)
        val iv = ImageView(ctx)
        iv.setImageDrawable(icon)
        c.addView(iv, LinearLayout.LayoutParams(ctx.px(40), ctx.px(40)))
        val t = label(name, 9f)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        c.addView(t, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(4) })
        c.setOnClickListener {
            if (Popup.launch(ctx, pkg)) GameOverlay.closePanel()
            else toast("Aplikasi tidak bisa dibuka")
        }
        c.setOnLongClickListener {
            Popup.toggle(store, pkg)
            loadPopups()
            toast("$name dihapus dari Pop Up")
            true
        }
        return c
    }

    // ---------- drawer kanan (geser ke kiri) ----------
    private fun buildDrawer() {
        drawer = LinearLayout(ctx)
        drawer.orientation = LinearLayout.HORIZONTAL
        tab = TabView(ctx)
        drawer.addView(tab, LinearLayout.LayoutParams(tabW, -1))

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.px(12), ctx.px(10), ctx.px(12), ctx.px(10))
        sv.addView(box)
        drawer.addView(sv, LinearLayout.LayoutParams(drawerW, -1))
        drawerBody = sv
        sv.visibility = View.INVISIBLE   // menu ke-2 baru muncul setelah tab digeser / diketuk

        box.addView(header("PENGATURAN PANEL"), LinearLayout.LayoutParams(-2, -2).also { it.bottomMargin = ctx.px(4) })

        // Crosshair
        val pCross = Pill(ctx)
        pCross.setOn(store.crossOn)
        pCross.onToggle = { v -> store.crossOn = v; GameOverlay.applyCrosshair() }
        val style = TextView(ctx)
        style.text = "◎"
        style.textSize = 15f
        style.setTextColor(Hud.cyan)
        style.setPadding(ctx.px(8), ctx.px(2), ctx.px(8), ctx.px(2))
        style.setOnClickListener {
            store.crossStyle = (store.crossStyle + 1) % 4
            GameOverlay.applyCrosshair()
        }
        box.addView(row("✛", "Crosshair", style, pCross))

        // Mixer suara (root / Shizuku)
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        for ((g, n, st) in listOf(Triple("🔔", "Dering", 2), Triple("📣", "Notifikasi", 5), Triple("📞", "Panggilan", 0))) {
            val mx = am.getStreamMaxVolume(st)
            val cv = am.getStreamVolume(st)
            box.addView(sliderRow(g, n, mx, cv) { v, fin ->
                if (fin && Access.requires(ctx, "Mixer suara", false)) bg { Root.run("cmd media_session volume --stream $st --set $v") }
            })
        }

        // Jangan ganggu
        pDnd = Pill(ctx)
        pDnd.onToggle = { v ->
            if (!Access.requires(ctx, "Jangan Ganggu", false)) pDnd.setOn(!v)
            else bg {
                if (v) Root.run("cmd notification set_dnd priority || settings put global zen_mode 1")
                else Root.run("cmd notification set_dnd off || settings put global zen_mode 0")
            }
        }
        box.addView(row("🔕", "Jangan Ganggu", pDnd))

        // WiFi
        pWifi = Pill(ctx)
        pWifi.onToggle = { v -> if (!Access.requires(ctx, "WiFi", false)) pWifi.setOn(!v) else bg { Root.run("svc wifi ${if (v) "enable" else "disable"}") } }
        box.addView(row("📶", "WiFi", pWifi))

        // Data
        pData = Pill(ctx)
        pData.onToggle = { v -> if (!Access.requires(ctx, "Data", false)) pData.setOn(!v) else bg { Root.run("svc data ${if (v) "enable" else "disable"}") } }
        box.addView(row("📡", "Data", pData))

        // Suara panel (klik / geser / buka)
        val pSfx = Pill(ctx)
        pSfx.setOn(Sfx.enabled)
        pSfx.onToggle = { v -> Sfx.enabled = v }
        box.addView(row("🔈", "Suara panel", pSfx))

        // Monitor
        val pMon = Pill(ctx)
        pMon.setOn(store.monitorOn)
        pMon.onToggle = { v -> store.monitorOn = v; GameOverlay.applyMonitor() }
        box.addView(row("📊", "Monitor", pMon))

        val dp = FrameLayout.LayoutParams(tabW + drawerW, cardH - ctx.px(68), Gravity.END or Gravity.CENTER_VERTICAL)
        card.addView(drawer, dp)
        drawer.translationX = drawerW.toFloat()

        // geser tab ke kiri untuk buka, ke kanan untuk tutup (tap juga bisa)
        var d0 = 0f
        var t0 = 0f
        var moved = false
        tab.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { d0 = e.rawX; t0 = drawer.translationX; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val d = e.rawX - d0
                    if (abs(d) > ctx.pxf(6f)) moved = true
                    drawer.translationX = (t0 + d).coerceIn(0f, drawerW.toFloat())
                    if (moved) {
                        drawerBody.visibility = View.VISIBLE
                        drawerBody.alpha = (1f - drawer.translationX / drawerW).coerceIn(0f, 1f)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val half = drawerW / 2f
                    val open = if (moved) drawer.translationX < half else drawer.translationX > half
                    setDrawer(open)
                    true
                }
                else -> true
            }
        }
    }

    private fun setDrawer(open: Boolean) {
        tab.open = open
        Sfx.play("swipe", 0.8f)
        if (open) drawerBody.visibility = View.VISIBLE
        drawerBody.animate().alpha(if (open) 1f else 0f).setDuration(200).start()
        drawer.animate().translationX(if (open) 0f else drawerW.toFloat()).setDuration(200)
            .withEndAction { if (!tab.open) drawerBody.visibility = View.INVISIBLE }.start()
    }

    private fun row(glyph: String, name: String, vararg right: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, ctx.px(7), 0, ctx.px(7))
        val g = label(glyph, 16f, Hud.cyan)
        g.gravity = Gravity.CENTER
        r.addView(g, LinearLayout.LayoutParams(ctx.px(26), -2))
        val n = label(name, 12f)
        n.maxLines = 1
        r.addView(n, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = ctx.px(6) })
        for (v in right) r.addView(v, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = ctx.px(6) })
        return r
    }

    // slider kecil bergaya panel baru: label neon di atas, bar hijau di bawah
    // isi blok MUSIK: judul lagu, kontrol putar, lalu ulangi / acak / AI Auto
    private fun fillMusic(box: LinearLayout, ctx: Context) {
        if (Music.list.isEmpty()) Music.load(ctx)
        box.removeAllViews()
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.px(6), ctx.px(5), ctx.px(6), ctx.px(5))
        box.background = Hud.rounded(Color.parseColor("#E6181818"), Color.parseColor("#1DB954"), ctx.pxf(10f), 1f)


        val name = if (Music.list.isEmpty()) "-" else Music.title(ctx, Music.list[Music.idx])
        box.addView(TextView(ctx).apply {
            text = "♫  " + name
            textSize = 10f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))

        fun ctl(label: String, active: Boolean = false, onTap: () -> Unit): TextView = TextView(ctx).apply {
            text = label
            textSize = 12f
            setTextColor(if (active) Color.BLACK else Color.WHITE)
            gravity = Gravity.CENTER
            background = Hud.rounded(if (active) Color.parseColor("#1DB954") else Color.parseColor("#282828"), Color.parseColor("#1DB954"), ctx.pxf(10f), 1f)
            setPadding(0, ctx.px(4), 0, ctx.px(4))
            setOnClickListener { Sfx.tap(); onTap(); fillMusic(box, ctx) }
        }
        fun lpW(r: Int = 0) = LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = ctx.px(r) }

        val row1 = LinearLayout(ctx)
        row1.addView(ctl("⏮") { Music.prev(ctx) }, lpW(4))
        row1.addView(ctl(if (Music.isPlaying()) "⏸" else "▶", true) { Music.toggle(ctx) }, lpW(4))
        row1.addView(ctl("⏭") { Music.next(ctx) }, lpW(0))
        box.addView(row1, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(4) })

        val row2 = LinearLayout(ctx)
        val rep = when (Music.repeat) { 1 -> "↻1"; 2 -> "↻All"; else -> "↻" }
        row2.addView(ctl(rep, Music.repeat != 0) { Music.setRepeat(ctx, (Music.repeat + 1) % 3) }, lpW(4))
        row2.addView(ctl("⤮", Music.shuffle) { Music.setShuffle(ctx, !Music.shuffle) }, lpW(4))
        row2.addView(ctl("AI", Music.aiAuto) { Music.setAi(ctx, !Music.aiAuto) }, lpW(4))
        row2.addView(ctl("≡") { openMusicAux() }, lpW(0))
        box.addView(row2, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(4) })
    }

    private fun miniSlider(glyph: String, name: String, max: Int, cur: Int, onChange: (Int, Boolean) -> Unit): LinearLayout {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        val nm = label("$glyph  $name", 10f, Hud.neon)
        nm.letterSpacing = 0.2f
        val pct = label("${100 * cur / max.coerceAtLeast(1)}%", 10f, Color.WHITE)
        head.addView(nm, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(pct)
        box.addView(head, LinearLayout.LayoutParams(-1, -2))
        val sb = SeekBar(ctx)
        sb.max = max
        sb.progress = cur
        val tint = ColorStateList.valueOf(Hud.neon)
        sb.progressTintList = tint
        sb.thumbTintList = tint
        sb.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(80, 46, 245, 160))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                pct.text = "${100 * p / max.coerceAtLeast(1)}%"
                if (fromUser) onChange(p, false)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { onChange(s.progress, true) }
        })
        box.addView(sb, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    private fun sliderRow(glyph: String, name: String, max: Int, cur: Int, onChange: (Int, Boolean) -> Unit): LinearLayout {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val pct = label("${100 * cur / max.coerceAtLeast(1)}%", 11f, Hud.sub)
        box.addView(row(glyph, name, pct))
        val sb = SeekBar(ctx)
        sb.max = max
        sb.progress = cur
        val tint = ColorStateList.valueOf(Hud.cyan)
        sb.progressTintList = tint
        sb.thumbTintList = tint
        sb.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(80, 120, 200, 255))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                pct.text = "${100 * p / max.coerceAtLeast(1)}%"
                if (fromUser) onChange(p, false)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { onChange(s.progress, true) }
        })
        box.addView(sb, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = ctx.px(2) })
        return box
    }

    // baca status WiFi / Data / Jangan Ganggu saat panel dibuka
    private fun loadToggles() {
        bg {
            val wifi = try {
                (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
            } catch (e: Exception) { false }
            val o = Root.run("echo D=\$(settings get global mobile_data); echo Z=\$(settings get global zen_mode)")
            val data = Regex("D=(\\d+)").find(o)?.groupValues?.get(1) == "1"
            val zen = (Regex("Z=(\\d+)").find(o)?.groupValues?.get(1) ?: "0") != "0"
            ui {
                pWifi.setOn(wifi)
                pData.setOn(data)
                pDnd.setOn(zen)
            }
        }
    }
}
