package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min

// =====================================================================
//  Game Panel overlay
//  Alur: masuk game -> animasi "X" -> X berjalan ke sisi kiri jadi garis
//        -> geser garis ke kanan -> Game Panel terbuka
// =====================================================================
object GameOverlay {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var app: Context
    private lateinit var ui: Context
    private lateinit var wm: WindowManager

    private var shown = false
    private var entry: XEntryView? = null
    private var handle: HandleView? = null
    private var panel: PanelUi? = null
    private var panelAnim: ValueAnimator? = null
    private var crosshair: CrosshairView? = null
    private var monitor: MonitorView? = null
    private var fpsThread: Thread? = null
    @Volatile private var lastFps = -1

    @Volatile private var samplerOn = false
    private var sampler: Thread? = null

    fun canDraw(c: Context): Boolean =
        Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c.applicationContext)

    // ---------- show / hide ----------
    fun show(c: Context) {
        h.post {
            if (shown) return@post
            val a = c.applicationContext
            if (!canDraw(a)) return@post
            app = a
            Sfx.init(a)
            ui = ContextThemeWrapper(a, android.R.style.Theme_Material)
            wm = a.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            shown = true

            val hp = handleXY()
            val inset = ui.pxf(Hud.HANDLE_INSET.toFloat())
            val lineX = if (Store(a).handleSide == 0) hp[0] + inset else hp[0] + ui.px(Hud.HANDLE_W) - inset
            val ev = XEntryView(ui, lineX, hp[1] + ui.px(Hud.HANDLE_H) / 2f, ui.pxf(Hud.HANDLE_HALF.toFloat()))
            entry = ev
            wm.addView(ev, lp(-1, -1, Gravity.START or Gravity.TOP, false))
            ev.start {
                h.post {
                    if (!shown || entry !== ev) return@post
                    entry = null
                    removeSafe(ev)
                    addHandle()
                }
            }
            applyCrosshair()
            applyMonitor()
        }
    }

    fun hide() {
        h.post {
            if (!shown) return@post
            shown = false
            samplerOn = false
            panelAnim?.cancel()
            entry?.let { val e = it; entry = null; e.cancel(); removeSafe(e) }
            handle?.let { removeSafe(it) }
            panel?.let { removeSafe(it.root) }
            crosshair?.let { removeSafe(it) }
            monitor?.let { removeSafe(it) }
            handle = null; panel = null; crosshair = null; monitor = null
        }
    }

    private fun removeSafe(v: View) {
        try { wm.removeView(v) } catch (e: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun lp(w: Int, hh: Int, gravity: Int, touchable: Boolean): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        f = if (touchable) f or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        else f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val p = WindowManager.LayoutParams(w, hh, type, f, PixelFormat.TRANSLUCENT)
        p.gravity = gravity
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return p
    }

    // ---------- handle (garis di tepi layar) ----------
    @Suppress("DEPRECATION")
    private fun screen(): IntArray {
        val m = android.util.DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return intArrayOf(m.widthPixels, m.heightPixels)
    }

    // posisi pojok kiri-atas jendela handle: [x, y]
    private fun handleXY(): IntArray {
        val sc = screen()
        val hw = ui.px(Hud.HANDLE_W)
        val hh = ui.px(Hud.HANDLE_H)
        val st = Store(app)
        val y = (st.handleY.coerceIn(0.08f, 0.92f) * sc[1] - hh / 2f).toInt().coerceIn(0, (sc[1] - hh).coerceAtLeast(0))
        val x = if (st.handleSide == 0) 0 else sc[0] - hw
        return intArrayOf(x, y)
    }

    private fun addHandle() {
        val hv = HandleView(ui)
        hv.alpha = 0f
        handle = hv
        val hw = ui.px(Hud.HANDLE_W)
        val hh = ui.px(Hud.HANDLE_H)
        val wlp = lp(hw, hh, Gravity.START or Gravity.TOP, true)
        val xy = handleXY()
        wlp.x = xy[0]; wlp.y = xy[1]
        wm.addView(hv, wlp)
        hv.animate().alpha(1f).setDuration(180).start()

        val sc = screen()
        val st = Store(app)
        val dist = ui.pxf(200f)
        val slop = ui.pxf(10f)
        var x0 = 0f
        var y0 = 0f
        var wx = 0
        var wy = 0
        var mode = 0           // 0 belum jelas | 1 buka panel | 2 geser sepanjang tepi | 3 pindah bebas
        var p = 0f
        val lift = Runnable {
            if (mode == 0) { mode = 3; hv.held = true; Sfx.play("swipe", 0.9f) }
        }

        fun updatePos() { try { wm.updateViewLayout(hv, wlp) } catch (e: Exception) {} }

        fun save() {
            st.handleSide = if (wlp.x + hw / 2 < sc[0] / 2) 0 else 1
            st.handleY = ((wlp.y + hh / 2f) / sc[1]).coerceIn(0.08f, 0.92f)
        }

        fun snap() {
            val toX = if (wlp.x + hw / 2 < sc[0] / 2) 0 else sc[0] - hw
            val fromX = wlp.x
            val a = ValueAnimator.ofInt(fromX, toX)
            a.duration = 220
            a.interpolator = DecelerateInterpolator()
            a.addUpdateListener { wlp.x = it.animatedValue as Int; updatePos() }
            a.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { save() }
            })
            a.start()
        }

        hv.setOnTouchListener { _, e ->
            val left = st.handleSide == 0
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    x0 = e.rawX; y0 = e.rawY; wx = wlp.x; wy = wlp.y; mode = 0; p = 0f
                    hv.postDelayed(lift, 380)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - x0
                    val dy = e.rawY - y0
                    val inward = if (left) dx else -dx
                    if (mode == 0 && (abs(dx) > slop || abs(dy) > slop)) {
                        if (inward > slop && inward > abs(dy)) { hv.removeCallbacks(lift); mode = 1; beginPanel() }
                        else if (abs(dy) > slop && abs(dy) > abs(dx)) { hv.removeCallbacks(lift); mode = 2 }
                    }
                    when (mode) {
                        1 -> { p = (inward / dist).coerceIn(0f, 1f); panel?.setProgress(p) }
                        2 -> { wlp.y = (wy + dy).toInt().coerceIn(0, (sc[1] - hh).coerceAtLeast(0)); updatePos() }
                        3 -> {
                            wlp.x = (wx + dx).toInt().coerceIn(0, (sc[0] - hw).coerceAtLeast(0))
                            wlp.y = (wy + dy).toInt().coerceIn(0, (sc[1] - hh).coerceAtLeast(0))
                            updatePos()
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    hv.removeCallbacks(lift)
                    when (mode) {
                        1 -> animatePanel(if (p > 0.35f) 1f else 0f)
                        2 -> save()
                        3 -> snap()
                        else -> if (e.actionMasked == MotionEvent.ACTION_UP && abs(e.rawX - x0) < slop && abs(e.rawY - y0) < slop) openPanel()
                    }
                    hv.held = false
                    mode = 0
                    true
                }
                else -> true
            }
        }
    }

    // ---------- panel ----------
    private fun beginPanel() {
        if (!shown || panel != null) return
        panelAnim?.cancel()
        Sfx.play("open")
        val pn = PanelUi(ui, Store(app).handleSide == 1)
        pn.setProgress(0f)
        panel = pn
        wm.addView(pn.root, lp(-1, -1, Gravity.START or Gravity.TOP, true))
        ensureSampler()
    }

    fun openPanel() {
        h.post {
            if (!shown) return@post
            beginPanel()
            animatePanel(1f)
        }
    }

    fun closePanel() {
        h.post { animatePanel(0f) }
    }

    private fun animatePanel(to: Float) {
        val pn = panel ?: return
        panelAnim?.cancel()
        val a = ValueAnimator.ofFloat(pn.progress, to)
        a.duration = if (to >= 1f) 950L else 520L
        a.interpolator = if (to >= 1f) android.view.animation.PathInterpolator(0.16f, 1f, 0.3f, 1f)
        else android.view.animation.PathInterpolator(0.45f, 0f, 0.55f, 1f)
        a.addUpdateListener { pn.setProgress(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) { cancelled = true }
            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled && to == 0f && panel === pn) {
                    removeSafe(pn.root)
                    panel = null
                }
            }
        })
        panelAnim = a
        a.start()
    }

    fun launch(pkg: String) {
        closePanel()
        if (pkg == Store(app).game) return
        val li = app.packageManager.getLaunchIntentForPackage(pkg) ?: return
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { app.startActivity(li) } catch (e: Exception) { return }
        GameService.start(app, pkg)
    }

    // ---------- crosshair ----------
    fun applyCrosshair() {
        h.post {
            if (!shown) return@post
            val st = Store(app)
            val cur = crosshair
            if (st.crossOn && cur == null) {
                val v = CrosshairView(ui, st.crossStyle)
                crosshair = v
                wm.addView(v, lp(ui.px(80), ui.px(80), Gravity.CENTER, false))
            } else if (!st.crossOn && cur != null) {
                removeSafe(cur)
                crosshair = null
            } else if (cur != null) {
                cur.kind = st.crossStyle
                cur.invalidate()
            }
        }
    }

    // ---------- monitor ----------
    fun applyMonitor() {
        h.post {
            if (!shown) return@post
            val on = Store(app).monitorOn
            val cur = monitor
            if (on && cur == null) {
                val t = MonitorView(ui)
                monitor = t
                val p = lp(-2, -2, Gravity.START or Gravity.TOP, false)
                p.x = ui.px(48); p.y = ui.px(6)
                wm.addView(t, p)
                ensureFps()
                ensureSampler()
            } else if (!on && cur != null) {
                removeSafe(cur)
                monitor = null
            }
        }
    }

    // ---------- FPS real-time untuk monitor ----------
    private fun ensureFps() {
        if (fpsThread != null) return
        val t = Thread {
            while (shown && monitor != null) {
                val f = SysStats.frameNow(app)
                lastFps = f.fps
                val fastMon = monitor != null
                h.post {
                    monitor?.estimate = f.est
                    monitor?.pushFps(f.fps)
                }
                try { Thread.sleep(if (fastMon) 500L else 1000L) } catch (e: InterruptedException) { break }
            }
            fpsThread = null
        }
        fpsThread = t
        t.start()
    }

    // ---------- sampler status sistem ----------
    private fun ensureSampler() {
        samplerOn = true
        if (sampler != null) return
        val t = Thread {
            while (samplerOn && shown && (panel != null || monitor != null)) {
                val fast = fpsThread != null
                val s0 = SysStats.sample(app, !fast)
                val s = if (fast) s0.copy(fps = lastFps) else s0
                h.post {
                    panel?.onStats(s)
                    monitor?.setStats(s)
                }
                try { Thread.sleep(2000) } catch (e: InterruptedException) { break }
            }
            sampler = null
        }
        sampler = t
        t.start()
    }
}

// =====================================================================
//  Isi Game Panel
//  Kiri   : daftar game (geser atas-bawah)
//  Tengah : jam, status, menu pengaturan performa (bawah)
//  Kanan  : drawer (geser ke kiri) pengaturan panel
// =====================================================================
class PanelUi(private val ctx: Context, private val fromRight: Boolean = false) {
    companion object {
        // statistik terakhir, supaya animasi gauge/bar langsung punya nilai saat panel dibuka
        private var last: SysStats.Sample? = null
    }

    private val store = Store(ctx)
    val root = FrameLayout(ctx)
    private val dim = View(ctx)
    private val card = HudFrame(ctx)
    private val wrap = FrameLayout(ctx)
    private var wrapTop = 0f
    private var screenH = 0
    var progress = 0f
        private set

    private val scale: Float
    private val cardW: Int
    private val cardH: Int
    private val sideMargin: Int
    private val drawerW = ctx.px(220)
    private val tabW = ctx.px(28)
    private val ease = android.view.animation.PathInterpolator(0.22f, 1f, 0.36f, 1f)
    private val gridW = ctx.px(3 * 62)

    private lateinit var drawer: LinearLayout
    private lateinit var tab: TabView
    private lateinit var statView: HudStatView
    private lateinit var fan: FanView
    private lateinit var vent: GillVentView
    private lateinit var drawerBody: View
    private lateinit var popCol: LinearLayout

    private lateinit var pWifi: Pill
    private lateinit var pData: Pill
    private lateinit var pDnd: Pill

    private var lastB = 0L

    init {
        val dm = ctx.resources.displayMetrics
        // ukuran layar sebenarnya; panel dirancang 800x340 dp lalu diperkecil (PANEL_SCALE) seperti panel Xiaomi
        val real = android.util.DisplayMetrics()
        try { (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(real) } catch (e: Exception) {}
        val sw = if (real.widthPixels > 0) real.widthPixels else dm.widthPixels
        val sh = if (real.heightPixels > 0) real.heightPixels else dm.heightPixels
        // ukuran awal (800x340 dp, diperkecil PANEL_SCALE), tetap di tengah vertikal, hanya digeser ke tepi kiri
        // (atau tepi kanan bila handle di kanan)
        val S = Hud.PANEL_SCALE
        scale = S
        cardW = min(ctx.px(940), (sw * 0.98f / S).toInt())
        cardH = min(ctx.px(356), (sh * 0.98f / S).toInt())
        sideMargin = ctx.px(8)
        wrapTop = (sh - cardH * S) / 2f
        screenH = sh

        dim.setBackgroundColor(Color.argb(165, 0, 0, 0))
        dim.alpha = 0f
        dim.setOnClickListener { GameOverlay.closePanel() }
        root.addView(dim, FrameLayout.LayoutParams(-1, -1))

        wrap.clipChildren = false
        wrap.scaleX = S
        wrap.scaleY = S
        wrap.addView(card, FrameLayout.LayoutParams(cardW, cardH))
        // pojok kiri layar: titik skala di tepi kiri supaya hasil perkecilan tetap menempel ke tepi
        wrap.pivotX = if (fromRight) cardW.toFloat() else 0f
        val wlp = FrameLayout.LayoutParams(cardW, cardH,
            (if (fromRight) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL)
        if (fromRight) wlp.rightMargin = ctx.px(8) else wlp.leftMargin = ctx.px(8)
        root.addView(wrap, wlp)

        buildMain()
        buildDrawer()

        val x = TextView(ctx)
        x.text = "✕"
        x.textSize = 16f
        x.setTextColor(Color.WHITE)
        x.gravity = Gravity.CENTER
        x.setOnClickListener { GameOverlay.closePanel() }
        val xp = FrameLayout.LayoutParams(ctx.px(40), ctx.px(30), Gravity.TOP or Gravity.START)
        xp.topMargin = ctx.px(6); xp.leftMargin = cardW / 2 + ctx.px(70)
        card.addView(x, xp)

        loadPopups()
        loadToggles()
        // tetesan air + kilau cahaya di atas panel (tidak menangkap sentuhan)
        // efek hidup: aurora + gelembung + ombak di belakang isi, percikan air + riak di depan
        val fxBack = PanelFxView(ctx, false)
        fxBack.clip = card.shape
        card.addView(fxBack, 0, FrameLayout.LayoutParams(-1, -1))
        val wet = WetGlowView(ctx, 14, false, 0.85f)
        wet.clip = card.shape
        card.addView(wet, FrameLayout.LayoutParams(-1, -1))
        val fxFront = PanelFxView(ctx, true)
        fxFront.clip = card.shape
        card.addView(fxFront, FrameLayout.LayoutParams(-1, -1))
        card.onTouchDown = { x, y -> fxFront.burst(x, y) }

        // gauge, RAM, CPU, suhu terisi satu per satu setelah panel selesai membesar
        last?.let { onStats(it) }
    }

    fun setProgress(p: Float) {
        progress = p
        dim.alpha = p
        // muncul dari tepi (tempat handle), kecil lalu membesar
        val s = 0.06f + 0.94f * p
        card.pivotX = if (fromRight) cardW.toFloat() else 0f
        card.pivotY = ((Store(ctx).handleY * screenH - wrapTop) / scale).coerceIn(0f, cardH.toFloat())
        card.scaleX = s
        card.scaleY = s
        card.alpha = (p * 2.2f).coerceAtMost(1f)
        card.translationX = (if (fromRight) 1f else -1f) * sideMargin * (1f - p)
    }

    fun onStats(s: SysStats.Sample) {
        last = s
        if (s.fps >= 0) statView.update(s.fps.toFloat(), "FPS", s.ramPct.toFloat(), s.cpuPct.toFloat(), s.tempC)
        else statView.update(s.hz.toFloat(), "LAYAR Hz", s.ramPct.toFloat(), s.cpuPct.toFloat(), s.tempC)
        fan.setLoad(s.cpuPct, s.tempC)
        vent.setLoad(s.cpuPct, s.tempC)
    }

    // ---------- helper ----------
    private fun bg(b: () -> Unit) { Thread { b() }.start() }
    private fun ui(b: () -> Unit) { root.post { b() } }
    private fun toast(s: String) { ui { Toast.makeText(ctx.applicationContext, s, Toast.LENGTH_SHORT).show() } }

    private fun label(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = true): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun header(t: String): TextView {
        val v = label(t, 10f, Hud.cyan)
        v.letterSpacing = 0.25f
        return v
    }

    // ---------- bagian utama (gaya HUD: ikon bulat kiri & kanan, modul status di tengah, dock setelan di bawah tengah) ----------
    private fun buildMain() {
        val main = LinearLayout(ctx)
        main.orientation = LinearLayout.VERTICAL
        main.setPadding(ctx.px(26), ctx.px(42), tabW + ctx.px(6), ctx.px(40))
        card.band = true
        card.addView(main, FrameLayout.LayoutParams(-1, -1))

        val clk = TextClock(ctx)
        clk.format12Hour = "hh:mm a"
        clk.format24Hour = "hh:mm a"
        clk.textSize = 14f
        clk.typeface = Typeface.DEFAULT_BOLD
        clk.letterSpacing = 0.15f
        clk.setTextColor(Color.WHITE)
        // jam di dataran tengah atas, seperti referensi
        card.addView(clk, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).also { it.topMargin = ctx.px(8) })

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        main.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))

        // ----- tile fitur -----
        val tStabil = RingTile(ctx, "🎯", "Stabil FPS", true)
        tStabil.on = store.stabil
        tStabil.setOnClickListener {
            if (!Access.requires(ctx, "Stabil FPS", true)) return@setOnClickListener
            store.stabil = !store.stabil
            tStabil.on = store.stabil
            bg { Boost.refresh(ctx) }
        }
        val tSmooth = RingTile(ctx, "🌊", "Smooth FPS", true)
        tSmooth.on = store.smooth
        tSmooth.setOnClickListener {
            if (!Access.requires(ctx, "Smooth FPS", false)) return@setOnClickListener
            store.smooth = !store.smooth
            tSmooth.on = store.smooth
            bg { Boost.refresh(ctx) }
        }
        val tRam = RingTile(ctx, "🧹", "Clean RAM")
        tRam.setOnClickListener {
            if (!Access.requires(ctx, "Clean RAM", false)) return@setOnClickListener
            toast("Membersihkan RAM...")
            bg {
                val freed = Boost.cleanRam(ctx, store.game)
                toast("RAM dibebaskan $freed MB")
            }
        }
        val tKill = RingTile(ctx, "⛔", "Stop App")
        tKill.setOnClickListener {
            if (!Access.requires(ctx, "Stop App", false)) return@setOnClickListener
            openStop()
        }
        val tAuto = RingTile(ctx, "🤖", "Auto Game", true)
        tAuto.on = store.auto
        tAuto.setOnClickListener {
            if (!Access.requires(ctx, "Auto Game", false)) return@setOnClickListener
            store.auto = !store.auto
            tAuto.on = store.auto
            if (store.auto) GameService.start(ctx)
        }
        val tCpu = RingTile(ctx, "⚙", "CPU")
        tCpu.setOnClickListener { if (Access.requires(ctx, "CPU Tuning", true)) openSheet(0) }
        val tGpu = RingTile(ctx, "🎮", "GPU")
        tGpu.setOnClickListener { if (Access.requires(ctx, "GPU Tuning", true)) openSheet(1) }
        val tNet = RingTile(ctx, "📶", "Jaringan")
        tNet.setOnClickListener { openNet() }
        val tTouch = RingTile(ctx, "👆", "Touch", true)
        tTouch.on = store.touch || store.touchSmooth
        tTouch.setOnClickListener { openTouch() }
        val tFps = RingTile(ctx, "🎞", "FPS")
        tFps.setOnClickListener { if (Access.requires(ctx, "FPS Tuning", true)) openSheet(2) }
        val tMore = RingTile(ctx, "🧩", "Pop Up APK")
        tMore.setOnClickListener { setDock(!dockOpen) }
        for (t in listOf(tStabil, tCpu, tGpu, tFps)) { t.tag = "ROOT"; t.tagOk = Access.satisfied(true) }
        for (t in listOf(tSmooth, tRam, tKill, tAuto, tNet, tTouch)) { t.tag = "ROOT/SHIZUKU"; t.tagOk = Access.satisfied(false) }

        fun grid(a: List<View>): LinearLayout {
            val g = LinearLayout(ctx)
            g.orientation = LinearLayout.VERTICAL
            for (r in 0 until 2) {
                val rr = LinearLayout(ctx)
                rr.orientation = LinearLayout.HORIZONTAL
                for (c in 0 until 3) {
                    val i = r * 3 + c
                    if (i < a.size) rr.addView(a[i]) else rr.addView(View(ctx), LinearLayout.LayoutParams(ctx.px(62), ctx.px(90)))
                }
                g.addView(rr)
            }
            return g
        }
        val leftTiles = listOf<View>(tStabil, tSmooth, tTouch, tAuto, tNet, tRam)
        val rightTiles = listOf<View>(tCpu, tGpu, tFps, tKill, tMore)
        row.addView(grid(leftTiles), LinearLayout.LayoutParams(gridW, -2))

        // ----- tengah (meniru HUD referensi): modul status di atas, kartu game + kipas + lubang angin di bawahnya -----
        val midCol = LinearLayout(ctx)
        midCol.orientation = LinearLayout.VERTICAL
        midCol.gravity = Gravity.CENTER_HORIZONTAL
        statView = HudStatView(ctx)
        midCol.addView(statView)
        val below = LinearLayout(ctx)
        below.orientation = LinearLayout.HORIZONTAL
        below.gravity = Gravity.CENTER
        below.addView(GameCardView(ctx, store), LinearLayout.LayoutParams(ctx.px(150), ctx.px(140)))
        fan = FanView(ctx)
        below.addView(fan, LinearLayout.LayoutParams(ctx.px(100), ctx.px(140)).also { it.leftMargin = ctx.px(8) })
        vent = GillVentView(ctx)
        below.addView(vent, LinearLayout.LayoutParams(ctx.px(46), ctx.px(140)).also { it.leftMargin = ctx.px(8) })
        midCol.addView(below, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = ctx.px(4) })
        row.addView(midCol, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = ctx.px(8); it.rightMargin = ctx.px(8) })

        row.addView(grid(rightTiles), LinearLayout.LayoutParams(gridW, -2))

        // ----- slider bawah: KECERAHAN (kiri) dan VOLUME (kanan), tengah dikosongkan untuk dock SETELAN -----
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val curB = try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (e: Exception) { 128 }
        val maxV = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
        val curV = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
        val sliders = LinearLayout(ctx)
        sliders.orientation = LinearLayout.HORIZONTAL
        sliders.gravity = Gravity.CENTER_VERTICAL
        sliders.addView(miniSlider("☀", "KECERAHAN", 255, curB) { v, fin ->
            val now = System.currentTimeMillis()
            if (fin || now - lastB > 250) {
                lastB = now
                bg { Root.run("settings put system screen_brightness_mode 0; settings put system screen_brightness ${v.coerceAtLeast(1)}") }
            }
        }, LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = ctx.px(120) })
        sliders.addView(miniSlider("🔊", "VOLUME", maxV, curV) { v, _ ->
            try { am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, v, 0) } catch (e: Exception) {}
        }, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = ctx.px(120) })
        main.addView(sliders, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(4) })

        buildDock()

        // ikon muncul bergantian pelan-pelan setelah panel terbuka
        val tiles = leftTiles + rightTiles + listOf<View>(statView, midCol.getChildAt(1))
        for (t in tiles) { t.alpha = 0f; t.translationY = ctx.px(14).toFloat() }
        root.post {
            tiles.forEachIndexed { i, t ->
                t.animate().alpha(1f).translationY(0f).setStartDelay(300L + i * 70L).setDuration(700).setInterpolator(ease).start()
            }
        }
    }

    // ---------- dock setelan lanjutan (bawah tengah) ----------
    private var dockOpen = false
    private lateinit var dockBody: LinearLayout
    private lateinit var dockTab: TextView

    private fun buildDock() {
        val bodyH = ctx.px(112)
        dockBody = LinearLayout(ctx)
        dockBody.orientation = LinearLayout.VERTICAL
        dockBody.setPadding(ctx.px(14), ctx.px(8), ctx.px(14), ctx.px(8))
        dockBody.background = Hud.rounded(Color.argb(225, 8, 22, 42), Hud.cyan, ctx.pxf(14f), 1.4f)
        dockBody.addView(header("POP UP APK · SETELAN LANJUTAN"), LinearLayout.LayoutParams(-2, -2).also { it.bottomMargin = ctx.px(4) })
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        popCol = LinearLayout(ctx)
        popCol.orientation = LinearLayout.HORIZONTAL
        hs.addView(popCol)
        r.addView(hs, LinearLayout.LayoutParams(0, -1, 1f))
        dockBody.addView(r, LinearLayout.LayoutParams(-1, 0, 1f))
        val bl = FrameLayout.LayoutParams(ctx.px(560), bodyH, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        bl.bottomMargin = ctx.px(36)
        dockBody.visibility = View.INVISIBLE
        dockBody.translationY = (bodyH + ctx.px(10)).toFloat()
        card.addView(dockBody, bl)

        // tab kecil di bawah tengah: ketuk atau geser ke atas untuk membuka
        dockTab = label("▲  SETELAN", 9.5f, Hud.cyan)
        dockTab.letterSpacing = 0.2f
        dockTab.gravity = Gravity.CENTER
        dockTab.background = Hud.rounded(Color.argb(200, 8, 22, 42), Hud.cyanDim, ctx.pxf(11f), 1.2f)
        var y0 = 0f
        dockTab.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { y0 = e.rawY; true }
                MotionEvent.ACTION_UP -> {
                    val d = e.rawY - y0
                    if (d < -ctx.px(10)) setDock(true) else if (d > ctx.px(10)) setDock(false) else setDock(!dockOpen)
                    true
                }
                else -> true
            }
        }
        val tl = FrameLayout.LayoutParams(ctx.px(120), ctx.px(22), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        tl.bottomMargin = ctx.px(8)
        card.addView(dockTab, tl)
    }

    private fun setDock(open: Boolean) {
        if (open == dockOpen) return
        dockOpen = open
        Sfx.play("swipe", 0.8f)
        dockTab.text = if (open) "▼  TUTUP" else "▲  SETELAN"
        val h = dockBody.height.takeIf { it > 0 } ?: ctx.px(112)
        dockBody.animate().cancel()
        if (open) {
            dockBody.visibility = View.VISIBLE
            dockBody.alpha = 0f
            dockBody.animate().translationY(0f).alpha(1f).setDuration(650).setInterpolator(ease).start()
            dockTab.animate().translationY(-ctx.px(0).toFloat()).setDuration(650).start()
        } else {
            dockBody.animate().translationY((h + ctx.px(10)).toFloat()).alpha(0f).setDuration(480)
                .setInterpolator(android.view.animation.PathInterpolator(0.4f, 0f, 0.6f, 1f))
                .withEndAction { if (!dockOpen) dockBody.visibility = View.INVISIBLE }.start()
        }
    }

    // ---------- sheet tuning CPU / GPU / FPS ----------
    private var sheet: TuneSheet? = null

    private fun openSheet(tab: Int) {
        closeAuxNow()
        if (sheet == null) {
            val s = TuneSheet(ctx) { closeSheet() }
            val lp = FrameLayout.LayoutParams(-1, -1)
            lp.leftMargin = ctx.px(26 + 3 * 62 + 8)
            lp.topMargin = ctx.px(44)
            lp.bottomMargin = ctx.px(44)
            lp.rightMargin = tabW + ctx.px(6)
            card.addView(s.root, 2, lp)
            s.root.alpha = 0f
            s.root.animate().alpha(1f).setDuration(160).start()
            sheet = s
        }
        sheet?.select(tab)
    }

    private fun closeSheet() {
        val s = sheet ?: return
        sheet = null
        s.root.animate().alpha(0f).setDuration(140).withEndAction { card.removeView(s.root) }.start()
    }

    // ---------- Pop Up APK ----------
    private var aux: View? = null

    private fun showAux(v: View) {
        closeAuxNow()
        closeSheet()
        val lp = FrameLayout.LayoutParams(-1, -1)
        lp.leftMargin = ctx.px(24 + 104 + 14)
        lp.topMargin = ctx.px(14)
        lp.bottomMargin = ctx.px(14)
        lp.rightMargin = tabW + ctx.px(6)
        card.addView(v, 2, lp)
        v.alpha = 0f
        v.animate().alpha(1f).setDuration(160).start()
        aux = v
    }

    private fun closeAux() {
        val v = aux ?: return
        aux = null
        v.animate().alpha(0f).setDuration(140).withEndAction { card.removeView(v) }.start()
    }

    private fun closeAuxNow() {
        aux?.let { card.removeView(it) }
        aux = null
    }

    private fun openPicker() {
        showAux(AppPickerView(ctx, store, { loadPopups() }, { closeAux() }).root)
    }

    private fun openStop() {
        showAux(StopSheet(ctx, store.game) { closeAux() }.root)
    }

    private fun openNet() {
        showAux(NetSheet(ctx, { openStop() }) { closeAux() }.root)
    }

    private fun openTouch() {
        showAux(TouchSheet(ctx) { closeAux() }.root)
    }

    private fun loadPopups() {
        popCol.removeAllViews()
        val pm = ctx.packageManager
        val add = LinearLayout(ctx)
        add.orientation = LinearLayout.VERTICAL
        add.gravity = Gravity.CENTER_HORIZONTAL
        add.setPadding(ctx.px(4), ctx.px(8), ctx.px(4), ctx.px(6))
        add.background = Hud.rounded(Color.argb(60, 60, 200, 255), Hud.cyan, ctx.pxf(10f), 1f)
        add.addView(label("＋", 20f, Hud.cyan))
        val at = label("Tambah APK", 9f)
        at.gravity = Gravity.CENTER
        add.addView(at)
        add.setOnClickListener { Sfx.tap(); openPicker() }
        popCol.addView(add, LinearLayout.LayoutParams(ctx.px(70), -2).also { it.rightMargin = ctx.px(8) })

        val list = Popup.list(store)
        if (list.isEmpty()) {
            val hint = label("Belum ada. Ketuk ＋ untuk menambah.", 9f, Hud.sub, false)
            popCol.addView(hint)
            return
        }
        for (pkg in list) {
            val icon = try { pm.getApplicationIcon(pkg) } catch (e: Exception) { continue }
            val name = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
            popCol.addView(popItem(pkg, name, icon), LinearLayout.LayoutParams(ctx.px(70), -2).also { it.rightMargin = ctx.px(8) })
        }
    }

    private fun popItem(pkg: String, name: String, icon: android.graphics.drawable.Drawable): View {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.setPadding(ctx.px(4), ctx.px(8), ctx.px(4), ctx.px(6))
        c.background = Hud.rounded(Color.argb(50, 15, 40, 70), Hud.cyanDim, ctx.pxf(10f), 1f)
        val iv = ImageView(ctx)
        iv.setImageDrawable(icon)
        c.addView(iv, LinearLayout.LayoutParams(ctx.px(40), ctx.px(40)))
        val t = label(name, 9f)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        c.addView(t, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(4) })
        c.setOnClickListener {
            if (Popup.launch(ctx, pkg)) GameOverlay.closePanel()
            else toast("Aplikasi tidak bisa dibuka")
        }
        c.setOnLongClickListener {
            Popup.toggle(store, pkg)
            loadPopups()
            toast("$name dihapus dari Pop Up")
            true
        }
        return c
    }

    // ---------- drawer kanan (geser ke kiri) ----------
    private fun buildDrawer() {
        drawer = LinearLayout(ctx)
        drawer.orientation = LinearLayout.HORIZONTAL
        tab = TabView(ctx)
        drawer.addView(tab, LinearLayout.LayoutParams(tabW, -1))

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.px(12), ctx.px(10), ctx.px(12), ctx.px(10))
        sv.addView(box)
        drawer.addView(sv, LinearLayout.LayoutParams(drawerW, -1))
        drawerBody = sv
        sv.visibility = View.INVISIBLE   // menu ke-2 baru muncul setelah tab digeser / diketuk

        box.addView(header("PENGATURAN PANEL"), LinearLayout.LayoutParams(-2, -2).also { it.bottomMargin = ctx.px(4) })

        // Crosshair
        val pCross = Pill(ctx)
        pCross.setOn(store.crossOn)
        pCross.onToggle = { v -> store.crossOn = v; GameOverlay.applyCrosshair() }
        val style = TextView(ctx)
        style.text = "◎"
        style.textSize = 15f
        style.setTextColor(Hud.cyan)
        style.setPadding(ctx.px(8), ctx.px(2), ctx.px(8), ctx.px(2))
        style.setOnClickListener {
            store.crossStyle = (store.crossStyle + 1) % 4
            GameOverlay.applyCrosshair()
        }
        box.addView(row("✛", "Crosshair", style, pCross))

        // Mixer suara (root / Shizuku)
        for ((g, n, st) in listOf(Triple("🔔", "Dering", 2), Triple("📣", "Notifikasi", 5), Triple("📞", "Panggilan", 0))) {
            val mx = am.getStreamMaxVolume(st)
            val cv = am.getStreamVolume(st)
            box.addView(sliderRow(g, n, mx, cv) { v, fin ->
                if (fin && Access.requires(ctx, "Mixer suara", false)) bg { Root.run("cmd media_session volume --stream $st --set $v") }
            })
        }

        // Jangan ganggu
        pDnd = Pill(ctx)
        pDnd.onToggle = { v ->
            if (!Access.requires(ctx, "Jangan Ganggu", false)) pDnd.setOn(!v)
            else bg {
                if (v) Root.run("cmd notification set_dnd priority || settings put global zen_mode 1")
                else Root.run("cmd notification set_dnd off || settings put global zen_mode 0")
            }
        }
        box.addView(row("🔕", "Jangan Ganggu", pDnd))

        // WiFi
        pWifi = Pill(ctx)
        pWifi.onToggle = { v -> if (!Access.requires(ctx, "WiFi", false)) pWifi.setOn(!v) else bg { Root.run("svc wifi ${if (v) "enable" else "disable"}") } }
        box.addView(row("📶", "WiFi", pWifi))

        // Data
        pData = Pill(ctx)
        pData.onToggle = { v -> if (!Access.requires(ctx, "Data", false)) pData.setOn(!v) else bg { Root.run("svc data ${if (v) "enable" else "disable"}") } }
        box.addView(row("📡", "Data", pData))

        // Suara panel (klik / geser / buka)
        val pSfx = Pill(ctx)
        pSfx.setOn(Sfx.enabled)
        pSfx.onToggle = { v -> Sfx.enabled = v }
        box.addView(row("🔈", "Suara panel", pSfx))

        // Monitor
        val pMon = Pill(ctx)
        pMon.setOn(store.monitorOn)
        pMon.onToggle = { v -> store.monitorOn = v; GameOverlay.applyMonitor() }
        box.addView(row("📊", "Monitor", pMon))

        val dp = FrameLayout.LayoutParams(tabW + drawerW, cardH - ctx.px(68), Gravity.END or Gravity.CENTER_VERTICAL)
        card.addView(drawer, dp)
        drawer.translationX = drawerW.toFloat()

        // geser tab ke kiri untuk buka, ke kanan untuk tutup (tap juga bisa)
        var d0 = 0f
        var t0 = 0f
        var moved = false
        tab.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { d0 = e.rawX; t0 = drawer.translationX; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val d = e.rawX - d0
                    if (abs(d) > ctx.pxf(6f)) moved = true
                    drawer.translationX = (t0 + d).coerceIn(0f, drawerW.toFloat())
                    if (moved) {
                        drawerBody.visibility = View.VISIBLE
                        drawerBody.alpha = (1f - drawer.translationX / drawerW).coerceIn(0f, 1f)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val half = drawerW / 2f
                    val open = if (moved) drawer.translationX < half else drawer.translationX > half
                    setDrawer(open)
                    true
                }
                else -> true
            }
        }
    }

    private fun setDrawer(open: Boolean) {
        tab.open = open
        Sfx.play("swipe", 0.8f)
        if (open) drawerBody.visibility = View.VISIBLE
        drawerBody.animate().alpha(if (open) 1f else 0f).setDuration(200).start()
        drawer.animate().translationX(if (open) 0f else drawerW.toFloat()).setDuration(200)
            .withEndAction { if (!tab.open) drawerBody.visibility = View.INVISIBLE }.start()
    }

    private fun row(glyph: String, name: String, vararg right: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, ctx.px(7), 0, ctx.px(7))
        val g = label(glyph, 16f, Hud.cyan)
        g.gravity = Gravity.CENTER
        r.addView(g, LinearLayout.LayoutParams(ctx.px(26), -2))
        val n = label(name, 12f)
        n.maxLines = 1
        r.addView(n, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = ctx.px(6) })
        for (v in right) r.addView(v, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = ctx.px(6) })
        return r
    }

    // slider kecil bergaya panel baru: label neon di atas, bar hijau di bawah
    private fun miniSlider(glyph: String, name: String, max: Int, cur: Int, onChange: (Int, Boolean) -> Unit): LinearLayout {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        val nm = label("$glyph  $name", 10f, Hud.neon)
        nm.letterSpacing = 0.2f
        val pct = label("${100 * cur / max.coerceAtLeast(1)}%", 10f, Color.WHITE)
        head.addView(nm, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(pct)
        box.addView(head, LinearLayout.LayoutParams(-1, -2))
        val sb = SeekBar(ctx)
        sb.max = max
        sb.progress = cur
        val tint = ColorStateList.valueOf(Hud.neon)
        sb.progressTintList = tint
        sb.thumbTintList = tint
        sb.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(80, 46, 245, 160))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                pct.text = "${100 * p / max.coerceAtLeast(1)}%"
                if (fromUser) onChange(p, false)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { onChange(s.progress, true) }
        })
        box.addView(sb, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    private fun sliderRow(glyph: String, name: String, max: Int, cur: Int, onChange: (Int, Boolean) -> Unit): LinearLayout {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val pct = label("${100 * cur / max.coerceAtLeast(1)}%", 11f, Hud.sub)
        box.addView(row(glyph, name, pct))
        val sb = SeekBar(ctx)
        sb.max = max
        sb.progress = cur
        val tint = ColorStateList.valueOf(Hud.cyan)
        sb.progressTintList = tint
        sb.thumbTintList = tint
        sb.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(80, 120, 200, 255))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                pct.text = "${100 * p / max.coerceAtLeast(1)}%"
                if (fromUser) onChange(p, false)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { onChange(s.progress, true) }
        })
        box.addView(sb, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = ctx.px(2) })
        return box
    }

    // baca status WiFi / Data / Jangan Ganggu saat panel dibuka
    private fun loadToggles() {
        bg {
            val wifi = try {
                (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
            } catch (e: Exception) { false }
            val o = Root.run("echo D=\$(settings get global mobile_data); echo Z=\$(settings get global zen_mode)")
            val data = Regex("D=(\\d+)").find(o)?.groupValues?.get(1) == "1"
            val zen = (Regex("Z=(\\d+)").find(o)?.groupValues?.get(1) ?: "0") != "0"
            ui {
                pWifi.setOn(wifi)
                pData.setOn(data)
                pDnd.setOn(zen)
            }
        }
    }
}
