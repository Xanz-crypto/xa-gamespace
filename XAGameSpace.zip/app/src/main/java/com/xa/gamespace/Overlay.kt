package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min

// =====================================================================
//  Game Panel overlay
//  Alur: masuk game -> animasi "X" -> X berjalan ke sisi kiri jadi garis
//        -> geser garis ke kanan -> Game Panel terbuka
// =====================================================================
object GameOverlay {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var app: Context
    private lateinit var ui: Context
    private lateinit var wm: WindowManager

    private var shown = false
    private var entry: EntryAnimView? = null
    private var handle: HandleView? = null
    private var panel: PanelUi? = null
    private var panelAnim: ValueAnimator? = null
    private var crosshair: CrosshairView? = null
    private var monitor: TextView? = null

    @Volatile private var samplerOn = false
    private var sampler: Thread? = null

    fun canDraw(c: Context): Boolean =
        Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c.applicationContext)

    // ---------- show / hide ----------
    fun show(c: Context) {
        h.post {
            if (shown) return@post
            val a = c.applicationContext
            if (!canDraw(a)) return@post
            app = a
            ui = ContextThemeWrapper(a, android.R.style.Theme_Material)
            wm = a.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            shown = true

            val ev = EntryAnimView(ui, ui.pxf(Hud.HANDLE_X.toFloat()), ui.pxf(Hud.HANDLE_HALF.toFloat()))
            entry = ev
            wm.addView(ev, lp(-1, -1, Gravity.START or Gravity.TOP, false))
            ev.start {
                h.post {
                    if (!shown || entry !== ev) return@post
                    entry = null
                    removeSafe(ev)
                    addHandle()
                }
            }
            applyCrosshair()
            applyMonitor()
        }
    }

    fun hide() {
        h.post {
            if (!shown) return@post
            shown = false
            samplerOn = false
            panelAnim?.cancel()
            entry?.let { val e = it; entry = null; e.cancel(); removeSafe(e) }
            handle?.let { removeSafe(it) }
            panel?.let { removeSafe(it.root) }
            crosshair?.let { removeSafe(it) }
            monitor?.let { removeSafe(it) }
            handle = null; panel = null; crosshair = null; monitor = null
        }
    }

    private fun removeSafe(v: View) {
        try { wm.removeView(v) } catch (e: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun lp(w: Int, hh: Int, gravity: Int, touchable: Boolean): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        f = if (touchable) f or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        else f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val p = WindowManager.LayoutParams(w, hh, type, f, PixelFormat.TRANSLUCENT)
        p.gravity = gravity
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return p
    }

    // ---------- handle (garis) ----------
    private fun addHandle() {
        val hv = HandleView(ui)
        hv.alpha = 0f
        handle = hv
        wm.addView(hv, lp(ui.px(Hud.HANDLE_W), ui.px(Hud.HANDLE_H), Gravity.START or Gravity.CENTER_VERTICAL, true))
        hv.animate().alpha(1f).setDuration(180).start()

        var x0 = 0f
        var dragging = false
        var p = 0f
        val dist = ui.pxf(200f)
        hv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { x0 = e.rawX; dragging = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - x0
                    if (!dragging && dx > ui.pxf(10f)) { dragging = true; beginPanel() }
                    if (dragging) {
                        p = (dx / dist).coerceIn(0f, 1f)
                        panel?.setProgress(p)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) animatePanel(if (p > 0.35f) 1f else 0f)
                    else if (e.actionMasked == MotionEvent.ACTION_UP && abs(e.rawX - x0) < ui.pxf(8f)) openPanel()
                    dragging = false
                    true
                }
                else -> true
            }
        }
    }

    // ---------- panel ----------
    private fun beginPanel() {
        if (!shown || panel != null) return
        panelAnim?.cancel()
        val pn = PanelUi(ui)
        pn.setProgress(0f)
        panel = pn
        wm.addView(pn.root, lp(-1, -1, Gravity.START or Gravity.TOP, true))
        ensureSampler()
    }

    fun openPanel() {
        h.post {
            if (!shown) return@post
            beginPanel()
            animatePanel(1f)
        }
    }

    fun closePanel() {
        h.post { animatePanel(0f) }
    }

    private fun animatePanel(to: Float) {
        val pn = panel ?: return
        panelAnim?.cancel()
        val a = ValueAnimator.ofFloat(pn.progress, to)
        a.duration = 260
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { pn.setProgress(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) { cancelled = true }
            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled && to == 0f && panel === pn) {
                    removeSafe(pn.root)
                    panel = null
                }
            }
        })
        panelAnim = a
        a.start()
    }

    fun launch(pkg: String) {
        closePanel()
        if (pkg == Store(app).game) return
        val li = app.packageManager.getLaunchIntentForPackage(pkg) ?: return
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { app.startActivity(li) } catch (e: Exception) { return }
        GameService.start(app, pkg)
    }

    // ---------- crosshair ----------
    fun applyCrosshair() {
        h.post {
            if (!shown) return@post
            val st = Store(app)
            val cur = crosshair
            if (st.crossOn && cur == null) {
                val v = CrosshairView(ui, st.crossStyle)
                crosshair = v
                wm.addView(v, lp(ui.px(80), ui.px(80), Gravity.CENTER, false))
            } else if (!st.crossOn && cur != null) {
                removeSafe(cur)
                crosshair = null
            } else if (cur != null) {
                cur.kind = st.crossStyle
                cur.invalidate()
            }
        }
    }

    // ---------- monitor ----------
    fun applyMonitor() {
        h.post {
            if (!shown) return@post
            val on = Store(app).monitorOn
            val cur = monitor
            if (on && cur == null) {
                val t = TextView(ui)
                t.textSize = 10f
                t.typeface = Typeface.DEFAULT_BOLD
                t.setTextColor(Hud.cyan)
                t.text = "…"
                t.setPadding(ui.px(8), ui.px(3), ui.px(8), ui.px(3))
                t.background = Hud.rounded(Color.argb(140, 4, 12, 22), Hud.cyanDim, ui.pxf(8f), 1f)
                monitor = t
                val p = lp(-2, -2, Gravity.START or Gravity.TOP, false)
                p.x = ui.px(48); p.y = ui.px(6)
                wm.addView(t, p)
                ensureSampler()
            } else if (!on && cur != null) {
                removeSafe(cur)
                monitor = null
            }
        }
    }

    // ---------- sampler status sistem ----------
    private fun ensureSampler() {
        samplerOn = true
        if (sampler != null) return
        val t = Thread {
            while (samplerOn && shown && (panel != null || monitor != null)) {
                val s = SysStats.sample(app)
                h.post {
                    panel?.onStats(s)
                    monitor?.text = "RAM ${s.ramPct}%  CPU ${s.cpuPct}%  ${s.hz}Hz  ${s.tempC.toInt()}°C"
                }
                try { Thread.sleep(2000) } catch (e: InterruptedException) { break }
            }
            sampler = null
        }
        sampler = t
        t.start()
    }
}

// =====================================================================
//  Isi Game Panel
//  Kiri   : daftar game (geser atas-bawah)
//  Tengah : jam, status, menu pengaturan performa (bawah)
//  Kanan  : drawer (geser ke kiri) pengaturan panel
// =====================================================================
class PanelUi(private val ctx: Context) {
    private val store = Store(ctx)
    val root = FrameLayout(ctx)
    private val dim = View(ctx)
    private val card = HudFrame(ctx)
    var progress = 0f
        private set

    private val cardW: Int
    private val cardH: Int
    private val sideMargin: Int
    private val drawerW = ctx.px(220)
    private val tabW = ctx.px(28)

    private lateinit var drawer: LinearLayout
    private lateinit var tab: TabView
    private lateinit var gauge: GaugeView
    private lateinit var ramBar: StatBar
    private lateinit var cpuBar: StatBar
    private lateinit var tmpBar: StatBar
    private lateinit var gamesCol: LinearLayout

    private lateinit var pWifi: Pill
    private lateinit var pData: Pill
    private lateinit var pDnd: Pill

    private var lastB = 0L

    init {
        val dm = ctx.resources.displayMetrics
        cardW = min((dm.widthPixels * 0.92f).toInt(), ctx.px(800))
        cardH = min((dm.heightPixels * 0.88f).toInt(), ctx.px(360))
        sideMargin = (dm.widthPixels - cardW) / 2

        dim.setBackgroundColor(Color.argb(165, 0, 0, 0))
        dim.alpha = 0f
        dim.setOnClickListener { GameOverlay.closePanel() }
        root.addView(dim, FrameLayout.LayoutParams(-1, -1))

        val cp = FrameLayout.LayoutParams(cardW, cardH, Gravity.START or Gravity.CENTER_VERTICAL)
        cp.leftMargin = sideMargin
        root.addView(card, cp)

        buildMain()
        buildDrawer()

        val x = TextView(ctx)
        x.text = "✕"
        x.textSize = 16f
        x.setTextColor(Color.WHITE)
        x.gravity = Gravity.CENTER
        x.setOnClickListener { GameOverlay.closePanel() }
        val xp = FrameLayout.LayoutParams(ctx.px(40), ctx.px(32), Gravity.TOP or Gravity.END)
        xp.topMargin = ctx.px(6); xp.rightMargin = ctx.px(30)
        card.addView(x, xp)

        loadGames()
        loadToggles()
    }

    fun setProgress(p: Float) {
        progress = p
        dim.alpha = p
        card.alpha = (p * 1.6f).coerceAtMost(1f)
        card.translationX = -(cardW + sideMargin) * (1f - p)
    }

    fun onStats(s: SysStats.Sample) {
        gauge.set(s.hz.toFloat(), 120f)
        ramBar.set(s.ramPct.toFloat())
        cpuBar.set(s.cpuPct.toFloat())
        tmpBar.set(s.tempC)
    }

    // ---------- helper ----------
    private fun bg(b: () -> Unit) { Thread { b() }.start() }
    private fun ui(b: () -> Unit) { root.post { b() } }
    private fun toast(s: String) { ui { Toast.makeText(ctx.applicationContext, s, Toast.LENGTH_SHORT).show() } }

    private fun label(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = true): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun header(t: String): TextView {
        val v = label(t, 10f, Hud.cyan)
        v.letterSpacing = 0.25f
        return v
    }

    // ---------- bagian utama ----------
    private fun buildMain() {
        val main = LinearLayout(ctx)
        main.orientation = LinearLayout.HORIZONTAL
        main.setPadding(ctx.px(24), ctx.px(18), tabW + ctx.px(6), ctx.px(14))
        card.addView(main, FrameLayout.LayoutParams(-1, -1))

        // ----- kiri: daftar game -----
        val left = LinearLayout(ctx)
        left.orientation = LinearLayout.VERTICAL
        left.addView(header("GAME"), LinearLayout.LayoutParams(-2, -2).also { it.bottomMargin = ctx.px(6) })
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        gamesCol = LinearLayout(ctx)
        gamesCol.orientation = LinearLayout.VERTICAL
        sv.addView(gamesCol)
        left.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(left, LinearLayout.LayoutParams(ctx.px(104), -1).also { it.rightMargin = ctx.px(14) })

        // ----- tengah -----
        val cs = ScrollView(ctx)
        cs.isVerticalScrollBarEnabled = false
        cs.isFillViewport = true
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        cs.addView(col, FrameLayout.LayoutParams(-1, -2))
        main.addView(cs, LinearLayout.LayoutParams(0, -1, 1f))

        val clk = TextClock(ctx)
        clk.format12Hour = "hh:mm a"
        clk.format24Hour = "hh:mm a"
        clk.textSize = 15f
        clk.typeface = Typeface.DEFAULT_BOLD
        clk.letterSpacing = 0.15f
        clk.setTextColor(Color.WHITE)
        col.addView(clk, LinearLayout.LayoutParams(-2, -2).also { it.bottomMargin = ctx.px(4) })

        val mid = LinearLayout(ctx)
        mid.orientation = LinearLayout.HORIZONTAL
        mid.gravity = Gravity.CENTER_VERTICAL
        gauge = GaugeView(ctx, "LAYAR Hz")
        mid.addView(gauge)
        val stats = LinearLayout(ctx)
        stats.orientation = LinearLayout.VERTICAL
        ramBar = StatBar(ctx, "RAM")
        cpuBar = StatBar(ctx, "CPU")
        tmpBar = StatBar(ctx, "SUHU", "°", 60f)
        stats.addView(ramBar); stats.addView(cpuBar); stats.addView(tmpBar)
        mid.addView(stats, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = ctx.px(16) })
        col.addView(mid)

        col.addView(View(ctx), LinearLayout.LayoutParams(1, 0, 1f))

        // ----- bawah tengah: menu performa -----
        col.addView(header("PERFORMA"), LinearLayout.LayoutParams(-2, -2).also { it.bottomMargin = ctx.px(4) })
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        hs.isFillViewport = true
        val perf = LinearLayout(ctx)
        perf.orientation = LinearLayout.HORIZONTAL
        perf.gravity = Gravity.CENTER
        hs.addView(perf, FrameLayout.LayoutParams(-1, -2))

        val tStabil = HexTile(ctx, "🎯", "Stabil FPS", true)
        tStabil.on = store.stabil
        tStabil.setOnClickListener {
            store.stabil = !store.stabil
            tStabil.on = store.stabil
            bg { Boost.refresh(ctx) }
        }
        val tSmooth = HexTile(ctx, "🌊", "Smooth FPS", true)
        tSmooth.on = store.smooth
        tSmooth.setOnClickListener {
            store.smooth = !store.smooth
            tSmooth.on = store.smooth
            bg { Boost.refresh(ctx) }
        }
        val tRam = HexTile(ctx, "🧹", "Clean RAM")
        tRam.setOnClickListener {
            toast("Membersihkan RAM...")
            bg {
                val freed = Boost.cleanRam(ctx, store.game)
                toast("RAM dibebaskan $freed MB")
            }
        }
        val tKill = HexTile(ctx, "⛔", "Stop App")
        tKill.setOnClickListener {
            toast("Menghentikan app latar belakang...")
            bg {
                val n = Boost.killBackground(ctx, store.game)
                toast("$n aplikasi dihentikan")
            }
        }
        val tAuto = HexTile(ctx, "🤖", "Auto Game", true)
        tAuto.on = store.auto
        tAuto.setOnClickListener {
            store.auto = !store.auto
            tAuto.on = store.auto
            if (store.auto) GameService.start(ctx)
        }
        for (t in listOf(tStabil, tSmooth, tRam, tKill, tAuto)) {
            perf.addView(t, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = ctx.px(2); it.rightMargin = ctx.px(2) })
        }
        col.addView(hs, LinearLayout.LayoutParams(-1, -2))
    }

    // ---------- daftar game ----------
    private fun loadGames() {
        bg {
            val list = Games.detect(ctx)
            val cur = store.game
            val sorted = list.sortedByDescending { it.pkg == cur }
            ui {
                gamesCol.removeAllViews()
                if (sorted.isEmpty()) {
                    gamesCol.addView(label("Belum ada game", 11f, Hud.sub, false))
                }
                sorted.forEach { gamesCol.addView(gameItem(it, it.pkg == cur), LinearLayout.LayoutParams(-1, -2).also { p -> p.bottomMargin = ctx.px(8) }) }
            }
        }
    }

    private fun gameItem(g: GameApp, current: Boolean): View {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.setPadding(ctx.px(4), ctx.px(8), ctx.px(4), ctx.px(6))
        c.background = Hud.rounded(
            if (current) Color.argb(90, 60, 200, 255) else Color.argb(50, 15, 40, 70),
            if (current) Hud.cyan else Hud.cyanDim, ctx.pxf(10f), 1f)
        val iv = ImageView(ctx)
        iv.setImageDrawable(g.icon)
        c.addView(iv, LinearLayout.LayoutParams(ctx.px(40), ctx.px(40)))
        val t = label(g.label, 9f)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        c.addView(t, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(4) })
        c.setOnClickListener { GameOverlay.launch(g.pkg) }
        return c
    }

    // ---------- drawer kanan (geser ke kiri) ----------
    private fun buildDrawer() {
        drawer = LinearLayout(ctx)
        drawer.orientation = LinearLayout.HORIZONTAL
        tab = TabView(ctx)
        drawer.addView(tab, LinearLayout.LayoutParams(tabW, -1))

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.px(12), ctx.px(10), ctx.px(12), ctx.px(10))
        sv.addView(box)
        drawer.addView(sv, LinearLayout.LayoutParams(drawerW, -1))

        box.addView(header("PENGATURAN PANEL"), LinearLayout.LayoutParams(-2, -2).also { it.bottomMargin = ctx.px(4) })

        // Crosshair
        val pCross = Pill(ctx)
        pCross.setOn(store.crossOn)
        pCross.onToggle = { v -> store.crossOn = v; GameOverlay.applyCrosshair() }
        val style = TextView(ctx)
        style.text = "◎"
        style.textSize = 15f
        style.setTextColor(Hud.cyan)
        style.setPadding(ctx.px(8), ctx.px(2), ctx.px(8), ctx.px(2))
        style.setOnClickListener {
            store.crossStyle = (store.crossStyle + 1) % 4
            GameOverlay.applyCrosshair()
        }
        box.addView(row("✛", "Crosshair", style, pCross))

        // Cahaya
        val curB = try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (e: Exception) { 128 }
        box.addView(sliderRow("☀", "Cahaya", 255, curB) { v, fin ->
            val now = System.currentTimeMillis()
            if (fin || now - lastB > 250) {
                lastB = now
                bg { Root.run("settings put system screen_brightness_mode 0; settings put system screen_brightness ${v.coerceAtLeast(1)}") }
            }
        })

        // Speaker
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val maxV = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
        val curV = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
        box.addView(sliderRow("🔊", "Speaker", maxV, curV) { v, _ ->
            try { am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, v, 0) } catch (e: Exception) {}
        })

        // Jangan ganggu
        pDnd = Pill(ctx)
        pDnd.onToggle = { v ->
            bg {
                if (v) Root.run("cmd notification set_dnd priority || settings put global zen_mode 1")
                else Root.run("cmd notification set_dnd off || settings put global zen_mode 0")
            }
        }
        box.addView(row("🔕", "Jangan Ganggu", pDnd))

        // WiFi
        pWifi = Pill(ctx)
        pWifi.onToggle = { v -> bg { Root.run("svc wifi ${if (v) "enable" else "disable"}") } }
        box.addView(row("📶", "WiFi", pWifi))

        // Data
        pData = Pill(ctx)
        pData.onToggle = { v -> bg { Root.run("svc data ${if (v) "enable" else "disable"}") } }
        box.addView(row("📡", "Data", pData))

        // Monitor
        val pMon = Pill(ctx)
        pMon.setOn(store.monitorOn)
        pMon.onToggle = { v -> store.monitorOn = v; GameOverlay.applyMonitor() }
        box.addView(row("📊", "Monitor", pMon))

        val dp = FrameLayout.LayoutParams(tabW + drawerW, cardH - ctx.px(68), Gravity.END or Gravity.CENTER_VERTICAL)
        card.addView(drawer, dp)
        drawer.translationX = drawerW.toFloat()

        // geser tab ke kiri untuk buka, ke kanan untuk tutup (tap juga bisa)
        var d0 = 0f
        var t0 = 0f
        var moved = false
        tab.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { d0 = e.rawX; t0 = drawer.translationX; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val d = e.rawX - d0
                    if (abs(d) > ctx.pxf(6f)) moved = true
                    drawer.translationX = (t0 + d).coerceIn(0f, drawerW.toFloat())
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val half = drawerW / 2f
                    val open = if (moved) drawer.translationX < half else drawer.translationX > half
                    setDrawer(open)
                    true
                }
                else -> true
            }
        }
    }

    private fun setDrawer(open: Boolean) {
        tab.open = open
        drawer.animate().translationX(if (open) 0f else drawerW.toFloat()).setDuration(200).start()
    }

    private fun row(glyph: String, name: String, vararg right: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, ctx.px(7), 0, ctx.px(7))
        val g = label(glyph, 16f, Hud.cyan)
        g.gravity = Gravity.CENTER
        r.addView(g, LinearLayout.LayoutParams(ctx.px(26), -2))
        val n = label(name, 12f)
        n.maxLines = 1
        r.addView(n, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = ctx.px(6) })
        for (v in right) r.addView(v, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = ctx.px(6) })
        return r
    }

    private fun sliderRow(glyph: String, name: String, max: Int, cur: Int, onChange: (Int, Boolean) -> Unit): LinearLayout {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val pct = label("${100 * cur / max.coerceAtLeast(1)}%", 11f, Hud.sub)
        box.addView(row(glyph, name, pct))
        val sb = SeekBar(ctx)
        sb.max = max
        sb.progress = cur
        val tint = ColorStateList.valueOf(Hud.cyan)
        sb.progressTintList = tint
        sb.thumbTintList = tint
        sb.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(80, 120, 200, 255))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                pct.text = "${100 * p / max.coerceAtLeast(1)}%"
                if (fromUser) onChange(p, false)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { onChange(s.progress, true) }
        })
        box.addView(sb, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = ctx.px(2) })
        return box
    }

    // baca status WiFi / Data / Jangan Ganggu saat panel dibuka
    private fun loadToggles() {
        bg {
            val wifi = try {
                (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
            } catch (e: Exception) { false }
            val o = Root.run("echo D=\$(settings get global mobile_data); echo Z=\$(settings get global zen_mode)")
            val data = Regex("D=(\\d+)").find(o)?.groupValues?.get(1) == "1"
            val zen = (Regex("Z=(\\d+)").find(o)?.groupValues?.get(1) ?: "0") != "0"
            ui {
                pWifi.setOn(wifi)
                pData.setOn(data)
                pDnd.setOn(zen)
            }
        }
    }
}
