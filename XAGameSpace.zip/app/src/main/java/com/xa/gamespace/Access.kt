package com.xa.gamespace

import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import rikka.shizuku.Shizuku

// Lapisan akses: ROOT (su) atau SHIZUKU (shell uid 2000). Root diprioritaskan.
object Access {
    enum class Mode { NONE, ROOT, SHIZUKU }

    @Volatile private var rootOk: Boolean? = null
    private val ui = Handler(Looper.getMainLooper())

    val isRoot: Boolean get() = rootOk == true

    private fun su(cmd: String): String = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (e: Exception) {
        ""
    }

    fun checkRoot(): Boolean {
        val r = su("id").contains("uid=0")
        rootOk = r
        return r
    }

    // panggil dari thread latar
    fun ensure() { if (rootOk == null) checkRoot() }

    fun shizukuRunning(): Boolean = try { Shizuku.pingBinder() } catch (t: Throwable) { false }

    fun shizukuGranted(): Boolean = try {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) { false }

    fun requestShizuku(code: Int) {
        try {
            if (Shizuku.pingBinder() && !Shizuku.isPreV11()) Shizuku.requestPermission(code)
        } catch (t: Throwable) {}
    }

    val mode: Mode
        get() = when {
            isRoot -> Mode.ROOT
            shizukuGranted() -> Mode.SHIZUKU
            else -> Mode.NONE
        }

    fun hasAny(): Boolean = mode != Mode.NONE

    fun label(): String = when (mode) {
        Mode.ROOT -> "ROOT"
        Mode.SHIZUKU -> "SHIZUKU (fitur khusus root nonaktif)"
        Mode.NONE -> "tanpa akses root/Shizuku"
    }

    fun run(cmd: String): String {
        if (rootOk == null) checkRoot()
        return when {
            rootOk == true -> su(cmd)
            shizukuGranted() -> shizuku(cmd)
            else -> ""
        }
    }

    // Shizuku.newProcess bersifat private sejak API 13.1 -> dipanggil lewat refleksi
    private fun shizuku(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (t: Throwable) {
        ""
    }

    fun tagFor(rootOnly: Boolean): String = if (rootOnly) "ROOT" else "ROOT/SHIZUKU"

    fun satisfied(rootOnly: Boolean): Boolean = if (rootOnly) isRoot else hasAny()

    // Cek akses sebuah fitur. Bila belum cukup -> tampil notif dan kembalikan false.
    fun requires(ctx: Context, name: String, rootOnly: Boolean): Boolean {
        if (satisfied(rootOnly)) return true
        val msg = if (rootOnly) {
            if (mode == Mode.SHIZUKU) "$name khusus ROOT. Shizuku tidak punya izin untuk fitur ini."
            else "$name khusus ROOT. Root belum aktif."
        } else "$name butuh ROOT atau Shizuku. Aktifkan lewat chip akses di atas."
        val app = ctx.applicationContext
        ui.post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() }
        return false
    }
}
