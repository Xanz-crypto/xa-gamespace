package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// Animasi loading menu awal: huruf X digambar, disambar petir, lalu progress bar
class SplashView(ctx: Context, private val onDone: () -> Unit) : View(ctx) {
    private val total = 2900L
    private var t = 0f
    private var finished = false
    private var anim: ValueAnimator? = null

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillP = Paint()
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        color = Color.WHITE
    }
    private val path = Path()

    init {
        isClickable = true
        setOnClickListener { skip() }
    }

    private fun dp(v: Float) = context.pxf(v)

    fun start() {
        Sfx.play("zap")
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = total
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { t = it.animatedValue as Float; invalidate() }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { finish() }
        })
        anim = a
        a.start()
    }

    private fun skip() { anim?.cancel() }

    private fun finish() {
        if (finished) return
        finished = true
        animate().alpha(0f).setDuration(350).withEndAction { onDone() }.start()
    }

    override fun onDetachedFromWindow() {
        anim?.removeAllListeners()
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    private fun bolt(r: Random, x0: Float, y0: Float, x1: Float, y1: Float, off: Float, out: ArrayList<Float>) {
        if (off < dp(5f)) { out.add(x1); out.add(y1); return }
        val mx = (x0 + x1) / 2 + (r.nextFloat() - 0.5f) * off
        val my = (y0 + y1) / 2 + (r.nextFloat() - 0.5f) * off
        bolt(r, x0, y0, mx, my, off / 2, out)
        bolt(r, mx, my, x1, y1, off / 2, out)
    }

    private fun strokeGlow(cv: Canvas, w: Float, core: Int) {
        line.color = Color.argb(45, 47, 140, 255); line.strokeWidth = w * 2.6f; cv.drawPath(path, line)
        line.color = Color.argb(110, 60, 200, 255); line.strokeWidth = w * 1.5f; cv.drawPath(path, line)
        line.color = core; line.strokeWidth = w * 0.55f; cv.drawPath(path, line)
    }

    private fun drawBolt(cv: Canvas, r: Random, x0: Float, y0: Float, x1: Float, y1: Float, wd: Float) {
        val pts = ArrayList<Float>()
        pts.add(x0); pts.add(y0)
        val len = hypot(x1 - x0, y1 - y0)
        bolt(r, x0, y0, x1, y1, len * 0.35f, pts)
        path.reset()
        path.moveTo(pts[0], pts[1])
        var i = 2
        while (i < pts.size - 1) { path.lineTo(pts[i], pts[i + 1]); i += 2 }
        strokeGlow(cv, wd, Color.WHITE)
        // cabang kecil
        if (pts.size > 12) {
            val k = ((pts.size / 4) / 2) * 2
            val bx = pts[k]; val by = pts[k + 1]
            val ang = r.nextFloat() * 2f * PI.toFloat()
            val bl = len * 0.25f
            val bp = ArrayList<Float>()
            bp.add(bx); bp.add(by)
            bolt(r, bx, by, bx + cos(ang) * bl, by + sin(ang) * bl, bl * 0.4f, bp)
            path.reset()
            path.moveTo(bp[0], bp[1])
            var j = 2
            while (j < bp.size - 1) { path.lineTo(bp[j], bp[j + 1]); j += 2 }
            strokeGlow(cv, wd * 0.5f, Color.argb(230, 220, 240, 255))
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        cv.drawColor(Color.parseColor("#03050C"))
        val cx = w / 2f
        val cy = h * 0.44f
        val s = min(w, h) * 0.17f

        // cahaya latar
        val gi = (0.35f + 0.65f * min(1f, t * 3f))
        glow.shader = RadialGradient(cx, cy, max(w, h) * 0.55f,
            intArrayOf(Color.argb((110 * gi).toInt(), 40, 120, 255), Color.argb(0, 10, 20, 60)),
            null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, glow)
        glow.shader = null

        val ms = (t * total).toLong()
        val bucket = (ms / 70L).toInt()
        val strike = t in 0.28f..0.82f

        // petir
        if (strike) {
            val r = Random(bucket * 7919L + 13)
            val big = max(w, h)
            for (i in 0 until 4) {
                if (r.nextInt(5) == 0) continue
                val ang = r.nextFloat() * 2f * PI.toFloat()
                drawBolt(cv, r, cx, cy, cx + cos(ang) * big, cy + sin(ang) * big, dp(6f))
            }
            for (i in 0 until 2) {
                if (r.nextInt(4) == 0) continue
                val sx = r.nextFloat() * w
                val corner = if (r.nextBoolean()) -1f else 1f
                drawBolt(cv, r, sx, 0f, cx + corner * s, cy - s, dp(5f))
            }
            if (bucket % 9 == 0) {
                fillP.color = Color.argb(45, 200, 225, 255)
                cv.drawRect(0f, 0f, w, h, fillP)
            }
        }

        // huruf X
        val p1 = ((t - 0.02f) / 0.2f).coerceIn(0f, 1f)
        val p2 = ((t - 0.2f) / 0.2f).coerceIn(0f, 1f)
        val shake = if (strike) (Random(bucket * 31L).nextFloat() - 0.5f) * dp(3f) else 0f
        val xw = dp(20f)
        if (p1 > 0f) {
            path.reset()
            path.moveTo(cx - s + shake, cy - s)
            path.lineTo(cx - s + shake + 2 * s * p1, cy - s + 2 * s * p1)
            strokeGlow(cv, xw, Color.parseColor("#E8F6FF"))
        }
        if (p2 > 0f) {
            path.reset()
            path.moveTo(cx + s + shake, cy - s)
            path.lineTo(cx + s + shake - 2 * s * p2, cy - s + 2 * s * p2)
            strokeGlow(cv, xw, Color.parseColor("#E8F6FF"))
        }

        // teks
        val ta = ((t - 0.5f) / 0.2f).coerceIn(0f, 1f)
        if (ta > 0f) {
            txt.textSize = dp(20f)
            txt.letterSpacing = 0.35f
            txt.color = Color.argb((255 * ta).toInt(), 255, 255, 255)
            cv.drawText("XA  GAME  SPACE", cx, cy + s + dp(52f), txt)
        }

        // progress
        val bw = w * 0.36f
        val by = h * 0.88f
        txt.textSize = dp(11f)
        txt.letterSpacing = 0.2f
        txt.color = Color.argb(200, 159, 184, 208)
        cv.drawText("MEMUAT  ${(t * 100).toInt()}%", cx, by - dp(10f), txt)
        fillP.color = Color.argb(70, 60, 200, 255)
        cv.drawRoundRect(cx - bw / 2, by, cx + bw / 2, by + dp(4f), dp(2f), dp(2f), fillP)
        fillP.color = Color.parseColor("#3CC8FF")
        cv.drawRoundRect(cx - bw / 2, by, cx - bw / 2 + bw * t, by + dp(4f), dp(2f), dp(2f), fillP)
    }
}
