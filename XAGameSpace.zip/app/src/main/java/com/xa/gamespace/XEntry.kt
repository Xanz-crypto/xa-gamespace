package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

// ============ Animasi masuk game ============
// Huruf X digambar goresan demi goresan di tengah layar, berkilat, lalu kedua goresannya menutup
// seperti gunting, berjalan ke tepi layar dan berubah menjadi GARIS (handle panel).
// (lineX, lineY) = titik tengah garis akhir (px), lineHalf = setengah panjang garis akhir (px).
class XEntryView(
    c: Context,
    private val lineX: Float,
    private val lineY: Float,
    private val lineHalf: Float
) : View(c) {
    private val total = 2700L
    private var t = 0f
    private var anim: ValueAnimator? = null
    private var sOpen = false
    private var sMove = false

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dimP = Paint()
    private val flashP = Paint(Paint.ANTI_ALIAS_FLAG)
    private var flashShader: RadialGradient? = null

    private fun dp(v: Float) = context.pxf(v)

    fun start(onEnd: () -> Unit) {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = total
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            t = it.animatedValue as Float
            if (!sOpen && t > 0.30f) { sOpen = true; Sfx.play("open", 0.8f) }
            if (!sMove && t > 0.62f) { sMove = true; Sfx.play("swipe", 0.8f) }
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onEnd() }
        })
        anim = a
        a.start()
    }

    fun cancel() { anim?.cancel() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        flashShader = RadialGradient(0f, 0f, 1f,
            intArrayOf(Color.argb(200, 255, 255, 255), Color.argb(80, 120, 220, 255), Color.argb(0, 60, 200, 255)),
            floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
        flashP.shader = flashShader
    }

    // satu goresan bercahaya dari (x0,y0) ke (x1,y1), sebagian sepanjang 'prog'
    private fun stroke(cv: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, prog: Float, core: Float, col: Int, boost: Float) {
        if (prog <= 0f) return
        val ex = x0 + (x1 - x0) * prog
        val ey = y0 + (y1 - y0) * prog
        val r = Color.red(col); val g = Color.green(col); val b = Color.blue(col)
        line.color = Color.argb((60 * boost).toInt().coerceAtMost(255), r, g, b)
        line.strokeWidth = core * 3.4f
        // cahaya luar, tengah, lalu inti putih kebiruan
        cv.drawLine(x0, y0, ex, ey, line)
        line.color = Color.argb((150 * boost).toInt().coerceAtMost(255), r, g, b)
        line.strokeWidth = core * 1.9f
        cv.drawLine(x0, y0, ex, ey, line)
        line.color = Color.argb(245, 235, 250, 255)
        line.strokeWidth = core
        cv.drawLine(x0, y0, ex, ey, line)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val time = t * total / 1000f

        // latar redup halus supaya X terlihat jelas di atas game
        val dimA = 95f * animSm(t / 0.08f) * (1f - animSm((t - 0.80f) / 0.18f))
        if (dimA > 1f) {
            dimP.color = Color.argb(dimA.toInt(), 0, 6, 20)
            cv.drawRect(0f, 0f, w, h, dimP)
        }

        val cx0 = w / 2f
        val cy0 = h / 2f
        val ext = minOf(h * 0.16f, dp(56f))          // setengah lebar X (ke tiap sudut)
        val col = Wet.cycle(time, 3f)

        // goresan: "\" lalu "/"
        val p1 = animSm((t - 0.03f) / 0.20f)
        val p2 = animSm((t - 0.17f) / 0.20f)

        // gerak menjadi garis: m = 0 (X di tengah) .. 1 (garis di tepi)
        val m = animSm((t - 0.62f) / 0.28f)
        val cx = animMix(cx0, lineX, m)
        val cy = animMix(cy0, lineY, m) - sin(PIf * m) * h * 0.08f
        val half = animMix(ext * 1.414f, lineHalf, m)    // setengah panjang tiap goresan
        val core = animMix(dp(6.5f), dp(2.6f), m)
        // sudut tiap goresan: 45 derajat -> 90 (tegak), dan -45 -> -90
        val aA = Math.toRadians(animMix(45f, 90f, m).toDouble())
        val aB = Math.toRadians(animMix(-45f, -90f, m).toDouble())
        val breathe = 1f + 0.04f * sin(time * 9f) * (1f - m)
        val hl = half * breathe
        val ax = cos(aA).toFloat() * hl
        val ay = sin(aA).toFloat() * hl
        val bx = cos(aB).toFloat() * hl
        val by = sin(aB).toFloat() * hl

        // kilat saat X selesai digambar
        val fl = animSm((t - 0.34f) / 0.04f) * (1f - animSm((t - 0.38f) / 0.16f))
        if (fl > 0.01f) {
            cv.save()
            cv.translate(cx0, cy0)
            cv.scale(ext * 2.6f, ext * 2.6f)
            flashP.alpha = (255 * fl).toInt()
            cv.drawCircle(0f, 0f, 1f, flashP)
            cv.restore()
            // cincin kejut
            val rp = animSm((t - 0.34f) / 0.22f)
            line.color = Color.argb((180 * (1f - rp) * fl.coerceAtLeast(0.4f)).toInt(), 190, 235, 255)
            line.strokeWidth = dp(2f)
            cv.drawCircle(cx0, cy0, ext * (0.8f + 1.8f * rp), line)
        }

        val boost = 1f + 0.9f * fl
        stroke(cv, cx - ax, cy - ay, cx + ax, cy + ay, p1, core, col, boost)
        stroke(cv, cx - bx, cy - by, cx + bx, cy + by, p2, core, col, boost)

        // percikan di ujung goresan saat menggambar
        if (p1 in 0.02f..0.98f) spark(cv, cx - ax + 2f * ax * p1, cy - ay + 2f * ay * p1, col)
        if (p2 in 0.02f..0.98f) spark(cv, cx - bx + 2f * bx * p2, cy - by + 2f * by * p2, col)

    }

    private fun spark(cv: Canvas, x: Float, y: Float, col: Int) {
        fillP.color = Color.argb(110, Color.red(col), Color.green(col), Color.blue(col))
        cv.drawCircle(x, y, dp(7f), fillP)
        fillP.color = Color.WHITE
        cv.drawCircle(x, y, dp(3f), fillP)
    }
}
