package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

// ============ Animasi masuk game: PUSARAN NEON ============
// Alur: kilatan cahaya cyan melintang di tengah -> pusaran spiral neon (cyan & hijau) berputar
// mengelilingi inti gelap -> lengan pusaran memadat dan meluncur ke tepi atas menjadi GARIS handle.
// Warna hanya memakai palet XAGameSpace (cyan & hijau neon), tanpa merah.
// (lineX, lineY) = titik tengah garis akhir (px), lineHalf = setengah panjang garis akhir (px).
class XEntryView(
    c: Context,
    private val lineX: Float,
    private val lineY: Float,
    private val lineHalf: Float
) : View(c) {
    private val total = 2700L
    private var t = 0f
    private var anim: ValueAnimator? = null

    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dimP = Paint()
    private val path = Path()
    private var coreShader: RadialGradient? = null

    private val arms = 7
    private val steps = 44

    private fun dp(v: Float) = context.pxf(v)

    fun start(onEnd: () -> Unit) {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = total
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            t = it.animatedValue as Float

            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onEnd() }
        })
        anim = a
        a.start()
    }

    fun cancel() { anim?.cancel() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        // inti gelap pusaran: pusat hitam kebiruan dengan tepi cyan tipis
        val r = minOf(w, h) * 0.22f
        coreShader = RadialGradient(0f, 0f, r,
            intArrayOf(Color.argb(235, 0, 4, 12), Color.argb(200, 0, 10, 24), Color.argb(0, 60, 200, 255)),
            floatArrayOf(0.55f, 0.8f, 1f), Shader.TileMode.CLAMP)
    }

    private fun stroke3(cv: Canvas, col: Int, a: Float, w: Float) {
        glow.color = Color.argb((60 * a).toInt().coerceIn(0, 255), Color.red(col), Color.green(col), Color.blue(col))
        glow.strokeWidth = w * 3.2f
        cv.drawPath(path, glow)
        glow.color = Color.argb((150 * a).toInt().coerceIn(0, 255), Color.red(col), Color.green(col), Color.blue(col))
        glow.strokeWidth = w * 1.7f
        cv.drawPath(path, glow)
        glow.color = Color.argb((240 * a).toInt().coerceIn(0, 255), 232, 252, 255)
        glow.strokeWidth = w
        cv.drawPath(path, glow)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val cx0 = w / 2f
        val cy0 = h / 2f
        val time = t * total / 1000f
        val cyan = Color.rgb(60, 200, 255)
        val neon = Color.rgb(46, 245, 160)

        // latar redup biru-hitam supaya pusaran terlihat di atas game
        val dimA = 110f * animSm(t / 0.10f) * (1f - animSm((t - 0.84f) / 0.14f))
        if (dimA > 1f) {
            dimP.color = Color.argb(dimA.toInt(), 0, 8, 22)
            cv.drawRect(0f, 0f, w, h, dimP)
        }

        // 1) kilatan horizontal di tengah layar
        val flash = animSm((t - 0.02f) / 0.08f) * (1f - animSm((t - 0.10f) / 0.14f))
        if (flash > 0.01f) {
            val fw = w * 0.55f * flash + dp(20f)
            glow.color = Color.argb((200 * flash).toInt(), 150, 235, 255)
            glow.strokeWidth = dp(3f) * flash + dp(1f)
            cv.drawLine(cx0 - fw, cy0, cx0 + fw, cy0, glow)
            fill.color = Color.argb((140 * flash).toInt(), 60, 200, 255)
            cv.drawCircle(cx0, cy0, dp(40f) * flash + dp(6f), fill)
        }

        // 2) pusaran: lengan spiral berputar mengelilingi pusat
        val m = animSm((t - 0.60f) / 0.26f)                      // 0 = pusaran .. 1 = garis di handle
        val grow = animSm((t - 0.10f) / 0.22f)                    // pusaran membesar
        val R = minOf(w, h) * 0.46f * grow * (1f - 0.35f * m)
        val spin = time * 3.2f
        val lineL = lineX - lineHalf
        val lineR = lineX + lineHalf

        if (grow > 0.01f) {
            for (k in 0 until arms) {
                val col = if (k % 2 == 0) cyan else neon
                val base = k * 2f * PIf / arms
                path.reset()
                for (s in 0..steps) {
                    val u = s / steps.toFloat()
                    // posisi di pusaran (spiral)
                    val rr = R * u
                    val th = base + u * 3.6f + spin
                    val sx = cx0 + rr * cos(th)
                    val sy = cy0 + rr * sin(th) * 0.62f            // sedikit gepeng supaya terasa 3D
                    // posisi tujuan: garis handle
                    val lx = lineL + (lineR - lineL) * u
                    val ly = lineY
                    val x = animMix(sx, lx, m)
                    val y = animMix(sy, ly, m)
                    if (s == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                val fade = animSm((t - 0.12f - k * 0.02f) / 0.14f) * (1f - animSm((t - 0.92f) / 0.08f))
                val width = animMix(dp(3.2f), dp(2.4f), m) * (1f - 0.12f * (k % 3))
                stroke3(cv, col, fade, width)
            }

            // inti gelap pusaran, hilang saat pusaran memadat
            val coreA = (1f - m) * grow
            if (coreA > 0.01f && coreShader != null) {
                cv.save()
                cv.translate(cx0, cy0)
                glow.shader = null
                fill.shader = coreShader
                fill.alpha = (255 * coreA).toInt()
                cv.drawCircle(0f, 0f, minOf(w, h) * 0.22f, fill)
                fill.shader = null
                fill.alpha = 255
                cv.restore()
            }
        }

        // 3) titik cahaya kecil di ujung lengan saat memadat
        if (m > 0.05f && m < 0.98f) {
            for (k in 0 until arms) {
                val u = 0.55f + 0.45f * ((k * 37) % 10) / 10f
                val px = animMix(lineL + (lineR - lineL) * u, lineL + (lineR - lineL) * u, m)
                fill.color = Color.argb((120 * (1f - m)).toInt(), 150, 245, 255)
                cv.drawCircle(px, lineY, dp(2.5f), fill)
            }
        }
    }
}
