package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

// ============ Animasi masuk game: GELOMBANG ============
// 1) riak cahaya melebar dari tengah layar
// 2) tiga gelombang sinus halus mengalir di tengah layar
// 3) gelombang memadat dan berubah menjadi GARIS di tepi atas (handle panel)
// (lineX, lineY) = titik tengah garis akhir (px), lineHalf = setengah panjang garis akhir (px).
class XEntryView(
    c: Context,
    private val lineX: Float,
    private val lineY: Float,
    private val lineHalf: Float
) : View(c) {
    private val total = 2700L
    private var t = 0f
    private var anim: ValueAnimator? = null
    private var sRipple = false
    private var sWave = false

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val wave = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val dimP = Paint()
    private val path = Path()

    private fun dp(v: Float) = context.pxf(v)

    fun start(onEnd: () -> Unit) {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = total
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            t = it.animatedValue as Float
            if (!sRipple && t > 0.04f) { sRipple = true; Sfx.play("open", 0.6f) }
            if (!sWave && t > 0.60f) { sWave = true; Sfx.play("swipe", 0.8f) }
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onEnd() }
        })
        anim = a
        a.start()
    }

    fun cancel() { anim?.cancel() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val time = t * total / 1000f
        val cx0 = w / 2f
        val cy0 = h / 2f

        // latar redup halus supaya gelombang terlihat di atas game
        val dimA = 90f * animSm(t / 0.08f) * (1f - animSm((t - 0.82f) / 0.16f))
        if (dimA > 1f) {
            dimP.color = Color.argb(dimA.toInt(), 0, 6, 20)
            cv.drawRect(0f, 0f, w, h, dimP)
        }

        // 1) riak melebar dari tengah
        for (i in 0 until 3) {
            val rp = animSm((t - 0.04f - i * 0.10f) / 0.42f)
            if (rp <= 0f || rp >= 1f) continue
            val rad = maxOf(w, h) * 0.5f * rp
            val col = Wet.cycle(time + i * 0.5f, 3f)
            ring.color = Color.argb((170 * (1f - rp)).toInt(), Color.red(col), Color.green(col), Color.blue(col))
            ring.strokeWidth = dp(2.5f) * (1f - 0.5f * rp)
            cv.drawCircle(cx0, cy0, rad, ring)
        }

        // 2) + 3) gelombang: tumbuh, mengalir, lalu memadat jadi garis handle
        val m = animSm((t - 0.62f) / 0.28f)                 // 0 = di tengah .. 1 = garis di tepi
        val cx = animMix(cx0, lineX, m)
        val cy = animMix(cy0, lineY, m)
        val half = animMix(w * 0.42f, lineHalf, m)
        val amp0 = dp(30f)

        for (k in 0 until 3) {
            val pk = animSm((t - 0.10f - k * 0.05f) / 0.30f)  // gelombang k muncul bertahap
            if (pk <= 0f) continue
            val amp = amp0 * pk * (1f - m) * (1f - 0.25f * k)
            val phase = time * 5f + k * 1.3f
            val yOff = (k - 1) * dp(9f) * (1f - m)
            val steps = 48
            path.reset()
            for (s in 0..steps) {
                val u = s / steps.toFloat()                 // 0..1 sepanjang gelombang
                val x = cx - half + 2f * half * u
                val y = cy + yOff + amp * sin(u * 2f * PIf * 1.6f + phase)
                if (s == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val col = Wet.cycle(time + k * 0.9f, 3f)
            val r = Color.red(col); val g = Color.green(col); val b = Color.blue(col)
            val core = animMix(dp(4.5f), dp(2.4f), m) * (1f - 0.2f * k)
            // cahaya luar, tengah, lalu inti putih kebiruan (sama gaya dengan garis handle)
            wave.color = Color.argb((70 * pk).toInt(), r, g, b); wave.strokeWidth = core * 3.4f
            cv.drawPath(path, wave)
            wave.color = Color.argb((160 * pk).toInt(), r, g, b); wave.strokeWidth = core * 1.8f
            cv.drawPath(path, wave)
            wave.color = Color.argb((240 * pk).toInt(), 235, 250, 255); wave.strokeWidth = core
            cv.drawPath(path, wave)
        }
    }
}
