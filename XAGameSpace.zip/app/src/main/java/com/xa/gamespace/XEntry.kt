package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

private fun xs(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
private fun xl(a: Float, b: Float, m: Float) = a + (b - a) * m
private fun xb(x: Float): Float {
    val t = x.coerceIn(0f, 1f)
    val c1 = 1.70158f
    val c3 = c1 + 1f
    return 1f + c3 * (t - 1f) * (t - 1f) * (t - 1f) + c1 * (t - 1f) * (t - 1f)
}

// ============ Animasi masuk game ============
// 1) huruf X muncul dan berputar satu kali,
// 2) kedua goresannya menegak jadi dua stik sejajar,
// 3) stik terbang satu per satu (bergantian) ke sisi tempat handle panel berada,
// 4) di sana keduanya merapat dan menyatu menjadi SATU stik (handle).
// (lineX, lineY) = titik tengah pasangan stik di handle (px), lineHalf = setengah panjang stik handle.
class XEntryView(
    c: Context,
    private val lineX: Float,
    private val lineY: Float,
    private val lineHalf: Float
) : View(c) {
    private val total = 5400L   // lebih lama (dulu 3300 ms) supaya animasi masuk game terasa megah; ubah di sini bila mau
    private var t = 0f
    private var anim: ValueAnimator? = null
    private var s1 = false
    private var s2 = false
    private var s3 = false
    private var s4 = false

    private val sticks = StickPainter(c)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private fun dp(v: Float) = context.pxf(v)

    fun start(onEnd: () -> Unit) {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = total
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            t = it.animatedValue as Float
            if (!s1 && t > 0.03f) { s1 = true; Sfx.play("open", 0.8f) }
            if (!s2 && t > 0.52f) { s2 = true; Sfx.play("swipe", 0.8f) }
            if (!s3 && t > 0.60f) { s3 = true; Sfx.play("swipe", 0.8f) }
            if (!s4 && t > 0.88f) { s4 = true; Sfx.play("tap", 0.9f) }
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onEnd() }
        })
        anim = a
        a.start()
    }

    fun cancel() { anim?.cancel() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val time = animNow()
        val col = Wet.cycle(time, 5f)
        val cr = Color.red(col); val cg = Color.green(col); val cb = Color.blue(col)
        val cx = w / 2f
        val cy = h / 2f
        val hx = min(w, h) * 0.16f
        val half0 = hx * 1.4142f
        val gap = dp(Hud.STICK_GAP.toFloat())
        val off0 = dp(13f)

        // game diredupkan sedikit selama animasi
        val dimA = (95 * xs(t / 0.12f) * (1f - xs((t - 0.55f) / 0.30f))).toInt()
        if (dimA > 0) {
            fillP.color = Color.argb(dimA, 3, 8, 20)
            cv.drawRect(0f, 0f, w, h, fillP)
        }
        // cahaya di tengah selama X berputar
        val glowA = xs(t / 0.10f) * (1f - xs((t - 0.48f) / 0.12f))
        if (glowA > 0.01f) {
            glowP.shader = RadialGradient(cx, cy, hx * 3.2f,
                Color.argb((140 * glowA).toInt(), cr, cg, cb), Color.argb(0, cr, cg, cb), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, hx * 3.2f, glowP)
            glowP.shader = null
        }

        val pop = xb(t / 0.12f)
        val spin = 360f * xs((t - 0.12f) / 0.28f)
        val q = xs((t - 0.40f) / 0.12f)

        // di handle kedua stik merapat dan menyatu menjadi satu stik
        val merge = xs((t - 0.88f) / 0.10f)
        for (i in 0..1) {
            val sign = if (i == 0) -1f else 1f
            val aStick = if (i == 1) 1f - merge else 1f
            val start = if (i == 0) 0.52f else 0.60f
            val dur = 0.26f
            val fromX = cx + sign * off0
            val toX = lineX + sign * gap / 2f * (1f - merge)
            val baseAng = (if (i == 0) 45f else -45f) * (1f - q) + spin

            // posisi stik pada kemajuan terbang mm (0..1)
            fun pose(mm: Float): FloatArray {
                val dx = toX - fromX
                val dy = lineY - cy
                val len = hypot(dx, dy).coerceAtLeast(1f)
                val arc = sin(Math.PI.toFloat() * mm) * dp(38f) * -sign
                val x = xl(fromX, toX, mm) + (-dy / len) * arc
                val y = xl(cy, lineY, mm) + (dx / len) * arc
                val hf = xl(half0, lineHalf, mm)
                val ang = sin(Math.PI.toFloat() * mm) * 14f * sign
                return floatArrayOf(x, y, hf, ang)
            }

            val m = xs((t - start) / dur)
            if (t < start) {
                // menunggu giliran: di tengah, berputar lalu menegak
                val x = cx + sign * off0 * q
                val bob = if (q >= 1f) sin(time * 5f + i) * dp(2f) else 0f
                sticks.draw(cv, x, cy + bob, half0 * pop, baseAng, col, 1f, 1f, 0.9f)
            } else {
                // jejak cahaya di belakang stik yang sedang terbang
                if (m > 0f && m < 1f) {
                    for (g in 5 downTo 1) {
                        val mg = xs((t - start - g * 0.014f) / dur)
                        if (mg > 0f && mg < m) {
                            val gp = pose(mg)
                            sticks.draw(cv, gp[0], gp[1], gp[2], gp[3], col, 0.7f, 0.22f * (1f - g / 6f) * aStick, 0.9f)
                        }
                    }
                }
                val ps = pose(m)
                sticks.draw(cv, ps[0], ps[1], ps[2], ps[3], col, 1f, aStick, 0.9f)
            }
        }

        // saat bersatu: riak cahaya di handle
        if (t > 0.86f) {
            val r = ((t - 0.86f) / 0.14f).coerceIn(0f, 1f)
            ringP.color = Color.argb((200 * (1f - r)).toInt(), cr, cg, cb)
            ringP.strokeWidth = dp(2f)
            cv.drawCircle(lineX, lineY, dp(8f) + r * dp(50f), ringP)
        }
    }
}
