package com.xa.gamespace

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

// Iklan hadiah (rewarded). ID di bawah adalah ID UJI Google.
// Ganti dengan Rewarded Ad Unit ID asli dari AdMob sebelum rilis.
object Ads {
    const val REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"
    private var ad: RewardedAd? = null

    fun init(ctx: Context) {
        MobileAds.initialize(ctx)
        load(ctx)
    }

    fun load(ctx: Context) {
        RewardedAd.load(ctx, REWARDED_ID, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(loaded: RewardedAd) { ad = loaded }
            override fun onAdFailedToLoad(e: LoadAdError) { ad = null }
        })
    }

    // onReward: dipanggil saat iklan selesai ditonton penuh
    // onDismissed: dipanggil saat iklan ditutup
    fun show(act: Activity, onReward: () -> Unit, onDismissed: () -> Unit, onFail: () -> Unit) {
        val r = ad
        if (r == null) { onFail(); load(act); return }
        ad = null
        r.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { load(act); onDismissed() }
            override fun onAdFailedToShowFullScreenContent(e: AdError) { load(act); onFail() }
        }
        r.show(act) { onReward() }
    }
}
