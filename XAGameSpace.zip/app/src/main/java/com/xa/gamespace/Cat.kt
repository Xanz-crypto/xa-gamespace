package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

internal val PIf = Math.PI.toFloat()
internal fun catSm(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
internal fun catMix(a: Float, b: Float, m: Float) = a + (b - a) * m
internal fun catBack(x: Float): Float {
    val t = x.coerceIn(0f, 1f)
    val c1 = 1.70158f
    val c3 = c1 + 1f
    return 1f + c3 * (t - 1f).pow(3) + c1 * (t - 1f).pow(2)
}
internal fun catNow(): Float = ((System.nanoTime() / 1_000_000L) % 600000L) / 1000f

// Kucing lucu digambar dengan Canvas. Titik acuan = telapak kaki (x, base), tinggi = size.
class CatDrawer {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val rect = RectF()

    private val OUT = Color.parseColor("#B08A84")
    private val FUR = Color.parseColor("#FFFDFB")
    private val BELLY = Color.parseColor("#FFF1F0")
    private val PINK = Color.parseColor("#FFB4BE")
    private val DARK = Color.parseColor("#3B2A2A")

    private fun oval(cv: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int, stroke: Boolean = true) {
        rect.set(l, t, r, b)
        fill.color = color
        cv.drawOval(rect, fill)
        if (stroke) { line.color = OUT; line.strokeWidth = 2.4f; cv.drawOval(rect, line) }
    }

    private fun fillPath(cv: Canvas, color: Int, stroke: Boolean) {
        fill.color = color
        cv.drawPath(path, fill)
        if (stroke) { line.color = OUT; line.strokeWidth = 2.4f; cv.drawPath(path, line) }
    }

    private fun capsule(cv: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        line.color = OUT; line.strokeWidth = 12f; cv.drawLine(x0, y0, x1, y1, line)
        line.color = FUR; line.strokeWidth = 8.4f; cv.drawLine(x0, y0, x1, y1, line)
    }

    private fun eye(cv: Canvas, ex: Float, happy: Float, blink: Boolean) {
        if (happy > 0.5f || blink) {
            path.reset()
            path.moveTo(ex - 5f, -60f)
            path.quadTo(ex, if (blink) -62f else -68f, ex + 5f, -60f)
            line.color = DARK; line.strokeWidth = 2.8f
            cv.drawPath(path, line)
        } else {
            oval(cv, ex - 4.6f, -69f, ex + 4.6f, -57f, DARK, false)
            oval(cv, ex - 3.2f, -67.8f, ex + 0.2f, -64.4f, Color.WHITE, false)
            oval(cv, ex + 0.6f, -62.2f, ex + 2.6f, -60.2f, Color.WHITE, false)
        }
    }

    fun draw(cv: Canvas, x: Float, base: Float, size: Float, time: Float,
             wave: Float, lick: Float, mouth: Float,
             sx: Float = 1f, sy: Float = 1f, rot: Float = 0f,
             walk: Float = 0f, step: Float = 0f) {
        if (size <= 1f) return
        val sw = sin(step) * walk
        val u = size / 100f
        cv.save()
        cv.translate(x, base)
        cv.rotate(rot, 0f, -size * 0.35f)
        cv.scale(sx, sy)
        cv.scale(1f, 1f + 0.015f * sin(time * 3.1f))
        cv.scale(u, u)
        if (walk > 0f) {
            // goyang jalan: badan naik turun dan miring ke kiri-kanan
            cv.translate(0f, -abs(sin(step)) * 5f * walk)
            cv.rotate(sw * 5f, 0f, 0f)
        }

        // ekor
        val wag = sin(time * 4f) * 10f + sw * 6f
        path.reset()
        path.moveTo(18f, -12f)
        path.cubicTo(40f, -10f, 46f + wag * 0.5f, -34f, 36f + wag, -50f)
        line.color = OUT; line.strokeWidth = 11f; cv.drawPath(path, line)
        line.color = FUR; line.strokeWidth = 7.4f; cv.drawPath(path, line)

        // badan, perut, kaki
        oval(cv, -24f, -48f, 24f, -2f, FUR)
        oval(cv, -14f, -40f, 14f, -6f, BELLY, false)
        val liftL = max(0f, sw) * 7f
        val liftR = max(0f, -sw) * 7f
        oval(cv, -21f, -8f - liftL, -3f, 0f - liftL, BELLY)
        oval(cv, 3f, -8f - liftR, 21f, 0f - liftR, BELLY)
        // tangan kiri (diam / mengayun saat jalan)
        val al = -sw * 5f
        capsule(cv, -19f, -38f, -22f + al, -17f)
        oval(cv, -27f + al, -22f, -17f + al, -13f, BELLY)

        // kepala (sedikit miring)
        cv.save()
        cv.rotate(4f * sin(time * 2f) + 6f * lick + sw * 3f, 0f, -45f)
        // telinga
        path.reset(); path.moveTo(-27f, -68f); path.quadTo(-29f, -101f, -5f, -85f); path.close()
        fillPath(cv, FUR, true)
        path.reset(); path.moveTo(-23f, -76f); path.quadTo(-24f, -93f, -12f, -85f); path.close()
        fillPath(cv, PINK, false)
        path.reset(); path.moveTo(27f, -68f); path.quadTo(29f, -101f, 5f, -85f); path.close()
        fillPath(cv, FUR, true)
        path.reset(); path.moveTo(23f, -76f); path.quadTo(24f, -93f, 12f, -85f); path.close()
        fillPath(cv, PINK, false)
        // wajah
        oval(cv, -31f, -88f, 31f, -38f, FUR)
        line.color = Color.argb(150, 176, 138, 132); line.strokeWidth = 2f
        cv.drawLine(0f, -87f, 0f, -80f, line)
        cv.drawLine(-7f, -86f, -5.5f, -80f, line)
        cv.drawLine(7f, -86f, 5.5f, -80f, line)
        // mata
        val happy = max(lick, if (wave > 0.5f) 0.7f else 0f)
        val blink = (time % 3.4f) < 0.14f
        eye(cv, -11f, happy, blink)
        eye(cv, 11f, happy, blink)
        // pipi merona
        fill.color = Color.argb(185, 255, 150, 165)
        rect.set(-31f, -58f, -15f, -48f); cv.drawOval(rect, fill)
        rect.set(15f, -58f, 31f, -48f); cv.drawOval(rect, fill)
        // hidung
        path.reset(); path.moveTo(-2.8f, -55f); path.lineTo(2.8f, -55f); path.lineTo(0f, -51.5f); path.close()
        fill.color = PINK; cv.drawPath(path, fill)
        line.color = OUT; line.strokeWidth = 1.2f; cv.drawPath(path, line)
        // mulut
        if (mouth > 0.05f) {
            oval(cv, -4.4f, -50f, 4.4f, -50f + 2f + 8f * mouth, Color.parseColor("#7A1F2B"))
            oval(cv, -2.6f, -46f + 4f * mouth, 2.6f, -43f + 6f * mouth, PINK, false)
        } else {
            path.reset()
            path.moveTo(-6f, -47.5f); path.quadTo(-3f, -43.5f, 0f, -49f); path.quadTo(3f, -43.5f, 6f, -47.5f)
            line.color = OUT; line.strokeWidth = 1.7f; cv.drawPath(path, line)
            if (lick > 0.05f) {
                val ext = 2f + 4f * abs(sin(time * 9f)) * lick
                oval(cv, 1.5f, -46.5f, 7.5f, -46.5f + ext + 1f, PINK)
            }
        }
        // kumis
        line.color = Color.argb(110, 176, 138, 132); line.strokeWidth = 1.1f
        for (side in floatArrayOf(-1f, 1f)) {
            cv.drawLine(side * 24f, -53f, side * 40f, -57f, line)
            cv.drawLine(side * 24f, -50f, side * 41f, -50f, line)
            cv.drawLine(side * 24f, -47f, side * 39f, -43f, line)
        }
        cv.restore()

        // tangan kanan: melambai / menjilat
        var th = catMix(-6f + sw * 14f, -150f + 24f * sin(time * 9.5f), wave)
        th = catMix(th, 122f + 7f * sin(time * 11f), lick)
        val len = catMix(24f, 20f, lick)
        cv.save()
        cv.translate(21f, -37f)
        cv.rotate(th)
        capsule(cv, 0f, 0f, 0f, len)
        oval(cv, -5.6f, len - 4.6f, 5.6f, len + 6f, BELLY)
        fill.color = PINK
        rect.set(-2f, len + 0.6f, 2f, len + 4.4f); cv.drawOval(rect, fill)
        rect.set(-4.6f, len - 2.4f, -2.4f, len - 0.4f); cv.drawOval(rect, fill)
        rect.set(2.4f, len - 2.4f, 4.6f, len - 0.4f); cv.drawOval(rect, fill)
        cv.restore()

        cv.restore()
    }
}

// ============ Animasi pembuka: kucing berjalan kiri ke kanan, Game Space terbuka mengikuti di belakangnya ============
class CatSplashView(ctx: Context, private val onDone: () -> Unit) : View(ctx) {
    private val total = 4200L
    private var t = 0f
    private var finished = false
    private var anim: ValueAnimator? = null
    private val cat = CatDrawer()
    private val bg = Paint()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private var edgeGlow: LinearGradient? = null
    private var revealX = 0f
    private var stepCount = 0

    // jejak kaki: x, y, waktu lahir
    private val prints = ArrayList<FloatArray>()

    init { isClickable = false }

    private fun dp(v: Float) = context.pxf(v)

    // sentuhan di area yang sudah terbuka diteruskan ke menu di bawahnya
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            if (e.x > revealX) { anim?.cancel(); return true }
            return false
        }
        return false
    }

    fun start() {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = total
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { t = it.animatedValue as Float; invalidate() }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { finish() }
        })
        anim = a
        a.start()
    }

    private fun finish() {
        if (finished) return
        finished = true
        onDone()
    }

    override fun onDetachedFromWindow() {
        anim?.removeAllListeners()
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        bg.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            Color.parseColor("#1B2358"), Color.parseColor("#5A3A86"), Shader.TileMode.CLAMP)
        val gw = dp(70f)
        edgeGlow = LinearGradient(0f, 0f, gw, 0f,
            intArrayOf(Color.argb(210, 255, 255, 255), Color.argb(90, 150, 220, 255), Color.argb(0, 150, 220, 255)),
            floatArrayOf(0f, 0.25f, 1f), Shader.TileMode.CLAMP)
    }

    private fun paw(cv: Canvas, x: Float, y: Float, s: Float, a: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.argb((190 * a).toInt(), 255, 170, 190)
        rect.set(x - s, y - s * 0.7f, x + s, y + s * 0.8f)
        cv.drawOval(rect, p)
        for (k in -1..2) {
            val tx = x + (k - 0.5f) * s * 0.85f
            val ty = y - s * (1.1f + 0.2f * (if (k == 0 || k == 1) 1f else 0f))
            cv.drawCircle(tx, ty, s * 0.36f, p)
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val time = t * total / 1000f

        val size = min(h * 0.34f, dp(130f))
        val base = h * 0.80f

        // kucing masuk dari luar kiri, berjalan, lalu keluar di kanan
        val walkT = ((t - 0.04f) / 0.88f).coerceIn(0f, 1f)
        val e = catMix(walkT, catSm(walkT), 0.25f)
        val catX = catMix(-size * 0.7f, w + size * 0.9f, e)
        val stepRate = 9.5f                       // putaran langkah per detik
        val step = time * stepRate
        val walking = if (walkT > 0f && walkT < 1f) 1f else 0f

        // bunyi langkah tiap kaki menapak
        val n = (step / PIf).toInt()
        if (walking > 0f && n > stepCount) {
            stepCount = n
            Sfx.play(if (n % 2 == 0) "step1" else "step2", 0.6f)
            if (catX in 0f..w) {
                val side = if (n % 2 == 0) -1f else 1f
                prints.add(floatArrayOf(catX + side * size * 0.12f, base - size * 0.01f, time))
            }
        }

        // area yang sudah terbuka = di belakang kucing
        revealX = (catX - size * 0.18f).coerceIn(0f, w)
        if (revealX < w) {
            cv.save()
            cv.clipRect(revealX, 0f, w, h)
            cv.drawRect(revealX, 0f, w, h, bg)
            cv.restore()
        }

        // tepi bercahaya mengikuti kucing, seperti permukaan basah
        if (revealX > 0f && revealX < w) {
            glowP.shader = edgeGlow
            cv.save()
            cv.translate(revealX, 0f)
            cv.scale(-1f, 1f)
            val flick = 0.8f + 0.2f * sin(time * 14f)
            glowP.alpha = (255 * flick).toInt()
            cv.drawRect(0f, 0f, dp(70f), h, glowP)
            cv.restore()
            glowP.shader = null
            // percikan kecil di belakang kucing
            for (i in 0 until 9) {
                val ph = (time * 1.6f + i * 0.37f) % 1f
                val px = revealX - ph * dp(90f) - i * dp(3f)
                val py = base - size * (0.15f + 0.8f * ((i * 0.618f) % 1f))
                p.style = Paint.Style.FILL
                p.color = Color.argb((200 * (1f - ph)).toInt(), 190, 235, 255)
                cv.drawCircle(px, py, dp(2.2f) * (1f - ph * 0.6f), p)
            }
        }

        // jejak kaki mungil
        val iter = prints.iterator()
        while (iter.hasNext()) {
            val pr = iter.next()
            val age = time - pr[2]
            if (age > 1.6f) { iter.remove(); continue }
            paw(cv, pr[0], pr[1], dp(4.5f), 1f - age / 1.6f)
        }

        // bayangan + kucing
        p.style = Paint.Style.FILL
        p.color = Color.argb(70, 0, 0, 0)
        rect.set(catX - size * 0.34f, base - size * 0.02f, catX + size * 0.34f, base + size * 0.05f)
        cv.drawOval(rect, p)
        val mouth = if (walking > 0f && sin(step * 0.5f) > 0.8f) 0.5f else 0f
        cat.draw(cv, catX, base, size, time, 0f, 0f, mouth, 1f, 1f, 0f, walking, step)
    }
}

// ============ Animasi masuk game: kucing menjilat tangan lalu melompat ke sisi kiri ============
class CatEntryView(c: Context, private val endX: Float, private val endY: Float) : View(c) {
    private var t = 0f
    private var anim: ValueAnimator? = null
    private val cat = CatDrawer()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var sLick = false
    private var sJump = false
    private var sLand = false

    private fun dp(v: Float) = context.pxf(v)

    fun start(onEnd: () -> Unit) {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 3100
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            t = it.animatedValue as Float
            if (!sLick && t > 0.18f) { sLick = true; Sfx.play("lick") }
            if (!sJump && t > 0.60f) { sJump = true; Sfx.play("jump") }
            if (!sLand && t > 0.88f) { sLand = true; Sfx.play("hello", 0.6f) }
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onEnd() }
        })
        anim = a
        a.start()
    }

    fun cancel() { anim?.cancel() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val time = t * 3.1f
        val s0 = min(h * 0.5f, dp(170f))
        val sEnd = dp(52f)
        val cx0 = w / 2f
        val cy0 = h / 2f
        var cx = cx0
        var cy = cy0
        var size = s0
        var sx = 1f
        var sy = 1f
        var rot = 0f
        var wave = 0f
        var mouth = 0f

        if (t < 0.10f) size = s0 * catBack(t / 0.10f)
        val lick = catSm((t - 0.10f) / 0.05f) * (1f - catSm((t - 0.48f) / 0.05f))
        if (t >= 0.52f && t < 0.60f) {
            val q = catSm((t - 0.52f) / 0.08f)
            sy = 1f - 0.18f * q; sx = 1f + 0.12f * q
        }
        if (t >= 0.60f) {
            val m = ((t - 0.60f) / 0.30f).coerceIn(0f, 1f)
            val e = catSm(m)
            cx = catMix(cx0, endX, e)
            size = catMix(s0, sEnd, e)
            cy = catMix(cy0, endY, e) - h * 0.22f * 4f * m * (1f - m)
            rot = -18f * sin(PIf * m)
            sy = 1f + 0.12f * sin(PIf * m)
            sx = 1f - 0.06f * sin(PIf * m)
        }
        if (t >= 0.90f) {
            val q = ((t - 0.90f) / 0.10f).coerceIn(0f, 1f)
            val sq = sin(PIf * q)
            sy = 1f - 0.12f * sq; sx = 1f + 0.08f * sq
            wave = catSm(q)
            mouth = sq * 0.9f
        }
        // bayangan di lantai sebelum lompat
        if (t < 0.64f) {
            val g = 1f - catSm((t - 0.58f) / 0.06f)
            p.color = Color.argb((70 * g).toInt(), 0, 0, 0)
            val gy = cy0 + s0 / 2f
            rect.set(cx0 - s0 * 0.36f, gy - s0 * 0.02f, cx0 + s0 * 0.36f, gy + s0 * 0.05f)
            cv.drawOval(rect, p)
        }
        cat.draw(cv, cx, cy + size / 2f, size, time, wave, lick, mouth, sx, sy, rot)
    }
}

// ============ Kucing mengintip di belakang panel sambil melambai ============
class CatPeekView(c: Context) : View(c) {
    private val cat = CatDrawer()
    private var time = 0f
    private var anim: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1000
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { time = catNow(); invalidate() }
        anim = a
        a.start()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val ph = (time % 5f) - 0.3f
        val mouth = if (ph in 0f..0.5f) sin(PIf * ph / 0.5f) * 0.8f else 0f
        cat.draw(cv, width / 2f, height.toFloat(), context.pxf(72f), time, 1f, 0f, mouth)
    }
}
