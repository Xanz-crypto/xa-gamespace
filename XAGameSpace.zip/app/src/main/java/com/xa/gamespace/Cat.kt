package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

internal val PIf = Math.PI.toFloat()
internal fun catSm(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
internal fun catMix(a: Float, b: Float, m: Float) = a + (b - a) * m
internal fun catBack(x: Float): Float {
    val t = x.coerceIn(0f, 1f)
    val c1 = 1.70158f
    val c3 = c1 + 1f
    return 1f + c3 * (t - 1f).pow(3) + c1 * (t - 1f).pow(2)
}
internal fun catNow(): Float = ((System.nanoTime() / 1_000_000L) % 600000L) / 1000f

// Kucing lucu digambar dengan Canvas. Titik acuan = telapak kaki (x, base), tinggi = size.
class CatDrawer {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val rect = RectF()

    private val OUT = Color.parseColor("#5B3A24")
    private val FUR = Color.parseColor("#FFC27A")
    private val BELLY = Color.parseColor("#FFF0D6")
    private val PINK = Color.parseColor("#FF9DB8")
    private val DARK = Color.parseColor("#2B1B12")

    private fun oval(cv: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int, stroke: Boolean = true) {
        rect.set(l, t, r, b)
        fill.color = color
        cv.drawOval(rect, fill)
        if (stroke) { line.color = OUT; line.strokeWidth = 2.4f; cv.drawOval(rect, line) }
    }

    private fun fillPath(cv: Canvas, color: Int, stroke: Boolean) {
        fill.color = color
        cv.drawPath(path, fill)
        if (stroke) { line.color = OUT; line.strokeWidth = 2.4f; cv.drawPath(path, line) }
    }

    private fun capsule(cv: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        line.color = OUT; line.strokeWidth = 12f; cv.drawLine(x0, y0, x1, y1, line)
        line.color = FUR; line.strokeWidth = 8.4f; cv.drawLine(x0, y0, x1, y1, line)
    }

    private fun eye(cv: Canvas, ex: Float, happy: Float, blink: Boolean) {
        if (happy > 0.5f || blink) {
            path.reset()
            path.moveTo(ex - 5f, -60f)
            path.quadTo(ex, if (blink) -62f else -68f, ex + 5f, -60f)
            line.color = DARK; line.strokeWidth = 2.8f
            cv.drawPath(path, line)
        } else {
            oval(cv, ex - 4.6f, -69f, ex + 4.6f, -57f, DARK, false)
            oval(cv, ex - 3.2f, -67.8f, ex + 0.2f, -64.4f, Color.WHITE, false)
            oval(cv, ex + 0.6f, -62.2f, ex + 2.6f, -60.2f, Color.WHITE, false)
        }
    }

    fun draw(cv: Canvas, x: Float, base: Float, size: Float, time: Float,
             wave: Float, lick: Float, mouth: Float,
             sx: Float = 1f, sy: Float = 1f, rot: Float = 0f) {
        if (size <= 1f) return
        val u = size / 100f
        cv.save()
        cv.translate(x, base)
        cv.rotate(rot, 0f, -size * 0.35f)
        cv.scale(sx, sy)
        cv.scale(1f, 1f + 0.015f * sin(time * 3.1f))
        cv.scale(u, u)

        // ekor
        val wag = sin(time * 4f) * 10f
        path.reset()
        path.moveTo(18f, -12f)
        path.cubicTo(40f, -10f, 46f + wag * 0.5f, -34f, 36f + wag, -50f)
        line.color = OUT; line.strokeWidth = 11f; cv.drawPath(path, line)
        line.color = FUR; line.strokeWidth = 7.4f; cv.drawPath(path, line)

        // badan, perut, kaki
        oval(cv, -24f, -48f, 24f, -2f, FUR)
        oval(cv, -14f, -40f, 14f, -6f, BELLY, false)
        oval(cv, -21f, -8f, -3f, 0f, BELLY)
        oval(cv, 3f, -8f, 21f, 0f, BELLY)
        // tangan kiri (diam)
        capsule(cv, -19f, -38f, -22f, -17f)
        oval(cv, -27f, -22f, -17f, -13f, BELLY)

        // kepala (sedikit miring)
        cv.save()
        cv.rotate(4f * sin(time * 2f) + 6f * lick, 0f, -45f)
        // telinga
        path.reset(); path.moveTo(-26f, -70f); path.lineTo(-23f, -99f); path.lineTo(-6f, -86f); path.close()
        fillPath(cv, FUR, true)
        path.reset(); path.moveTo(-22f, -77f); path.lineTo(-21f, -92f); path.lineTo(-11f, -84f); path.close()
        fillPath(cv, PINK, false)
        path.reset(); path.moveTo(26f, -70f); path.lineTo(23f, -99f); path.lineTo(6f, -86f); path.close()
        fillPath(cv, FUR, true)
        path.reset(); path.moveTo(22f, -77f); path.lineTo(21f, -92f); path.lineTo(11f, -84f); path.close()
        fillPath(cv, PINK, false)
        // wajah
        oval(cv, -31f, -88f, 31f, -38f, FUR)
        line.color = Color.argb(150, 91, 58, 36); line.strokeWidth = 2f
        cv.drawLine(0f, -87f, 0f, -80f, line)
        cv.drawLine(-7f, -86f, -5.5f, -80f, line)
        cv.drawLine(7f, -86f, 5.5f, -80f, line)
        // mata
        val happy = max(lick, if (wave > 0.5f) 0.7f else 0f)
        val blink = (time % 3.4f) < 0.14f
        eye(cv, -11f, happy, blink)
        eye(cv, 11f, happy, blink)
        // pipi merona
        fill.color = Color.argb(150, 255, 120, 150)
        rect.set(-29f, -56f, -17f, -49f); cv.drawOval(rect, fill)
        rect.set(17f, -56f, 29f, -49f); cv.drawOval(rect, fill)
        // hidung
        path.reset(); path.moveTo(-2.8f, -55f); path.lineTo(2.8f, -55f); path.lineTo(0f, -51.5f); path.close()
        fill.color = PINK; cv.drawPath(path, fill)
        line.color = OUT; line.strokeWidth = 1.2f; cv.drawPath(path, line)
        // mulut
        if (mouth > 0.05f) {
            oval(cv, -4.4f, -50f, 4.4f, -50f + 2f + 8f * mouth, Color.parseColor("#7A1F2B"))
            oval(cv, -2.6f, -46f + 4f * mouth, 2.6f, -43f + 6f * mouth, PINK, false)
        } else {
            path.reset()
            path.moveTo(-6f, -47.5f); path.quadTo(-3f, -43.5f, 0f, -49f); path.quadTo(3f, -43.5f, 6f, -47.5f)
            line.color = OUT; line.strokeWidth = 1.7f; cv.drawPath(path, line)
            if (lick > 0.05f) {
                val ext = 2f + 4f * abs(sin(time * 9f)) * lick
                oval(cv, 1.5f, -46.5f, 7.5f, -46.5f + ext + 1f, PINK)
            }
        }
        // kumis
        line.color = Color.argb(200, 91, 58, 36); line.strokeWidth = 1.2f
        for (side in floatArrayOf(-1f, 1f)) {
            cv.drawLine(side * 24f, -53f, side * 40f, -57f, line)
            cv.drawLine(side * 24f, -50f, side * 41f, -50f, line)
            cv.drawLine(side * 24f, -47f, side * 39f, -43f, line)
        }
        cv.restore()

        // tangan kanan: melambai / menjilat
        var th = catMix(-6f, -150f + 24f * sin(time * 9.5f), wave)
        th = catMix(th, 122f + 7f * sin(time * 11f), lick)
        val len = catMix(24f, 20f, lick)
        cv.save()
        cv.translate(21f, -37f)
        cv.rotate(th)
        capsule(cv, 0f, 0f, 0f, len)
        oval(cv, -5.6f, len - 4.6f, 5.6f, len + 6f, BELLY)
        fill.color = PINK
        rect.set(-2f, len + 0.6f, 2f, len + 4.4f); cv.drawOval(rect, fill)
        rect.set(-4.6f, len - 2.4f, -2.4f, len - 0.4f); cv.drawOval(rect, fill)
        rect.set(2.4f, len - 2.4f, 4.6f, len - 0.4f); cv.drawOval(rect, fill)
        cv.restore()

        cv.restore()
    }
}

// ============ Animasi loading menu awal: kucing melambai + teks sambutan ============
class CatSplashView(ctx: Context, private val onDone: () -> Unit) : View(ctx) {
    private val total = 3400L
    private var t = 0f
    private var finished = false
    private var anim: ValueAnimator? = null
    private val cat = CatDrawer()
    private val bg = Paint()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f
    }
    private val path = Path()
    private val rect = RectF()
    private var sxs = FloatArray(0)
    private var sys = FloatArray(0)
    private var sph = FloatArray(0)
    private val msg = "HALLO SELAMAT BERMAIN"

    init {
        isClickable = true
        setOnClickListener { anim?.cancel() }
    }

    private fun dp(v: Float) = context.pxf(v)

    fun start() {
        Handler(Looper.getMainLooper()).postDelayed({ if (!finished) Sfx.play("hello") }, 450)
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = total
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { t = it.animatedValue as Float; invalidate() }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { finish() }
        })
        anim = a
        a.start()
    }

    private fun finish() {
        if (finished) return
        finished = true
        animate().alpha(0f).setDuration(350).withEndAction { onDone() }.start()
    }

    override fun onDetachedFromWindow() {
        anim?.removeAllListeners()
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        bg.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            Color.parseColor("#1B2358"), Color.parseColor("#5A3A86"), Shader.TileMode.CLAMP)
        val r = Random(9)
        sxs = FloatArray(26) { r.nextFloat() * w }
        sys = FloatArray(26) { r.nextFloat() * h * 0.7f }
        sph = FloatArray(26) { r.nextFloat() * 6f }
    }

    private fun heart(cv: Canvas, x: Float, y: Float, r: Float) {
        path.reset()
        path.moveTo(x, y + r * 0.9f)
        path.cubicTo(x - r * 1.6f, y - r * 0.3f, x - r * 0.6f, y - r * 1.4f, x, y - r * 0.45f)
        path.cubicTo(x + r * 0.6f, y - r * 1.4f, x + r * 1.6f, y - r * 0.3f, x, y + r * 0.9f)
        cv.drawPath(path, p)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val time = t * total / 1000f
        cv.drawRect(0f, 0f, w, h, bg)

        // bintang
        p.style = Paint.Style.FILL
        for (i in sxs.indices) {
            val tw = 0.5f + 0.5f * sin(time * 2f + sph[i])
            p.color = Color.argb((60 + 150 * tw).toInt(), 255, 245, 210)
            cv.drawCircle(sxs[i], sys[i], dp(1.3f) * (0.6f + tw), p)
        }
        // hati melayang
        if (time > 0.3f) {
            for (i in 0 until 6) {
                val ph = ((time * 0.2f) + i * 0.17f) % 1f
                val hx = w * (0.1f + 0.16f * i) + sin(time * 1.3f + i) * dp(10f)
                val hy = h * (1.05f - ph * 1.1f)
                p.color = Color.argb((140 * (1f - ph)).toInt(), 255, 140, 180)
                heart(cv, hx, hy, dp(7f))
            }
        }

        // kucing
        val s = min(h * 0.5f, w * 0.34f)
        val cx = w / 2f
        val base = h * 0.62f
        val sc = catBack(time / 0.5f)
        p.color = Color.argb((70 * sc.coerceIn(0f, 1f)).toInt(), 0, 0, 0)
        rect.set(cx - s * 0.36f * sc, base - s * 0.02f, cx + s * 0.36f * sc, base + s * 0.05f)
        cv.drawOval(rect, p)
        val wave = catSm((time - 0.25f) / 0.3f)
        var mouth = 0f
        for (st in floatArrayOf(0.5f, 0.85f, 2.0f)) {
            val ph = (time - st) / 0.28f
            if (ph in 0f..1f) mouth = sin(PIf * ph) * 0.9f
        }
        cat.draw(cv, cx, base, s * sc, time, wave, 0f, mouth)

        // teks sambutan, muncul huruf demi huruf
        txt.textSize = dp(24f)
        val full = txt.measureText(msg)
        if (full > w * 0.88f) txt.textSize = txt.textSize * w * 0.88f / full
        val tw = txt.measureText(msg)
        val x0 = cx - tw / 2f
        val ty = base + dp(46f)
        val n = ((time - 0.7f) / 0.05f).toInt().coerceIn(0, msg.length)
        for (i in 0 until n) {
            val born = 0.7f + i * 0.05f
            val bounce = max(0f, 1f - (time - born) / 0.35f)
            val off = -dp(12f) * bounce * abs(sin(bounce * 3f * PIf))
            val px = x0 + txt.measureText(msg, 0, i)
            val ch = msg.substring(i, i + 1)
            txt.color = Color.argb(200, 255, 120, 170)
            cv.drawText(ch, px + dp(2f), ty + off + dp(2f), txt)
            txt.color = Color.WHITE
            cv.drawText(ch, px, ty + off, txt)
        }

        // progress
        val bw = w * 0.34f
        val by = h * 0.9f
        p.color = Color.argb(70, 255, 255, 255)
        cv.drawRoundRect(cx - bw / 2, by, cx + bw / 2, by + dp(5f), dp(3f), dp(3f), p)
        p.color = Color.parseColor("#FFB6D0")
        cv.drawRoundRect(cx - bw / 2, by, cx - bw / 2 + bw * t, by + dp(5f), dp(3f), dp(3f), p)
    }
}

// ============ Animasi masuk game: kucing menjilat tangan lalu melompat ke sisi kiri ============
class CatEntryView(c: Context, private val endX: Float, @Suppress("UNUSED_PARAMETER") endHalf: Float) : View(c) {
    private var t = 0f
    private var anim: ValueAnimator? = null
    private val cat = CatDrawer()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var sLick = false
    private var sJump = false
    private var sLand = false

    private fun dp(v: Float) = context.pxf(v)

    fun start(onEnd: () -> Unit) {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 3100
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            t = it.animatedValue as Float
            if (!sLick && t > 0.18f) { sLick = true; Sfx.play("lick") }
            if (!sJump && t > 0.60f) { sJump = true; Sfx.play("jump") }
            if (!sLand && t > 0.88f) { sLand = true; Sfx.play("hello", 0.6f) }
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onEnd() }
        })
        anim = a
        a.start()
    }

    fun cancel() { anim?.cancel() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val time = t * 3.1f
        val s0 = min(h * 0.5f, dp(170f))
        val sEnd = dp(52f)
        val cx0 = w / 2f
        val cy0 = h / 2f
        var cx = cx0
        var cy = cy0
        var size = s0
        var sx = 1f
        var sy = 1f
        var rot = 0f
        var wave = 0f
        var mouth = 0f

        if (t < 0.10f) size = s0 * catBack(t / 0.10f)
        val lick = catSm((t - 0.10f) / 0.05f) * (1f - catSm((t - 0.48f) / 0.05f))
        if (t >= 0.52f && t < 0.60f) {
            val q = catSm((t - 0.52f) / 0.08f)
            sy = 1f - 0.18f * q; sx = 1f + 0.12f * q
        }
        if (t >= 0.60f) {
            val m = ((t - 0.60f) / 0.30f).coerceIn(0f, 1f)
            val e = catSm(m)
            cx = catMix(cx0, endX, e)
            size = catMix(s0, sEnd, e)
            cy = catMix(cy0, cy0, e) - h * 0.22f * 4f * m * (1f - m)
            rot = -18f * sin(PIf * m)
            sy = 1f + 0.12f * sin(PIf * m)
            sx = 1f - 0.06f * sin(PIf * m)
        }
        if (t >= 0.90f) {
            val q = ((t - 0.90f) / 0.10f).coerceIn(0f, 1f)
            val sq = sin(PIf * q)
            sy = 1f - 0.12f * sq; sx = 1f + 0.08f * sq
            wave = catSm(q)
            mouth = sq * 0.9f
        }
        // bayangan di lantai sebelum lompat
        if (t < 0.64f) {
            val g = 1f - catSm((t - 0.58f) / 0.06f)
            p.color = Color.argb((70 * g).toInt(), 0, 0, 0)
            val gy = cy0 + s0 / 2f
            rect.set(cx0 - s0 * 0.36f, gy - s0 * 0.02f, cx0 + s0 * 0.36f, gy + s0 * 0.05f)
            cv.drawOval(rect, p)
        }
        cat.draw(cv, cx, cy + size / 2f, size, time, wave, lick, mouth, sx, sy, rot)
    }
}

// ============ Kucing mengintip di belakang panel sambil melambai ============
class CatPeekView(c: Context) : View(c) {
    private val cat = CatDrawer()
    private var time = 0f
    private var anim: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1000
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { time = catNow(); invalidate() }
        anim = a
        a.start()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val ph = (time % 5f) - 0.3f
        val mouth = if (ph in 0f..0.5f) sin(PIf * ph / 0.5f) * 0.8f else 0f
        cat.draw(cv, width / 2f, height.toFloat(), context.pxf(72f), time, 1f, 0f, mouth)
    }
}
