package com.xa.gamespace

import android.view.View

interface Page {
    fun build(): View
    fun update(s: Snap) {}
}
