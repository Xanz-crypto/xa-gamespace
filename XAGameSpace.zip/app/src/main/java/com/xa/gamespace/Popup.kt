package com.xa.gamespace

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

// Pop up APK: buka aplikasi lain sebagai jendela mengambang di atas game
object Popup {
    private const val KEY = "popup_apps"

    fun list(s: Store): List<String> = s.get(KEY).split(",").filter { it.isNotBlank() }

    private fun save(s: Store, l: List<String>) = s.put(KEY, l.joinToString(","))

    // true = sekarang terpilih
    fun toggle(s: Store, pkg: String): Boolean {
        val l = list(s).toMutableList()
        return if (l.remove(pkg)) { save(s, l); false } else { l.add(pkg); save(s, l); true }
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val app = ctx.applicationContext
        val li = app.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        val comp = li.component?.flattenToShortString() ?: return false
        if (Access.hasAny()) {
            Thread {
                Access.run("settings put global enable_freeform_support 1; " +
                    "settings put global force_resizable_activities 1; " +
                    "am start --windowingMode 5 -n $comp")
            }.start()
        } else {
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val dm = app.resources.displayMetrics
            val w = dm.widthPixels
            val h = dm.heightPixels
            try {
                val o = ActivityOptions.makeBasic().setLaunchBounds(Rect(w / 4, h / 8, w * 3 / 4, h * 7 / 8))
                app.startActivity(li, o.toBundle())
            } catch (e: Exception) {
                try { app.startActivity(li) } catch (e2: Exception) { return false }
            }
        }
        return true
    }
}

// Daftar semua aplikasi untuk ditambah / dihapus manual dari daftar pop up
class AppPickerView(private val ctx: Context, private val store: Store,
                    private val onChange: () -> Unit, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val list = LinearLayout(ctx)

    private fun px(v: Int) = ctx.px(v)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        root.setPadding(px(12), px(10), px(12), px(10))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(ctx)
        t.text = "TAMBAH APK MANUAL"
        t.textSize = 12f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(Hud.cyan)
        head.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        val x = TextView(ctx)
        x.text = "✕"
        x.textSize = 16f
        x.setTextColor(Color.WHITE)
        x.setPadding(px(10), px(2), px(4), px(2))
        x.setOnClickListener { Sfx.tap(); onClose() }
        head.addView(x)
        root.addView(head)

        val hint = TextView(ctx)
        hint.text = "Ketuk aplikasi untuk menambah (✓) atau menghapus dari daftar Pop Up."
        hint.textSize = 10f
        hint.setTextColor(Hud.sub)
        root.addView(hint, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(2); it.bottomMargin = px(6) })

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val loading = TextView(ctx)
        loading.text = "Memuat aplikasi..."
        loading.textSize = 11f
        loading.setTextColor(Hud.sub)
        list.orientation = LinearLayout.VERTICAL
        list.addView(loading)

        Thread {
            val pm = ctx.packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(q, 0)
                .map { Triple(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .distinctBy { it.first }
                .filter { it.first != ctx.packageName }
                .sortedBy { it.second.lowercase() }
            root.post {
                list.removeAllViews()
                for ((pkg, label, icon) in apps) list.addView(rowFor(pkg, label, icon))
            }
        }.start()
    }

    private fun rowFor(pkg: String, label: String, icon: android.graphics.drawable.Drawable): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(px(4), px(5), px(4), px(5))
        val iv = ImageView(ctx)
        iv.setImageDrawable(icon)
        r.addView(iv, LinearLayout.LayoutParams(px(30), px(30)))
        val n = TextView(ctx)
        n.text = label
        n.textSize = 12f
        n.setTextColor(Color.WHITE)
        n.maxLines = 1
        n.ellipsize = android.text.TextUtils.TruncateAt.END
        r.addView(n, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = px(10) })
        val c = TextView(ctx)
        c.textSize = 15f
        c.typeface = Typeface.DEFAULT_BOLD
        fun paint() {
            val on = pkg in Popup.list(store)
            c.text = if (on) "✓" else "＋"
            c.setTextColor(if (on) Color.parseColor("#38E8A5") else Hud.cyan)
        }
        paint()
        r.addView(c)
        r.setOnClickListener {
            Sfx.tap()
            Popup.toggle(store, pkg)
            paint()
            onChange()
        }
        return r
    }
}
