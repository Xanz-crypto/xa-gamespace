package com.xa.gamespace

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

// Pop up APK: buka aplikasi lain sebagai jendela mengambang di atas game
object Popup {
    private const val KEY = "popup_apps"

    fun list(s: Store): List<String> = s.get(KEY).split(",").filter { it.isNotBlank() }

    private fun save(s: Store, l: List<String>) = s.put(KEY, l.joinToString(","))

    // true = sekarang terpilih
    fun toggle(s: Store, pkg: String): Boolean {
        val l = list(s).toMutableList()
        return if (l.remove(pkg)) { save(s, l); false } else { l.add(pkg); save(s, l); true }
    }

    private fun waitTask(pkg: String): Int? {
        for (i in 0 until 3) {
            try { Thread.sleep(if (i == 0) 900L else 700L) } catch (e: InterruptedException) {}
            val id = taskIdOf(pkg)
            if (id != null) return id
        }
        return null
    }

    // Cari id task aplikasi dari dumpsys (Android 10-14); utamakan yang mode freeform
    fun taskIdOf(pkg: String): Int? {
        val out = Access.run("dumpsys activity activities | grep -E \"(Task|TaskRecord)\\{\" | grep \"$pkg\"")
        val re = Regex("#(\\d+)\\s[^}]*?" + Regex.escape(pkg))
        val lines = out.lines().filter { it.contains(pkg) }
        val pick = lines.firstOrNull { it.contains("freeform") } ?: lines.firstOrNull() ?: return null
        return re.find(pick)?.groupValues?.get(1)?.toIntOrNull()
    }

    fun resizeTask(id: Int, r: Rect) {
        val a = Access.run("am task resize $id ${r.left} ${r.top} ${r.right} ${r.bottom}")
        if (a.contains("xception") || a.contains("rror") || a.contains("sage")) {
            Access.run("am task resize $id ${r.left},${r.top},${r.right},${r.bottom}")
        }
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val app = ctx.applicationContext
        val li = app.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        val comp = li.component?.flattenToShortString() ?: return false
        if (Access.hasAny()) {
            Thread {
                Access.run("settings put global enable_freeform_support 1; " +
                    "settings put global force_resizable_activities 1; " +
                    "am start --windowingMode 5 -n $comp")
                // cari task jendela pop up lalu pasang kontrol ukuran / posisi
                var id = waitTask(pkg)
                if (id != null) {
                    val dm = app.resources.displayMetrics
                    val w = dm.widthPixels
                    val h = dm.heightPixels
                    val r = Rect(w * 20 / 100, h * 15 / 100, w * 80 / 100, h * 85 / 100)
                    resizeTask(id, r)
                    val name = try {
                        app.packageManager.getApplicationLabel(app.packageManager.getApplicationInfo(pkg, 0)).toString()
                    } catch (e: Exception) { pkg }
                    PopupControl.show(app, name, id, r)
                }
            }.start()
        } else {
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val dm = app.resources.displayMetrics
            val w = dm.widthPixels
            val h = dm.heightPixels
            try {
                val o = ActivityOptions.makeBasic().setLaunchBounds(Rect(w / 4, h / 8, w * 3 / 4, h * 7 / 8))
                app.startActivity(li, o.toBundle())
            } catch (e: Exception) {
                try { app.startActivity(li) } catch (e2: Exception) { return false }
            }
        }
        return true
    }
}

// Daftar semua aplikasi untuk ditambah / dihapus manual dari daftar pop up
class AppPickerView(private val ctx: Context, private val store: Store,
                    private val onChange: () -> Unit, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val list = LinearLayout(ctx)

    private fun px(v: Int) = ctx.px(v)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        root.setPadding(px(12), px(10), px(12), px(10))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(ctx)
        t.text = "TAMBAH APK MANUAL"
        t.textSize = 12f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(Hud.cyan)
        head.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        val x = TextView(ctx)
        x.text = "✕"
        x.textSize = 16f
        x.setTextColor(Color.WHITE)
        x.setPadding(px(10), px(2), px(4), px(2))
        x.setOnClickListener { Sfx.tap(); onClose() }
        head.addView(x)
        root.addView(head)

        val hint = TextView(ctx)
        hint.text = "Ketuk aplikasi untuk menambah (✓) atau menghapus dari daftar Pop Up."
        hint.textSize = 10f
        hint.setTextColor(Hud.sub)
        root.addView(hint, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(2); it.bottomMargin = px(6) })

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val loading = TextView(ctx)
        loading.text = "Memuat aplikasi..."
        loading.textSize = 11f
        loading.setTextColor(Hud.sub)
        list.orientation = LinearLayout.VERTICAL
        list.addView(loading)

        Thread {
            val pm = ctx.packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(q, 0)
                .map { Triple(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .distinctBy { it.first }
                .filter { it.first != ctx.packageName }
                .sortedBy { it.second.lowercase() }
            root.post {
                list.removeAllViews()
                for ((pkg, label, icon) in apps) list.addView(rowFor(pkg, label, icon))
            }
        }.start()
    }

    private fun rowFor(pkg: String, label: String, icon: android.graphics.drawable.Drawable): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(px(4), px(5), px(4), px(5))
        val iv = ImageView(ctx)
        iv.setImageDrawable(icon)
        r.addView(iv, LinearLayout.LayoutParams(px(30), px(30)))
        val n = TextView(ctx)
        n.text = label
        n.textSize = 12f
        n.setTextColor(Color.WHITE)
        n.maxLines = 1
        n.ellipsize = android.text.TextUtils.TruncateAt.END
        r.addView(n, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = px(10) })
        val c = TextView(ctx)
        c.textSize = 15f
        c.typeface = Typeface.DEFAULT_BOLD
        fun paint() {
            val on = pkg in Popup.list(store)
            c.text = if (on) "✓" else "＋"
            c.setTextColor(if (on) Color.parseColor("#38E8A5") else Hud.cyan)
        }
        paint()
        r.addView(c)
        r.setOnClickListener {
            Sfx.tap()
            Popup.toggle(store, pkg)
            paint()
            onChange()
        }
        return r
    }
}

// Kontrol ukuran & posisi jendela pop up: ◀ ▲ ▼ ▶ pindah, − + kecilkan / besarkan, ✕ tutup kontrol
object PopupControl {
    private val ui = Handler(Looper.getMainLooper())
    private var view: View? = null
    private var wm: WindowManager? = null
    private var info: TextView? = null
    private var taskId = 0
    private var label = ""
    private var b = Rect()
    private var sw = 1
    private var sh = 1

    @Suppress("DEPRECATION")
    fun show(ctx: Context, name: String, id: Int, start: Rect) {
        val app = ctx.applicationContext
        ui.post {
            dismissNow()
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(app)) return@post
            val dm = app.resources.displayMetrics
            sw = dm.widthPixels; sh = dm.heightPixels
            taskId = id; label = name; b = Rect(start)
            val w = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager

            val row = LinearLayout(app)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(app.px(8), app.px(5), app.px(8), app.px(5))
            row.background = Hud.rounded(Color.argb(225, 6, 16, 30), Hud.cyan, app.pxf(18f), 1f)

            val t = TextView(app)
            t.textSize = 10f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(Hud.cyan)
            t.setPadding(app.px(4), 0, app.px(8), 0)
            info = t
            row.addView(t)

            fun btn(txt: String, act: () -> Unit) {
                val v = TextView(app)
                v.text = txt
                v.textSize = 15f
                v.gravity = Gravity.CENTER
                v.setTextColor(Color.WHITE)
                v.background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(60, 255, 255, 255), app.pxf(12f), 1f)
                v.setOnClickListener { Sfx.tap(); act() }
                row.addView(v, LinearLayout.LayoutParams(app.px(36), app.px(32)).also { it.leftMargin = app.px(3) })
            }
            btn("◀") { move(-1, 0) }
            btn("▲") { move(0, -1) }
            btn("▼") { move(0, 1) }
            btn("▶") { move(1, 0) }
            btn("－") { scale(0.85f) }
            btn("＋") { scale(1.18f) }
            btn("✕") { dismiss() }

            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(-2, -2, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lp.y = app.px(14)
            try { w.addView(row, lp) } catch (e: Exception) { return@post }
            view = row; wm = w
            refreshInfo()
        }
    }

    private fun refreshInfo() {
        info?.text = "$label · ${b.width() * 100 / sw}%"
    }

    private fun clamp() {
        var dx = 0
        var dy = 0
        if (b.left < 0) dx = -b.left
        if (b.right > sw) dx = sw - b.right
        if (b.top < 0) dy = -b.top
        if (b.bottom > sh) dy = sh - b.bottom
        b.offset(dx, dy)
    }

    private fun apply() {
        refreshInfo()
        val r = Rect(b)
        val id = taskId
        Thread { Popup.resizeTask(id, r) }.start()
    }

    private fun move(dx: Int, dy: Int) {
        b.offset(dx * sw * 8 / 100, dy * sh * 8 / 100)
        clamp()
        apply()
    }

    private fun scale(f: Float) {
        val cx = b.centerX()
        val cy = b.centerY()
        val nw = (b.width() * f).toInt().coerceIn(sw * 25 / 100, sw)
        val nh = (b.height() * f).toInt().coerceIn(sh * 25 / 100, sh)
        b.set(cx - nw / 2, cy - nh / 2, cx + nw / 2, cy + nh / 2)
        clamp()
        apply()
    }

    private fun dismissNow() {
        view?.let { try { wm?.removeView(it) } catch (e: Exception) {} }
        view = null
        info = null
    }

    fun dismiss() { ui.post { dismissNow() } }
}
