package com.xa.gamespace

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class Ui(val c: Context) {
    fun dp(v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun lp(w: Int = -1, h: Int = -2, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    fun bg(color: Int, radius: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    fun grad(c1: Int, c2: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2))
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    fun tint(color: Int, a: Int) = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))

    fun label(t: String, size: Float = 14f, color: Int = Theme.text, bold: Boolean = false): TextView {
        val v = TextView(c)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    fun vbox(): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    fun hbox(): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    fun card(): LinearLayout {
        val l = vbox()
        l.background = bg(Theme.card, 16, Theme.stroke)
        l.setPadding(dp(14), dp(14), dp(14), dp(14))
        l.layoutParams = lp(b = 12)
        return l
    }

    fun cardHeader(icon: String, title: String, sub: String, right: View? = null): LinearLayout {
        val h = hbox()
        val ic = label(icon, 18f)
        ic.gravity = Gravity.CENTER
        ic.background = bg(Theme.tile, 12, Theme.stroke)
        h.addView(ic, lp(dp(40), dp(40), r = 12))
        val t = vbox()
        t.addView(label(title, 15f, Theme.text, true))
        if (sub.isNotEmpty()) {
            val s = label(sub, 11f, Theme.sub)
            s.maxLines = 2
            t.addView(s)
        }
        h.addView(t, lp(0, -2, 1f))
        if (right != null) h.addView(right, lp(-2, -2, l = 8))
        return h
    }

    fun tile(title: String, value: String, color: Int = Theme.text, bare: Boolean = false): Pair<LinearLayout, TextView> {
        val l = vbox()
        l.gravity = Gravity.CENTER
        if (!bare) {
            l.background = bg(Theme.tile, 12, Theme.stroke)
            l.setPadding(dp(6), dp(10), dp(6), dp(10))
        }
        val t = label(title, 10f, Theme.sub)
        t.gravity = Gravity.CENTER
        val v = label(value, if (bare) 14f else 15f, color, true)
        v.gravity = Gravity.CENTER
        v.maxLines = 1
        l.addView(t)
        l.addView(v, lp(-2, -2, t = 3))
        return l to v
    }

    fun row(vararg v: View): LinearLayout {
        val r = hbox()
        v.forEachIndexed { i, x -> r.addView(x, lp(0, -2, 1f, l = if (i == 0) 0 else 6)) }
        return r
    }

    fun setPill(v: TextView, t: String, color: Int) {
        v.text = t
        v.setTextColor(color)
        v.background = bg(tint(color, 28), 20, tint(color, 90))
    }

    fun pill(t: String, color: Int): TextView {
        val v = label(t, 10f, color, true)
        setPill(v, t, color)
        v.setPadding(dp(10), dp(4), dp(10), dp(4))
        return v
    }

    fun gradBtn(t: String, onClick: () -> Unit): TextView {
        val v = label(t, 15f, Theme.onAccent, true)
        v.gravity = Gravity.CENTER
        v.background = grad(Theme.accent, Theme.accent2, 14)
        v.setPadding(dp(16), dp(14), dp(16), dp(14))
        v.setOnClickListener { onClick() }
        return v
    }

    fun ghostBtn(t: String, onClick: () -> Unit): TextView {
        val v = label(t, 14f, Theme.accent, true)
        v.gravity = Gravity.CENTER
        v.background = bg(Theme.tile, 14, Theme.stroke)
        v.setPadding(dp(14), dp(12), dp(14), dp(12))
        v.setOnClickListener { onClick() }
        return v
    }

    fun section(t: String): TextView {
        val v = label(t.uppercase(), 11f, Theme.sub, true)
        v.setPadding(dp(4), dp(6), 0, dp(8))
        return v
    }

    fun switchRow(title: String, desc: String, on: Boolean, cb: (Boolean) -> Unit): LinearLayout {
        val r = hbox()
        r.setPadding(0, dp(8), 0, dp(8))
        val l = vbox()
        l.addView(label(title, 14f))
        if (desc.isNotEmpty()) l.addView(label(desc, 11f, Theme.sub))
        r.addView(l, lp(0, -2, 1f, r = 10))
        r.addView(Toggle(c, on, cb))
        return r
    }

    fun slider(title: String, min: Int, max: Int, value: Int, fmt: (Int) -> String, cb: (Int) -> Unit): LinearLayout {
        val l = vbox()
        l.setPadding(0, dp(8), 0, dp(8))
        val h = hbox()
        val tv = label(fmt(value), 13f, Theme.accent, true)
        h.addView(label(title, 14f), lp(0, -2, 1f))
        h.addView(tv)
        val sb = SeekBar(c)
        sb.max = max - min
        sb.progress = value - min
        sb.progressTintList = ColorStateList.valueOf(Theme.accent)
        sb.thumbTintList = ColorStateList.valueOf(Theme.accent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { tv.text = fmt(p + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { cb(sb.progress + min) }
        })
        l.addView(h)
        l.addView(sb)
        return l
    }

    fun segmented(opts: List<String>, sel: Int, cb: (Int) -> Unit): LinearLayout {
        val r = hbox()
        r.background = bg(Theme.tile, 12, Theme.stroke)
        r.setPadding(dp(3), dp(3), dp(3), dp(3))
        val tvs = ArrayList<TextView>()
        fun paint(s: Int) {
            tvs.forEachIndexed { i, t ->
                if (i == s) {
                    t.background = grad(Theme.accent, Theme.accent2, 9)
                    t.setTextColor(Theme.onAccent)
                } else {
                    t.background = null
                    t.setTextColor(Theme.sub)
                }
            }
        }
        opts.forEachIndexed { i, o ->
            val t = label(o, 12f, Theme.sub, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(9), 0, dp(9))
            t.setOnClickListener { paint(i); cb(i) }
            tvs.add(t)
            r.addView(t, lp(0, -2, 1f))
        }
        paint(sel)
        return r
    }

    fun dominant(d: Drawable): Int {
        return try {
            val b = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 8, 8)
            d.draw(Canvas(b))
            var r = 0L
            var g = 0L
            var bl = 0L
            var n = 0
            for (x in 0 until 8) for (y in 0 until 8) {
                val px = b.getPixel(x, y)
                if (Color.alpha(px) > 128) {
                    r += Color.red(px); g += Color.green(px); bl += Color.blue(px); n++
                }
            }
            if (n == 0) Theme.accent else {
                val hsv = FloatArray(3)
                Color.RGBToHSV((r / n).toInt(), (g / n).toInt(), (bl / n).toInt(), hsv)
                hsv[1] = hsv[1].coerceAtLeast(0.5f)
                hsv[2] = hsv[2].coerceIn(0.45f, 0.8f)
                Color.HSVToColor(hsv)
            }
        } catch (e: Exception) {
            Theme.accent
        }
    }

    fun appLabel(pkg: String): String = try {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    fun gameCard(pkg: String, selected: Boolean, mode: String, w: Int, h: Int, onTap: () -> Unit, onMode: () -> Unit): LinearLayout {
        val pm = c.packageManager
        var icon: Drawable? = null
        try { icon = pm.getApplicationIcon(pkg) } catch (e: Exception) {}
        val col = if (icon != null) dominant(icon) else Theme.accent
        val l = vbox()
        l.setPadding(dp(12), dp(12), dp(12), dp(12))
        val g = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(tint(col, 210), Theme.card))
        g.cornerRadius = dp(16).toFloat()
        g.setStroke(dp(if (selected) 2 else 1), if (selected) Theme.accent else Theme.stroke)
        l.background = g
        val top = hbox()
        val iv = ImageView(c)
        if (icon != null) iv.setImageDrawable(icon)
        top.addView(iv, lp(dp(46), dp(46)))
        top.addView(View(c), lp(0, 1, 1f))
        if (selected) {
            val ck = label("✓", 14f, Theme.onAccent, true)
            ck.gravity = Gravity.CENTER
            ck.background = bg(Theme.accent, 20)
            top.addView(ck, lp(dp(26), dp(26)))
        }
        l.addView(top)
        l.addView(View(c), lp(-1, 0, 1f))
        val name = label(appLabel(pkg), 15f, Color.WHITE, true)
        name.maxLines = 1
        l.addView(name)
        val mp = pill("MODE  " + mode.uppercase(), Theme.accent)
        mp.setOnClickListener { onMode() }
        l.addView(mp, lp(-2, -2, t = 6))
        l.setOnClickListener { onTap() }
        l.layoutParams = lp(w, h)
        return l
    }
}
