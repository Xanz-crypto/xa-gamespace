package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object Theme {
    val accent = Color.parseColor("#FF7A3D")
    val accent2 = Color.parseColor("#FFC15A")
    val sub = Color.parseColor("#B8BCCB")
    val good = Color.parseColor("#38E8A5")
    val bad = Color.parseColor("#FF5470")
    val warn = Color.parseColor("#FFC24B")
}

class Ui(val c: Context) {
    fun dp(v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun lp(w: Int = -1, h: Int = -2, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    fun glass(radius: Int = 16, fill: Int = Color.argb(150, 10, 12, 18), stroke: Int = Color.argb(70, 255, 255, 255)): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radius).toFloat()
        g.setStroke(dp(1), stroke)
        return g
    }

    fun label(t: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(c)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    fun vbox(): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    fun hbox(): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    fun btn(text: String, primary: Boolean = false, onClick: () -> Unit): TextView {
        val t = label(text, 12f, if (primary) Color.parseColor("#1A0C04") else Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        t.background = if (primary) {
            val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Theme.accent, Theme.accent2))
            g.cornerRadius = dp(12).toFloat()
            g
        } else glass(12, Color.argb(120, 255, 255, 255), Color.argb(60, 255, 255, 255))
        t.setOnClickListener { Sfx.tap(); onClick() }
        return t
    }

    fun chip(text: String, color: Int): TextView {
        val t = label(text, 11f, color, true)
        t.setPadding(dp(10), dp(5), dp(10), dp(5))
        t.background = glass(20, Color.argb(130, 8, 9, 14), color and 0x00FFFFFF or (0x90 shl 24))
        return t
    }

    fun space(): View = View(c)
}
