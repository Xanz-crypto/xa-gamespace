package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

fun Context.px(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.pxf(v: Float): Float = v * resources.displayMetrics.density

object Hud {
    val cyan = Color.parseColor("#3CC8FF")
    val cyanDim = Color.argb(120, 60, 200, 255)
    val dark1 = Color.parseColor("#0F2A48")
    val dark2 = Color.parseColor("#071322")
    val sub = Color.parseColor("#9FB8D0")

    // handle panel: garis bercahaya di tepi layar (jendela sentuh dp)
    const val HANDLE_W = 40      // lebar jendela handle
    const val HANDLE_H = 130     // tinggi jendela handle
    const val HANDLE_HALF = 44   // setengah panjang garis
    const val HANDLE_INSET = 5   // jarak garis dari tepi layar

    fun rounded(fill: Int, stroke: Int, radius: Float, sw: Float = 1f): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = radius
        g.setStroke(sw.toInt().coerceAtLeast(1), stroke)
        return g
    }
}

// ============ Tile heksagon (ikon fitur) ============
class HexTile(c: Context, private val glyph: String, private val label: String, private val badge: Boolean = false) : View(c) {
    var on = false
        set(v) { field = v; invalidate() }
    var tag: String? = null
    var tagOk = true

    override fun performClick(): Boolean {
        Sfx.tap()
        return super.performClick()
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = c.pxf(1.6f) }
    private val gl = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = c.pxf(20f); color = Color.WHITE }
    private val lb = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; textSize = c.pxf(10f); typeface = Typeface.DEFAULT_BOLD
    }
    private val bd = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hex = Path()

    init { isClickable = true }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(context.px(64), context.px(90))
    }

    override fun drawableStateChanged() {
        super.drawableStateChanged()
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = context.pxf(28f)
        val r = context.pxf(25f) * (if (isPressed) 0.9f else 1f)
        hex.reset()
        for (i in 0 until 6) {
            val a = Math.toRadians(60.0 * i - 90.0)
            val x = cx + (r * cos(a)).toFloat()
            val y = cy + (r * sin(a)).toFloat()
            if (i == 0) hex.moveTo(x, y) else hex.lineTo(x, y)
        }
        hex.close()
        fill.color = if (on) Color.argb(160, 40, 170, 230) else Color.argb(160, 10, 28, 50)
        cv.drawPath(hex, fill)
        if (on) {
            val pulse = 0.65f + 0.35f * sin(animNow() * 3f)
            val gc = Wet.cycle(animNow(), 7f)
            stroke.strokeWidth = context.pxf(6f)
            stroke.color = Color.argb((90 * pulse).toInt(), Color.red(gc), Color.green(gc), Color.blue(gc))
            cv.drawPath(hex, stroke)
            stroke.strokeWidth = context.pxf(1.6f)
            postInvalidateDelayed(60)
        }
        stroke.color = if (on) Hud.cyan else Hud.cyanDim
        cv.drawPath(hex, stroke)
        cv.drawText(glyph, cx, cy - (gl.ascent() + gl.descent()) / 2f, gl)
        lb.color = if (on) Hud.cyan else Color.WHITE
        cv.drawText(label, cx, context.pxf(70f), lb)
        tag?.let {
            val tp = Paint(Paint.ANTI_ALIAS_FLAG)
            tp.textAlign = Paint.Align.CENTER
            tp.textSize = context.pxf(7.5f)
            tp.typeface = Typeface.DEFAULT_BOLD
            tp.color = if (tagOk) Color.parseColor("#38E8A5") else Color.parseColor("#FFC24B")
            cv.drawText(it + if (tagOk) "" else " !", cx, context.pxf(83f), tp)
        }
        if (badge) {
            val bx = cx + r * 0.85f
            val by = cy - r * 0.85f
            val br = context.pxf(8f)
            bd.style = Paint.Style.FILL
            bd.color = if (on) Hud.cyan else Color.parseColor("#0A1C30")
            cv.drawCircle(bx, by, br, bd)
            bd.style = Paint.Style.STROKE
            bd.strokeWidth = context.pxf(1f)
            bd.color = Hud.cyan
            cv.drawCircle(bx, by, br, bd)
            val t = Paint(Paint.ANTI_ALIAS_FLAG)
            t.textAlign = Paint.Align.CENTER
            t.textSize = context.pxf(10f)
            t.typeface = Typeface.DEFAULT_BOLD
            t.color = if (on) Color.parseColor("#04141F") else Hud.cyan
            cv.drawText(if (on) "✓" else "+", bx, by - (t.ascent() + t.descent()) / 2f, t)
        }
    }
}

// ============ Bar status (RAM / CPU / suhu) ============
class StatBar(c: Context, private val name: String, private val suffix: String = "%", private val maxV: Float = 100f) : View(c) {
    private var v = 0f
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = c.pxf(11f); typeface = Typeface.DEFAULT_BOLD }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(value: Float) { v = value; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(context.px(120), context.px(30))
    }

    override fun onDraw(cv: Canvas) {
        t.color = Hud.cyan
        t.textAlign = Paint.Align.LEFT
        cv.drawText(name, 0f, context.pxf(11f), t)
        t.color = Color.WHITE
        t.textAlign = Paint.Align.RIGHT
        cv.drawText("${v.toInt()}$suffix", width.toFloat(), context.pxf(11f), t)
        val n = 12
        val gap = context.pxf(2f)
        val sw = (width - gap * (n - 1)) / n
        val filled = ((v / maxV).coerceIn(0f, 1f) * n + 0.5f).toInt()
        for (i in 0 until n) {
            p.color = if (i < filled) Hud.cyan else Color.argb(50, 120, 200, 255)
            val l = i * (sw + gap)
            cv.drawRect(l, context.pxf(18f), l + sw, context.pxf(24f), p)
        }
    }
}

// ============ Gauge melingkar ============
class GaugeView(c: Context, var caption: String) : View(c) {
    private var value = 0f
    private var max = 120f
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = c.pxf(7f); strokeCap = Paint.Cap.ROUND; color = Color.argb(60, 120, 200, 255)
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = c.pxf(7f); strokeCap = Paint.Cap.ROUND; color = Hud.cyan
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; textSize = c.pxf(28f); typeface = Typeface.DEFAULT_BOLD; color = Color.WHITE
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; textSize = c.pxf(9f); typeface = Typeface.DEFAULT_BOLD; color = Hud.sub
    }
    private val rect = RectF()

    fun set(v: Float, m: Float) { value = v; max = m; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(context.px(96), context.px(96))
    }

    override fun onDraw(cv: Canvas) {
        val i = context.pxf(8f)
        rect.set(i, i, width - i, height - i)
        cv.drawArc(rect, 135f, 270f, false, track)
        val sweep = 270f * (value / max).coerceIn(0f, 1f)
        if (sweep > 0f) cv.drawArc(rect, 135f, sweep, false, arc)
        val cy = height / 2f
        cv.drawText(value.toInt().toString(), width / 2f, cy + context.pxf(6f), big)
        cv.drawText(caption, width / 2f, cy + context.pxf(26f), small)
    }
}

// ============ Bingkai panel (sudut terpotong ala HUD, tepinya bercahaya) ============
class HudFrame(c: Context) : FrameLayout(c) {
    private val path = Path()
    private val seg = Path()
    private val pm = PathMeasure()
    private var len = 1f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = c.pxf(2f); color = Hud.cyan }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = c.pxf(8f); color = Color.argb(45, 60, 200, 255) }
    private val comet = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val tab = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Hud.cyan }

    init { setWillNotDraw(false) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val i = context.pxf(3f)
        val c = context.pxf(30f)
        val W = w.toFloat()
        val H = h.toFloat()
        path.reset()
        path.moveTo(c, i)
        path.lineTo(W - c, i)
        path.lineTo(W - i, c)
        path.lineTo(W - i, H - c)
        path.lineTo(W - c, H - i)
        path.lineTo(c, H - i)
        path.lineTo(i, H - c)
        path.lineTo(i, c)
        path.close()
        pm.setPath(path, true)
        len = pm.length.coerceAtLeast(1f)
        fill.shader = LinearGradient(0f, 0f, 0f, H, Color.argb(225, 15, 42, 72), Color.argb(235, 7, 19, 34), Shader.TileMode.CLAMP)
    }

    private fun part(cv: Canvas, a: Float, b: Float, p: Paint) {
        if (b <= a) return
        seg.reset()
        pm.getSegment(a, b, seg, true)
        cv.drawPath(seg, p)
    }

    private fun arc(cv: Canvas, a: Float, b: Float, p: Paint) {
        if (a < 0f) { part(cv, a + len, len, p); part(cv, 0f, b, p) } else part(cv, a, b, p)
    }

    override fun onDraw(cv: Canvas) {
        val now = animNow()
        val col = Wet.cycle(now, 10f)
        val pulse = 0.6f + 0.4f * sin(now * 2f)
        val r = Color.red(col); val g = Color.green(col); val b = Color.blue(col)

        cv.drawPath(path, fill)
        glow.color = Color.argb((60 + 70 * pulse).toInt(), r, g, b)
        cv.drawPath(path, glow)
        line.color = Wet.mix(Hud.cyan, col, 0.55f)
        cv.drawPath(path, line)

        // kilat cahaya yang berlari mengelilingi tepi panel
        val head = ((now * 0.2f) % 1f) * len
        val seglen = len * 0.035f
        for (k in 0 until 6) {
            val a = 1f - k / 6f
            comet.strokeWidth = context.pxf(8f) * a
            comet.color = Color.argb((80 * a).toInt(), r, g, b)
            arc(cv, head - (k + 1) * seglen, head - k * seglen, comet)
            comet.strokeWidth = context.pxf(2.6f)
            comet.color = Color.argb((255 * a).toInt(), 235, 250, 255)
            arc(cv, head - (k + 1) * seglen, head - k * seglen, comet)
        }

        val th = context.pxf(26f)
        val tw = context.pxf(5f)
        tab.color = line.color
        cv.drawRect(0f, height / 2f - th, tw, height / 2f + th, tab)
        cv.drawRect(width - tw, height / 2f - th, width.toFloat(), height / 2f + th, tab)
        if (isAttachedToWindow) postInvalidateDelayed(33)
    }
}

// ============ Tab geser drawer (sisi kanan panel) ============
class TabView(c: Context) : View(c) {
    var open = false
        set(v) { field = v; invalidate() }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 60, 200, 255) }
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; textSize = c.pxf(18f); typeface = Typeface.DEFAULT_BOLD; color = Color.parseColor("#04141F")
    }

    override fun onDraw(cv: Canvas) {
        val h = context.pxf(70f)
        val r = RectF(context.pxf(3f), height / 2f - h, width.toFloat() - context.pxf(3f), height / 2f + h)
        cv.drawRoundRect(r, context.pxf(6f), context.pxf(6f), bar)
        val cy = height / 2f
        cv.drawText(if (open) "›" else "‹", width / 2f, cy - (t.ascent() + t.descent()) / 2f, t)
    }
}

// ============ Pill ON / OFF ============
class Pill(c: Context) : TextView(c) {
    var on = false
        private set
    var onToggle: ((Boolean) -> Unit)? = null

    init {
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(c.px(12), c.px(5), c.px(12), c.px(5))
        setOn(false)
        setOnClickListener {
            Sfx.tap()
            setOn(!on)
            onToggle?.invoke(on)
        }
    }

    fun setOn(v: Boolean) {
        on = v
        text = if (v) "ON" else "OFF"
        setTextColor(if (v) Color.parseColor("#04141F") else Hud.sub)
        background = Hud.rounded(if (v) Hud.cyan else Color.argb(60, 255, 255, 255), Hud.cyanDim, context.pxf(12f), 1f)
    }
}

// ============ Animasi masuk game: X -> garis di sisi layar ============
class EntryAnimView(c: Context, private val endX: Float, private val endHalf: Float) : View(c) {
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = c.pxf(2f) }
    private var t = 0f
    private var anim: ValueAnimator? = null

    fun start(onEnd: () -> Unit) {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 2100
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { t = it.animatedValue as Float; invalidate() }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onEnd() }
        })
        anim = a
        a.start()
    }

    fun cancel() { anim?.cancel() }

    private fun lerp(a: Float, b: Float, m: Float) = a + (b - a) * m

    override fun onDraw(cv: Canvas) {
        val W = width.toFloat()
        val H = height.toFloat()
        val L = context.pxf(58f)
        var cx = W / 2f
        var cy = H / 2f
        var half = L
        var a1 = 45f
        var a2 = -45f
        var alpha = 1f
        var wd = context.pxf(5f)

        if (t < 0.28f) {
            val g = t / 0.28f
            val e = 1f - (1f - g) * (1f - g)
            half = L * e
            alpha = e
            ring.color = Color.argb((160 * (1f - e)).toInt(), 60, 200, 255)
            cv.drawCircle(cx, cy, L * 2.2f * e, ring)
        } else if (t < 0.5f) {
            val p = (t - 0.28f) / 0.22f
            half = L * (1f + 0.07f * sin(p * 2f * PI.toFloat()))
        } else {
            val x = (t - 0.5f) / 0.5f
            val m = x * x * (3f - 2f * x)
            cx = lerp(W / 2f, endX, m)
            cy = lerp(H / 2f, H / 2f, m)
            half = lerp(L, endHalf, m)
            a1 = lerp(45f, 90f, m)
            a2 = lerp(-45f, -90f, m)
            wd = lerp(context.pxf(5f), context.pxf(3f), m)
        }

        glow.strokeWidth = wd * 3.6f
        glow.color = Color.argb((70 * alpha).toInt(), 60, 200, 255)
        core.strokeWidth = wd
        core.color = Color.argb((255 * alpha).toInt(), 60, 200, 255)
        for (ang in floatArrayOf(a1, a2)) {
            val r = Math.toRadians(ang.toDouble())
            val dx = (cos(r) * half).toFloat()
            val dy = (sin(r) * half).toFloat()
            cv.drawLine(cx - dx, cy - dy, cx + dx, cy + dy, glow)
            cv.drawLine(cx - dx, cy - dy, cx + dx, cy + dy, core)
        }
    }
}

// ============ Handle panel: garis bercahaya di tepi layar, bisa dipindah-pindah ============
class HandleView(c: Context) : View(c) {
    private val store = Store(c)
    private var anim: ValueAnimator? = null
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val chev = Path()

    // true saat handle sedang diangkat untuk dipindah
    var held = false
        set(v) { field = v; invalidate() }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1000
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { invalidate() }
        anim = a
        a.start()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val t = animNow()
        val left = store.handleSide == 0
        val inset = context.pxf(Hud.HANDLE_INSET.toFloat())
        val x = if (held) width / 2f else if (left) inset else width - inset
        val cy = height / 2f
        val half = context.pxf(Hud.HANDLE_HALF.toFloat()) * (if (held) 1.15f else 1f)
        val col = Wet.cycle(t, 6f)
        val r = Color.red(col); val g = Color.green(col); val b = Color.blue(col)
        val pulse = 0.6f + 0.4f * sin(t * 3f)
        val k = if (held) 1.5f else 1f

        // cahaya berwarna di sekeliling garis
        stroke.color = Color.argb((70 * pulse * k).toInt().coerceAtMost(255), r, g, b)
        stroke.strokeWidth = context.pxf(9f) * k
        cv.drawLine(x, cy - half, x, cy + half, stroke)
        stroke.color = Color.argb((150 * k).toInt().coerceAtMost(255), r, g, b)
        stroke.strokeWidth = context.pxf(5f)
        cv.drawLine(x, cy - half, x, cy + half, stroke)
        stroke.color = Color.argb(245, 235, 250, 255)
        stroke.strokeWidth = context.pxf(2.6f)
        cv.drawLine(x, cy - half, x, cy + half, stroke)

        // titik cahaya yang berlari naik-turun di sepanjang garis
        val ry = cy + sin(t * 2.2f) * half * 0.85f
        dotP.color = Color.argb(110, r, g, b)
        cv.drawCircle(x, ry, context.pxf(5f), dotP)
        dotP.color = Color.WHITE
        cv.drawCircle(x, ry, context.pxf(2.2f), dotP)

        // tanda panah kecil: geser ke arah dalam untuk membuka panel
        val dir = if (left) 1f else -1f
        val cx = x + dir * (context.pxf(12f) + context.pxf(3f) * sin(t * 4f))
        chev.reset()
        chev.moveTo(cx - dir * context.pxf(3f), cy - context.pxf(5f))
        chev.lineTo(cx + dir * context.pxf(2f), cy)
        chev.lineTo(cx - dir * context.pxf(3f), cy + context.pxf(5f))
        stroke.color = Color.argb((230 * (0.4f + 0.6f * pulse)).toInt(), 255, 255, 255)
        stroke.strokeWidth = context.pxf(1.8f)
        cv.drawPath(chev, stroke)
    }
}

// ============ Crosshair ============
class CrosshairView(c: Context, var kind: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val f = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(context.px(80), context.px(80))
    }

    private fun line(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        p.color = Color.argb(160, 0, 0, 0); p.strokeWidth = context.pxf(4f)
        cv.drawLine(x1, y1, x2, y2, p)
        p.color = Color.parseColor("#FF3B3B"); p.strokeWidth = context.pxf(2f)
        cv.drawLine(x1, y1, x2, y2, p)
    }

    private fun dot(cv: Canvas, cx: Float, cy: Float, r: Float) {
        f.color = Color.argb(160, 0, 0, 0)
        cv.drawCircle(cx, cy, r + context.pxf(1.5f), f)
        f.color = Color.parseColor("#FF3B3B")
        cv.drawCircle(cx, cy, r, f)
    }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val gap = context.pxf(5f)
        val len = context.pxf(16f)
        when (kind % 4) {
            0 -> {
                line(cv, cx - len - gap, cy, cx - gap, cy)
                line(cv, cx + gap, cy, cx + len + gap, cy)
                line(cv, cx, cy - len - gap, cx, cy - gap)
                line(cv, cx, cy + gap, cx, cy + len + gap)
            }
            1 -> {
                p.color = Color.argb(160, 0, 0, 0); p.strokeWidth = context.pxf(4f)
                cv.drawCircle(cx, cy, context.pxf(14f), p)
                p.color = Color.parseColor("#FF3B3B"); p.strokeWidth = context.pxf(2f)
                cv.drawCircle(cx, cy, context.pxf(14f), p)
                dot(cv, cx, cy, context.pxf(2.5f))
            }
            2 -> dot(cv, cx, cy, context.pxf(3.5f))
            else -> {
                line(cv, cx - len, cy, cx - gap * 2, cy)
                line(cv, cx + gap * 2, cy, cx + len, cy)
                line(cv, cx, cy + gap * 2, cx, cy + len)
                dot(cv, cx, cy, context.pxf(2f))
            }
        }
    }
}
