package com.xa.gamespace

import android.widget.LinearLayout
import android.widget.ScrollView

class MusicPanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box = u.vbox()

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        build()
    }

    private fun redraw() { a.updateMusicLabel(); build() }

    private fun build() {
        box.removeAllViews()
        val cur = if (Music.list.isEmpty()) "-" else Music.title(a, Music.list[Music.idx])
        val status = if (Music.isPlaying()) "▶ Sedang diputar" else "■ Berhenti"
        box.addView(u.label("SEKARANG", 11f, Theme.sub, true), u.lp(-1, -2))
        box.addView(u.label(cur, 16f, Hud.cyan, true), u.lp(-1, -2, t = 2))
        box.addView(u.label(status, 11f, Theme.sub), u.lp(-1, -2, t = 2, b = 10))

        // kontrol utama
        val row = u.hbox()
        row.addView(u.btn("⏮") { Music.prev(a); redraw() }, u.lp(0, -2, 1f, r = 6))
        row.addView(u.btn(if (Music.isPlaying()) "⏸" else "▶", true) { Music.toggle(a); redraw() }, u.lp(0, -2, 1f, r = 6))
        row.addView(u.btn("⏭") { Music.next(a); redraw() }, u.lp(0, -2, 1f))
        box.addView(row, u.lp(-1, -2, b = 10))

        // pengaturan: musik on/off, ulangi, acak
        box.addView(u.btn("Musik: " + if (Music.on) "ON" else "OFF") { Music.setOn(a, !Music.on); redraw() }, u.lp(-1, -2, b = 6))
        val repLabel = when (Music.repeat) { 1 -> "Ulangi: Satu lagu"; 2 -> "Ulangi: Semua"; else -> "Ulangi: Mati" }
        box.addView(u.btn(repLabel) { Music.setRepeat(a, (Music.repeat + 1) % 3); redraw() }, u.lp(-1, -2, b = 6))
        box.addView(u.btn("Acak: " + if (Music.shuffle) "ON" else "OFF") { Music.setShuffle(a, !Music.shuffle); redraw() }, u.lp(-1, -2, b = 6))

        // playlist
        box.addView(u.label("PLAYLIST (${Music.list.size})", 12f, Hud.cyan, true), u.lp(-1, -2, t = 12, b = 4))
        box.addView(u.btn("+ Tambah lagu dari HP") { a.pickSong() }, u.lp(-1, -2, b = 6))
        Music.list.forEachIndexed { i, uri ->
            val r = u.hbox()
            val mark = if (i == Music.idx) "▶  " else "    "
            r.addView(u.btn(mark + Music.title(a, uri)) { Music.play(a, i); redraw() }, u.lp(0, -2, 1f, r = 6))
            if (i > 0) r.addView(u.btn("✕") { Music.remove(a, i); redraw() }, u.lp(-2, -2))
            box.addView(r, u.lp(-1, -2, b = 6))
        }

        // AI Auto di paling bawah panel
        box.addView(u.label("AI", 12f, Hud.cyan, true), u.lp(-1, -2, t = 14, b = 4))
        box.addView(u.btn("AI Auto: " + if (Music.aiAuto) "ON" else "OFF", Music.aiAuto) { Music.setAi(a, !Music.aiAuto); redraw() }, u.lp(-1, -2))
        box.addView(u.label("Lagu berikutnya dipilih otomatis dari yang belum sering diputar.", 11f, Theme.sub), u.lp(-1, -2, t = 4))
    }
}
