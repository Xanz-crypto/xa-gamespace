package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.VideoView

// Warna gaya Spotify
object Spot {
    val BG: Int = Color.parseColor("#121212")
    val HIGH: Int = Color.parseColor("#282828")
    val TRACK: Int = Color.parseColor("#4D4D4D")
    val GREEN: Int = Color.parseColor("#1DB954")
    val SUB: Int = Color.parseColor("#B3B3B3")
    val WHITE: Int = Color.parseColor("#FFFFFF")
    val COVERS = listOf("#1DB954", "#E8115B", "#8D67AB", "#F59B23", "#2E77D0", "#E13300")
}

// Equalizer hijau: bergerak hanya saat musik diputar
class EqView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Spot.GREEN }
    private val rect = RectF()
    override fun onDraw(cv: Canvas) {
        val playing = Music.isPlaying()
        val t = System.currentTimeMillis() / 1000.0
        val n = 3
        val gap = width * 0.18f
        val bw = (width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val wave = Math.abs(Math.sin(t * 5.0 + i * 1.7)).toFloat()
            val h = if (playing) height * (0.35f + 0.65f * wave) else height * 0.3f
            val x = i * (bw + gap)
            rect.set(x, height - h, x + bw, height.toFloat())
            cv.drawRoundRect(rect, bw / 2, bw / 2, p)
        }
        if (playing) postInvalidateOnAnimation()
    }
}

// Progress bar bergaya Spotify: bisa digeser untuk pindah posisi
class SeekView(ctx: Context, private val onSeek: (Float) -> Unit) : View(ctx) {
    var progress = 0f
    var dragging = false
    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Spot.TRACK }
    private val fgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Spot.GREEN }
    private val knobP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Spot.WHITE }
    private val r = RectF()

    private fun dpF(v: Float) = v * resources.displayMetrics.density

    override fun onDraw(cv: Canvas) {
        val h = dpF(4f)
        val cy = height / 2f
        r.set(0f, cy - h / 2, width.toFloat(), cy + h / 2)
        cv.drawRoundRect(r, h, h, bgP)
        val x = width * progress.coerceIn(0f, 1f)
        r.set(0f, cy - h / 2, x, cy + h / 2)
        cv.drawRoundRect(r, h, h, fgP)
        cv.drawCircle(x, cy, dpF(6f), knobP)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                dragging = true
                progress = (e.x / width).coerceIn(0f, 1f)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                onSeek(progress)
            }
        }
        return true
    }
}

class MusicPanel(
    private val a: Context,
    private val pick: (String) -> Unit,
    private val newPlaylist: () -> Unit
) {
    private val d = a.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    // kiri: pemutar (tetap, tidak ikut digeser). kanan: video di atas, daftar lagu di bawah (yang bisa digeser)
    val root = LinearLayout(a).apply {
        orientation = LinearLayout.HORIZONTAL
        // latar solid dengan sudut membulat: tidak tembus ke menu di belakangnya
        background = GradientDrawable().apply {
            setColor(Spot.BG)
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.parseColor("#1DB954"))
        }
        clipToOutline = true
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }
    private val left = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private val right = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private val listBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private var seek: SeekView? = null
    private var tPos: TextView? = null
    private var tDur: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            if (Music.isPlaying()) root.postDelayed(this, 500)
        }
    }

    init {
        left.gravity = Gravity.CENTER_VERTICAL
        root.addView(left, LinearLayout.LayoutParams(0, -1, 0.38f).also { it.rightMargin = dp(12) })
        root.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {}
            override fun onViewDetachedFromWindow(v: View) { root.removeCallbacks(tick) }
        })
        root.addView(right, LinearLayout.LayoutParams(0, -1, 0.58f))

        // video dance di kanan atas (diam, tidak ikut digeser)
        val frame = FrameLayout(a).apply {
            background = rr(Color.BLACK, dp(14).toFloat())
            clipToOutline = true
        }
        val vv = VideoView(a)
        val rid = a.resources.getIdentifier("poster", "raw", a.packageName)
        vv.setVideoURI(Uri.parse("android.resource://${a.packageName}/$rid"))
        vv.setOnPreparedListener { mp ->
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            vv.start()
        }
        frame.addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        right.addView(frame, LinearLayout.LayoutParams(-1, dp(110)).also { it.bottomMargin = dp(6) })

        // daftar lagu: hanya bagian ini yang bisa digeser
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(listBox)
        right.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        refresh()
    }

    fun refresh() {
        buildLeft()
        buildList()
    }

    private fun redraw() = refresh()

    private fun lp(w: Int, h: Int, t: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h).also { it.topMargin = dp(t); it.bottomMargin = dp(b) }

    private fun lpW(r: Int = 0) = LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = dp(r) }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(a).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
    }

    private fun rr(fill: Int, radius: Float, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun icon(t: String, size: Float, color: Int, onTap: () -> Unit) = TextView(a).apply {
        text = t
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(dp(6), dp(8), dp(6), dp(8))
        setOnClickListener { onTap() }
    }

    private fun pill(t: String, on: Boolean, onTap: () -> Unit) = TextView(a).apply {
        text = t
        textSize = 12f
        setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
        setTextColor(if (on) Color.BLACK else Spot.WHITE)
        gravity = Gravity.CENTER
        background = rr(if (on) Spot.GREEN else Spot.HIGH, dp(20).toFloat())
        setPadding(dp(14), dp(7), dp(14), dp(7))
        setOnClickListener { onTap() }
    }

    // sampul sederhana: huruf pertama di atas gradasi warna
    private fun cover(title: String, px: Int) = TextView(a).apply {
        text = title.firstOrNull()?.uppercase() ?: "♪"
        textSize = px / d * 0.42f
        setTextColor(Spot.WHITE)
        gravity = Gravity.CENTER
        setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
        val c = Color.parseColor(Spot.COVERS[Math.abs(title.hashCode()) % Spot.COVERS.size])
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c, Color.BLACK)).apply {
            cornerRadius = dp(8).toFloat()
        }
    }

    private fun fmt(ms: Int): String {
        val s = ms.coerceAtLeast(0) / 1000
        return String.format("%d:%02d", s / 60, s % 60)
    }

    private fun updateProgress() {
        val dur = Music.duration().coerceAtLeast(1)
        val pos = Music.position()
        seek?.let { if (!it.dragging) { it.progress = pos.toFloat() / dur; it.invalidate() } }
        tPos?.text = fmt(pos)
        tDur?.text = fmt(Music.duration())
    }

    // ===== kiri: pemutar =====
    private fun buildLeft() {
        root.removeCallbacks(tick)
        left.removeAllViews()
        val cur = Music.list.getOrNull(Music.idx)
        val title = if (cur == null) "Belum ada lagu" else Music.title(a, cur)
        val playing = Music.isPlaying()

        left.addView(label("SEKARANG DIPUTAR", 9f, Spot.SUB, true), lp(-2, -2, b = 4))
        left.addView(cover(title, dp(84)), LinearLayout.LayoutParams(dp(84), dp(84)).also {
            it.bottomMargin = dp(6)
        })
        left.addView(label(title, 14f, Spot.WHITE, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, lp(-1, -2))
        left.addView(label("Dari: ${Music.queueName}", 10f, Spot.SUB), lp(-1, -2, t = 1, b = 6))

        val sk = SeekView(a) { f ->
            Music.seekTo((f * Music.duration().coerceAtLeast(1)).toInt())
            updateProgress()
        }
        seek = sk
        left.addView(sk, lp(-1, dp(14)))
        val times = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        tPos = label(fmt(Music.position()), 11f, Spot.SUB)
        tDur = label(fmt(Music.duration()), 11f, Spot.SUB).apply { gravity = Gravity.END }
        times.addView(tPos, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(tDur, LinearLayout.LayoutParams(0, -2, 1f))
        left.addView(times, lp(-1, -2, b = 4))

        val ctl = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        ctl.addView(icon("⇄", 20f, if (Music.shuffle) Spot.GREEN else Spot.SUB) {
            Music.setShuffle(a, !Music.shuffle); redraw()
        }, lpW())
        ctl.addView(icon("⏮", 24f, Spot.WHITE) { Music.prev(a); redraw() }, lpW())
        val play = TextView(a).apply {
            text = if (playing) "❚❚" else "▶"
            textSize = 20f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Spot.GREEN) }
            setOnClickListener { Music.toggle(a); redraw() }
        }
        ctl.addView(play, LinearLayout.LayoutParams(dp(44), dp(44)))
        ctl.addView(icon("⏭", 24f, Spot.WHITE) { Music.next(a); redraw() }, lpW())
        val repTxt = if (Music.repeat == 1) "↻1" else "↻"
        ctl.addView(icon(repTxt, 20f, if (Music.repeat != 0) Spot.GREEN else Spot.SUB) {
            Music.setRepeat(a, (Music.repeat + 1) % 3); redraw()
        }, lpW())
        left.addView(ctl, lp(-1, -2, b = 6))

        val chips = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        chips.addView(pill("AI Auto", Music.aiAuto) { Music.setAi(a, !Music.aiAuto); redraw() }, lpW(8))
        chips.addView(pill(if (Music.on) "Musik: ON" else "Musik: OFF", Music.on) {
            Music.setOn(a, !Music.on); redraw()
        }, lpW(0))
        left.addView(chips, lp(-1, -2))

        if (playing) root.postDelayed(tick, 500)
        updateProgress()
    }

    // ===== kanan bawah: playlist =====
    private fun buildList() {
        listBox.removeAllViews()
        for (name in Music.playlistNames()) {
            listBox.addView(section(name), lp(-1, -2, b = 14))
        }
        listBox.addView(pill("＋ Buat playlist baru", true) { newPlaylist() }, lp(-2, -2, b = 12))
    }

    private fun section(name: String): LinearLayout {
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val tracks = Music.playlist(name)
        val head = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(label(name.uppercase(), 12f, Spot.GREEN, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(label("${tracks.size} lagu", 11f, Spot.SUB), LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = dp(8) })
        if (!Music.isBuiltinPlaylist(name)) {
            head.addView(pill("＋ Tambah", false) { pick(name) }, LinearLayout.LayoutParams(-2, -2))
        }
        box.addView(head, lp(-1, -2, b = 6))

        if (tracks.isEmpty()) {
            box.addView(label("Belum ada lagu di playlist ini.", 11f, Spot.SUB), lp(-1, -2, b = 4))
        }
        tracks.forEachIndexed { i, uri ->
            val active = Music.queueName == name && i == Music.idx
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = if (active) rr(Spot.HIGH, dp(8).toFloat()) else null
                setPadding(dp(6), dp(4), dp(4), dp(4))
            }
            val left = if (active) EqView(a).also { it.layoutParams = LinearLayout.LayoutParams(dp(16), dp(14)) }
                       else label((i + 1).toString(), 12f, Spot.SUB).apply { gravity = Gravity.CENTER }
            row.addView(left, LinearLayout.LayoutParams(dp(26), -2))
            val t = Music.title(a, uri)
            row.addView(cover(t, dp(28)), LinearLayout.LayoutParams(dp(28), dp(28)).also { it.rightMargin = dp(8) })
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            col.addView(label(t, 13f, if (active) Spot.GREEN else Spot.WHITE, active).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            if (!Music.isSystem(uri)) {
                row.addView(icon("✕", 13f, Spot.SUB) { Music.remove(a, name, i); redraw() },
                    LinearLayout.LayoutParams(-2, -2))
            }
            row.setOnClickListener { Music.playFrom(a, name, i); redraw() }
            box.addView(row, lp(-1, -2, b = 2))
        }
        return box
    }
}
