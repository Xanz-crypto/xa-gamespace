package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// Warna gaya Spotify
object Spot {
    val BG: Int = Color.parseColor("#121212")
    val CARD: Int = Color.parseColor("#181818")
    val HIGH: Int = Color.parseColor("#282828")
    val TRACK: Int = Color.parseColor("#4D4D4D")
    val GREEN: Int = Color.parseColor("#1DB954")
    val SUB: Int = Color.parseColor("#B3B3B3")
    val WHITE: Int = Color.parseColor("#FFFFFF")
    val COVERS = listOf("#1DB954", "#E8115B", "#8D67AB", "#F59B23", "#2E77D0", "#E13300")
}

// Equalizer hijau: bergerak hanya saat musik diputar
class EqView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Spot.GREEN }
    private val rect = RectF()
    override fun onDraw(cv: Canvas) {
        val playing = Music.isPlaying()
        val t = System.currentTimeMillis() / 1000.0
        val n = 3
        val gap = width * 0.18f
        val bw = (width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val wave = Math.abs(Math.sin(t * 5.0 + i * 1.7)).toFloat()
            val h = if (playing) height * (0.35f + 0.65f * wave) else height * 0.3f
            val x = i * (bw + gap)
            rect.set(x, height - h, x + bw, height.toFloat())
            cv.drawRoundRect(rect, bw / 2, bw / 2, p)
        }
        if (playing) postInvalidateOnAnimation()
    }
}

// Progress bar bergaya Spotify: bisa digeser untuk seek
class SeekView(ctx: Context, private val onSeek: (Float) -> Unit) : View(ctx) {
    var progress = 0f
    var dragging = false
    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Spot.TRACK }
    private val fgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Spot.GREEN }
    private val knobP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Spot.WHITE }
    private val r = RectF()

    private fun dpF(v: Float) = v * resources.displayMetrics.density

    override fun onDraw(cv: Canvas) {
        val h = dpF(4f)
        val cy = height / 2f
        r.set(0f, cy - h / 2, width.toFloat(), cy + h / 2)
        cv.drawRoundRect(r, h, h, bgP)
        val x = width * progress.coerceIn(0f, 1f)
        r.set(0f, cy - h / 2, x, cy + h / 2)
        cv.drawRoundRect(r, h, h, fgP)
        cv.drawCircle(x, cy, dpF(6f), knobP)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                dragging = true
                progress = (e.x / width).coerceIn(0f, 1f)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                onSeek(progress)
            }
        }
        return true
    }
}

class MusicPanel(private val a: MainActivity) {
    private val d = a.resources.displayMetrics.density
    val root = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Spot.BG)
        setPadding(dp(18), dp(14), dp(18), dp(14))
    }
    private val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private var seek: SeekView? = null
    private var tPos: TextView? = null
    private var tDur: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            if (Music.isPlaying()) root.postDelayed(this, 500)
        }
    }

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        build()
    }

    private fun dp(v: Int) = (v * d).toInt()

    private fun redraw() = build()

    private fun lp(w: Int, h: Int, t: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h).also { it.topMargin = dp(t); it.bottomMargin = dp(b) }

    private fun lpW(r: Int = 0) =
        LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = dp(r) }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(a).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
    }

    private fun rr(fill: Int, radius: Float, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun icon(t: String, size: Float, color: Int, onTap: () -> Unit) = TextView(a).apply {
        text = t
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(dp(6), dp(8), dp(6), dp(8))
        setOnClickListener { onTap() }
    }

    private fun pill(t: String, on: Boolean, onTap: () -> Unit) = TextView(a).apply {
        text = t
        textSize = 12f
        setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
        setTextColor(if (on) Color.BLACK else Spot.WHITE)
        gravity = Gravity.CENTER
        background = rr(if (on) Spot.GREEN else Spot.HIGH, dp(20).toFloat())
        setPadding(dp(14), dp(7), dp(14), dp(7))
        setOnClickListener { onTap() }
    }

    // sampul album sederhana: huruf pertama di atas gradasi warna
    private fun cover(title: String, px: Int) = TextView(a).apply {
        text = title.firstOrNull()?.uppercase() ?: "♪"
        textSize = px / d * 0.42f
        setTextColor(Spot.WHITE)
        gravity = Gravity.CENTER
        setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
        val c = Color.parseColor(Spot.COVERS[Math.abs(title.hashCode()) % Spot.COVERS.size])
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c, Color.BLACK)).apply {
            cornerRadius = dp(8).toFloat()
        }
    }

    private fun fmt(ms: Int): String {
        val s = (ms.coerceAtLeast(0)) / 1000
        return String.format("%d:%02d", s / 60, s % 60)
    }

    private fun updateProgress() {
        val dur = Music.duration().coerceAtLeast(1)
        val pos = Music.position()
        seek?.let { if (!it.dragging) { it.progress = pos.toFloat() / dur; it.invalidate() } }
        tPos?.text = fmt(pos)
        tDur?.text = fmt(Music.duration())
    }

    private fun build() {
        root.removeCallbacks(tick)
        box.removeAllViews()
        val cur = Music.list.getOrNull(Music.idx)
        val title = if (cur == null) "Belum ada lagu" else Music.title(a, cur)
        val playing = Music.isPlaying()

        // poster video di bagian atas (tanpa suara, diputar berulang)
        val posterH = dp(200)
        val frame = android.widget.FrameLayout(a).apply {
            background = rr(Color.BLACK, dp(14).toFloat())
            clipToOutline = true
        }
        val vv = android.widget.VideoView(a)
        vv.setVideoURI(android.net.Uri.parse("android.resource://${a.packageName}/${a.resources.getIdentifier("poster", "raw", a.packageName)}"))
        vv.setOnPreparedListener { mp ->
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            vv.start()
        }
        frame.addView(vv, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            Gravity.CENTER))
        box.addView(frame, lp(-1, posterH, b = 14))

        box.addView(label("SEKARANG DIPUTAR", 11f, Spot.SUB, true).apply { gravity = Gravity.CENTER },
            lp(-1, -2, b = 12))

        // sampul besar di tengah
        val coverPx = dp(240)
        box.addView(cover(title, coverPx), LinearLayout.LayoutParams(coverPx, coverPx).also {
            it.gravity = Gravity.CENTER_HORIZONTAL
            it.bottomMargin = dp(20)
        })

        // judul dan sub-judul
        box.addView(label(title, 22f, Spot.WHITE, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, lp(-1, -2))
        box.addView(label("Lokal · GameSpace", 13f, Spot.SUB), lp(-1, -2, t = 2, b = 16))

        // progress bar + waktu
        val sk = SeekView(a) { f ->
            Music.seekTo((f * Music.duration().coerceAtLeast(1)).toInt())
            updateProgress()
        }
        seek = sk
        box.addView(sk, lp(-1, dp(24)))
        val times = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        tPos = label(fmt(Music.position()), 11f, Spot.SUB)
        tDur = label(fmt(Music.duration()), 11f, Spot.SUB).apply { gravity = Gravity.END }
        times.addView(tPos, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(tDur, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(times, lp(-1, -2, b = 12))

        // kontrol: acak, sebelumnya, putar, berikutnya, ulangi
        val ctl = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        ctl.addView(icon("⇄", 20f, if (Music.shuffle) Spot.GREEN else Spot.SUB) {
            Music.setShuffle(a, !Music.shuffle); redraw()
        }, lpW())
        ctl.addView(icon("⏮", 26f, Spot.WHITE) { Music.prev(a); redraw() }, lpW())
        val play = TextView(a).apply {
            text = if (playing) "❚❚" else "▶"
            textSize = 20f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Spot.GREEN) }
            setOnClickListener { Music.toggle(a); redraw() }
        }
        ctl.addView(play, LinearLayout.LayoutParams(dp(68), dp(68)))
        ctl.addView(icon("⏭", 26f, Spot.WHITE) { Music.next(a); redraw() }, lpW())
        val repTxt = if (Music.repeat == 1) "↻1" else "↻"
        ctl.addView(icon(repTxt, 20f, if (Music.repeat != 0) Spot.GREEN else Spot.SUB) {
            Music.setRepeat(a, (Music.repeat + 1) % 3); redraw()
        }, lpW())
        box.addView(ctl, lp(-1, -2, b = 16))

        // chip: AI Auto dan musik on/off
        val chips = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        chips.addView(pill("AI Auto", Music.aiAuto) { Music.setAi(a, !Music.aiAuto); redraw() }, lpW(8))
        chips.addView(pill(if (Music.on) "Musik: ON" else "Musik: OFF", Music.on) {
            Music.setOn(a, !Music.on); redraw()
        }, lpW(0))
        box.addView(chips, lp(-1, -2, b = 22))

        // daftar putar
        val head = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(label("Daftar putar", 18f, Spot.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(pill("＋ Tambah", true) { a.pickSong() }, LinearLayout.LayoutParams(-2, -2))
        box.addView(head, lp(-1, -2, b = 10))
        val sys1 = Music.list.count { Music.systemPlaylistName(it) == Music.SYSTEM_NAME && Music.isSystem(it) }
        val sys2 = Music.list.count { Music.systemPlaylistName(it) == Music.SYSTEM2_NAME && Music.isSystem(it) }
        box.addView(label(Music.SYSTEM_NAME.uppercase() + " · $sys1 LAGU", 11f, Spot.GREEN, true), lp(-1, -2, b = 4))
        box.addView(label(Music.SYSTEM2_NAME.uppercase() + " · $sys2 LAGU", 11f, Spot.GREEN, true), lp(-1, -2, b = 8))

        Music.list.forEachIndexed { i, uri ->
            val active = i == Music.idx
            val songTitle = Music.title(a, uri)
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = if (active) rr(Spot.HIGH, dp(8).toFloat()) else null
                setPadding(dp(8), dp(8), dp(4), dp(8))
            }
            val left = if (active) EqView(a).also { it.layoutParams = LinearLayout.LayoutParams(dp(16), dp(14)) }
                       else label((i + 1).toString(), 13f, Spot.SUB).apply { gravity = Gravity.CENTER }
            row.addView(left, LinearLayout.LayoutParams(dp(28), -2))
            row.addView(cover(songTitle, dp(40)), LinearLayout.LayoutParams(dp(40), dp(40)).also { it.rightMargin = dp(12) })
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            col.addView(label(songTitle, 15f, if (active) Spot.GREEN else Spot.WHITE, active).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            col.addView(label(if (Music.isSystem(uri)) Music.systemPlaylistName(uri) else "Lokal", 12f, Spot.SUB), lp(-1, -2, t = 2))
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            if (!Music.isSystem(uri)) {
                row.addView(icon("✕", 14f, Spot.SUB) { Music.remove(a, i); redraw() }, LinearLayout.LayoutParams(-2, -2))
            }
            row.setOnClickListener { Music.play(a, i); redraw() }
            box.addView(row, lp(-1, -2, b = 4))
        }

        box.addView(label("AI Auto memilih lagu berikutnya dari yang belum sering diputar.", 11f, Spot.SUB),
            lp(-1, -2, t = 14))

        if (playing) root.postDelayed(tick, 500)
        updateProgress()
    }
}
