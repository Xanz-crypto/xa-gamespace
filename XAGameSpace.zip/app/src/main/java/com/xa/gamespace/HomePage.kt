package com.xa.gamespace

import android.os.Build
import android.view.View
import android.widget.ScrollView
import android.widget.TextView

class HomePage(private val a: MainActivity) : Page {
    private val u = a.ui
    private var built = false

    private lateinit var rootPill: TextView
    private lateinit var selinuxPill: TextView
    private lateinit var tUptime: TextView
    private lateinit var tRoot: TextView
    private lateinit var tGame: TextView

    private lateinit var ramPct: TextView
    private lateinit var ramBar: BarView
    private lateinit var tRamUsed: TextView
    private lateinit var tRamFree: TextView
    private lateinit var tSwap: TextView
    private lateinit var tCache: TextView

    private lateinit var stPct: TextView
    private lateinit var stBar: BarView
    private lateinit var tStUsed: TextView
    private lateinit var tStFree: TextView
    private lateinit var tStTotal: TextView

    private lateinit var tTemp: TextView
    private lateinit var tBatt: TextView
    private lateinit var tVolt: TextView

    private lateinit var tCpu: TextView
    private lateinit var tFreq: TextView
    private lateinit var tPing: TextView
    private lateinit var tFps: TextView

    private lateinit var boostInfo: TextView

    override fun build(): View {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        val col = u.vbox()
        col.setPadding(u.dp(16), u.dp(22), u.dp(16), u.dp(24))
        sv.addView(col)

        // Header
        val head = u.hbox()
        val t = u.vbox()
        t.addView(u.label("XA Game Space", 22f, Theme.text, true))
        t.addView(u.label("${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", 11f, Theme.sub))
        head.addView(t, u.lp(0, -2, 1f))
        head.addView(u.pill("v2.0", Theme.accent))
        rootPill = u.pill("Root ...", Theme.sub)
        head.addView(rootPill, u.lp(-2, -2, l = 6))
        col.addView(head, u.lp(b = 14))

        // Status perangkat
        val c1 = u.card()
        selinuxPill = u.pill("SELinux ...", Theme.sub)
        c1.addView(u.cardHeader("📱", "Status Perangkat", Sys.soc() + " · Linux " + (System.getProperty("os.version") ?: ""), selinuxPill))
        val (t1, v1) = u.tile("Uptime", Sys.uptimeText()); tUptime = v1
        val (t2, v2) = u.tile("Akses Root", "..."); tRoot = v2
        val (t3, v3) = u.tile("Game dipilih", "-"); tGame = v3
        c1.addView(u.row(t1, t2, t3), u.lp(t = 12))
        col.addView(c1)

        // RAM
        val c2 = u.card()
        ramPct = u.label("0%", 22f, Theme.good, true)
        c2.addView(u.cardHeader("🧠", "Memori RAM", "Terpakai dan swap", ramPct))
        ramBar = BarView(a)
        c2.addView(ramBar, u.lp(-1, u.dp(8), t = 12, b = 12))
        val (r1, rv1) = u.tile("Terpakai", "-"); tRamUsed = rv1
        val (r2, rv2) = u.tile("Tersedia", "-"); tRamFree = rv2
        val (r3, rv3) = u.tile("Swap", "-"); tSwap = rv3
        c2.addView(u.row(r1, r2, r3))
        val cr = u.hbox()
        cr.addView(u.label("Cache yang bisa dibersihkan", 12f, Theme.sub), u.lp(0, -2, 1f))
        tCache = u.label("-", 12f, Theme.text, true)
        cr.addView(tCache)
        c2.addView(cr, u.lp(t = 12))
        col.addView(c2)

        // Penyimpanan
        val c3 = u.card()
        stPct = u.label("0%", 22f, Theme.accent, true)
        c3.addView(u.cardHeader("💾", "Penyimpanan Internal", "Partisi data", stPct))
        stBar = BarView(a)
        c3.addView(stBar, u.lp(-1, u.dp(8), t = 12, b = 12))
        val (s1, sv1) = u.tile("Terpakai", "-"); tStUsed = sv1
        val (s2, sv2) = u.tile("Kosong", "-"); tStFree = sv2
        val (s3, sv3) = u.tile("Total", "-"); tStTotal = sv3
        c3.addView(u.row(s1, s2, s3))
        col.addView(c3)

        // Suhu dan baterai
        val c4 = u.card()
        c4.addView(u.cardHeader("🌡", "Suhu dan Baterai", "Sensor termal dan baterai"))
        val (b1, bv1) = u.tile("Suhu", "-"); tTemp = bv1
        val (b2, bv2) = u.tile("Daya", "-"); tBatt = bv2
        val (b3, bv3) = u.tile("Voltase", "-"); tVolt = bv3
        c4.addView(u.row(b1, b2, b3), u.lp(t = 12))
        col.addView(c4)

        // Performa live
        val c5 = u.card()
        c5.addView(u.cardHeader("⚡", "Performa Live", "Diperbarui tiap beberapa detik"))
        val (p1, pv1) = u.tile("CPU", "-"); tCpu = pv1
        val (p2, pv2) = u.tile("Frekuensi", "-"); tFreq = pv2
        val (p3, pv3) = u.tile("Ping", "-"); tPing = pv3
        val (p4, pv4) = u.tile("FPS", "-"); tFps = pv4
        c5.addView(u.row(p1, p2, p3, p4), u.lp(t = 12))
        col.addView(c5)

        // Tombol boost
        col.addView(u.gradBtn("⚡  Boost Sekarang") { a.boost() }, u.lp(t = 4))
        boostInfo = u.label("Aman: semua perubahan bisa dipulihkan lewat tombol Pulihkan di tab Alat.", 11f, Theme.sub)
        boostInfo.gravity = android.view.Gravity.CENTER
        col.addView(boostInfo, u.lp(t = 8, b = 14))

        col.addView(u.ghostBtn("🎮  Buka Game Space (landscape)") { a.openSpace() })
        built = true
        return sv
    }

    private fun sev(v: Float, warn: Float, bad: Float) = if (v >= bad) Theme.bad else if (v >= warn) Theme.warn else Theme.good

    override fun update(s: Snap) {
        if (!built) return
        val ok = a.rootOk
        if (ok == null) {
            u.setPill(rootPill, "Root ...", Theme.sub)
            tRoot.text = "..."
        } else {
            u.setPill(rootPill, if (ok) "Root" else "No Root", if (ok) Theme.good else Theme.bad)
            tRoot.text = if (ok) "Granted" else "Ditolak"
            tRoot.setTextColor(if (ok) Theme.good else Theme.bad)
        }
        u.setPill(selinuxPill, "SELinux " + a.selinux, Theme.good)
        tUptime.text = Sys.uptimeText()
        tGame.text = a.selectedGame()?.let { u.appLabel(it) } ?: "-"
        tGame.textSize = 12f

        ramPct.text = "${s.ramPct}%"
        ramPct.setTextColor(sev(s.ramPct.toFloat(), 70f, 88f))
        ramBar.set(s.ramPct / 100f)
        tRamUsed.text = String.format("%.2f GB", s.ramUsed)
        tRamFree.text = String.format("%.2f GB", s.ramTotal - s.ramUsed)
        tSwap.text = String.format("%.1f/%.1f GB", s.swapUsed, s.swapTotal)
        tCache.text = "~${s.cacheMb} MB"

        val (total, free) = Sys.storage()
        val used = total - free
        val pct = if (total > 0) (100 * used / total).toInt() else 0
        stPct.text = "$pct%"
        stBar.set(pct / 100f)
        tStUsed.text = String.format("%.1f GB", used)
        tStFree.text = String.format("%.1f GB", free)
        tStTotal.text = String.format("%.0f GB", total)

        tTemp.text = String.format("%.1f°C", s.temp)
        tTemp.setTextColor(sev(s.temp, 40f, 45f))
        tBatt.text = "${s.batt}% " + if (s.charging) "⚡" else ""
        tVolt.text = String.format("%.2f V", s.volt) + if (s.healthOk) "" else " !"

        tCpu.text = "${s.cpu}%"
        tCpu.setTextColor(sev(s.cpu.toFloat(), 60f, 85f))
        tFreq.text = if (s.freq > 0f) String.format("%.2f GHz", s.freq) else "-"
        tPing.text = if (s.ping >= 0) "${s.ping} ms" else "-"
        tFps.text = if (a.selectedGame() != null && s.fps > 0) "${s.fps}" else "-"
    }
}
