package com.xa.gamespace

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GameSpaceActivity : Activity() {
    private lateinit var store: Store
    private lateinit var u: Ui
    private lateinit var cards: LinearLayout
    private lateinit var tTemp: TextView
    private lateinit var tCpu: TextView
    private lateinit var tPing: TextView
    private lateinit var tFps: TextView
    private lateinit var tBatt: TextView
    private lateinit var clock: TextView
    private lateinit var ramPill: TextView
    private lateinit var modeBtn: TextView
    private lateinit var playBtn: TextView
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    @Volatile private var polling = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        Theme.apply(store.str("accent", "Hijau"))
        u = Ui(this)
        if (store.bool("keepon", true)) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(build())
        render()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun navBtn(icon: String, active: Boolean, onClick: () -> Unit): TextView {
        val t = u.label(icon, 20f, Theme.text)
        t.gravity = Gravity.CENTER
        if (active) t.background = u.bg(u.tint(Theme.accent, 40), 14, u.tint(Theme.accent, 120))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun build(): View {
        val rootL = u.hbox()
        rootL.setBackgroundColor(Theme.bg)

        // Sidebar
        val side = u.vbox()
        side.gravity = Gravity.CENTER_HORIZONTAL
        side.setBackgroundColor(Color.parseColor("#0C0E14"))
        side.setPadding(u.dp(10), u.dp(14), u.dp(10), u.dp(14))
        val logo = u.label("XA", 15f, Theme.accent, true)
        logo.gravity = Gravity.CENTER
        logo.background = u.bg(Color.BLACK, 40, Theme.accent)
        side.addView(logo, u.lp(u.dp(48), u.dp(48), b = 16))
        side.addView(navBtn("🎮", true) {}, u.lp(u.dp(48), u.dp(48), b = 8))
        side.addView(navBtn("⚡", false) {
            toast("Menyiapkan boost...")
            Thread {
                Boost.on(this, selected())
                runOnUiThread { toast("Boost aktif") }
            }.start()
        }, u.lp(u.dp(48), u.dp(48), b = 8))
        side.addView(navBtn("🧹", false) {
            Thread {
                Boost.cleanRam()
                runOnUiThread { toast("RAM dibersihkan") }
            }.start()
        }, u.lp(u.dp(48), u.dp(48), b = 8))
        side.addView(navBtn("♻", false) { Launcher.restore(this) { toast("Pengaturan dipulihkan") } }, u.lp(u.dp(48), u.dp(48), b = 8))
        side.addView(navBtn("⚙", false) {
            startActivity(Intent(this, MainActivity::class.java).putExtra("tab", 3))
            finish()
        }, u.lp(u.dp(48), u.dp(48), b = 8))
        side.addView(View(this), u.lp(1, 0, 1f))
        side.addView(navBtn("⏻", false) { finish() }, u.lp(u.dp(48), u.dp(48)))
        rootL.addView(side, u.lp(u.dp(72), -1))

        // Konten
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val main = u.vbox()
        main.setPadding(u.dp(22), u.dp(14), u.dp(22), u.dp(12))
        sv.addView(main)

        val top = u.hbox()
        val tt = u.vbox()
        tt.addView(u.label("X A   G A M E   S P A C E", 10f, Theme.accent, true))
        tt.addView(u.label("Pilih Game", 24f, Theme.text, true))
        top.addView(tt, u.lp(0, -2, 1f))
        ramPill = u.pill("RAM 0%", Theme.accent)
        top.addView(ramPill)
        clock = u.label(fmt.format(Date()), 16f, Theme.sub, true)
        top.addView(clock, u.lp(-2, -2, l = 12))
        main.addView(top, u.lp(b = 10))

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        cards = u.hbox()
        hs.addView(cards)
        main.addView(hs, u.lp(b = 12))

        // Bar status
        val bar = u.hbox()
        bar.background = u.bg(Theme.card, 18, Theme.stroke)
        bar.setPadding(u.dp(14), u.dp(10), u.dp(14), u.dp(10))
        val (a1, v1) = u.tile("SUHU", "-", Theme.text, true); tTemp = v1
        val (a2, v2) = u.tile("CPU", "-", Theme.text, true); tCpu = v2
        val (a3, v3) = u.tile("PING", "-", Theme.text, true); tPing = v3
        val (a4, v4) = u.tile("FPS", "-", Theme.text, true); tFps = v4
        val (a5, v5) = u.tile("BATERAI", "-", Theme.text, true); tBatt = v5
        val stats = u.row(a1, a2, a3, a4, a5)
        bar.addView(stats, u.lp(0, -2, 1f, r = 10))
        modeBtn = u.ghostBtn("Mode") {
            val p = selected()
            if (p != null) {
                val cur = Boost.MODES.indexOf(store.gameMode(p))
                store.setGameMode(p, Boost.MODES[(cur + 1) % Boost.MODES.size])
                render()
            }
        }
        bar.addView(modeBtn, u.lp(-2, -2, r = 8))
        playBtn = u.gradBtn("▶  Main") { selected()?.let { Launcher.play(this, it) } }
        bar.addView(playBtn, u.lp(-2, -2))
        main.addView(bar)

        rootL.addView(sv, u.lp(0, -1, 1f))
        return rootL
    }

    private fun selected(): String? {
        val s = store.selected
        val g = store.games
        return if (s != null && s in g) s else g.firstOrNull()
    }

    private fun render() {
        cards.removeAllViews()
        val games = store.games.toList().sortedBy { u.appLabel(it).lowercase() }
        val sel = selected()
        if (games.isEmpty()) {
            cards.addView(u.label("Belum ada game. Tambahkan lewat tab Game di aplikasi.", 13f, Theme.sub))
        }
        games.forEach { pkg ->
            val card = u.gameCard(pkg, pkg == sel, store.gameMode(pkg), u.dp(190), u.dp(140),
                { store.selected = pkg; render() },
                {
                    val cur = Boost.MODES.indexOf(store.gameMode(pkg))
                    store.setGameMode(pkg, Boost.MODES[(cur + 1) % Boost.MODES.size])
                    render()
                })
            card.layoutParams = u.lp(u.dp(190), u.dp(140), r = 12)
            cards.addView(card)
        }
        modeBtn.text = sel?.let { "Mode: " + store.gameMode(it) } ?: "Mode"
        playBtn.text = sel?.let { "▶  " + u.appLabel(it) } ?: "▶  Main"
    }

    override fun onResume() {
        super.onResume()
        polling = true
        val stats = Stats(this)
        Thread {
            while (polling) {
                val s = stats.read(selected(), true)
                runOnUiThread {
                    tTemp.text = String.format("%.1f°C", s.temp)
                    tCpu.text = String.format("%.2f GHz", s.freq)
                    tPing.text = if (s.ping >= 0) "${s.ping} ms" else "-"
                    tFps.text = if (s.fps > 0) "${s.fps}" else "-"
                    tBatt.text = "${s.batt}%"
                    u.setPill(ramPill, "RAM ${s.ramPct}%", Theme.accent)
                    clock.text = fmt.format(Date())
                }
                try { Thread.sleep(2500) } catch (e: InterruptedException) { break }
            }
        }.start()
    }

    override fun onPause() {
        polling = false
        super.onPause()
    }
}
