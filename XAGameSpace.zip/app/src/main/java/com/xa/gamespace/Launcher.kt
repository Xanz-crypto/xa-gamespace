package com.xa.gamespace

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast

object Launcher {
    fun play(a: Activity, pkg: String) {
        val st = Store(a)
        val li = a.packageManager.getLaunchIntentForPackage(pkg)
        if (li == null) {
            Toast.makeText(a, "Game tidak bisa dibuka", Toast.LENGTH_SHORT).show()
            return
        }
        if (st.flag("overlay") && !Settings.canDrawOverlays(a)) {
            Toast.makeText(a, "Izinkan tampil di atas aplikasi lain untuk monitor", Toast.LENGTH_LONG).show()
            a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName)))
            return
        }
        Toast.makeText(a, "Menyiapkan boost...", Toast.LENGTH_SHORT).show()
        Thread {
            Boost.on(a, pkg)
            a.runOnUiThread {
                if (st.flag("overlay") && Settings.canDrawOverlays(a)) {
                    val si = Intent(a, OverlayService::class.java).putExtra("pkg", pkg)
                    if (Build.VERSION.SDK_INT >= 26) a.startForegroundService(si) else a.startService(si)
                }
                a.startActivity(li)
            }
        }.start()
    }

    fun restore(a: Activity, done: () -> Unit) {
        Thread {
            Boost.off(a)
            a.runOnUiThread {
                a.stopService(Intent(a, OverlayService::class.java))
                done()
            }
        }.start()
    }
}
