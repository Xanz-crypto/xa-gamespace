package com.xa.gamespace

object Root {
    @Volatile private var ok: Boolean? = null

    fun run(cmd: String): String = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (e: Exception) {
        ""
    }

    fun check(): Boolean {
        val r = run("id").contains("uid=0")
        ok = r
        return r
    }

    fun available(): Boolean = ok ?: check()
}
