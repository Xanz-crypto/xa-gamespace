package com.xa.gamespace

// Dipertahankan agar kode lama tetap jalan; sekarang lewat Access (root atau Shizuku).
object Root {
    fun run(cmd: String): String = Access.run(cmd)
    fun check(): Boolean = Access.checkRoot()
    fun available(): Boolean { Access.ensure(); return Access.hasAny() }
}
