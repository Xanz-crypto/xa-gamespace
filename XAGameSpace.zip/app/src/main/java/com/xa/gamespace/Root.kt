package com.xa.gamespace

object Root {
    fun run(cmd: String): String = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (e: Exception) {
        ""
    }

    fun available(): Boolean = run("id").contains("uid=0")
}
