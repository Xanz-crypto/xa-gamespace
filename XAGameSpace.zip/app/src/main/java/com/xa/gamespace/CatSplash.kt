package com.xa.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ============ Animasi pembuka ============
// 1. Maskot mengintip dari tepi KANAN layar (dua kali, kedua kali sambil "psst" dan melambai).
// 2. Jongkok bersiap, lalu berlari ke KIRI sambil menarik menu Game Space masuk lewat tali.
// onPull(x) dipanggil tiap frame dengan posisi tepi kiri menu (px): layar penuh = menu sudah di tempat.
class CatSplashView(
    ctx: Context,
    private val onPull: (Float) -> Unit,
    private val onDone: () -> Unit
) : View(ctx) {
    private val total = 4600L
    private val tPeek1 = 0.40f      // intip pertama
    private val tPeek2 = 1.50f      // intip kedua, lebih berani
    private val tCrouch = 2.55f     // jongkok
    private val tRun = 2.90f        // mulai berlari
    private val runDur = 1.50f

    private var time = 0f
    private var finished = false
    private var anim: ValueAnimator? = null
    private val cat = CatDrawer()
    private val bg = Paint()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ropeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val path = Path()
    private val rect = RectF()
    private var edgeGlow: LinearGradient? = null

    // keadaan per frame (dihitung di update())
    private var catX = 0f
    private var sxv = -1f
    private var syv = 1f
    private var rotV = 0f
    private var wave = 0f
    private var mouth = 0f
    private var walk = 0f
    private var step = 0f
    private var menuX = Float.MAX_VALUE
    private var ropeOn = false
    private var stepCount = 0
    private var size = 0f
    private var base = 0f
    private var gap = 0f
    private var ready = false

    private var sPeek1 = false
    private var sPeek2 = false
    private var sPsst = false
    private var sDash = false
    private var sPull = false
    private var sArrive = false

    // debu di kaki: x, y, waktu lahir
    private val dust = ArrayList<FloatArray>()

    init { isClickable = false }

    private fun dp(v: Float) = context.pxf(v)

    // sentuhan di panggung kosong = lewati animasi; di area menu diteruskan ke menu
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            if (e.x < menuX) { anim?.cancel(); return true }
            return false
        }
        return false
    }

    fun start() {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = total
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            time = (it.animatedValue as Float) * total / 1000f
            update()
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { finish() }
        })
        anim = a
        a.start()
    }

    private fun finish() {
        if (finished) return
        finished = true
        onDone()
    }

    override fun onDetachedFromWindow() {
        anim?.removeAllListeners()
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        bg.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            Color.parseColor("#1B2358"), Color.parseColor("#5A3A86"), Shader.TileMode.CLAMP)
        val gw = dp(70f)
        edgeGlow = LinearGradient(0f, 0f, gw, 0f,
            intArrayOf(Color.argb(210, 255, 255, 255), Color.argb(90, 150, 220, 255), Color.argb(0, 150, 220, 255)),
            floatArrayOf(0f, 0.25f, 1f), Shader.TileMode.CLAMP)
    }

    private fun update() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        ready = true
        val tm = time
        size = min(h * 0.34f, dp(130f))
        base = h * 0.80f
        val hw = CatStyle.halfWidth()
        gap = (hw + 0.22f) * size

        // posisi tengah maskot saat mengintip: e=0 tersembunyi di luar kanan, e=1 wajah + badan terlihat
        fun peekCenter(e: Float) = w + 0.15f * size - e * 0.55f * size + hw * size

        // suara tiap tahap
        if (!sPeek1 && tm > tPeek1) { sPeek1 = true; Sfx.play("peek", 0.8f) }
        if (!sPeek2 && tm > tPeek2) { sPeek2 = true; Sfx.play("peek", 1f) }
        if (!sPsst && tm > 2.0f) { sPsst = true; Sfx.play("psst", 0.7f) }
        if (!sDash && tm > tCrouch + 0.1f) { sDash = true; Sfx.play("dash", 0.8f) }
        if (!sPull && tm > tRun) { sPull = true; Sfx.play("pull", 0.7f) }

        walk = 0f
        wave = 0f
        mouth = 0f
        syv = 1f
        sxv = -1f                // saat mengintip dicerminkan agar tangan yang melambai ada di sisi layar
        rotV = 0f

        if (tm < tRun) {
            val e1 = catSm((tm - tPeek1) / 0.30f) * (1f - catSm((tm - (tPeek1 + 0.55f)) / 0.25f)) * 0.55f
            val e2 = catSm((tm - tPeek2) / 0.35f)
            val e = max(e1, e2)
            catX = peekCenter(e)
            // condong keluar sambil goyang penasaran
            rotV = -14f * e + 3.5f * sin(tm * 5f) * e
            // melambai + "psst"
            wave = catSm((tm - 2.0f) / 0.15f) * (1f - catSm((tm - 2.5f) / 0.15f))
            mouth = if (tm in 2.0f..2.3f) 0.7f else 0f
            // jongkok bersiap
            if (tm >= tCrouch) {
                val q = catSm((tm - tCrouch) / 0.30f)
                syv = 1f - 0.14f * q
                sxv = -(1f + 0.08f * q)
            }
            menuX = w
        } else {
            val rt = ((tm - tRun) / runDur).coerceIn(0f, 1f)
            val re = catMix(rt, catSm(rt), 0.55f)
            val x0 = peekCenter(1f)
            val x1 = -gap - (hw + 0.35f) * size
            catX = catMix(x0, x1, re)
            sxv = 1f
            rotV = -10f
            walk = if (rt < 1f) 1f else 0f
            step = (tm - tRun) * 16f
            mouth = if (walk > 0f && sin(step * 0.5f) > 0.8f) 0.5f else 0f
            menuX = (catX + gap).coerceIn(0f, w)
            ropeOn = catX + gap > 0f
        }

        // langkah kaki + debu
        if (walk > 0f) {
            val n = (step / PIf).toInt()
            if (n > stepCount) {
                stepCount = n
                Sfx.play(if (n % 2 == 0) "step1" else "step2", 0.5f)
                if (catX in 0f..w) dust.add(floatArrayOf(catX + (hw * 0.6f) * size, base, tm))
            }
        }

        // menu mendarat
        if (sPull && !sArrive && menuX <= 0f) {
            sArrive = true
            Sfx.play("arrive", 0.8f)
        }
        onPull(if (menuX >= w) w else menuX)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        if (!ready) { cv.drawRect(0f, 0f, w, h, bg); return }
        val tm = time

        // panggung kosong di sebelah kiri tepi menu
        val mx = if (menuX > w) w else menuX
        if (mx > 0f) {
            cv.save()
            cv.clipRect(0f, 0f, mx, h)
            cv.drawRect(0f, 0f, mx, h, bg)
            p.style = Paint.Style.FILL
            for (i in 0 until 16) {
                val sx0 = ((i * 0.618f) % 1f) * w
                val sy0 = (0.05f + (i * 0.37f) % 0.6f) * h
                val tw = 0.5f + 0.5f * sin(tm * 2.2f + i * 1.7f)
                p.color = Color.argb((150 * tw).toInt(), 255, 255, 255)
                cv.drawCircle(sx0, sy0, dp(1.2f + (i % 3) * 0.5f), p)
            }
            cv.restore()
        }

        // tepi menu bercahaya + percikan saat ditarik
        if (mx > 0f && mx < w - 1f) {
            glowP.shader = edgeGlow
            cv.save()
            cv.translate(mx, 0f)
            cv.scale(-1f, 1f)
            val flick = 0.8f + 0.2f * sin(tm * 14f)
            glowP.alpha = (255 * flick).toInt()
            cv.drawRect(0f, 0f, dp(70f), h, glowP)
            cv.restore()
            glowP.shader = null
            for (i in 0 until 9) {
                val ph = (tm * 1.6f + i * 0.37f) % 1f
                val px = mx - ph * dp(90f) - i * dp(3f)
                val py = base - size * (0.15f + 0.8f * ((i * 0.618f) % 1f))
                p.style = Paint.Style.FILL
                p.color = Color.argb((200 * (1f - ph)).toInt(), 190, 235, 255)
                cv.drawCircle(px, py, dp(2.2f) * (1f - ph * 0.6f), p)
            }
        }

        // debu
        val di = dust.iterator()
        while (di.hasNext()) {
            val d = di.next()
            val age = tm - d[2]
            if (age > 0.6f) { di.remove(); continue }
            val k = age / 0.6f
            p.style = Paint.Style.FILL
            p.color = Color.argb((120 * (1f - k)).toInt(), 235, 235, 255)
            cv.drawCircle(d[0] + dp(10f) * k, d[1] - dp(4f) - dp(10f) * k, dp(3f) + dp(7f) * k, p)
        }

        // tali penarik: dari tangan maskot ke tepi menu
        if (ropeOn && tm >= tRun) {
            val ax = catX + (CatStyle.halfWidth() - 0.05f) * size
            val ay = base - size * 0.42f
            val bx = catX + gap
            val sag = size * 0.05f * (1f + 0.5f * sin(tm * 17f))
            path.reset()
            path.moveTo(ax, ay)
            path.quadTo((ax + bx) / 2f, ay + sag, bx, ay)
            ropeP.color = Color.argb(200, 120, 80, 50); ropeP.strokeWidth = dp(4.2f)
            cv.drawPath(path, ropeP)
            ropeP.color = Color.parseColor("#F2D3A0"); ropeP.strokeWidth = dp(2.4f)
            cv.drawPath(path, ropeP)
        }

        // bayangan + maskot
        val hw = CatStyle.halfWidth()
        p.style = Paint.Style.FILL
        p.color = Color.argb(70, 0, 0, 0)
        rect.set(catX - size * (hw + 0.04f), base - size * 0.02f, catX + size * (hw + 0.04f), base + size * 0.05f)
        cv.drawOval(rect, p)
        cat.draw(cv, catX, base, size, tm, wave, 0f, mouth, sxv, syv, rotV, walk, step)
    }
}
