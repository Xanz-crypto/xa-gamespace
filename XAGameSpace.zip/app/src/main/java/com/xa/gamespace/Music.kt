package com.xa.gamespace

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns

// Pemutar musik GameSpace: playlist, ulangi, acak, dan AI Auto.
// Lagu bawaan "Bye slow" selalu ada di urutan pertama dan tidak bisa dihapus.
object Music {
    const val BUILTIN = "raw:bye_slow"
    private const val KEY_LIST = "music_list"
    private const val KEY_IDX = "music_idx"
    private const val KEY_REP = "music_rep"      // 0 mati, 1 ulangi satu, 2 ulangi semua
    private const val KEY_SHUF = "music_shuf"
    private const val KEY_AI = "music_ai"
    private const val KEY_ON = "music_on"

    private var mp: MediaPlayer? = null
    val list = ArrayList<String>()
    var idx = 0
    var repeat = 0
    var shuffle = false
    var aiAuto = false
    var on = true
    private val recent = HashSet<Int>()

    fun load(ctx: Context) {
        val s = Store(ctx)
        list.clear()
        s.get(KEY_LIST).split("\n").filter { it.isNotBlank() }.forEach { list.add(it) }
        if (list.isEmpty() || list[0] != BUILTIN) list.add(0, BUILTIN)
        idx = (s.get(KEY_IDX).toIntOrNull() ?: 0).coerceIn(0, list.size - 1)
        repeat = s.get(KEY_REP).toIntOrNull() ?: 0
        shuffle = s.get(KEY_SHUF) == "1"
        aiAuto = s.get(KEY_AI) == "1"
        on = s.get(KEY_ON) != "0"
    }

    private fun save(ctx: Context) {
        val s = Store(ctx)
        s.put(KEY_LIST, list.joinToString("\n"))
        s.put(KEY_IDX, idx.toString())
        s.put(KEY_REP, repeat.toString())
        s.put(KEY_SHUF, if (shuffle) "1" else "0")
        s.put(KEY_AI, if (aiAuto) "1" else "0")
        s.put(KEY_ON, if (on) "1" else "0")
    }

    fun title(ctx: Context, u: String): String {
        if (u == BUILTIN) return "Bye slow"
        val name = try {
            ctx.contentResolver.query(Uri.parse(u), arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) { null }
        return (name ?: "Lagu").substringBeforeLast('.')
    }

    fun isPlaying(): Boolean = try { mp?.isPlaying == true } catch (e: Exception) { false }

    fun add(ctx: Context, u: String) {
        if (!list.contains(u)) list.add(u)
        save(ctx)
    }

    fun remove(ctx: Context, i: Int) {
        if (i <= 0 || i >= list.size) return   // lagu bawaan tidak bisa dihapus
        val wasCur = i == idx
        list.removeAt(i)
        if (idx >= i && idx > 0) idx--
        if (wasCur) stop()
        save(ctx)
    }

    fun play(ctx: Context, i: Int = idx) {
        if (list.isEmpty()) return
        idx = i.coerceIn(0, list.size - 1)
        recent.add(idx)
        release()
        val u = list[idx]
        val p = MediaPlayer()
        try {
            if (u.startsWith("raw:")) {
                val fd = ctx.resources.openRawResourceFd(com.xa.gamespace.R.raw.bye_slow)
                p.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                fd.close()
            } else {
                p.setDataSource(ctx, Uri.parse(u))
            }
            p.setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            p.isLooping = repeat == 1
            p.setOnCompletionListener { next(ctx, auto = true) }
            p.prepare()
            mp = p
            if (on) p.start()
        } catch (e: Exception) {
            p.release()
            mp = null
            if (list.size > 1) next(ctx, auto = true)   // lagu rusak: lewati
        }
        save(ctx)
    }

    fun toggle(ctx: Context) {
        val p = mp
        if (p == null) { play(ctx); return }
        if (p.isPlaying) p.pause() else p.start()
        on = p.isPlaying || on
        save(ctx)
    }

    fun next(ctx: Context, auto: Boolean = false) {
        if (list.isEmpty()) return
        val n = when {
            auto && repeat == 1 -> idx
            aiAuto -> pickAi()
            shuffle -> if (list.size == 1) 0 else (0 until list.size).filter { it != idx }.random()
            idx + 1 < list.size -> idx + 1
            repeat == 2 -> 0
            else -> { if (!auto) play(ctx, 0) else stop(); return }
        }
        play(ctx, n)
    }

    fun prev(ctx: Context) {
        val p = mp
        if (p != null && p.currentPosition > 3000) { p.seekTo(0); return }
        play(ctx, if (idx > 0) idx - 1 else list.size - 1)
    }

    // AI Auto: pilih lagu yang belum sering diputar, lalu mengulang dari awal bila semua sudah
    private fun pickAi(): Int {
        if (list.size == 1) return 0
        var pool = (0 until list.size).filter { it != idx && it !in recent }
        if (pool.isEmpty()) { recent.clear(); pool = (0 until list.size).filter { it != idx } }
        return pool.random()
    }

    fun stop() {
        release()
    }

    private fun release() {
        try { mp?.stop() } catch (e: Exception) {}
        try { mp?.release() } catch (e: Exception) {}
        mp = null
    }

    fun setOn(ctx: Context, v: Boolean) {
        on = v
        if (v) { if (mp == null) play(ctx) else mp?.start() } else mp?.pause()
        save(ctx)
    }

    fun setRepeat(ctx: Context, v: Int) { repeat = v; mp?.isLooping = v == 1; save(ctx) }
    fun setShuffle(ctx: Context, v: Boolean) { shuffle = v; save(ctx) }
    fun setAi(ctx: Context, v: Boolean) { aiAuto = v; recent.clear(); save(ctx) }
}
