package com.xa.gamespace

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns

// Pemutar musik GameSpace dengan beberapa playlist.
// Playlist 1 System dan Playlist 2 System selalu ada dan tidak bisa dihapus.
object Music {
    const val SYSTEM_NAME = "Playlist 1 System"
    const val SYSTEM2_NAME = "Playlist 2 System"
    const val MANUAL_NAME = "Lagu manual"

    val SYSTEM_TRACKS = listOf("bye_slow", "poker_face", "judas", "cant_remember_to_forget_you", "say_my_name")
    val SYSTEM2_TRACKS = listOf("dj_aku_meriang", "dj_kopi_lambada_bootleg", "bumpa", "onty_onty")

    private val SYSTEM_TITLES = mapOf(
        "bye_slow" to "Bye slow",
        "poker_face" to "Poker Face",
        "judas" to "Judas",
        "cant_remember_to_forget_you" to "Can't Remember to Forget You",
        "say_my_name" to "Say My Name",
        "dj_aku_meriang" to "DJ Aku Meriang",
        "dj_kopi_lambada_bootleg" to "DJ Kopi Lambada Bootleg",
        "bumpa" to "Bumpa",
        "onty_onty" to "Onty Onty"
    )

    fun isSystem(u: String) = u.startsWith("raw:")
    fun isBuiltinPlaylist(name: String) = name == SYSTEM_NAME || name == SYSTEM2_NAME

    private const val KEY_NAMES = "pl_names"
    private const val KEY_QUEUE = "music_queue"
    private const val KEY_IDX = "music_idx"
    private const val KEY_REP = "music_rep"
    private const val KEY_SHUF = "music_shuf"
    private const val KEY_AI = "music_ai"
    private const val KEY_ON = "music_on"
    private const val KEY_VOL = "music_vol"

    // volume khusus musik GameSpace (0.0 sampai 1.0), terpisah dari volume media HP
    var volume = 1f

    private var mp: MediaPlayer? = null
    val playlists = LinkedHashMap<String, ArrayList<String>>()
    var queueName = SYSTEM_NAME
    var list: ArrayList<String> = ArrayList()   // antrean yang sedang diputar
    var idx = 0
    var repeat = 0
    var shuffle = false
    var aiAuto = false
    var on = true
    private val recent = HashSet<Int>()

    fun playlistNames(): List<String> = playlists.keys.toList()
    fun playlist(name: String): List<String> = playlists[name] ?: emptyList()

    fun load(ctx: Context) {
        val s = Store(ctx)
        playlists.clear()
        playlists[SYSTEM_NAME] = ArrayList(SYSTEM_TRACKS.map { "raw:$it" })
        playlists[SYSTEM2_NAME] = ArrayList(SYSTEM2_TRACKS.map { "raw:$it" })
        playlists[MANUAL_NAME] = readList(s, MANUAL_NAME)
        s.get(KEY_NAMES).split("\n").filter { it.isNotBlank() && !playlists.containsKey(it) }
            .forEach { n -> playlists[n] = readList(s, n) }
        queueName = s.get(KEY_QUEUE).takeIf { playlists.containsKey(it) } ?: SYSTEM_NAME
        list = playlists[queueName]!!
        idx = (s.get(KEY_IDX).toIntOrNull() ?: 0).coerceIn(0, maxOf(0, list.size - 1))
        repeat = s.get(KEY_REP).toIntOrNull() ?: 0
        shuffle = s.get(KEY_SHUF) == "1"
        aiAuto = s.get(KEY_AI) == "1"
        on = s.get(KEY_ON) != "0"
        volume = (s.get(KEY_VOL).toFloatOrNull() ?: 1f).coerceIn(0f, 1f)
        MusicService.start(ctx)
    }

    private fun readList(s: Store, name: String): ArrayList<String> =
        ArrayList(s.get("pl:$name").split("\n").filter { it.isNotBlank() })

    private fun save(ctx: Context) {
        val s = Store(ctx)
        playlists.forEach { (n, l) ->
            if (!isBuiltinPlaylist(n)) s.put("pl:$n", l.joinToString("\n"))
        }
        s.put(KEY_NAMES, playlists.keys.filter { !isBuiltinPlaylist(it) && it != MANUAL_NAME }.joinToString("\n"))
        s.put(KEY_QUEUE, queueName)
        s.put(KEY_IDX, idx.toString())
        s.put(KEY_REP, repeat.toString())
        s.put(KEY_SHUF, if (shuffle) "1" else "0")
        s.put(KEY_AI, if (aiAuto) "1" else "0")
        s.put(KEY_ON, if (on) "1" else "0")
        s.put(KEY_VOL, volume.toString())
    }

    fun title(ctx: Context, u: String): String {
        if (u.startsWith("raw:")) return SYSTEM_TITLES[u.removePrefix("raw:")] ?: "Lagu"
        val name = try {
            ctx.contentResolver.query(Uri.parse(u), arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) { null }
        return (name ?: "Lagu").substringBeforeLast('.')
    }

    fun isPlaying(): Boolean = try { mp?.isPlaying == true } catch (e: Exception) { false }
    fun position(): Int = try { mp?.currentPosition ?: 0 } catch (e: Exception) { 0 }
    fun duration(): Int = try { mp?.duration ?: 0 } catch (e: Exception) { 0 }
    fun seekTo(ms: Int) { try { mp?.seekTo(ms) } catch (e: Exception) {} }

    // ---------- kelola playlist ----------
    fun createPlaylist(ctx: Context, name: String): Boolean {
        if (name.isBlank() || playlists.containsKey(name)) return false
        playlists[name] = ArrayList()
        save(ctx)
        return true
    }

    fun addTo(ctx: Context, name: String, u: String) {
        val l = playlists[name] ?: return
        if (!l.contains(u)) l.add(u)
        save(ctx)
    }

    fun add(ctx: Context, u: String) = addTo(ctx, MANUAL_NAME, u)

    fun remove(ctx: Context, name: String, i: Int) {
        val l = playlists[name] ?: return
        if (i < 0 || i >= l.size || isSystem(l[i])) return   // lagu sistem tidak bisa dihapus
        if (name == queueName) {
            if (i == idx && name == queueName) stop()
            if (i < idx) idx--
        }
        l.removeAt(i)
        save(ctx)
    }

    // ---------- pemutaran ----------
    fun playFrom(ctx: Context, name: String, i: Int) {
        val l = playlists[name] ?: return
        if (l.isEmpty()) return
        queueName = name
        list = l
        play(ctx, i)
    }

    fun play(ctx: Context, i: Int = idx) {
        if (list.isEmpty()) return
        MusicService.start(ctx)
        idx = i.coerceIn(0, list.size - 1)
        recent.add(idx)
        release()
        val u = list[idx]
        val p = MediaPlayer()
        try {
            if (u.startsWith("raw:")) {
                val resId = ctx.resources.getIdentifier(u.removePrefix("raw:"), "raw", ctx.packageName)
                val fd = ctx.resources.openRawResourceFd(resId)
                p.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                fd.close()
            } else {
                p.setDataSource(ctx, Uri.parse(u))
            }
            p.setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            p.isLooping = repeat == 1
            p.setOnCompletionListener { next(ctx, auto = true) }
            p.prepare()
            p.setVolume(volume, volume)
            mp = p
            if (on) p.start()
        } catch (e: Exception) {
            p.release()
            mp = null
            if (list.size > 1) next(ctx, auto = true)   // lagu rusak: lewati
        }
        save(ctx)
    }

    fun toggle(ctx: Context) {
        val p = mp
        if (p == null) { play(ctx); return }
        if (p.isPlaying) p.pause() else p.start()
        on = p.isPlaying || on
        save(ctx)
    }

    fun next(ctx: Context, auto: Boolean = false) {
        if (list.isEmpty()) return
        val n = when {
            auto && repeat == 1 -> idx
            aiAuto -> pickAi()
            shuffle -> if (list.size == 1) 0 else (0 until list.size).filter { it != idx }.random()
            idx + 1 < list.size -> idx + 1
            repeat == 2 -> 0
            else -> { if (!auto) play(ctx, 0) else stop(); return }
        }
        play(ctx, n)
    }

    fun prev(ctx: Context) {
        val p = mp
        if (p != null && p.currentPosition > 3000) { p.seekTo(0); return }
        play(ctx, if (idx > 0) idx - 1 else list.size - 1)
    }

    // AI Auto: pilih lagu yang belum sering diputar, lalu mengulang bila semua sudah
    private fun pickAi(): Int {
        if (list.size == 1) return 0
        var pool = (0 until list.size).filter { it != idx && it !in recent }
        if (pool.isEmpty()) { recent.clear(); pool = (0 until list.size).filter { it != idx } }
        return pool.random()
    }

    fun stop() = release()

    private fun release() {
        try { mp?.stop() } catch (e: Exception) {}
        try { mp?.release() } catch (e: Exception) {}
        mp = null
    }

    fun setOn(ctx: Context, v: Boolean) {
        on = v
        if (v) { if (mp == null) play(ctx) else mp?.start() } else mp?.pause()
        save(ctx)
    }

    // dipanggil saat slider digeser: langsung terasa tanpa menyimpan
    fun setVolumeLive(v: Float) {
        volume = v.coerceIn(0f, 1f)
        try { mp?.setVolume(volume, volume) } catch (e: Exception) {}
    }

    // dipanggil saat slider dilepas: simpan nilainya
    fun setVolume(ctx: Context, v: Float) {
        setVolumeLive(v)
        try { save(ctx) } catch (e: Exception) {}
    }

    fun setRepeat(ctx: Context, v: Int) { repeat = v; mp?.isLooping = v == 1; save(ctx) }
    fun setShuffle(ctx: Context, v: Boolean) { shuffle = v; save(ctx) }
    fun setAi(ctx: Context, v: Boolean) { aiAuto = v; recent.clear(); save(ctx) }
}
