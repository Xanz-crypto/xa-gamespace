package com.xa.gamespace

import android.view.View
import kotlin.math.PI

// Fungsi bantu animasi
internal val PIf = PI.toFloat()
internal fun animSm(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
internal fun animMix(a: Float, b: Float, m: Float) = a + (b - a) * m
internal fun animNow(): Float = ((System.nanoTime() / 1_000_000L) % 600000L) / 1000f

// Penjadwal animasi dekoratif. Efek panel (aurora, gelembung, kipas, kilat tepi, dll.) berjalan TERUS,
// termasuk saat panel sedang dibuka, ditutup, atau digeser pelan. Tidak ada lagi jeda.
// Keringanan didapat dari jumlah elemen yang sedikit dan jadwal gambar yang hemat, bukan dari menghentikan efek.
object Gate {
    // dipertahankan agar kode lama tetap kompatibel; selalu false
    val calm = false

    // jadwalkan gambar berikutnya setelah ms milidetik
    fun later(v: View, ms: Long) { v.postInvalidateDelayed(ms) }

    // jadwalkan gambar berikutnya tepat di frame layar berikutnya
    fun frame(v: View) { v.postInvalidateOnAnimation() }

    fun setCalm(on: Boolean) { /* efek tidak pernah dijeda */ }
}
