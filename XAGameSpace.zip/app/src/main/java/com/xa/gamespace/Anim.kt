package com.xa.gamespace

import kotlin.math.PI

// Fungsi bantu animasi
internal val PIf = PI.toFloat()
internal fun animSm(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
internal fun animMix(a: Float, b: Float, m: Float) = a + (b - a) * m
internal fun animNow(): Float = ((System.nanoTime() / 1_000_000L) % 600000L) / 1000f
