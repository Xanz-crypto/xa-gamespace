package com.xa.gamespace

import android.view.View
import kotlin.math.PI

// Fungsi bantu animasi
internal val PIf = PI.toFloat()
internal fun animSm(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
internal fun animMix(a: Float, b: Float, m: Float) = a + (b - a) * m
internal fun animNow(): Float = ((System.nanoTime() / 1_000_000L) % 600000L) / 1000f

// Gerbang animasi dekoratif. Saat panel sedang membuka/menutup, efek yang terus bergerak (kipas, aurora, kilat tepi, dll.)
// dijeda dulu supaya semua tenaga dipakai untuk gerakan buka panel, lalu dilanjutkan setelah selesai.
// Semua dipanggil dari thread UI.
object Gate {
    @Volatile var calm = false
        private set
    private val waiting = java.util.WeakHashMap<View, Long>()

    // jadwalkan gambar berikutnya setelah ms milidetik
    fun later(v: View, ms: Long) { if (calm) waiting[v] = ms else v.postInvalidateDelayed(ms) }

    // jadwalkan gambar berikutnya tepat di frame layar berikutnya (halus, tanpa selisih timer)
    fun frame(v: View) { if (calm) waiting[v] = 0L else v.postInvalidateOnAnimation() }

    fun setCalm(on: Boolean) {
        if (calm == on) return
        calm = on
        if (!on) {
            val l = ArrayList<View>(waiting.keys)
            waiting.clear()
            for (v in l) v.invalidate()
        }
    }
}
