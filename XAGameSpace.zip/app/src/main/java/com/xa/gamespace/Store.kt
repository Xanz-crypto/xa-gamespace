package com.xa.gamespace

import android.content.Context

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("gs", Context.MODE_PRIVATE)

    var games: Set<String>
        get() = sp.getStringSet("games", emptySet())!!.toSet()
        set(v) { sp.edit().putStringSet("games", HashSet(v)).apply() }

    var active: Boolean
        get() = sp.getBoolean("active", false)
        set(v) { sp.edit().putBoolean("active", v).apply() }

    var game: String?
        get() = sp.getString("game", null)
        set(v) { sp.edit().putString("game", v).apply() }

    fun flag(k: String): Boolean {
        val def = Boost.FLAGS.firstOrNull { it.first == k }?.third ?: true
        return sp.getBoolean("f_$k", def)
    }

    fun setFlag(k: String, v: Boolean) { sp.edit().putBoolean("f_$k", v).apply() }

    fun saved(k: String): String = sp.getString("s_$k", "") ?: ""

    fun save(k: String, v: String) { sp.edit().putString("s_$k", v).apply() }
}
