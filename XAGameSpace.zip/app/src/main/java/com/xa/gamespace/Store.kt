package com.xa.gamespace

import android.content.Context

class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("xa3", Context.MODE_PRIVATE)

    var stabil: Boolean
        get() = sp.getBoolean("stabil", true)
        set(v) { sp.edit().putBoolean("stabil", v).apply() }

    var smooth: Boolean
        get() = sp.getBoolean("smooth", true)
        set(v) { sp.edit().putBoolean("smooth", v).apply() }

    var auto: Boolean
        get() = sp.getBoolean("auto", true)
        set(v) { sp.edit().putBoolean("auto", v).apply() }

    var crossOn: Boolean
        get() = sp.getBoolean("cross_on", false)
        set(v) { sp.edit().putBoolean("cross_on", v).apply() }

    var crossStyle: Int
        get() = sp.getInt("cross_style", 0)
        set(v) { sp.edit().putInt("cross_style", v).apply() }

    var monitorOn: Boolean
        get() = sp.getBoolean("monitor_on", false)
        set(v) { sp.edit().putBoolean("monitor_on", v).apply() }

    var soundEnabled: Boolean
        get() = sp.getBoolean("sound_enabled", true)
        set(v) { sp.edit().putBoolean("sound_enabled", v).apply() }

    var soundStyle: String
        get() = sp.getString("sound_style", "mature") ?: "mature"
        set(v) { sp.edit().putString("sound_style", v).apply() }

    var networkBoost: Boolean
        get() = sp.getBoolean("network_boost", false)
        set(v) { sp.edit().putBoolean("network_boost", v).apply() }

    var manualApps: String
        get() = sp.getString("manual_apps", "") ?: ""
        set(v) { sp.edit().putString("manual_apps", v).apply() }

    fun manualAppSet(): MutableSet<String> =
        manualApps.split("|").filter { it.isNotBlank() }.toMutableSet()

    fun saveManualApps(v: Set<String>) {
        manualApps = v.filter { it.isNotBlank() }.distinct().joinToString("|")
    }

    var active: Boolean
        get() = sp.getBoolean("active", false)
        set(v) { sp.edit().putBoolean("active", v).apply() }

    var game: String?
        get() = sp.getString("game", null)
        set(v) { sp.edit().putString("game", v).apply() }

    fun get(k: String): String = sp.getString(k, "") ?: ""
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }
}
