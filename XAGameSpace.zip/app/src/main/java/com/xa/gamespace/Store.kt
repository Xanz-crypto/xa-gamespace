package com.xa.gamespace

import android.content.Context

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("gs", Context.MODE_PRIVATE)

    var games: Set<String>
        get() = sp.getStringSet("games", emptySet())!!.toSet()
        set(v) { sp.edit().putStringSet("games", HashSet(v)).apply() }

    var active: Boolean
        get() = sp.getBoolean("active", false)
        set(v) { sp.edit().putBoolean("active", v).apply() }

    var game: String?
        get() = sp.getString("game", null)
        set(v) { sp.edit().putString("game", v).apply() }

    var selected: String?
        get() = sp.getString("sel", null)
        set(v) { sp.edit().putString("sel", v).apply() }

    fun gameMode(pkg: String): String = sp.getString("mode_$pkg", "Performa") ?: "Performa"
    fun setGameMode(pkg: String, m: String) { sp.edit().putString("mode_$pkg", m).apply() }

    fun flag(k: String): Boolean {
        val def = Boost.FLAGS.firstOrNull { it.first == k }?.third ?: true
        return sp.getBoolean("f_$k", def)
    }
    fun setFlag(k: String, v: Boolean) { sp.edit().putBoolean("f_$k", v).apply() }

    fun bool(k: String, def: Boolean): Boolean = sp.getBoolean("b_$k", def)
    fun setBool(k: String, v: Boolean) { sp.edit().putBoolean("b_$k", v).apply() }

    fun int(k: String, def: Int): Int = sp.getInt("i_$k", def)
    fun setInt(k: String, v: Int) { sp.edit().putInt("i_$k", v).apply() }

    fun str(k: String, def: String): String = sp.getString("t_$k", def) ?: def
    fun setStr(k: String, v: String) { sp.edit().putString("t_$k", v).apply() }

    fun saved(k: String): String = sp.getString("s_$k", "") ?: ""
    fun save(k: String, v: String) { sp.edit().putString("s_$k", v).apply() }

    fun resetSettings() {
        val keep = games
        val sel = selected
        sp.edit().clear().apply()
        games = keep
        selected = sel
    }
}
