package com.xa.gamespace

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

// Isi panel "TAMBAH GAME": semua aplikasi terpasang. Ketuk untuk menambahkannya ke kartu game
// (atau menghapusnya lagi). Game yang sudah dikenali otomatis diberi tanda OTOMATIS.
class GamePickerView(private val ctx: Context, private val onChange: () -> Unit) {
    val root = LinearLayout(ctx)
    private val list = LinearLayout(ctx)
    private val hint = TextView(ctx)
    private val search = EditText(ctx)

    private class App(val pkg: String, val label: String, val icon: Drawable, val auto: Boolean)

    private var apps: List<App> = emptyList()
    private var shown: List<App> = emptyList()

    private fun px(v: Int) = ctx.px(v)

    init {
        root.orientation = LinearLayout.VERTICAL

        hint.textSize = 10.5f
        hint.setTextColor(Hud.sub)
        hint.text = "Ketuk aplikasi untuk menambahkannya sebagai game. Ketuk lagi untuk menghapus."
        root.addView(hint, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(6) })

        search.hint = "Cari aplikasi..."
        search.textSize = 12f
        search.setTextColor(Color.WHITE)
        search.setHintTextColor(Hud.sub)
        search.setSingleLine(true)
        search.setPadding(px(10), px(6), px(10), px(6))
        search.background = Hud.rounded(Color.argb(150, 8, 22, 40), Hud.cyanDim, ctx.pxf(8f), 1f)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { render() }
        })
        root.addView(search, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(6) })

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val loading = TextView(ctx)
        loading.text = "Memuat aplikasi..."
        loading.textSize = 11f
        loading.setTextColor(Hud.sub)
        list.addView(loading)

        Thread {
            val pm = ctx.packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val added = Games.custom(ctx)
            val all = try {
                pm.queryIntentActivities(q, 0)
                    .map { App(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm), false) }
                    .distinctBy { it.pkg }
                    .filter { it.pkg != ctx.packageName }
                    .map { App(it.pkg, it.label, it.icon, Games.isAuto(ctx, it.pkg)) }
            } catch (e: Exception) { emptyList() }
            // yang sudah ditambahkan di atas, lalu sisanya urut abjad
            val sorted = all.sortedWith(compareBy<App>({ it.pkg !in added }, { it.label.lowercase() }))
            root.post { apps = sorted; render() }
        }.start()
    }

    private fun render() {
        list.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        shown = if (q.isEmpty()) apps else apps.filter { it.label.lowercase().contains(q) || it.pkg.lowercase().contains(q) }
        if (shown.isEmpty()) {
            val t = TextView(ctx)
            t.text = if (apps.isEmpty()) "Tidak ada aplikasi." else "Tidak ada hasil untuk \"$q\"."
            t.textSize = 11f
            t.setTextColor(Hud.sub)
            list.addView(t)
            return
        }
        for (a in shown) list.addView(rowFor(a))
    }

    private fun rowFor(a: App): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(px(4), px(6), px(4), px(6))

        val iv = ImageView(ctx)
        iv.setImageDrawable(a.icon)
        r.addView(iv, LinearLayout.LayoutParams(px(32), px(32)))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val n = TextView(ctx)
        n.text = a.label
        n.textSize = 12.5f
        n.setTextColor(Color.WHITE)
        n.maxLines = 1
        n.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(n)
        val p = TextView(ctx)
        p.text = a.pkg
        p.textSize = 8.5f
        p.setTextColor(Hud.sub)
        p.maxLines = 1
        p.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(p)
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = px(10) })

        val c = TextView(ctx)
        c.textSize = 10f
        c.typeface = Typeface.DEFAULT_BOLD
        c.setPadding(px(8), px(3), px(8), px(3))
        fun paint() {
            val on = a.pkg in Games.custom(ctx)
            when {
                on -> {
                    c.text = "✓ DITAMBAH"
                    c.setTextColor(Color.parseColor("#38E8A5"))
                    c.background = Hud.rounded(Color.argb(60, 56, 232, 165), Color.parseColor("#38E8A5"), ctx.pxf(9f), 1f)
                }
                a.auto -> {
                    c.text = "OTOMATIS"
                    c.setTextColor(Hud.sub)
                    c.background = Hud.rounded(Color.argb(50, 90, 110, 140), Color.TRANSPARENT, ctx.pxf(9f), 0f)
                }
                else -> {
                    c.text = "＋ TAMBAH"
                    c.setTextColor(Hud.cyan)
                    c.background = Hud.rounded(Color.argb(40, 40, 170, 230), Hud.cyan, ctx.pxf(9f), 1f)
                }
            }
        }
        paint()
        r.addView(c)

        r.setOnClickListener {
            Sfx.tap()
            if (a.auto && a.pkg !in Games.custom(ctx)) {
                Toast.makeText(ctx.applicationContext, "${a.label} sudah terdeteksi otomatis sebagai game", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val added = Games.toggleCustom(ctx, a.pkg)
            paint()
            Toast.makeText(ctx.applicationContext,
                if (added) "${a.label} ditambahkan ke daftar game" else "${a.label} dihapus dari daftar game",
                Toast.LENGTH_SHORT).show()
            onChange()
        }
        return r
    }
}
