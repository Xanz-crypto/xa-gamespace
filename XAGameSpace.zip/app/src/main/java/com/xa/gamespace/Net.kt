package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.Socket

// =====================================================================
//  OPTIMAL JARINGAN (versi baru)
//  Fokus pada yang benar-benar menurunkan latensi di HP:
//   - antrean paket fq_codel (anti bufferbloat): lonjakan ping saat unduhan/update berjalan
//   - Wi-Fi: power save mati, latensi rendah, performa tinggi, Wi-Fi Lock
//   - koneksi tidak pindah sendiri di tengah game, Doze dimatikan selama game
//   - TCP low-latency (notsent 16 KB, tanpa slow-start setelah idle)
//  Ping ke server game ditentukan rute provider & jarak server; aplikasi tidak bisa
//  memangkasnya sampai di bawah itu. Yang bisa diturunkan adalah antrean dan jitter.
//  Semua nilai asli disimpan dan bisa dikembalikan lewat Reset.
// =====================================================================
object NetOpt {
    data class Probe(val avg: Int, val jitter: Int, val loss: Int) {
        val ok: Boolean get() = avg >= 0
    }

    data class Diag(
        val kind: String,
        val rssi: Int,
        val freq: Int,
        val link: Int,
        val net: Probe,
        val gw: Probe?,
        val target: String
    )

    private val TARGETS = listOf("Google" to "8.8.8.8", "Cloudflare" to "1.1.1.1")
    private const val IP4 = "/proc/sys/net/ipv4/"
    private const val CC = IP4 + "tcp_congestion_control"
    private val TCP_SET = listOf(
        "tcp_slow_start_after_idle" to "0",
        "tcp_low_latency" to "1",
        "tcp_fastopen" to "3",
        "tcp_notsent_lowat" to "16384",
        "tcp_autocorking" to "0"
    )
    private val TCP_SNAP = listOf(CC) + TCP_SET.map { IP4 + it.first }
    private val NET_KEYS = listOf(
        "wifi_scan_always_enabled", "ble_scan_always_enabled", "mobile_data_always_on",
        "adaptive_connectivity_enabled", "wifi_wakeup_enabled"
    )
    private val SAFE = Regex("^[A-Za-z0-9_.\\- ]+$")
    private val SAFE_TCP = Regex("^[a-z0-9 ]+$")
    private val DEV = Regex("^[a-z0-9_]+$")

    // ---------- pengukuran ----------
    fun probe(host: String, port: Int, n: Int, timeoutMs: Int): Probe {
        val ts = ArrayList<Int>()
        var fail = 0
        for (i in 0 until n) {
            val t0 = System.nanoTime()
            var ok = false
            try {
                Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
                ok = true
            } catch (e: ConnectException) {
                // ditolak = host membalas, RTT tetap sah
                if ((e.message ?: "").contains("refused", true)) ok = true
            } catch (e: Exception) {
            }
            if (ok) ts.add(((System.nanoTime() - t0) / 1_000_000L).toInt()) else fail++
            if (i < n - 1) try { Thread.sleep(60) } catch (e: InterruptedException) { break }
        }
        if (ts.isEmpty()) return Probe(-1, 0, 100)
        var jit = 0
        for (i in 1 until ts.size) jit += Math.abs(ts[i] - ts[i - 1])
        val jitter = if (ts.size > 1) jit / (ts.size - 1) else 0
        return Probe(ts.sum() / ts.size, jitter, fail * 100 / n)
    }

    fun fmt(p: Probe?): String = when {
        p == null -> "-"
        !p.ok -> "gagal"
        else -> "${p.avg} ms · jitter ${p.jitter} · loss ${p.loss}%"
    }

    private fun gateway(ctx: Context): String? = try {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val g = wm.dhcpInfo.gateway
        if (g == 0) null else "${g and 0xff}.${(g shr 8) and 0xff}.${(g shr 16) and 0xff}.${(g shr 24) and 0xff}"
    } catch (e: Throwable) { null }

    fun kind(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = try { cm.getNetworkCapabilities(cm.activeNetwork) } catch (e: Exception) { null }
        return when {
            caps == null -> "none"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cell"
            else -> "other"
        }
    }

    fun diagnose(ctx: Context): Diag {
        val kind = kind(ctx)
        var rssi = 0; var link = 0; var freq = 0
        var gw: Probe? = null
        if (kind == "wifi") {
            try {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val i = wm.connectionInfo
                rssi = i.rssi; link = i.linkSpeed; freq = i.frequency
            } catch (e: Throwable) {}
            gateway(ctx)?.let { g -> probe(g, 80, 6, 500).takeIf { it.ok }?.let { gw = it } }
        }
        var net = Probe(-1, 0, 100)
        var target = ""
        if (kind != "none") {
            val res = arrayOfNulls<Probe>(TARGETS.size)
            val ths = ArrayList<Thread>()
            for ((i, t) in TARGETS.withIndex()) {
                val th = Thread { res[i] = probe(t.second, 443, 6, 1200) }
                th.start(); ths.add(th)
            }
            for (th in ths) try { th.join() } catch (e: InterruptedException) {}
            for ((i, t) in TARGETS.withIndex()) {
                val p = res[i]
                if (p != null && p.ok && (!net.ok || p.avg < net.avg)) { net = p; target = t.first }
            }
        }
        return Diag(kind, rssi, freq, link, net, gw, target)
    }

    fun adviceFor(d: Diag): List<String> {
        val a = ArrayList<String>()
        if (d.kind == "none") a.add("Tidak ada koneksi internet aktif.")
        if (d.kind == "wifi") {
            if (d.rssi in -127..-76) a.add("Sinyal Wi-Fi lemah (${d.rssi} dBm). Dekatkan HP ke router. Ini penyebab lag terbesar di Wi-Fi.")
            if (d.freq in 2400..2500) a.add("Terhubung ke 2.4 GHz (padat). Pakai 5 GHz bila router punya.")
            if (d.gw != null && (d.gw!!.avg > 20 || d.gw!!.loss > 0))
                a.add("Jalur HP ke router lambat (${fmt(d.gw)}). Coba ganti channel router atau restart router.")
        }
        if (d.net.ok && (d.net.jitter > 25 || d.net.loss > 0))
            a.add("Jitter/loss ke internet tinggi (${fmt(d.net)}). Antrean paket membantu, tapi sebagian penyebabnya ada di jalur provider.")
        if (!d.net.ok && d.kind != "none") a.add("Internet tidak terjangkau (ping gagal).")
        if (a.isEmpty()) a.add("Jaringan sehat. Tidak ada masalah yang terdeteksi.")
        return a
    }

    // ---------- setelan dasar (root & Shizuku) ----------
    private fun wifiCmds(): List<String> = listOf(
        "cmd wifi force-low-latency-mode enabled",
        "cmd wifi force-hi-perf-mode enabled",
        "settings put global wifi_scan_always_enabled 0",
        "settings put global ble_scan_always_enabled 0",
        "settings put global mobile_data_always_on 1",   // data seluler tetap tersambung walau Wi-Fi aktif
        "settings put global adaptive_connectivity_enabled 0",
        "settings put global wifi_wakeup_enabled 0"
    )

    private fun ensureSnap(ctx: Context) {
        val st = Store(ctx)
        if (st.get("snap_net2").isBlank()) {
            val script = NET_KEYS.joinToString("\n") { "echo \"S|$it|\$(settings get global $it)\"" }
            val o = Access.run(script)
            if (o.lines().any { it.startsWith("S|") }) st.put("snap_net2", o)
        }
    }

    // Wi-Fi Lock: Wi-Fi tidak masuk mode hemat daya selama game
    @Volatile private var lock: WifiManager.WifiLock? = null

    @Synchronized fun holdWifi(ctx: Context, on: Boolean) {
        try {
            if (on) {
                if (lock?.isHeld == true) return
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                else WifiManager.WIFI_MODE_FULL_HIGH_PERF
                val l = wm.createWifiLock(mode, "xa:game")
                l.setReferenceCounted(false)
                l.acquire()
                lock = l
            } else {
                lock?.let { if (it.isHeld) it.release() }
                lock = null
            }
        } catch (e: Throwable) {}
    }

    // Doze dimatikan selama game agar koneksi latar tidak ditidurkan
    fun idle(ctx: Context, off: Boolean) {
        val st = Store(ctx)
        if (off) {
            Access.run("dumpsys deviceidle disable")
            st.put("idle_off", "1")
        } else if (st.get("idle_off") == "1") {
            Access.run("dumpsys deviceidle enable")
            st.put("idle_off", "")
        }
    }

    // ---------- kernel: antrean paket + TCP (khusus root) ----------
    private fun ifaceName(): String {
        val t = Access.run("ip route get 1.1.1.1 2>/dev/null").trim().split(Regex("\\s+"))
        val i = t.indexOf("dev")
        val d = if (i >= 0) t.getOrNull(i + 1).orEmpty() else ""
        return if (DEV.matches(d)) d else ""
    }

    private fun tcpSnapScript(): String = TCP_SNAP.joinToString("\n") { p ->
        "[ -w $p ] && echo \"T|$p|\$(cat $p | tr '\\t' ' ')\""
    }

    fun applyKernel(ctx: Context): String {
        if (!Access.isRoot) return "Kernel dilewati (butuh root)."
        val st = Store(ctx)
        var dev = ifaceName()
        if (dev.isEmpty()) dev = "wlan0"

        if (st.get("snap_kernel").isBlank()) {
            val snap = Access.run(tcpSnapScript()).lines().filter { it.startsWith("T|") }
            if (snap.isNotEmpty()) st.put("snap_kernel", snap.joinToString("\n"))
        }
        st.put("kdev", dev)

        val c = ArrayList<String>()
        // fq_codel dengan target 3 ms: antrean pendek, paket game tidak menunggu unduhan
        c.add("tc qdisc replace dev $dev root fq_codel limit 400 target 3ms interval 50ms ecn 2>/dev/null || tc qdisc replace dev $dev root fq_codel 2>/dev/null")
        for ((k, v) in TCP_SET) c.add("[ -w $IP4$k ] && echo $v > $IP4$k")
        val avail = Access.run("cat ${IP4}tcp_available_congestion_control 2>/dev/null").trim()
        if (avail.split(" ").contains("bbr")) c.add("echo bbr > $CC")
        if (dev.startsWith("wlan")) {
            c.add("command -v iw >/dev/null 2>&1 && iw dev $dev set power_save off 2>/dev/null")
            st.put("kpsv", "1")
        }
        val out = Access.run(c.joinToString("\n") + "\ntc qdisc show dev $dev 2>/dev/null | head -n 1\ncat $CC 2>/dev/null")
        val lines = out.lines().map { it.trim() }.filter { it.isNotBlank() }
        val qd = lines.firstOrNull { it.contains("fq_codel") || it.contains("qdisc") } ?: "tidak terbaca"
        val cc = lines.lastOrNull() ?: "?"
        return "Antrean $dev: $qd\nTCP: low-latency, notsent 16 KB, idle-slow-start mati · cc = $cc"
    }

    fun restoreKernel(ctx: Context) {
        val st = Store(ctx)
        val c = ArrayList<String>()
        for (l in st.get("snap_kernel").lines()) {
            val p = l.split("|", limit = 3)
            if (p.size == 3 && p[0] == "T" && p[1].startsWith(IP4) || p.size == 3 && p[0] == "T" && p[1] == CC) {
                val v = p[2].trim()
                if (SAFE_TCP.matches(v)) c.add("[ -w ${p[1]} ] && echo $v > ${p[1]}")
            }
        }
        val dev = st.get("kdev")
        if (DEV.matches(dev)) {
            c.add("tc qdisc del dev $dev root 2>/dev/null")
            if (st.get("kpsv") == "1") c.add("command -v iw >/dev/null 2>&1 && iw dev $dev set power_save on 2>/dev/null")
        }
        if (c.isNotEmpty() && Access.isRoot) Access.run(c.joinToString("\n"))
        st.put("snap_kernel", ""); st.put("kdev", ""); st.put("kpsv", "")
    }

    // ---------- BOOST ----------
    // root = true : Wi-Fi + Doze + antrean fq_codel + TCP low-latency + Wi-Fi power save mati
    // root = false: Wi-Fi + Doze + Wi-Fi Lock (lewat Shizuku, tanpa kernel)
    fun boost(ctx: Context, root: Boolean, progress: (String) -> Unit): String {
        val total = if (root) 5 else 4
        var step = 0
        fun next(t: String) { step++; progress("$step/$total  $t") }

        next("Mengukur kondisi awal...")
        val before = diagnose(ctx)
        ensureSnap(ctx)

        next("Wi-Fi: latensi rendah, scan latar mati...")
        Access.run(wifiCmds().joinToString("\n"))
        holdWifi(ctx, true)

        next("Mematikan tidur jaringan (Doze) selama game...")
        idle(ctx, true)

        var kernelTxt = ""
        if (root) {
            next("Antrean paket fq_codel + TCP low-latency...")
            kernelTxt = applyKernel(ctx)
        }

        next("Mengukur ulang...")
        val after = diagnose(ctx)

        val sb = StringBuilder()
        sb.append(if (root) "SELESAI · MODE ROOT\n" else "SELESAI · MODE SHIZUKU\n")
        sb.append("Ping internet : ").append(fmt(before.net)).append("\n")
        sb.append("        →     ").append(fmt(after.net))
        if (after.target.isNotEmpty()) sb.append("  (${after.target})")
        sb.append("\n")
        if (after.gw != null) sb.append("Router       : ").append(fmt(after.gw)).append("\n")
        sb.append("\nYang diterapkan:\n")
        sb.append("• Wi-Fi latensi rendah + performa tinggi, scan latar mati\n")
        sb.append("• Wi-Fi Lock aktif, Doze dimatikan selama game\n")
        sb.append("• Wi-Fi + data seluler: tetap tersambung bersamaan (mobile_data_always_on=1), sehingga pindah jalur saat Wi-Fi lemah lebih cepat\n")
        if (root) {
            sb.append("• ").append(kernelTxt.replace("\n", "\n  ")).append("\n")
        } else {
            sb.append("• Antrean paket & TCP kernel hanya di mode ROOT\n")
        }
        sb.append("\nCatatan jujur: ping ke server game ditentukan rute provider dan jarak server. ")
        sb.append("Boost menurunkan antrean dan jitter (lonjakan saat unduhan/update berjalan). ")
        sb.append("Angka 10–20 ms ke server tidak bisa dijamin dari HP; itu bergantung pada provider dan lokasi server.\n")
        return sb.toString().trim()
    }

    // ukur satu jalur tertentu (Wi-Fi atau data) langsung lewat Network, tanpa root
    fun probeOn(net: android.net.Network, host: String, port: Int, n: Int, timeoutMs: Int): Probe {
        val ts = ArrayList<Int>()
        var fail = 0
        for (i in 0 until n) {
            val t0 = System.nanoTime()
            var ok = false
            try {
                net.socketFactory.createSocket().use { s -> s.connect(InetSocketAddress(host, port), timeoutMs); ok = true }
            } catch (e: Exception) {}
            if (ok) ts.add(((System.nanoTime() - t0) / 1_000_000L).toInt()) else fail++
            if (i < n - 1) try { Thread.sleep(60) } catch (e: InterruptedException) { break }
        }
        if (ts.isEmpty()) return Probe(-1, 0, 100)
        var jit = 0
        for (i in 1 until ts.size) jit += Math.abs(ts[i] - ts[i - 1])
        val jitter = if (ts.size > 1) jit / (ts.size - 1) else 0
        return Probe(ts.sum() / ts.size, jitter, fail * 100 / n)
    }

    // bandingkan Wi-Fi dan data seluler berdampingan
    fun compare(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var wifi: android.net.Network? = null
        var cell: android.net.Network? = null
        for (nw in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(nw) ?: continue
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
            if (wifi == null && c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = nw
            if (cell == null && c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) cell = nw
        }
        val pw = wifi?.let { probeOn(it, "8.8.8.8", 443, 6, 1500) }
        val pc = cell?.let { probeOn(it, "8.8.8.8", 443, 6, 1500) }
        val sb = StringBuilder()
        sb.append("Wi-Fi : ").append(if (wifi == null) "tidak tersambung" else fmt(pw)).append("\n")
        sb.append("Data  : ").append(if (cell == null) "tidak tersambung" else fmt(pc)).append("\n\n")
        val wOk = pw != null && pw.ok
        val cOk = pc != null && pc.ok
        val saran = when {
            wOk && cOk -> if (pw!!.avg <= pc!!.avg) "Wi-Fi lebih cepat (${pw.avg} vs ${pc.avg} ms)" else "Data lebih cepat (${pc.avg} vs ${pw!!.avg} ms)"
            wOk -> "Pakai Wi-Fi, data tidak terukur"
            cOk -> "Pakai data, Wi-Fi tidak terukur"
            else -> "Keduanya gagal diukur"
        }
        sb.append("Saran: ").append(saran)
        return sb.toString()
    }

    // ---------- verifikasi & reset ----------
    fun resetAll(ctx: Context): String {
        val st = Store(ctx)
        val c = ArrayList<String>()
        c.add("cmd wifi force-low-latency-mode disabled")
        c.add("cmd wifi force-hi-perf-mode disabled")
        for (l in st.get("snap_net2").lines()) {
            val p = l.trim().split("|", limit = 3)
            if (p.size == 3 && p[0] == "S" && p[1] in NET_KEYS) {
                val v = p[2].trim()
                if (v.isBlank() || v == "null") c.add("settings delete global ${p[1]}")
                else if (SAFE.matches(v)) c.add("settings put global ${p[1]} $v")
            }
        }
        if (c.isNotEmpty()) Access.run(c.joinToString("\n"))
        restoreKernel(ctx)
        holdWifi(ctx, false)
        idle(ctx, false)
        st.put("snap_net2", "")
        return "Jaringan dikembalikan ke setelan bawaan HP."
    }
}

// ============================================================
//  Sheet "OPTIMAL JARINGAN"
// ============================================================
class NetSheet(private val ctx: Context, private val onStop: (() -> Unit)? = null, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val box = LinearLayout(ctx)
    private val pingTxt = TextView(ctx)
    private val netTxt = TextView(ctx)
    private val detail = TextView(ctx)
    private val result = TextView(ctx)
    private val store = Store(ctx)
    @Volatile private var busy = false

    private fun px(v: Int) = ctx.px(v)

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun btn(t: String, primary: Boolean = false, click: () -> Unit): TextView {
        val v = tv(t, 12f, if (primary) Color.parseColor("#04141F") else Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.setPadding(px(14), px(9), px(14), px(9))
        v.background = if (primary) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(16f), 1f)
        else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(60, 255, 255, 255), ctx.pxf(16f), 1f)
        v.setOnClickListener { Sfx.tap(); click() }
        return v
    }

    private fun section(title: String, desc: String, tag: String) {
        val h = LinearLayout(ctx)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.addView(tv(title, 13f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (tag.isNotEmpty()) h.addView(tv(tag, 10f, Color.parseColor("#FFC24B"), true))
        box.addView(h, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(12) })
        if (desc.isNotEmpty()) box.addView(tv(desc, 11f, Hud.sub), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(3) })
    }

    private fun show(t: String, color: Int = Color.parseColor("#38E8A5")) {
        root.post { result.setTextColor(color); result.text = t }
    }

    private fun pingColor(ms: Int) = when {
        ms < 0 -> Color.parseColor("#FF5D5D")
        ms <= 25 -> Color.parseColor("#38E8A5")
        ms <= 60 -> Color.parseColor("#FFC24B")
        else -> Color.parseColor("#FF5D5D")
    }

    private fun setPing(ms: Int) {
        pingTxt.text = if (ms < 0) "gagal" else "$ms ms"
        pingTxt.setTextColor(pingColor(ms))
    }

    private fun refreshNet() {
        netTxt.text = when (NetOpt.kind(ctx)) {
            "none" -> "Tidak ada koneksi"
            "wifi" -> "Wi-Fi"
            "cell" -> "Data seluler"
            else -> "Terhubung"
        }
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(12f), 1f)
        root.setPadding(px(16), px(12), px(16), px(12))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("OPTIMAL JARINGAN", 14f, Hud.cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        val x = tv("✕", 18f)
        x.setPadding(px(10), px(2), px(4), px(2))
        x.setOnClickListener { Sfx.tap(); onClose() }
        head.addView(x)
        root.addView(head)

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        box.orientation = LinearLayout.VERTICAL
        sv.addView(box)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        // status + ping + diagnosa
        val st = LinearLayout(ctx)
        st.orientation = LinearLayout.HORIZONTAL
        st.gravity = Gravity.CENTER_VERTICAL
        netTxt.textSize = 12f; netTxt.setTextColor(Hud.sub)
        pingTxt.textSize = 22f; pingTxt.typeface = Typeface.DEFAULT_BOLD
        pingTxt.text = "-- ms"
        st.addView(netTxt, LinearLayout.LayoutParams(0, -2, 1f))
        st.addView(pingTxt, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(10) })
        st.addView(btn("Diagnosa") { diagnose() })
        box.addView(st, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })

        detail.textSize = 11f
        detail.setTextColor(Hud.sub)
        box.addView(detail, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(6) })

        // ---- BOOST ROOT vs SHIZUKU (dibedakan) ----
        section("BOOST ROOT",
            "Paket lengkap: antrean fq_codel (anti lonjakan ping), TCP low-latency, Wi-Fi power save mati, " +
                "Wi-Fi latensi rendah, Doze mati selama game.",
            if (Access.isRoot) "ROOT ✓" else "ROOT ✗")
        box.addView(btn("⚡ Boost Root", true) { boostNow(true) }, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })

        section("BOOST SHIZUKU",
            "Tanpa kernel: Wi-Fi latensi rendah, scan latar mati, koneksi tidak pindah sendiri, Wi-Fi Lock, Doze mati selama game.",
            if (Access.hasAny()) "SHIZUKU ✓" else "SHIZUKU ✗")
        box.addView(btn("⚡ Boost Shizuku", true) { boostNow(false) }, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })

        // ---- kunci Wi-Fi ----
        val pLock = Pill(ctx)
        pLock.setOn(store.get("wifi_lock") != "0")
        pLock.onToggle = { v ->
            store.put("wifi_lock", if (v) "1" else "0")
            if (store.active) Thread { NetOpt.holdWifi(ctx, v) }.start()
        }
        section("Kunci Wi-Fi saat game", "Wi-Fi tidak masuk mode hemat daya selama game berjalan.", "")
        box.addView(pLock, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(6) })

        // ---- lainnya ----
        section("Bandingkan Wi-Fi vs Data", "Ukur ping Wi-Fi dan data seluler berdampingan, lalu lihat mana yang lebih cepat.", "")
        box.addView(btn("Ukur keduanya") { Thread { show(NetOpt.compare(ctx), Hud.sub) }.start() }, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(6) })

        section("Lainnya", "", "")
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(btn("⛔ Stop App") { onStop?.invoke() }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(8) })
        row.addView(btn("Reset ke bawaan") {
            if (!Access.requires(ctx, "Reset jaringan", false)) return@btn
            Thread { show(NetOpt.resetAll(ctx), Hud.sub) }.start()
        })
        box.addView(row, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(6) })

        result.textSize = 11f
        result.setTextColor(Hud.sub)
        box.addView(result, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(10) })

        refreshNet()
        diagnose()
    }

    private fun diagnose() {
        if (busy) return
        busy = true
        pingTxt.text = "…"
        pingTxt.setTextColor(Color.WHITE)
        detail.text = "Mengukur ping, jitter, dan sinyal..."
        Thread {
            val d = NetOpt.diagnose(ctx)
            val sb = StringBuilder()
            if (d.kind == "wifi") {
                sb.append("Wi-Fi ").append(d.rssi).append(" dBm · ").append(d.link).append(" Mbps · ")
                    .append(if (d.freq in 2400..2500) "2.4 GHz" else if (d.freq > 4900) "5 GHz" else "${d.freq} MHz").append("\n")
                if (d.gw != null) sb.append("Router: ").append(NetOpt.fmt(d.gw)).append("\n")
            }
            sb.append("Internet").append(if (d.target.isNotEmpty()) " (${d.target})" else "")
                .append(": ").append(NetOpt.fmt(d.net)).append("\n\n")
            for (a in NetOpt.adviceFor(d)) sb.append("• ").append(a).append("\n")
            busy = false
            root.post {
                refreshNet()
                setPing(d.net.avg)
                detail.text = sb.toString().trim()
            }
        }.start()
    }

    private fun boostNow(rootMode: Boolean) {
        if (!Access.requires(ctx, if (rootMode) "Boost Root" else "Boost Shizuku", rootMode)) return
        if (busy) return
        busy = true
        show("Memulai...", Hud.sub)
        Thread {
            val txt = NetOpt.boost(ctx, rootMode) { show(it, Hud.sub) }
            busy = false
            show(txt)
            val p = NetOpt.probe("8.8.8.8", 443, 4, 1500)
            root.post { refreshNet(); setPing(p.avg) }
        }.start()
    }
}
