package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.ConnectException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

// =====================================================================
//  Mesin optimasi jaringan: diagnosa nyata (ping, jitter, loss, DNS, sinyal Wi-Fi),
//  Wi-Fi latensi rendah, DNS terenkripsi tercepat (diverifikasi, otomatis dibatalkan bila gagal),
//  tweak TCP kernel (root) + semua nilai asli disimpan dan bisa dikembalikan.
// =====================================================================
object NetOpt {
    data class Probe(val avg: Int, val jitter: Int, val loss: Int) {
        val ok: Boolean get() = avg >= 0
    }

    data class Diag(
        val kind: String,          // wifi / cell / none
        val rssi: Int,
        val linkMbps: Int,
        val freqMhz: Int,
        val gw: Probe?,
        val net: Probe,
        val dnsMs: Int,
        val advice: List<String>,
        val netName: String = ""
    )

    private val TARGETS = listOf("Google" to "8.8.8.8", "Cloudflare" to "1.1.1.1", "Quad9" to "9.9.9.9")

    private val DOT = listOf("Google" to "dns.google", "Cloudflare" to "one.one.one.one", "Quad9" to "dns.quad9.net")

    private const val IP4 = "/proc/sys/net/ipv4/"
    private const val CORE = "/proc/sys/net/core/"
    private const val CC = IP4 + "tcp_congestion_control"
    private val TCP_NUM = listOf(
        "tcp_slow_start_after_idle" to "0",
        "tcp_low_latency" to "1",
        "tcp_fastopen" to "3",
        "tcp_no_metrics_save" to "1",
        "tcp_mtu_probing" to "1",
        "tcp_autocorking" to "0",
        "tcp_notsent_lowat" to "131072",
        "tcp_thin_linear_timeouts" to "1"
    )
    private val TCP_PATHS: List<String> = listOf(CC) + TCP_NUM.map { IP4 + it.first } +
        listOf(CORE + "rmem_max", CORE + "wmem_max", CORE + "netdev_max_backlog", IP4 + "tcp_rmem", IP4 + "tcp_wmem")

    private val NET_KEYS = listOf(
        "wifi_scan_always_enabled", "ble_scan_always_enabled", "mobile_data_always_on",
        "wifi_networks_available_notification_on", "private_dns_mode", "private_dns_specifier"
    )

    private val SAFE = Regex("^[A-Za-z0-9_.\\- ]+$")
    private val SAFE_TCP = Regex("^[a-z0-9 ]+$")

    // ---------- pengukuran ----------
    fun probe(host: String, port: Int, n: Int, timeoutMs: Int): Probe {
        val ts = ArrayList<Int>()
        var fail = 0
        for (i in 0 until n) {
            val t0 = System.nanoTime()
            var ok = false
            try {
                Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
                ok = true
            } catch (e: ConnectException) {
                // ditolak = host membalas, jadi waktunya tetap sah sebagai RTT
                if ((e.message ?: "").contains("refused", true)) ok = true
            } catch (e: Exception) {
            }
            if (ok) ts.add(((System.nanoTime() - t0) / 1_000_000L).toInt()) else fail++
            if (i < n - 1) {
                try { Thread.sleep(60) } catch (e: InterruptedException) { break }
            }
        }
        if (ts.isEmpty()) return Probe(-1, 0, 100)
        var jit = 0
        for (i in 1 until ts.size) jit += Math.abs(ts[i] - ts[i - 1])
        val jitter = if (ts.size > 1) jit / (ts.size - 1) else 0
        return Probe(ts.sum() / ts.size, jitter, fail * 100 / n)
    }

    // waktu resolusi DNS dengan nama unik (NXDOMAIN) supaya tidak kena cache
    fun dnsMs(): Int {
        val ts = ArrayList<Int>()
        val seed = System.nanoTime() % 1000000L
        for (i in 0 until 3) {
            val t0 = System.nanoTime()
            try { InetAddress.getByName("xa$seed$i.example.com") } catch (e: Exception) {}
            ts.add(((System.nanoTime() - t0) / 1_000_000L).toInt())
        }
        ts.sort()
        return ts[1]
    }

    private fun gateway(ctx: Context): String? = try {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val g = wm.dhcpInfo.gateway
        if (g == 0) null else "${g and 0xff}.${(g shr 8) and 0xff}.${(g shr 16) and 0xff}.${(g shr 24) and 0xff}"
    } catch (e: Throwable) { null }

    fun kind(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = try { cm.getNetworkCapabilities(cm.activeNetwork) } catch (e: Exception) { null }
        return when {
            caps == null -> "none"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cell"
            else -> "other"
        }
    }

    fun fmt(p: Probe?): String = when {
        p == null -> "-"
        !p.ok -> "gagal"
        else -> "${p.avg} ms · jitter ${p.jitter} · loss ${p.loss}%"
    }

    fun diagnose(ctx: Context): Diag {
        val kind = kind(ctx)
        var rssi = 0; var link = 0; var freq = 0
        var gw: Probe? = null
        if (kind == "wifi") {
            try {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val i = wm.connectionInfo
                rssi = i.rssi; link = i.linkSpeed; freq = i.frequency
            } catch (e: Throwable) {}
            val g = gateway(ctx)
            if (g != null) {
                val p = probe(g, 80, 8, 500)
                if (p.ok) gw = p
            }
        }
        var net = Probe(-1, 0, 100)
        var netName = ""
        if (kind != "none") {
            for ((n, h) in TARGETS) {
                val p = probe(h, 443, 5, 1500)
                if (p.ok && (!net.ok || p.avg < net.avg)) { net = p; netName = n }
            }
        }
        val dns = if (kind == "none") -1 else dnsMs()

        val a = ArrayList<String>()
        if (kind == "none") a.add("Tidak ada koneksi internet aktif.")
        if (kind == "wifi") {
            if (rssi in -127..-76) a.add("Sinyal Wi-Fi lemah ($rssi dBm). Dekatkan HP ke router atau hilangkan penghalang. Ini penyebab lag terbesar.")
            else if (rssi in -75..-68) a.add("Sinyal Wi-Fi sedang ($rssi dBm). Lebih dekat ke router akan lebih stabil.")
            if (freq in 2400..2500) a.add("Terhubung ke 2.4 GHz (padat, mudah bentrok). Bila router punya 5 GHz, pindah ke jaringan 5 GHz.")
            if (link in 1..39) a.add("Kecepatan link rendah ($link Mbps): kualitas sambungan ke router buruk.")
            if (gw != null && (gw.avg > 25 || gw.loss > 0 || gw.jitter > 15))
                a.add("Jalur HP ke router bermasalah (${fmt(gw)}): kemungkinan interferensi Wi-Fi atau terlalu banyak perangkat. Coba restart router / ganti channel.")
        }
        if (net.ok) {
            val routerFine = kind != "wifi" || gw == null || (gw.avg <= 25 && gw.loss == 0)
            if ((net.avg > 100 || net.loss > 0 || net.jitter > 30) && routerFine)
                a.add("Jalur ke internet lambat/tidak stabil (${fmt(net)}) padahal sinyal ke router baik: masalah ada di provider/kuota/jam sibuk, di luar kendali aplikasi.")
        } else if (kind != "none") a.add("Internet tidak terjangkau (ping gagal).")
        if (dns > 150) a.add("DNS lambat ($dns ms). Optimizer akan memilih DNS tercepat.")
        if (a.isEmpty()) a.add("Jaringan sehat. Tidak ada masalah yang terdeteksi.")
        return Diag(kind, rssi, link, freq, gw, net, dns, a, netName)
    }

    // ---------- snapshot setelan ----------
    private fun settingsSnap(): String {
        val sb = StringBuilder()
        for (k in NET_KEYS) sb.append("echo \"S|global|$k|§(settings get global $k)\"\n")
        return sb.toString().replace('§', '$')
    }

    private fun ensureSnap(ctx: Context) {
        val st = Store(ctx)
        if (st.get("snap_net").isBlank()) {
            val o = Access.run(settingsSnap())
            if (o.lines().any { it.startsWith("S|") }) st.put("snap_net", o)
        }
    }

    // ---------- Wi-Fi & data ----------
    fun wifiData(): String {
        val c = ArrayList<String>()
        c.add("cmd wifi force-low-latency-mode enabled")
        c.add("cmd wifi force-hi-perf-mode enabled")
        c.add("settings put global wifi_scan_always_enabled 0")
        c.add("settings put global ble_scan_always_enabled 0")
        c.add("settings put global wifi_networks_available_notification_on 0")
        c.add("settings put global mobile_data_always_on 0")
        c.add("cmd netpolicy set restrict-background false")
        if (Access.isRoot) {
            c.add("command -v iw >/dev/null 2>&1 && iw dev wlan0 set power_save off")
            c.add("ndc resolver flushdefaultif 2>/dev/null")
        }
        return c.joinToString("\n")
    }

    // Wi-Fi lock: Wi-Fi tidak masuk mode hemat daya selama game berjalan
    @Volatile private var lock: WifiManager.WifiLock? = null

    @Synchronized fun holdWifi(ctx: Context, on: Boolean) {
        try {
            if (on) {
                if (lock?.isHeld == true) return
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                else WifiManager.WIFI_MODE_FULL_HIGH_PERF
                val l = wm.createWifiLock(mode, "xa:game")
                l.setReferenceCounted(false)
                l.acquire()
                lock = l
            } else {
                lock?.let { if (it.isHeld) it.release() }
                lock = null
            }
        } catch (e: Throwable) {
        }
    }

    // ---------- DNS ----------
    // Pilih DNS terenkripsi tercepat. Diverifikasi; bila internet jadi tidak bisa resolve, dibatalkan otomatis.
    fun smartDns(ctx: Context, curDnsMs: Int): String {
        val cand = DOT.map { (n, h) -> Triple(n, h, probe(h, 853, 4, 1500)) }
            .filter { it.third.ok && it.third.loss <= 25 }
        val best = cand.minByOrNull { it.third.avg }
            ?: return "DNS: jaringan ini memblokir DNS terenkripsi (port 853), DNS otomatis dipertahankan."
        if (curDnsMs in 0..(best.third.avg + 10))
            return "DNS: bawaan sudah cepat ($curDnsMs ms), tidak diganti."
        Access.run("settings put global private_dns_mode hostname; settings put global private_dns_specifier ${best.second}")
        try { Thread.sleep(1500) } catch (e: InterruptedException) {}
        var good = false
        var t = -1
        for (h in listOf("www.wikipedia.org", "www.bing.com")) {
            val t0 = System.nanoTime()
            try { InetAddress.getByName(h); good = true } catch (e: Exception) {}
            if (good) { t = ((System.nanoTime() - t0) / 1_000_000L).toInt(); break }
        }
        if (!good) {
            Access.run("settings put global private_dns_mode opportunistic")
            return "DNS ${best.first} gagal diverifikasi, dikembalikan ke otomatis (internet tetap aman)."
        }
        return "DNS: ${best.first} (${best.third.avg} ms ke server, resolusi uji $t ms)"
    }

    // ---------- TCP kernel (root) ----------
    private fun tcpSnapScript(): String {
        val sb = StringBuilder()
        for (p in TCP_PATHS) sb.append("[ -w $p ] && echo \"T|$p|§(cat $p | tr '\\t' ' ')\"\n")
        sb.append("echo \"A|§(cat ${IP4}tcp_available_congestion_control 2>/dev/null)\"\n")
        return sb.toString().replace('§', '$')
    }

    fun applyTcp(ctx: Context): String {
        if (!Access.isRoot) return "TCP kernel dilewati (butuh root)."
        val st = Store(ctx)
        val map = LinkedHashMap<String, String>()
        var avail = ""
        for (l in Access.run(tcpSnapScript()).lines()) {
            val p = l.split("|", limit = 3)
            if (p.size == 3 && p[0] == "T") map[p[1]] = p[2].trim()
            else if (p.size >= 2 && p[0] == "A") avail = p[1]
        }
        if (map.isEmpty()) return "TCP: jalur kernel tidak bisa ditulis di HP ini."
        if (st.get("snap_tcp").isBlank()) st.put("snap_tcp", map.entries.joinToString("\n") { "${it.key}|${it.value}" })

        val c = ArrayList<String>()
        if (map.containsKey(CC) && avail.split(" ").contains("bbr")) c.add("echo bbr > $CC")
        for ((k, v) in TCP_NUM) if (map.containsKey(IP4 + k)) c.add("echo $v > ${IP4 + k}")
        fun raise(p: String, target: Long) {
            val cur = map[p]?.toLongOrNull() ?: return
            if (cur < target) c.add("echo $target > $p")
        }
        raise(CORE + "rmem_max", 4194304L)
        raise(CORE + "wmem_max", 4194304L)
        raise(CORE + "netdev_max_backlog", 5000L)
        for (k in listOf("tcp_rmem", "tcp_wmem")) {
            val p = IP4 + k
            val parts = (map[p] ?: continue).split(" ").filter { it.isNotBlank() }
            val mx = parts.getOrNull(2)?.toLongOrNull() ?: continue
            if (parts.size == 3 && mx < 4194304L) c.add("echo ${parts[0]} ${parts[1]} 4194304 > $p")
        }
        if (c.isNotEmpty()) Access.run(c.joinToString("\n"))
        val now = Access.run("cat $CC").trim()
        return "TCP: ${c.size} parameter diatur, congestion control = $now"
    }

    fun restoreTcp(ctx: Context) {
        val st = Store(ctx)
        val snap = st.get("snap_tcp")
        if (snap.isBlank()) return
        val c = ArrayList<String>()
        for (l in snap.lines()) {
            val p = l.split("|", limit = 2)
            if (p.size == 2 && p[0] in TCP_PATHS && SAFE_TCP.matches(p[1].trim()))
                c.add("[ -w ${p[0]} ] && echo ${p[1].trim()} > ${p[0]}")
        }
        if (c.isNotEmpty()) Access.run(c.joinToString("\n"))
        st.put("snap_tcp", "")
    }

    // ---------- antrean paket (anti bufferbloat, root) ----------
    private val DEV = Regex("^[a-z0-9_]+$")

    private fun devScript(): String =
        ("dev=§(ip route get 8.8.8.8 2>/dev/null | sed -n 's/.* dev \\([^ ]*\\).*/\\1/p' | head -n 1)\n" +
            "[ -z \"§dev\" ] && dev=wlan0\n" +
            "echo \"DEV|§dev\"\n" +
            "echo \"Q|§(cat /sys/class/net/§dev/tx_queue_len 2>/dev/null)\"\n").replace('§', '$')

    // fq_codel + antrean pendek: paket game tidak mengantre di belakang unduhan
    fun applyQueue(ctx: Context): String {
        if (!Access.isRoot) return "Antrean paket dilewati (butuh root)."
        var dev = "wlan0"
        var q = ""
        for (l in Access.run(devScript()).lines()) {
            val p = l.trim().split("|", limit = 2)
            if (p.size == 2 && p[0] == "DEV" && DEV.matches(p[1])) dev = p[1]
            if (p.size == 2 && p[0] == "Q") q = p[1].trim()
        }
        val st = Store(ctx)
        if (st.get("snap_q").isBlank() && q.toIntOrNull() != null) st.put("snap_q", "$dev|$q")
        Access.run(
            "tc qdisc replace dev $dev root fq_codel 2>/dev/null\n" +
                "[ -w /sys/class/net/$dev/tx_queue_len ] && echo 200 > /sys/class/net/$dev/tx_queue_len"
        )
        return "Antrean $dev: fq_codel, panjang antrean ${q.ifBlank { "?" }} → 200"
    }

    fun restoreQueue(ctx: Context) {
        val st = Store(ctx)
        val snap = st.get("snap_q")
        if (snap.isBlank()) return
        val p = snap.split("|")
        if (p.size == 2 && DEV.matches(p[0]) && p[1].toIntOrNull() != null) {
            Access.run("tc qdisc del dev ${p[0]} root 2>/dev/null\n[ -w /sys/class/net/${p[0]}/tx_queue_len ] && echo ${p[1]} > /sys/class/net/${p[0]}/tx_queue_len")
        }
        st.put("snap_q", "")
    }

    // ---------- reset ----------
    fun resetAll(ctx: Context): String {
        val st = Store(ctx)
        val c = ArrayList<String>()
        c.add("cmd wifi force-low-latency-mode disabled")
        c.add("cmd wifi force-hi-perf-mode disabled")
        var hasDns = false
        for (l in st.get("snap_net").lines()) {
            val p = l.trim().split("|", limit = 4)
            if (p.size == 4 && p[0] == "S" && p[1] == "global" && p[2] in NET_KEYS) {
                val v = p[3].trim()
                if (p[2] == "private_dns_mode" && v.isNotBlank() && v != "null") hasDns = true
                if (v.isBlank() || v == "null") c.add("settings delete global ${p[2]}")
                else if (SAFE.matches(v)) c.add("settings put global ${p[2]} $v")
            }
        }
        if (!hasDns) c.add("settings put global private_dns_mode opportunistic")
        Access.run(c.joinToString("\n"))
        restoreTcp(ctx)
        restoreQueue(ctx)
        holdWifi(ctx, false)
        st.put("snap_net", "")
        return "Jaringan dikembalikan ke setelan bawaan HP."
    }

    // ---------- BOOST ----------
    // rootMode = true : paket lengkap termasuk kernel (TCP, antrean paket, power save Wi-Fi) -> khusus ROOT
    // rootMode = false: hanya yang boleh lewat Shizuku (tanpa kernel)
    fun boostAll(ctx: Context, rootMode: Boolean, killBg: Boolean, progress: (String) -> Unit): String {
        val st = Store(ctx)
        val total = if (rootMode) 7 else 5
        var step = 0
        fun next(t: String) { step++; progress("$step/$total  $t") }

        next("Mengukur kondisi awal...")
        val before = diagnose(ctx)
        ensureSnap(ctx)

        next("Wi-Fi latensi rendah & data...")
        Access.run(wifiData())
        holdWifi(ctx, true)

        next("Mencari DNS tercepat...")
        val dns = smartDns(ctx, before.dnsMs)

        var tcp = ""
        var queue = ""
        if (rootMode) {
            next("Tweak TCP kernel...")
            tcp = applyTcp(ctx)
            next("Antrean paket anti-bufferbloat...")
            queue = applyQueue(ctx)
        }

        var killed = -1
        if (killBg) {
            next("Menghentikan aplikasi latar penyedot jaringan...")
            killed = Boost.killBackground(ctx, st.game)
        } else next("Lewati hentikan aplikasi latar...")

        next("Mengukur ulang...")
        try { Thread.sleep(1200) } catch (e: InterruptedException) {}
        val after = diagnose(ctx)

        val sb = StringBuilder()
        sb.append(if (rootMode) "SELESAI · MODE ROOT\n" else "SELESAI · MODE SHIZUKU\n")
        sb.append("Internet : ").append(fmt(before.net)).append("\n      →  ").append(fmt(after.net))
        if (after.netName.isNotEmpty()) sb.append(" (").append(after.netName).append(")")
        sb.append("\n")
        if (after.gw != null) sb.append("Router   : ").append(fmt(after.gw)).append("\n")
        if (before.dnsMs >= 0 || after.dnsMs >= 0) sb.append("DNS      : ${before.dnsMs} ms → ${after.dnsMs} ms\n")
        sb.append("\n• Wi-Fi: latensi rendah + performa tinggi aktif, scan latar dimatikan, Wi-Fi Lock aktif\n")
        sb.append("• ").append(dns).append("\n")
        if (rootMode) {
            sb.append("• ").append(tcp).append("\n")
            sb.append("• ").append(queue).append("\n")
        } else sb.append("• Tweak kernel (TCP, antrean) tidak tersedia di mode Shizuku; gunakan root untuk itu.\n")
        if (killed >= 0) sb.append("• Aplikasi latar dihentikan: $killed\n")
        if (after.net.ok && after.net.avg > 10)
            sb.append("\nCatatan: ping ke internet ditentukan jarak server dan provider (umumnya 10–40 ms). " +
                "Angka 1–10 ms hanya realistis ke router. Aplikasi menekan latensi di sisi HP, bukan jarak ke server.\n")
        sb.append("\nYang masih bisa membuat lag:\n")
        for (a in after.advice) sb.append("– ").append(a).append("\n")
        return sb.toString().trim()
    }
}

// Sheet "Optimal Jaringan"
class NetSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val box = LinearLayout(ctx)
    private val pingTxt = TextView(ctx)
    private val netTxt = TextView(ctx)
    private val detail = TextView(ctx)
    private val result = TextView(ctx)
    private val store = Store(ctx)
    @Volatile private var busy = false

    private fun px(v: Int) = ctx.px(v)

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun btn(t: String, primary: Boolean = false, click: () -> Unit): TextView {
        val v = tv(t, 11f, if (primary) Color.parseColor("#04141F") else Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.setPadding(px(12), px(7), px(12), px(7))
        v.background = if (primary) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(16f), 1f)
        else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(60, 255, 255, 255), ctx.pxf(16f), 1f)
        v.setOnClickListener { Sfx.tap(); click() }
        return v
    }

    private fun section(title: String, desc: String, tag: String, pill: Pill? = null) {
        val h = LinearLayout(ctx)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.addView(tv(title, 12f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        h.addView(tv(tag, 9f, Color.parseColor("#FFC24B"), true).also { it.setPadding(0, 0, px(if (pill != null) 8 else 0), 0) })
        if (pill != null) h.addView(pill)
        box.addView(h, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(10) })
        if (desc.isNotEmpty()) box.addView(tv(desc, 10f, Hud.sub), LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(5) })
    }

    private fun show(t: String, color: Int = Color.parseColor("#38E8A5")) {
        root.post { result.setTextColor(color); result.text = t }
    }

    private fun runCmd(name: String, rootOnly: Boolean, cmd: String) {
        if (!Access.requires(ctx, name, rootOnly)) return
        show("Menjalankan $name...", Hud.sub)
        Thread {
            val out = Access.run(cmd)
            show("$name selesai." + if (out.isBlank()) "" else "\n" + out.take(220))
        }.start()
    }

    private fun pingColor(ms: Int) = when {
        ms < 0 -> Color.parseColor("#FF5D5D")
        ms < 60 -> Color.parseColor("#38E8A5")
        ms < 120 -> Color.parseColor("#FFC24B")
        else -> Color.parseColor("#FF5D5D")
    }

    private fun setPing(ms: Int) {
        pingTxt.text = if (ms < 0) "gagal" else "$ms ms"
        pingTxt.setTextColor(pingColor(ms))
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        root.setPadding(px(12), px(10), px(12), px(10))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("OPTIMAL JARINGAN", 12f, Hud.cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        val x = tv("✕", 16f)
        x.setPadding(px(10), px(2), px(4), px(2))
        x.setOnClickListener { Sfx.tap(); onClose() }
        head.addView(x)
        root.addView(head)

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        box.orientation = LinearLayout.VERTICAL
        sv.addView(box)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        // status + ping
        val st = LinearLayout(ctx)
        st.orientation = LinearLayout.HORIZONTAL
        st.gravity = Gravity.CENTER_VERTICAL
        netTxt.textSize = 11f; netTxt.setTextColor(Hud.sub)
        pingTxt.textSize = 18f; pingTxt.typeface = Typeface.DEFAULT_BOLD; pingTxt.setTextColor(Color.WHITE)
        pingTxt.text = "-- ms"
        st.addView(netTxt, LinearLayout.LayoutParams(0, -2, 1f))
        st.addView(pingTxt, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(10) })
        st.addView(btn("Diagnosa", true) { diagnose() })
        box.addView(st, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(6) })

        detail.textSize = 10f
        detail.setTextColor(Hud.sub)
        box.addView(detail, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(4) })

        val rootOk = Access.satisfied(true)
        val shOk = Access.hasAny()
        section("MODE ROOT",
            "Paket terdalam: Wi-Fi latensi rendah, power save Wi-Fi mati, DNS tercepat (diuji), TCP kernel (BBR, Fast Open, " +
                "buffer, autocorking), antrean fq_codel anti-bufferbloat, flush DNS, hentikan app latar, ukur ulang.",
            if (rootOk) "ROOT ✓" else "ROOT ✗")
        box.addView(btn("⚡ BOOST ROOT  ·  jaringan penuh", true) { boostTotal(true) })

        section("MODE SHIZUKU",
            "Tanpa tweak kernel: Wi-Fi latensi rendah, scan latar mati, data saver mati, DNS tercepat (diuji), " +
                "Wi-Fi Lock, hentikan app latar, ukur ulang.",
            if (shOk) "SHIZUKU ✓" else "SHIZUKU ✗")
        box.addView(btn("⚡ BOOST SHIZUKU  ·  tanpa kernel", true) { boostTotal(false) })

        val pKill = Pill(ctx)
        pKill.setOn(store.get("net_kill") != "0")
        pKill.onToggle = { v -> store.put("net_kill", if (v) "1" else "0") }
        section("Hentikan app latar", "Ikut dihentikan saat Boost Root / Shizuku (game tidak ikut dihentikan).", "", pKill)

        val pLock = Pill(ctx)
        pLock.setOn(store.get("wifi_lock") != "0")
        pLock.onToggle = { v ->
            store.put("wifi_lock", if (v) "1" else "0")
            if (store.active) Thread { NetOpt.holdWifi(ctx, v) }.start()
        }
        section("Kunci Wi-Fi saat game", "Wi-Fi tidak masuk mode hemat daya selama game berjalan (Wi-Fi Lock). Otomatis saat boost aktif.", "", pLock)

        section("Alat manual", "Atur satu per satu bila perlu.", "")

        section("Wi-Fi & data", "Latensi rendah + performa tinggi, matikan scan Wi-Fi/Bluetooth di latar, data saver mati.", "ROOT/SHIZUKU")
        box.addView(btn("Optimalkan Wi-Fi & data") { runCmd("Optimasi Wi-Fi", false, NetOpt.wifiData()) })

        section("DNS pribadi", "Ganti DNS terenkripsi agar resolusi server game lebih cepat. 'Otomatis' = bawaan HP.", "ROOT/SHIZUKU")
        box.addView(dnsChips())

        section("Kernel TCP + antrean", "BBR (jika ada), Fast Open, MTU probing, autocorking mati, buffer lebih besar, antrean fq_codel pendek. Nilai asli disimpan.", "KHUSUS ROOT")
        box.addView(btn("Tweak TCP + antrean") {
            if (!Access.requires(ctx, "Tweak TCP", true)) return@btn
            show("Menjalankan Tweak TCP...", Hud.sub)
            Thread { show(NetOpt.applyTcp(ctx) + "\n" + NetOpt.applyQueue(ctx)) }.start()
        })

        box.addView(btn("Reset ke bawaan") {
            if (!Access.requires(ctx, "Reset jaringan", false)) return@btn
            Thread { show(NetOpt.resetAll(ctx)) }.start()
        }, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(12) })

        result.textSize = 10f
        result.setTextColor(Hud.sub)
        box.addView(result, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })

        refreshNet()
        quickPing()
    }

    private fun refreshNet() {
        netTxt.text = when (NetOpt.kind(ctx)) {
            "none" -> "Tidak ada koneksi"
            "wifi" -> "Terhubung: Wi-Fi"
            "cell" -> "Terhubung: Data seluler"
            else -> "Terhubung"
        }
    }

    private fun quickPing() {
        pingTxt.text = "…"
        pingTxt.setTextColor(Color.WHITE)
        Thread {
            val p = NetOpt.probe("8.8.8.8", 443, 4, 1500)
            root.post { refreshNet(); setPing(p.avg) }
        }.start()
    }

    private fun diagnose() {
        if (busy) return
        busy = true
        pingTxt.text = "…"
        pingTxt.setTextColor(Color.WHITE)
        detail.text = "Mengukur ping, jitter, DNS, sinyal..."
        Thread {
            val d = NetOpt.diagnose(ctx)
            val sb = StringBuilder()
            if (d.kind == "wifi") {
                sb.append("Wi-Fi: ").append(d.rssi).append(" dBm · ").append(d.linkMbps).append(" Mbps · ")
                    .append(if (d.freqMhz in 2400..2500) "2.4 GHz" else if (d.freqMhz > 4900) "5 GHz" else "${d.freqMhz} MHz").append("\n")
                if (d.gw != null) sb.append("Router: ").append(NetOpt.fmt(d.gw)).append("\n")
            }
            sb.append("Internet").append(if (d.netName.isNotEmpty()) " (server terdekat: ${d.netName})" else "").append(": ").append(NetOpt.fmt(d.net)).append("\n")
            if (d.dnsMs >= 0) sb.append("DNS: ").append(d.dnsMs).append(" ms\n")
            sb.append("\n")
            for (a in d.advice) sb.append("• ").append(a).append("\n")
            busy = false
            root.post {
                refreshNet()
                setPing(d.net.avg)
                detail.text = sb.toString().trim()
            }
        }.start()
    }

    private fun boostTotal(rootMode: Boolean) {
        if (!Access.requires(ctx, if (rootMode) "Boost Root" else "Boost Shizuku", rootMode)) return
        if (busy) return
        busy = true
        show("Memulai...", Hud.sub)
        Thread {
            val kill = store.get("net_kill") != "0"
            val txt = NetOpt.boostAll(ctx, rootMode, kill) { show(it, Hud.sub) }
            val p = NetOpt.probe("8.8.8.8", 443, 4, 1500)
            busy = false
            show(txt)
            root.post { refreshNet(); setPing(p.avg) }
        }.start()
    }

    private fun dnsChips(): View {
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.HORIZONTAL
        val opts = listOf(
            Triple("Otomatis", "opportunistic", ""),
            Triple("Google", "hostname", "dns.google"),
            Triple("Cloudflare", "hostname", "one.one.one.one"),
            Triple("Quad9", "hostname", "dns.quad9.net"),
            Triple("Mati", "off", "")
        )
        for ((name, mode, host) in opts) {
            l.addView(btn(name) {
                val cmd = "settings put global private_dns_mode $mode" +
                    if (host.isNotEmpty()) "; settings put global private_dns_specifier $host" else ""
                runCmd("DNS $name", false, cmd)
            }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(6) })
        }
        hs.addView(l)
        return hs
    }
}
