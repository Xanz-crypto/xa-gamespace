package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.InetSocketAddress
import java.net.Socket

// Sheet "Optimal Jaringan" di Game Panel: tes ping, optimasi Wi-Fi / data, DNS pribadi, tweak TCP (root)
class NetSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val box = LinearLayout(ctx)
    private val pingTxt = TextView(ctx)
    private val netTxt = TextView(ctx)
    private val result = TextView(ctx)
    private var dns = ""

    private fun px(v: Int) = ctx.px(v)

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun btn(t: String, primary: Boolean = false, click: () -> Unit): TextView {
        val v = tv(t, 11f, if (primary) Color.parseColor("#04141F") else Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.setPadding(px(12), px(7), px(12), px(7))
        v.background = if (primary) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(16f), 1f)
        else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(60, 255, 255, 255), ctx.pxf(16f), 1f)
        v.setOnClickListener { Sfx.tap(); click() }
        return v
    }

    private fun section(title: String, desc: String, tag: String) {
        val h = LinearLayout(ctx)
        h.orientation = LinearLayout.HORIZONTAL
        h.addView(tv(title, 12f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        h.addView(tv(tag, 9f, Color.parseColor("#FFC24B"), true))
        box.addView(h, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(10) })
        box.addView(tv(desc, 10f, Hud.sub), LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(5) })
    }

    private fun runCmd(name: String, rootOnly: Boolean, cmd: String) {
        if (!Access.requires(ctx, name, rootOnly)) return
        result.text = "Menjalankan $name..."
        Thread {
            val out = Access.run(cmd)
            root.post { result.text = "$name selesai." + if (out.isBlank()) "" else "\n" + out.take(220) }
        }.start()
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        root.setPadding(px(12), px(10), px(12), px(10))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("OPTIMAL JARINGAN", 12f, Hud.cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        val x = tv("✕", 16f)
        x.setPadding(px(10), px(2), px(4), px(2))
        x.setOnClickListener { Sfx.tap(); onClose() }
        head.addView(x)
        root.addView(head)

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        box.orientation = LinearLayout.VERTICAL
        sv.addView(box)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        // status + ping
        val st = LinearLayout(ctx)
        st.orientation = LinearLayout.HORIZONTAL
        st.gravity = Gravity.CENTER_VERTICAL
        netTxt.textSize = 11f; netTxt.setTextColor(Hud.sub)
        pingTxt.textSize = 18f; pingTxt.typeface = Typeface.DEFAULT_BOLD; pingTxt.setTextColor(Color.WHITE)
        pingTxt.text = "-- ms"
        st.addView(netTxt, LinearLayout.LayoutParams(0, -2, 1f))
        st.addView(pingTxt, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(10) })
        st.addView(btn("Tes ping", true) { testPing() })
        box.addView(st, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(6) })

        section("Optimizer Root", "Paket lengkap: Wi-Fi latensi rendah, data, DNS Google, dan tweak kernel TCP " +
            "(BBR, tanpa slow-start, buffer besar). Ping dibandingkan sebelum dan sesudah.", "KHUSUS ROOT")
        box.addView(btn("⚡ OPTIMIZER ROOT  ·  jaringan + Wi-Fi", true) { optimize("Optimizer Root", true) })

        section("Optimizer V2", "Untuk Shizuku (tanpa tweak kernel): Wi-Fi latensi rendah, data, DNS tercepat dipilih " +
            "otomatis, hentikan app latar yang memakai jaringan, lalu bandingkan ping.", "SHIZUKU")
        box.addView(btn("⚡ OPTIMIZER V2  ·  Shizuku", true) { optimize("Optimizer V2", false) })

        section("Alat manual", "Atur satu per satu bila perlu.", "")

        section("Wi-Fi", "Mode latensi rendah + performa tinggi, matikan scan Wi-Fi/Bluetooth di latar.", "ROOT/SHIZUKU")
        box.addView(btn("Optimalkan Wi-Fi", true) {
            runCmd("Optimasi Wi-Fi", false,
                "cmd wifi force-low-latency-mode enabled; cmd wifi force-hi-perf-mode enabled; " +
                    "settings put global wifi_scan_always_enabled 0; settings put global ble_scan_always_enabled 0")
        })

        section("Data seluler", "Matikan data ganda saat Wi-Fi aktif dan penghemat data supaya ping stabil.", "ROOT/SHIZUKU")
        box.addView(btn("Optimalkan data", true) {
            runCmd("Optimasi data", false,
                "settings put global mobile_data_always_on 0; cmd netpolicy set restrict-background false")
        })

        section("DNS pribadi", "Ganti DNS agar resolusi server game lebih cepat.", "ROOT/SHIZUKU")
        box.addView(dnsChips())

        section("Kernel TCP", "Prioritaskan latensi: congestion control BBR (jika didukung), tanpa slow-start setelah idle.", "KHUSUS ROOT")
        box.addView(btn("Tweak TCP") {
            runCmd("Tweak TCP", true,
                "grep -q bbr /proc/sys/net/ipv4/tcp_available_congestion_control && " +
                    "echo bbr > /proc/sys/net/ipv4/tcp_congestion_control; " +
                    "echo 0 > /proc/sys/net/ipv4/tcp_slow_start_after_idle; " +
                    "echo 1 > /proc/sys/net/ipv4/tcp_low_latency 2>/dev/null; " +
                    "cat /proc/sys/net/ipv4/tcp_congestion_control")
        })

        box.addView(btn("Reset ke bawaan") {
            runCmd("Reset jaringan", false,
                "cmd wifi force-low-latency-mode disabled; cmd wifi force-hi-perf-mode disabled; " +
                    "settings put global private_dns_mode opportunistic")
        }, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(12) })

        result.textSize = 10f
        result.setTextColor(Hud.sub)
        box.addView(result, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })

        refreshNet()
        testPing()
    }

    private fun measure(host: String): Long {
        val ts = ArrayList<Long>()
        for (i in 0 until 2) {
            val t0 = System.nanoTime()
            try {
                Socket().use { it.connect(InetSocketAddress(host, 53), 1500) }
                ts.add((System.nanoTime() - t0) / 1_000_000)
            } catch (e: Exception) {}
        }
        if (ts.isEmpty()) return -1
        ts.sort()
        return ts[ts.size / 2]
    }

    private fun fmt(m: Long) = if (m < 0) "gagal" else "$m ms"

    private val common = "cmd wifi force-low-latency-mode enabled; cmd wifi force-hi-perf-mode enabled; " +
        "settings put global wifi_scan_always_enabled 0; settings put global ble_scan_always_enabled 0; " +
        "settings put global mobile_data_always_on 0; cmd netpolicy set restrict-background false"

    // root = true -> Optimizer Root (kernel TCP), false -> Optimizer V2 (Shizuku / shell)
    private fun optimize(name: String, root: Boolean) {
        if (!Access.requires(ctx, name, root)) return
        result.text = "$name berjalan... mengukur ping dulu"
        Thread {
            val before = measure("8.8.8.8")
            val info = StringBuilder()
            val cmd = StringBuilder(common)
            if (root) {
                cmd.append("; settings put global private_dns_mode hostname; settings put global private_dns_specifier dns.google")
                cmd.append("; grep -q bbr /proc/sys/net/ipv4/tcp_available_congestion_control && echo bbr > /proc/sys/net/ipv4/tcp_congestion_control")
                cmd.append("; echo 0 > /proc/sys/net/ipv4/tcp_slow_start_after_idle")
                cmd.append("; echo 1 > /proc/sys/net/ipv4/tcp_low_latency 2>/dev/null")
                cmd.append("; echo 1 > /proc/sys/net/ipv4/tcp_window_scaling; echo 1 > /proc/sys/net/ipv4/tcp_sack")
                cmd.append("; echo 3 > /proc/sys/net/ipv4/tcp_fastopen 2>/dev/null")
                cmd.append("; echo 4194304 > /proc/sys/net/core/rmem_max; echo 4194304 > /proc/sys/net/core/wmem_max")
                info.append("DNS: Google\nTCP: ").append("congestion control, slow-start, buffer dioptimalkan")
            } else {
                val g = measure("8.8.8.8")
                val c = measure("1.1.1.1")
                val useCf = c >= 0 && (g < 0 || c < g)
                val host = if (useCf) "one.one.one.one" else "dns.google"
                cmd.append("; settings put global private_dns_mode hostname; settings put global private_dns_specifier $host")
                info.append("DNS tercepat: ").append(if (useCf) "Cloudflare" else "Google")
                    .append(" (Google ").append(fmt(g)).append(", Cloudflare ").append(fmt(c)).append(")")
            }
            Access.run(cmd.toString())
            if (!root) {
                val n = Boost.killBackground(ctx, Store(ctx).game)
                info.append("\nApp latar dihentikan: ").append(n)
            }
            val after = measure("8.8.8.8")
            this.root.post {
                result.text = "$name selesai.\nPing: ${fmt(before)} → ${fmt(after)}\n$info"
                pingTxt.text = fmt(after)
                pingTxt.setTextColor(when {
                    after < 0 -> Color.parseColor("#FF5D5D")
                    after < 60 -> Color.parseColor("#38E8A5")
                    after < 120 -> Color.parseColor("#FFC24B")
                    else -> Color.parseColor("#FF5D5D")
                })
            }
        }.start()
    }

    private fun dnsChips(): View {
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.HORIZONTAL
        val opts = listOf(
            Triple("Otomatis", "opportunistic", ""),
            Triple("Google", "hostname", "dns.google"),
            Triple("Cloudflare", "hostname", "one.one.one.one"),
            Triple("Mati", "off", "")
        )
        for ((name, mode, host) in opts) {
            l.addView(btn(name) {
                dns = name
                val cmd = "settings put global private_dns_mode $mode" +
                    if (host.isNotEmpty()) "; settings put global private_dns_specifier $host" else ""
                runCmd("DNS $name", false, cmd)
            }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(6) })
        }
        hs.addView(l)
        return hs
    }

    private fun refreshNet() {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = try { cm.getNetworkCapabilities(cm.activeNetwork) } catch (e: Exception) { null }
        netTxt.text = when {
            caps == null -> "Tidak ada koneksi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Terhubung: Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Terhubung: Data seluler"
            else -> "Terhubung"
        }
    }

    private fun testPing() {
        pingTxt.text = "…"
        pingTxt.setTextColor(Color.WHITE)
        Thread {
            val ts = ArrayList<Long>()
            for (i in 0 until 3) {
                val t0 = System.nanoTime()
                try {
                    Socket().use { it.connect(InetSocketAddress("8.8.8.8", 53), 1500) }
                    ts.add((System.nanoTime() - t0) / 1_000_000)
                } catch (e: Exception) {}
            }
            ts.sort()
            root.post {
                refreshNet()
                if (ts.isEmpty()) {
                    pingTxt.text = "gagal"
                    pingTxt.setTextColor(Color.parseColor("#FF5D5D"))
                } else {
                    val m = ts[ts.size / 2]
                    pingTxt.text = "$m ms"
                    pingTxt.setTextColor(when {
                        m < 60 -> Color.parseColor("#38E8A5")
                        m < 120 -> Color.parseColor("#FFC24B")
                        else -> Color.parseColor("#FF5D5D")
                    })
                }
            }
        }.start()
    }
}
