package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.ConnectException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

// =====================================================================
//  Mesin optimasi jaringan: diagnosa nyata (ping, jitter, loss, DNS, sinyal Wi-Fi),
//  Wi-Fi latensi rendah, DNS terenkripsi tercepat (diverifikasi, otomatis dibatalkan bila gagal),
//  tweak TCP kernel (root) + semua nilai asli disimpan dan bisa dikembalikan.
// =====================================================================
object NetOpt {
    data class Probe(val avg: Int, val jitter: Int, val loss: Int) {
        val ok: Boolean get() = avg >= 0
    }

    data class Diag(
        val kind: String,          // wifi / cell / none
        val rssi: Int,
        val linkMbps: Int,
        val freqMhz: Int,
        val gw: Probe?,
        val net: Probe,
        val dnsMs: Int,
        val advice: List<String>,
        val netName: String = ""
    )

    private val TARGETS = listOf("Google" to "8.8.8.8", "Cloudflare" to "1.1.1.1", "Quad9" to "9.9.9.9")

    private val DOT = listOf("Google" to "dns.google", "Cloudflare" to "one.one.one.one", "Quad9" to "dns.quad9.net")

    private const val IP4 = "/proc/sys/net/ipv4/"
    private const val CORE = "/proc/sys/net/core/"
    private const val CC = IP4 + "tcp_congestion_control"
    private val TCP_NUM = listOf(
        "tcp_slow_start_after_idle" to "0",
        "tcp_low_latency" to "1",
        "tcp_fastopen" to "3",
        "tcp_no_metrics_save" to "1",
        "tcp_mtu_probing" to "1",
        "tcp_autocorking" to "0",
        "tcp_notsent_lowat" to "131072",
        "tcp_thin_linear_timeouts" to "1"
    )
    private val TCP_PATHS: List<String> = listOf(CC) + TCP_NUM.map { IP4 + it.first } +
        listOf(CORE + "rmem_max", CORE + "wmem_max", CORE + "netdev_max_backlog", IP4 + "tcp_rmem", IP4 + "tcp_wmem")

    private val NET_KEYS = listOf(
        "wifi_scan_always_enabled", "ble_scan_always_enabled", "mobile_data_always_on",
        "wifi_networks_available_notification_on", "private_dns_mode", "private_dns_specifier",
        "adaptive_connectivity_enabled", "wifi_wakeup_enabled", "wifi_suspend_optimizations_enabled"
    )

    private val SAFE = Regex("^[A-Za-z0-9_.\\- ]+$")
    private val SAFE_TCP = Regex("^[a-z0-9 ]+$")

    // ---------- pengukuran ----------
    fun probe(host: String, port: Int, n: Int, timeoutMs: Int): Probe {
        val ts = ArrayList<Int>()
        var fail = 0
        for (i in 0 until n) {
            val t0 = System.nanoTime()
            var ok = false
            try {
                Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
                ok = true
            } catch (e: ConnectException) {
                // ditolak = host membalas, jadi waktunya tetap sah sebagai RTT
                if ((e.message ?: "").contains("refused", true)) ok = true
            } catch (e: Exception) {
            }
            if (ok) ts.add(((System.nanoTime() - t0) / 1_000_000L).toInt()) else fail++
            if (i < n - 1) {
                try { Thread.sleep(60) } catch (e: InterruptedException) { break }
            }
        }
        if (ts.isEmpty()) return Probe(-1, 0, 100)
        var jit = 0
        for (i in 1 until ts.size) jit += Math.abs(ts[i] - ts[i - 1])
        val jitter = if (ts.size > 1) jit / (ts.size - 1) else 0
        return Probe(ts.sum() / ts.size, jitter, fail * 100 / n)
    }

    // waktu resolusi DNS dengan nama unik (NXDOMAIN) supaya tidak kena cache
    fun dnsMs(): Int {
        val ts = ArrayList<Int>()
        val seed = System.nanoTime() % 1000000L
        for (i in 0 until 3) {
            val t0 = System.nanoTime()
            try { InetAddress.getByName("xa$seed$i.example.com") } catch (e: Exception) {}
            ts.add(((System.nanoTime() - t0) / 1_000_000L).toInt())
        }
        ts.sort()
        return ts[1]
    }

    private fun gateway(ctx: Context): String? = try {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val g = wm.dhcpInfo.gateway
        if (g == 0) null else "${g and 0xff}.${(g shr 8) and 0xff}.${(g shr 16) and 0xff}.${(g shr 24) and 0xff}"
    } catch (e: Throwable) { null }

    fun kind(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = try { cm.getNetworkCapabilities(cm.activeNetwork) } catch (e: Exception) { null }
        return when {
            caps == null -> "none"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cell"
            else -> "other"
        }
    }

    fun fmt(p: Probe?): String = when {
        p == null -> "-"
        !p.ok -> "gagal"
        else -> "${p.avg} ms · jitter ${p.jitter} · loss ${p.loss}%"
    }

    fun diagnose(ctx: Context): Diag {
        val kind = kind(ctx)
        var rssi = 0; var link = 0; var freq = 0
        var gw: Probe? = null
        if (kind == "wifi") {
            try {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val i = wm.connectionInfo
                rssi = i.rssi; link = i.linkSpeed; freq = i.frequency
            } catch (e: Throwable) {}
            val g = gateway(ctx)
            if (g != null) {
                val p = probe(g, 80, 8, 500)
                if (p.ok) gw = p
            }
        }
        var net = Probe(-1, 0, 100)
        var netName = ""
        if (kind != "none") {
            // tiga server diukur bersamaan agar diagnosa cepat
            val res = arrayOfNulls<Probe>(TARGETS.size)
            val ths = ArrayList<Thread>()
            for ((i, t) in TARGETS.withIndex()) {
                val th = Thread { res[i] = probe(t.second, 443, 5, 1200) }
                th.start()
                ths.add(th)
            }
            for (th in ths) { try { th.join() } catch (e: InterruptedException) {} }
            for ((i, t) in TARGETS.withIndex()) {
                val p = res[i]
                if (p != null && p.ok && (!net.ok || p.avg < net.avg)) { net = p; netName = t.first }
            }
        }
        val dns = if (kind == "none") -1 else dnsMs()

        val a = ArrayList<String>()
        if (kind == "none") a.add("Tidak ada koneksi internet aktif.")
        if (kind == "wifi") {
            if (rssi in -127..-76) a.add("Sinyal Wi-Fi lemah ($rssi dBm). Dekatkan HP ke router atau hilangkan penghalang. Ini penyebab lag terbesar.")
            else if (rssi in -75..-68) a.add("Sinyal Wi-Fi sedang ($rssi dBm). Lebih dekat ke router akan lebih stabil.")
            if (freq in 2400..2500) a.add("Terhubung ke 2.4 GHz (padat, mudah bentrok). Bila router punya 5 GHz, pindah ke jaringan 5 GHz.")
            if (link in 1..39) a.add("Kecepatan link rendah ($link Mbps): kualitas sambungan ke router buruk.")
            if (gw != null && (gw.avg > 25 || gw.loss > 0 || gw.jitter > 15))
                a.add("Jalur HP ke router bermasalah (${fmt(gw)}): kemungkinan interferensi Wi-Fi atau terlalu banyak perangkat. Coba restart router / ganti channel.")
        }
        if (net.ok) {
            val routerFine = kind != "wifi" || gw == null || (gw.avg <= 25 && gw.loss == 0)
            if ((net.avg > 100 || net.loss > 0 || net.jitter > 30) && routerFine)
                a.add("Jalur ke internet lambat/tidak stabil (${fmt(net)}) padahal sinyal ke router baik: masalah ada di provider/kuota/jam sibuk, di luar kendali aplikasi.")
        } else if (kind != "none") a.add("Internet tidak terjangkau (ping gagal).")
        if (dns > 150) a.add("DNS lambat ($dns ms). Optimizer akan memilih DNS tercepat.")
        if (a.isEmpty()) a.add("Jaringan sehat. Tidak ada masalah yang terdeteksi.")
        return Diag(kind, rssi, link, freq, gw, net, dns, a, netName)
    }

    // ---------- snapshot setelan ----------
    private fun settingsSnap(): String {
        val sb = StringBuilder()
        for (k in NET_KEYS) sb.append("echo \"S|global|$k|§(settings get global $k)\"\n")
        return sb.toString().replace('§', '$')
    }

    private fun ensureSnap(ctx: Context) {
        val st = Store(ctx)
        if (st.get("snap_net").isBlank()) {
            val o = Access.run(settingsSnap())
            if (o.lines().any { it.startsWith("S|") }) st.put("snap_net", o)
        }
    }

    // ---------- Wi-Fi & data ----------
    fun wifiData(): String {
        val c = ArrayList<String>()
        c.add("cmd wifi force-low-latency-mode enabled")
        c.add("cmd wifi force-hi-perf-mode enabled")
        c.add("settings put global wifi_scan_always_enabled 0")
        c.add("settings put global ble_scan_always_enabled 0")
        c.add("settings put global wifi_networks_available_notification_on 0")
        c.add("settings put global mobile_data_always_on 0")
        // jaringan tidak berpindah sendiri (Wi-Fi <-> data) di tengah game
        c.add("settings put global adaptive_connectivity_enabled 0")
        c.add("settings put global wifi_wakeup_enabled 0")
        // Wi-Fi tidak masuk mode tidur/hemat saat layar menyala atau mati (penyebab lonjakan ping)
        c.add("settings put global wifi_suspend_optimizations_enabled 0")
        c.add("cmd netpolicy set restrict-background false")
        if (Access.isRoot) {
            c.add("command -v iw >/dev/null 2>&1 && iw dev wlan0 set power_save off")
            c.add("ndc resolver flushdefaultif 2>/dev/null")
        }
        return c.joinToString("\n")
    }

    // Wi-Fi lock: Wi-Fi tidak masuk mode hemat daya selama game berjalan
    @Volatile private var lock: WifiManager.WifiLock? = null

    @Synchronized fun holdWifi(ctx: Context, on: Boolean) {
        try {
            if (on) {
                if (lock?.isHeld == true) return
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                else WifiManager.WIFI_MODE_FULL_HIGH_PERF
                val l = wm.createWifiLock(mode, "xa:game")
                l.setReferenceCounted(false)
                l.acquire()
                lock = l
            } else {
                lock?.let { if (it.isHeld) it.release() }
                lock = null
            }
        } catch (e: Throwable) {
        }
    }


    // Root: jendela kongesti awal besar -> halaman/sesi game pertama datang lebih cepat (hilang sendiri saat jaringan putus)
    fun routeBoost(): String {
        if (!Access.isRoot) return "Rute dilewati (butuh root)."
        Access.run("r=§(ip route show default 2>/dev/null | head -n 1)\n[ -n \"§r\" ] && ip route change §r initcwnd 20 initrwnd 20 2>/dev/null".replace('§', '$'))
        return "Rute default: jendela awal 20 paket (respons pertama lebih cepat)"
    }

    // ---------- denyut anti-tidur ----------
    // Radio Wi-Fi / seluler yang "menganggur" masuk mode hemat dan butuh puluhan ms untuk bangun: itu yang terasa
    // sebagai lonjakan ping. Paket kecil tiap 0,7 detik menjaga radio tetap siaga selama game berjalan.
    @Volatile private var pulseThread: Thread? = null

    @Synchronized fun pulse(ctx: Context, on: Boolean) {
        if (!on) { pulseThread?.interrupt(); pulseThread = null; return }
        if (pulseThread?.isAlive == true) return
        val app = ctx.applicationContext
        val t = Thread {
            var sock: DatagramSocket? = null
            try {
                val ds = DatagramSocket()
                sock = ds
                val buf = ByteArray(4)
                while (!Thread.currentThread().isInterrupted) {
                    val k = kind(app)
                    if (k != "none") {
                        val gw = if (k == "wifi") gateway(app) else null
                        try {
                            val addr = InetAddress.getByName(gw ?: "1.1.1.1")
                            ds.send(DatagramPacket(buf, buf.size, addr, if (gw != null) 9 else 53))
                        } catch (e: Exception) {}
                    }
                    Thread.sleep(700)
                }
            } catch (e: InterruptedException) {
            } catch (e: Throwable) {
            } finally {
                try { sock?.close() } catch (e: Throwable) {}
            }
        }
        t.isDaemon = true
        t.start()
        pulseThread = t
    }

    fun pulsing(): Boolean = pulseThread?.isAlive == true

    // ---------- jalur tercepat: Wi-Fi vs data seluler ----------
    data class PathRes(val wifi: Probe?, val cell: Probe?)

    private fun probeVia(net: Network, host: String, n: Int): Probe {
        val ts = ArrayList<Int>()
        var fail = 0
        for (i in 0 until n) {
            val t0 = System.nanoTime()
            var ok = false
            try {
                net.socketFactory.createSocket().use { it.connect(InetSocketAddress(host, 443), 1500) }
                ok = true
            } catch (e: ConnectException) {
                if ((e.message ?: "").contains("refused", true)) ok = true
            } catch (e: Exception) {
            }
            if (ok) ts.add(((System.nanoTime() - t0) / 1_000_000L).toInt()) else fail++
            try { Thread.sleep(60) } catch (e: InterruptedException) { break }
        }
        if (ts.isEmpty()) return Probe(-1, 0, 100)
        var jit = 0
        for (i in 1 until ts.size) jit += Math.abs(ts[i] - ts[i - 1])
        return Probe(ts.sum() / ts.size, if (ts.size > 1) jit / (ts.size - 1) else 0, fail * 100 / n)
    }

    // Mengukur ping lewat Wi-Fi DAN lewat data seluler secara terpisah (data seluler dinyalakan sebentar bila perlu)
    fun pathTest(ctx: Context): PathRes {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var wNet: Network? = null
        var cNet: Network? = null
        try {
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wNet = n
                else if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) cNet = n
            }
        } catch (e: Throwable) {}
        var cb: ConnectivityManager.NetworkCallback? = null
        if (cNet == null) {
            val got = arrayOfNulls<Network>(1)
            val latch = CountDownLatch(1)
            try {
                val req = NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
                val c = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) { got[0] = network; latch.countDown() }
                }
                cb = c
                cm.requestNetwork(req, c)
                latch.await(4, TimeUnit.SECONDS)
                cNet = got[0]
            } catch (e: Throwable) {}
        }
        var wifi: Probe? = null
        var cell: Probe? = null
        val w = wNet
        val c = cNet
        val th1 = if (w != null) Thread { wifi = probeVia(w, "1.1.1.1", 6) } else null
        val th2 = if (c != null) Thread { cell = probeVia(c, "1.1.1.1", 6) } else null
        th1?.start(); th2?.start()
        try { th1?.join(); th2?.join() } catch (e: InterruptedException) {}
        try { cb?.let { cm.unregisterNetworkCallback(it) } } catch (e: Throwable) {}
        return PathRes(wifi, cell)
    }

    // ---------- DNS ----------
    // Pilih DNS terenkripsi tercepat. Diverifikasi; bila internet jadi tidak bisa resolve, dibatalkan otomatis.
    fun smartDns(ctx: Context, curDnsMs: Int): String {
        val cand = DOT.map { (n, h) -> Triple(n, h, probe(h, 853, 4, 1500)) }
            .filter { it.third.ok && it.third.loss <= 25 }
        val best = cand.minByOrNull { it.third.avg }
            ?: return "DNS: jaringan ini memblokir DNS terenkripsi (port 853), DNS otomatis dipertahankan."
        if (curDnsMs in 0..(best.third.avg + 10))
            return "DNS: bawaan sudah cepat ($curDnsMs ms), tidak diganti."
        Access.run("settings put global private_dns_mode hostname; settings put global private_dns_specifier ${best.second}")
        try { Thread.sleep(1500) } catch (e: InterruptedException) {}
        var good = false
        var t = -1
        for (h in listOf("www.wikipedia.org", "www.bing.com")) {
            val t0 = System.nanoTime()
            try { InetAddress.getByName(h); good = true } catch (e: Exception) {}
            if (good) { t = ((System.nanoTime() - t0) / 1_000_000L).toInt(); break }
        }
        if (!good) {
            Access.run("settings put global private_dns_mode opportunistic")
            return "DNS ${best.first} gagal diverifikasi, dikembalikan ke otomatis (internet tetap aman)."
        }
        return "DNS: ${best.first} (${best.third.avg} ms ke server, resolusi uji $t ms)"
    }

    // ---------- TCP kernel (root) ----------
    private fun tcpSnapScript(): String {
        val sb = StringBuilder()
        for (p in TCP_PATHS) sb.append("[ -w $p ] && echo \"T|$p|§(cat $p | tr '\\t' ' ')\"\n")
        sb.append("echo \"A|§(cat ${IP4}tcp_available_congestion_control 2>/dev/null)\"\n")
        return sb.toString().replace('§', '$')
    }

    fun applyTcp(ctx: Context): String {
        if (!Access.isRoot) return "TCP kernel dilewati (butuh root)."
        val st = Store(ctx)
        val map = LinkedHashMap<String, String>()
        var avail = ""
        for (l in Access.run(tcpSnapScript()).lines()) {
            val p = l.split("|", limit = 3)
            if (p.size == 3 && p[0] == "T") map[p[1]] = p[2].trim()
            else if (p.size >= 2 && p[0] == "A") avail = p[1]
        }
        if (map.isEmpty()) return "TCP: jalur kernel tidak bisa ditulis di HP ini."
        if (st.get("snap_tcp").isBlank()) st.put("snap_tcp", map.entries.joinToString("\n") { "${it.key}|${it.value}" })

        val c = ArrayList<String>()
        if (map.containsKey(CC) && avail.split(" ").contains("bbr")) c.add("echo bbr > $CC")
        for ((k, v) in TCP_NUM) if (map.containsKey(IP4 + k)) c.add("echo $v > ${IP4 + k}")
        fun raise(p: String, target: Long) {
            val cur = map[p]?.toLongOrNull() ?: return
            if (cur < target) c.add("echo $target > $p")
        }
        raise(CORE + "rmem_max", 4194304L)
        raise(CORE + "wmem_max", 4194304L)
        raise(CORE + "netdev_max_backlog", 5000L)
        for (k in listOf("tcp_rmem", "tcp_wmem")) {
            val p = IP4 + k
            val parts = (map[p] ?: continue).split(" ").filter { it.isNotBlank() }
            val mx = parts.getOrNull(2)?.toLongOrNull() ?: continue
            if (parts.size == 3 && mx < 4194304L) c.add("echo ${parts[0]} ${parts[1]} 4194304 > $p")
        }
        if (c.isNotEmpty()) Access.run(c.joinToString("\n"))
        val now = Access.run("cat $CC").trim()
        return "TCP: ${c.size} parameter diatur, congestion control = $now"
    }

    fun restoreTcp(ctx: Context) {
        val st = Store(ctx)
        val snap = st.get("snap_tcp")
        if (snap.isBlank()) return
        val c = ArrayList<String>()
        for (l in snap.lines()) {
            val p = l.split("|", limit = 2)
            if (p.size == 2 && p[0] in TCP_PATHS && SAFE_TCP.matches(p[1].trim()))
                c.add("[ -w ${p[0]} ] && echo ${p[1].trim()} > ${p[0]}")
        }
        if (c.isNotEmpty()) Access.run(c.joinToString("\n"))
        st.put("snap_tcp", "")
    }

    // ---------- antrean paket (anti bufferbloat, root) ----------
    private val DEV = Regex("^[a-z0-9_]+$")

    private fun devScript(): String =
        ("dev=§(ip route get 8.8.8.8 2>/dev/null | sed -n 's/.* dev \\([^ ]*\\).*/\\1/p' | head -n 1)\n" +
            "[ -z \"§dev\" ] && dev=wlan0\n" +
            "echo \"DEV|§dev\"\n" +
            "echo \"Q|§(cat /sys/class/net/§dev/tx_queue_len 2>/dev/null)\"\n").replace('§', '$')

    // fq_codel + antrean pendek: paket game tidak mengantre di belakang unduhan
    fun applyQueue(ctx: Context): String {
        if (!Access.isRoot) return "Antrean paket dilewati (butuh root)."
        var dev = "wlan0"
        var q = ""
        for (l in Access.run(devScript()).lines()) {
            val p = l.trim().split("|", limit = 2)
            if (p.size == 2 && p[0] == "DEV" && DEV.matches(p[1])) dev = p[1]
            if (p.size == 2 && p[0] == "Q") q = p[1].trim()
        }
        val st = Store(ctx)
        if (st.get("snap_q").isBlank() && q.toIntOrNull() != null) st.put("snap_q", "$dev|$q")
        Access.run(
            "tc qdisc replace dev $dev root fq_codel 2>/dev/null\n" +
                "[ -w /sys/class/net/$dev/tx_queue_len ] && echo 200 > /sys/class/net/$dev/tx_queue_len"
        )
        return "Antrean $dev: fq_codel, panjang antrean ${q.ifBlank { "?" }} → 200"
    }

    fun restoreQueue(ctx: Context) {
        val st = Store(ctx)
        val snap = st.get("snap_q")
        if (snap.isBlank()) return
        val p = snap.split("|")
        if (p.size == 2 && DEV.matches(p[0]) && p[1].toIntOrNull() != null) {
            Access.run("tc qdisc del dev ${p[0]} root 2>/dev/null\n[ -w /sys/class/net/${p[0]}/tx_queue_len ] && echo ${p[1]} > /sys/class/net/${p[0]}/tx_queue_len")
        }
        st.put("snap_q", "")
    }

    // ---------- Doze (tidur jaringan) ----------
    // Selama game, Doze dimatikan agar koneksi latar tidak ditidurkan; dikembalikan saat game selesai / reset.
    fun idle(ctx: Context, off: Boolean) {
        val st = Store(ctx)
        if (off) {
            Access.run("dumpsys deviceidle disable")
            st.put("idle_off", "1")
        } else if (st.get("idle_off") == "1") {
            Access.run("dumpsys deviceidle enable")
            st.put("idle_off", "")
        }
    }

    // Baca ulang kondisi sebenarnya setelah boost, supaya kelihatan mana yang benar-benar aktif
    fun verify(ctx: Context): String {
        val script = ("echo \"K|dnsmode|§(settings get global private_dns_mode)\"\n" +
            "echo \"K|dnshost|§(settings get global private_dns_specifier)\"\n" +
            "echo \"K|adaptive|§(settings get global adaptive_connectivity_enabled)\"\n" +
            "echo \"K|dataon|§(settings get global mobile_data_always_on)\"\n" +
            "echo \"K|doze|§(dumpsys deviceidle | grep -m1 -i mDeepEnabled)\"\n" +
            "echo \"K|cc|§(cat ${CC} 2>/dev/null)\"\n").replace('§', '$')
        val m = HashMap<String, String>()
        for (l in Access.run(script).lines()) {
            val p = l.trim().split("|", limit = 3)
            if (p.size == 3 && p[0] == "K") m[p[1]] = p[2].trim()
        }
        val sb = StringBuilder()
        fun line(ok: Boolean, t: String) { sb.append(if (ok) "✓ " else "✗ ").append(t).append("\n") }
        line(lock?.isHeld == true, "Wi-Fi Lock " + if (lock?.isHeld == true) "aktif" else "tidak aktif (hanya relevan di Wi-Fi)")
        val mode = m["dnsmode"] ?: ""
        if (mode == "hostname") line(true, "DNS terenkripsi: ${m["dnshost"]}")
        else line(mode == "opportunistic", "DNS: " + (if (mode == "opportunistic") "otomatis (bawaan, sudah cepat)" else mode.ifBlank { "tidak terbaca" }))
        line(m["adaptive"] == "0", "Adaptive connectivity " + if (m["adaptive"] == "0") "mati (jaringan tidak pindah sendiri)" else "tidak bisa dimatikan di HP ini")
        line(m["dataon"] == "0", "Data seluler tidak aktif ganda saat Wi-Fi " + if (m["dataon"] == "0") "✓" else "(tidak terbaca)")
        val doze = m["doze"] ?: ""
        if (doze.isNotBlank()) line(doze.contains("false"), "Doze " + if (doze.contains("false")) "dimatikan selama game" else "masih aktif")
        if (Access.isRoot && !m["cc"].isNullOrBlank()) line(true, "Congestion control: ${m["cc"]}")
        return sb.toString().trim()
    }

    // ---------- reset ----------
    fun resetAll(ctx: Context): String {
        val st = Store(ctx)
        val c = ArrayList<String>()
        c.add("cmd wifi force-low-latency-mode disabled")
        c.add("cmd wifi force-hi-perf-mode disabled")
        var hasDns = false
        for (l in st.get("snap_net").lines()) {
            val p = l.trim().split("|", limit = 4)
            if (p.size == 4 && p[0] == "S" && p[1] == "global" && p[2] in NET_KEYS) {
                val v = p[3].trim()
                if (p[2] == "private_dns_mode" && v.isNotBlank() && v != "null") hasDns = true
                if (v.isBlank() || v == "null") c.add("settings delete global ${p[2]}")
                else if (SAFE.matches(v)) c.add("settings put global ${p[2]} $v")
            }
        }
        if (!hasDns) c.add("settings put global private_dns_mode opportunistic")
        Access.run(c.joinToString("\n"))
        restoreTcp(ctx)
        restoreQueue(ctx)
        holdWifi(ctx, false)
        pulse(ctx, false)
        idle(ctx, false)
        NetBg.stop(ctx)
        st.put("snap_net", "")
        st.put("net_active", "")
        return "Jaringan dikembalikan ke setelan bawaan HP."
    }

    // ---------- MODE: OPTIMAL / UP / MAX / ULTRA ----------
    // 1 OPTIMAL : Wi-Fi/data latensi rendah, DNS tercepat, Wi-Fi Lock, koneksi stabil      (root atau Shizuku)
    // 2 UP      : + TCP kernel (root) + Data Saver fokus game                              (Shizuku: Data Saver saja)
    // 3 MAX     : + antrean anti-bufferbloat (root) + aplikasi latar ditidurkan             (Shizuku: app tidur)
    // 4 ULTRA   : + firewall blokir app latar (root) + prioritas paket game + hentikan app latar
    fun modeName(m: Int): String = when (m) {
        1 -> "OPTIMAL"
        2 -> "OPTIMAL UP"
        3 -> "OPTIMAL MAX"
        4 -> "OPTIMAL ULTRA"
        else -> "MATI"
    }

    @Volatile var running = false
        private set

    // quick = true: tanpa pengukuran sebelum/sesudah (dipakai saat otomatis ketika game dibuka)
    fun runMode(ctx: Context, mode: Int, quick: Boolean, progress: (String) -> Unit): String {
        if (mode !in 1..4) return "Mode tidak dikenal."
        synchronized(this) {
            if (running) return "Optimasi lain sedang berjalan, tunggu sebentar."
            running = true
        }
        try {
            return runModeInner(ctx, mode, quick, progress)
        } finally {
            running = false
        }
    }

    private fun runModeInner(ctx: Context, mode: Int, quick: Boolean, progress: (String) -> Unit): String {
        val st = Store(ctx)
        val root = Access.isRoot
        val bgLevel = when (mode) { 2 -> 1; 3 -> 2; 4 -> 3; else -> 0 }
        var total = 4
        if (mode >= 2) total++
        if (mode >= 3) total++
        if (bgLevel > 0) total++
        if (mode == 4) total++
        if (!quick) total += 2
        var step = 0
        fun next(t: String) { step++; progress("$step/$total  ${modeName(mode)}: $t") }

        var before: Diag? = null
        if (!quick) { next("Mengukur kondisi awal..."); before = diagnose(ctx) }
        next("Menyimpan setelan asli...")
        ensureSnap(ctx)

        next("Wi-Fi latensi rendah, data, Wi-Fi Lock...")
        Access.run(wifiData())
        if (st.get("wifi_lock") != "0") holdWifi(ctx, true)

        next("Menstabilkan koneksi...")
        idle(ctx, true)
        if (st.get("net_pulse") != "0") pulse(ctx, true)

        next("Mencari DNS tercepat...")
        val dns = smartDns(ctx, before?.dnsMs ?: -1)

        val res = ArrayList<String>()
        res.add("✓ Wi-Fi latensi rendah + performa tinggi, scan latar mati, Wi-Fi Lock")
        res.add("✓ Koneksi distabilkan (Doze dan perpindahan jaringan otomatis dimatikan)")
        if (st.get("net_pulse") != "0") res.add("✓ Denyut anti-tidur aktif (radio tidak sempat masuk mode hemat)")
        res.add("✓ $dns")

        if (mode >= 2) {
            next("Tweak TCP kernel...")
            if (root) { res.add("✓ " + applyTcp(ctx)); res.add("✓ " + routeBoost()) } else res.add("✗ TCP kernel: butuh root (dilewati)")
        }
        if (mode >= 3) {
            next("Antrean paket anti-bufferbloat...")
            if (root) res.add("✓ " + applyQueue(ctx)) else res.add("✗ Antrean paket: butuh root (dilewati)")
        }
        var bgCount = 0
        if (bgLevel > 0) {
            next("Membatasi jaringan aplikasi latar...")
            val r = NetBg.apply(ctx, bgLevel)
            bgCount = r.count
            res.addAll(r.lines)
        }
        if (mode == 4) {
            next("Prioritas paket game + hentikan app latar...")
            res.add(NetBg.applyQos(ctx))
            val k = NetBg.killTargets(ctx)
            res.add("✓ $k aplikasi latar dihentikan paksa (yang diizinkan, inti, dan VPN tidak disentuh)")
        }

        var after: Diag? = null
        if (!quick) {
            next("Mengukur ulang...")
            try { Thread.sleep(1200) } catch (e: InterruptedException) {}
            after = diagnose(ctx)
        }
        st.put("net_active", mode.toString())

        val sb = StringBuilder()
        sb.append("SELESAI · ").append(modeName(mode)).append(" · ")
            .append(if (root) "AKSES ROOT" else "AKSES SHIZUKU").append("\n")
        if (before != null && after != null) {
            sb.append("Internet : ").append(fmt(before.net)).append("\n      →  ").append(fmt(after.net))
            if (after.netName.isNotEmpty()) sb.append(" (").append(after.netName).append(")")
            sb.append("\n")
            if (after.gw != null) sb.append("Router   : ").append(fmt(after.gw)).append("\n")
            if (before.dnsMs >= 0 || after.dnsMs >= 0) sb.append("DNS      : ${before.dnsMs} ms → ${after.dnsMs} ms\n")
        }
        sb.append("\nYang dijalankan:\n")
        for (l in res) sb.append(l).append("\n")
        sb.append("\nHasil pembacaan ulang:\n").append(verify(ctx)).append("\n")
        for (l in NetBg.verify(ctx)) sb.append(l).append("\n")
        if (after != null && after.net.ok && after.net.avg > 10)
            sb.append("\nCatatan: ping ke internet ditentukan jarak server dan provider (umumnya 10–40 ms). " +
                "Angka 1–10 ms hanya realistis ke router. Aplikasi menekan latensi di sisi HP dan membuang lalu lintas latar, bukan jarak ke server.\n")
        if (bgLevel > 0 && bgCount > 0)
            sb.append("\nPembatasan latar dilepas otomatis saat game selesai (atau tombol Lepas batasan).\n")
        if (after != null) {
            sb.append("\nYang masih bisa membuat lag:\n")
            for (a in after.advice) sb.append("– ").append(a).append("\n")
        }
        return sb.toString().trim()
    }
}

// Sheet "Optimal Jaringan" (V4.8): 4 mode (Optimal / Up / Max / Ultra), fokus game (batasi jaringan latar), alat manual
class NetSheet(private val ctx: Context, private val onStop: (() -> Unit)? = null, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val main = LinearLayout(ctx)
    private val box = LinearLayout(ctx)
    private val pingTxt = TextView(ctx)
    private val netTxt = TextView(ctx)
    private val detail = TextView(ctx)
    private val result = TextView(ctx)
    private val activeTxt = TextView(ctx)
    private val bgStatus = TextView(ctx)
    private val bgDesc = TextView(ctx)
    private val allowBtn: TextView
    private val wifiPing = TextView(ctx)
    private val cellPing = TextView(ctx)
    private val pathVerdict = TextView(ctx)
    private val store = Store(ctx)
    private val autoChips = ArrayList<TextView>()
    private val bgChips = ArrayList<TextView>()
    private var allowView: NetAllowSheet? = null
    @Volatile private var busy = false

    private fun px(v: Int) = ctx.px(v)

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun btn(t: String, primary: Boolean = false, click: () -> Unit): TextView {
        val v = tv(t, 11f, if (primary) Color.parseColor("#04141F") else Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.setPadding(px(12), px(7), px(12), px(7))
        v.background = if (primary) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(16f), 1f)
        else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(60, 255, 255, 255), ctx.pxf(16f), 1f)
        v.setOnClickListener { Sfx.tap(); click() }
        return v
    }

    // judul bagian + garis pemisah
    private fun title(t: String, tag: String = "") {
        val h = LinearLayout(ctx)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        val tx = tv(t, 11f, Hud.cyan, true)
        tx.letterSpacing = 0.12f
        h.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        if (tag.isNotEmpty()) h.addView(tv(tag, 9f, Color.parseColor("#FFC24B"), true))
        box.addView(h, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(14) })
        val line = View(ctx)
        line.setBackgroundColor(Hud.cyanDim)
        box.addView(line, LinearLayout.LayoutParams(-1, 1).also { it.topMargin = px(3); it.bottomMargin = px(6) })
    }

    private fun note(t: String): TextView {
        val v = tv(t, 10f, Hud.sub)
        box.addView(v, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(5) })
        return v
    }

    private fun show(t: String, color: Int = Color.parseColor("#38E8A5")) {
        root.post { result.setTextColor(color); result.text = t }
    }

    private fun runCmd(name: String, rootOnly: Boolean, cmd: String) {
        if (!Access.requires(ctx, name, rootOnly)) return
        show("Menjalankan $name...", Hud.sub)
        Thread {
            val out = Access.run(cmd)
            show("$name selesai." + if (out.isBlank()) "" else "\n" + out.take(220))
        }.start()
    }

    private fun pingColor(ms: Int) = when {
        ms < 0 -> Color.parseColor("#FF5D5D")
        ms < 60 -> Color.parseColor("#38E8A5")
        ms < 120 -> Color.parseColor("#FFC24B")
        else -> Color.parseColor("#FF5D5D")
    }

    private fun setPing(ms: Int) {
        pingTxt.text = if (ms < 0) "gagal" else "$ms ms"
        pingTxt.setTextColor(pingColor(ms))
    }

    private fun paintChips(chips: List<TextView>, cur: Int) {
        for ((i, c) in chips.withIndex()) {
            val on = i == cur
            c.setTextColor(if (on) Color.parseColor("#04141F") else Color.WHITE)
            c.background = if (on) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(16f), 1f)
            else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(60, 255, 255, 255), ctx.pxf(16f), 1f)
        }
    }

    // deretan chip pilihan; sel = indeks terpilih
    private fun chipRow(names: List<String>, sel: Int, store: ArrayList<TextView>, pick: (Int) -> Unit): View {
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.HORIZONTAL
        store.clear()
        for ((i, n) in names.withIndex()) {
            val c = tv(n, 11f, Color.WHITE, true)
            c.gravity = Gravity.CENTER
            c.setPadding(px(12), px(6), px(12), px(6))
            c.setOnClickListener { Sfx.tap(); paintChips(store, i); pick(i) }
            store.add(c)
            l.addView(c, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(6) })
        }
        paintChips(store, sel)
        hs.addView(l)
        return hs
    }

    // satu baris fitur gaya Game Space: nama + label akses, penjelasan, lalu tombol/saklar di kanan
    private fun feature(icon: String, name: String, tag: String, desc: String, action: View?, below: View? = null) {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(px(10), px(8), px(10), px(8))
        r.background = Hud.rounded(Color.argb(130, 8, 22, 40), Hud.cyanDim, ctx.pxf(12f), 1f)
        r.addView(tv(icon, 18f), LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(10) })
        val t = LinearLayout(ctx)
        t.orientation = LinearLayout.VERTICAL
        val h = LinearLayout(ctx)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.addView(tv(name, 12f, Color.WHITE, true))
        h.addView(tv(tag, 8.5f, Color.parseColor("#FFC24B"), true), LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = px(8) })
        t.addView(h)
        t.addView(tv(desc, 9.5f, Hud.sub), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(2) })
        if (below != null) t.addView(below, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(6) })
        r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        if (action != null) r.addView(action, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = px(10) })
        box.addView(r, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(6) })
    }

    private fun testPath() {
        if (busy) return
        busy = true
        wifiPing.text = "…"; cellPing.text = "…"
        pathVerdict.text = "Mengukur kedua jalur, tunggu beberapa detik..."
        Thread {
            val r = NetOpt.pathTest(ctx)
            busy = false
            root.post {
                fun put(t: TextView, p: NetOpt.Probe?) {
                    if (p == null) { t.text = "tidak ada"; t.setTextColor(Hud.sub) }
                    else { t.text = if (p.ok) "${p.avg} ms" else "gagal"; t.setTextColor(pingColor(p.avg)) }
                }
                put(wifiPing, r.wifi)
                put(cellPing, r.cell)
                val w = r.wifi
                val c = r.cell
                pathVerdict.text = when {
                    w == null && c == null -> "Tidak ada jalur internet yang bisa diukur."
                    w == null || !w.ok -> "Wi-Fi tidak tersedia. Pakai data seluler."
                    c == null || !c.ok -> "Data seluler tidak bisa diukur (nyalakan data seluler). Gunakan Wi-Fi."
                    c.avg + 8 < w.avg -> "Data seluler lebih cepat (${c.avg} vs ${w.avg} ms). Untuk game, matikan Wi-Fi sementara " +
                        "atau pindah ke Wi-Fi 5 GHz yang lebih dekat router."
                    w.avg + 8 < c.avg -> "Wi-Fi lebih cepat (${w.avg} vs ${c.avg} ms). Tetap di Wi-Fi."
                    else -> "Kedua jalur sama (${w.avg} vs ${c.avg} ms). Wi-Fi lebih hemat kuota."
                }
            }
        }.start()
    }

    private fun modeCard(id: Int, name: String, sub: String, tag: String, color: Int): View {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(px(10), px(8), px(10), px(8))
        c.background = Hud.rounded(Color.argb(150, 8, 22, 40), color, ctx.pxf(12f), 2f)
        c.addView(tv(name, 12f, color, true))
        c.addView(tv(sub, 9.5f, Color.WHITE), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(3) })
        c.addView(tv(tag, 8.5f, Color.parseColor("#FFC24B"), true), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(4) })
        c.setOnClickListener { Sfx.tap(); startMode(id) }
        return c
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        root.setPadding(px(12), px(10), px(12), px(10))
        main.orientation = LinearLayout.VERTICAL
        root.addView(main, LinearLayout.LayoutParams(-1, -1))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("OPTIMAL JARINGAN", 12f, Hud.cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        val x = tv("✕", 16f)
        x.setPadding(px(10), px(2), px(4), px(2))
        x.setOnClickListener { Sfx.tap(); onClose() }
        head.addView(x)
        main.addView(head)

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        box.orientation = LinearLayout.VERTICAL
        sv.addView(box)
        main.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        // ================= 0. PINTASAN: ROOT / SHIZUKU =================
        val quick = LinearLayout(ctx)
        quick.orientation = LinearLayout.HORIZONTAL
        fun big(title: String, sub: String, tag: String, color: Int, click: () -> Unit): View {
            val c = LinearLayout(ctx)
            c.orientation = LinearLayout.VERTICAL
            c.setPadding(px(12), px(10), px(12), px(10))
            c.background = Hud.rounded(Color.argb(170, 8, 22, 40), color, ctx.pxf(14f), 2f)
            c.addView(tv(title, 13f, color, true))
            c.addView(tv(sub, 9.5f, Color.WHITE), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(3) })
            c.addView(tv(tag, 8.5f, Color.parseColor("#FFC24B"), true), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(4) })
            c.setOnClickListener { Sfx.tap(); click() }
            return c
        }
        quick.addView(big("⚡ OPTIMAL JARINGAN ROOT", "Target 10–2 ms. Semua tweak root: TCP Turbo, antrean anti-lag, rute cepat, blokir app latar, prioritas paket game.",
            "KHUSUS ROOT", Color.parseColor("#FF5D5D")) {
            if (!Access.requires(ctx, "Optimal Jaringan Root", true)) return@big
            startMode(4)
        }, LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = px(6) })
        quick.addView(big("🛡 OPTIMAL JARINGAN SHIZUKU", "Tanpa root: Wi-Fi latensi rendah, DNS tercepat, denyut anti-tidur, Data Saver, app latar ditidurkan.",
            "SHIZUKU / NON-ROOT", Color.parseColor("#3CC8FF")) {
            if (!Access.requires(ctx, "Optimal Jaringan Shizuku", false)) return@big
            startMode(3)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(quick, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })

        // ================= 1. STATUS =================
        val st = LinearLayout(ctx)
        st.orientation = LinearLayout.HORIZONTAL
        st.gravity = Gravity.CENTER_VERTICAL
        st.setPadding(px(12), px(10), px(12), px(10))
        st.background = Hud.rounded(Color.argb(150, 8, 22, 40), Hud.cyan, ctx.pxf(14f), 1.5f)
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        netTxt.textSize = 12f; netTxt.setTextColor(Color.WHITE); netTxt.typeface = Typeface.DEFAULT_BOLD
        activeTxt.textSize = 9.5f; activeTxt.setTextColor(Hud.sub)
        col.addView(netTxt)
        col.addView(activeTxt)
        pingTxt.textSize = 22f; pingTxt.typeface = Typeface.DEFAULT_BOLD; pingTxt.setTextColor(Color.WHITE)
        pingTxt.text = "-- ms"
        st.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        st.addView(pingTxt, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(12) })
        st.addView(btn("Diagnosa", true) { diagnose() })
        box.addView(st, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })
        detail.textSize = 10f
        detail.setTextColor(Hud.sub)
        box.addView(detail, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(4) })

        // ================= 2. JALUR: Wi-Fi vs Data =================
        title("JALUR TERCEPAT", "WI-FI vs DATA")
        note("Mengukur ping lewat Wi-Fi dan lewat data seluler secara terpisah, lalu menyarankan jalur yang lebih kecil. " +
            "Data seluler dinyalakan sebentar hanya untuk tes (kuota terpakai sangat kecil).")
        val pathRow = LinearLayout(ctx)
        pathRow.orientation = LinearLayout.HORIZONTAL
        for ((k, tvw) in listOf("WI-FI" to wifiPing, "DATA SELULER" to cellPing)) {
            val c = LinearLayout(ctx)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER
            c.setPadding(px(8), px(8), px(8), px(8))
            c.background = Hud.rounded(Color.argb(150, 8, 22, 40), Hud.cyanDim, ctx.pxf(12f), 1f)
            c.addView(tv(k, 9.5f, Hud.sub, true))
            tvw.textSize = 17f; tvw.typeface = Typeface.DEFAULT_BOLD; tvw.setTextColor(Color.WHITE); tvw.text = "-- ms"
            c.addView(tvw)
            pathRow.addView(c, LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = px(6) })
        }
        pathRow.addView(btn("Tes jalur", true) { testPath() }, LinearLayout.LayoutParams(-2, -1))
        box.addView(pathRow)
        pathVerdict.textSize = 10f
        pathVerdict.setTextColor(Hud.sub)
        box.addView(pathVerdict, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(5) })

        // ================= 3. MODE =================
        title("MODE OPTIMASI", if (Access.isRoot) "ROOT ✓" else if (Access.hasAny()) "SHIZUKU ✓" else "BELUM ADA AKSES")
        note("Pilih satu. Makin tinggi makin dalam, dan setiap mode sudah termasuk isi mode di bawahnya. " +
            "Bagian yang butuh root dilewati otomatis di Shizuku dan dijelaskan di hasil.")
        val grid = LinearLayout(ctx)
        grid.orientation = LinearLayout.VERTICAL
        val r1 = LinearLayout(ctx)
        r1.orientation = LinearLayout.HORIZONTAL
        val r2 = LinearLayout(ctx)
        r2.orientation = LinearLayout.HORIZONTAL
        r1.addView(modeCard(1, "OPTIMAL", "Dasar ping rendah: Wi-Fi mode latensi rendah, tanpa hemat daya, scan latar mati, DNS tercepat, " +
            "Wi-Fi Lock, denyut anti-tidur.\nCocok: dipakai setiap hari.",
            "ROOT / SHIZUKU", Color.parseColor("#3CC8FF")), LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = px(6) })
        r1.addView(modeCard(2, "OPTIMAL UP", "+ TCP Turbo di kernel dan Data Saver: unduhan latar tidak berebut dengan game.\n" +
            "Cocok: game online biasa.",
            "ROOT: +kernel · SHIZUKU: +Data Saver", Color.parseColor("#38E8A5")), LinearLayout.LayoutParams(0, -2, 1f))
        r2.addView(modeCard(3, "OPTIMAL MAX", "+ antrean anti-lag (paket game tidak menunggu di belakang unduhan) dan aplikasi latar ditidurkan.\n" +
            "Cocok: ranked / kompetitif.",
            "ROOT: +antrean · SHIZUKU: +app tidur", Color.parseColor("#FFC24B")), LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = px(6) })
        r2.addView(modeCard(4, "OPTIMAL ULTRA", "+ blokir total jaringan app latar, prioritas paket game, app latar dihentikan.\n" +
            "Paling agresif: notifikasi app lain berhenti selama game.",
            "ROOT penuh · SHIZUKU: sebagian", Color.parseColor("#FF5D5D")), LinearLayout.LayoutParams(0, -2, 1f))
        grid.addView(r1, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(6) })
        grid.addView(r2)
        box.addView(grid)

        val autoSel = (store.get("net_auto").toIntOrNull() ?: 0).coerceIn(0, 4)
        box.addView(tv("Otomatis saat game dibuka:", 10f, Hud.sub, true), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8); it.bottomMargin = px(4) })
        box.addView(chipRow(listOf("Mati", "Optimal", "Up", "Max", "Ultra"), autoSel, autoChips) { i ->
            store.put("net_auto", i.toString())
            show(if (i == 0) "Mode otomatis dimatikan." else "Mode ${NetOpt.modeName(i)} akan jalan sendiri tiap game dibuka.", Hud.sub)
        })

        // ================= 4. FOKUS GAME =================
        title("FOKUS GAME", "ROOT / SHIZUKU")
        note("Membatasi jaringan aplikasi lain supaya seluruh bandwidth dan antrean dipakai game. Game, aplikasi inti, VPN, " +
            "dan daftar \"diizinkan\" tidak disentuh. Dilepas otomatis saat game selesai.")
        bgStatus.textSize = 10f
        bgStatus.typeface = Typeface.DEFAULT_BOLD
        box.addView(bgStatus, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(5) })
        box.addView(chipRow(listOf("Mati", "Ringan", "Sedang", "Keras"), 0, bgChips) { i -> setBg(i) })
        bgDesc.textSize = 10f
        bgDesc.setTextColor(Hud.sub)
        bgDesc.text = "Ringan: Data Saver sistem · Sedang: + app latar ditidurkan · Keras: + firewall total (ROOT)"
        box.addView(bgDesc, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(5) })
        val bgRow = LinearLayout(ctx)
        bgRow.orientation = LinearLayout.HORIZONTAL
        allowBtn = btn("Aplikasi diizinkan") { openAllow() }
        bgRow.addView(allowBtn, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(6) })
        bgRow.addView(btn("Lepas batasan") {
            if (!Access.requires(ctx, "Lepas batasan", false)) return@btn
            Thread { show(NetBg.stop(ctx)); root.post { refreshBg() } }.start()
        })
        box.addView(bgRow, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(6) })
        val pSys = Pill(ctx)
        pSys.setOn(NetBg.includeSystem(ctx))
        pSys.onToggle = { v -> store.put("net_bg_sys", if (v) "1" else "0") }
        val sysRow = LinearLayout(ctx)
        sysRow.orientation = LinearLayout.HORIZONTAL
        sysRow.gravity = Gravity.CENTER_VERTICAL
        sysRow.addView(tv("Ikut batasi aplikasi sistem non-inti (bloatware)", 10.5f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        sysRow.addView(pSys)
        box.addView(sysRow, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })

        // ================= 5. FITUR PING RENDAH (manual) =================
        title("FITUR PING RENDAH", "MANUAL")
        note("Tiap fitur bisa dijalankan sendiri. Penjelasan singkat ada di bawah nama fitur.")
        feature("📶", "Wi-Fi Latensi Rendah", "ROOT / SHIZUKU",
            "Wi-Fi diminta mode latensi rendah + performa tinggi, hemat daya Wi-Fi dimatikan, scan Wi-Fi/Bluetooth latar dihentikan. " +
                "Mengurangi lonjakan ping saat HP \"bangun\" dari tidur radio.",
            btn("Terapkan") { runCmd("Optimasi Wi-Fi", false, NetOpt.wifiData()) })
        val pPulse = Pill(ctx)
        pPulse.setOn(store.get("net_pulse") != "0")
        pPulse.onToggle = { v ->
            store.put("net_pulse", if (v) "1" else "0")
            if (store.active || NetOpt.pulsing()) Thread { NetOpt.pulse(ctx, v) }.start()
        }
        feature("💓", "Denyut Anti-Tidur", "SEMUA HP",
            "Mengirim paket sangat kecil tiap 0,7 detik agar radio Wi-Fi/seluler tidak masuk mode hemat. " +
                "Efektif menekan jitter (ping naik-turun). Aktif otomatis selama game.", pPulse)
        val pLock = Pill(ctx)
        pLock.setOn(store.get("wifi_lock") != "0")
        pLock.onToggle = { v ->
            store.put("wifi_lock", if (v) "1" else "0")
            if (store.active) Thread { NetOpt.holdWifi(ctx, v) }.start()
        }
        feature("🔒", "Kunci Wi-Fi saat game", "SEMUA HP",
            "Wi-Fi ditahan di mode latensi rendah selama game berjalan; dilepas saat game ditutup.", pLock)
        feature("🌐", "DNS Tercepat", "ROOT / SHIZUKU",
            "Server DNS mempercepat membuka server game (login, matchmaking). 'Otomatis' = bawaan HP. " +
                "Mode optimasi memilih yang tercepat sendiri dan membatalkannya bila internet jadi bermasalah.",
            null, dnsChips())
        feature("⚡", "TCP Turbo", "KHUSUS ROOT",
            "Mengatur kernel: BBR bila tersedia, Fast Open, buffer lebih besar, tanpa slow-start setelah diam. " +
                "Koneksi stabil dan cepat pulih. Nilai asli disimpan dan dikembalikan.",
            btn("Terapkan") {
                if (!Access.requires(ctx, "TCP Turbo", true)) return@btn
                show("Menjalankan TCP Turbo...", Hud.sub)
                Thread { show(NetOpt.applyTcp(ctx)) }.start()
            })
        feature("🚦", "Antrean Anti-Lag", "KHUSUS ROOT",
            "Memakai antrean fq_codel dan antrean pendek: paket game tidak menunggu di belakang unduhan (bufferbloat), " +
                "jadi ping tidak melonjak saat ada yang mengunduh.",
            btn("Terapkan") {
                if (!Access.requires(ctx, "Antrean Anti-Lag", true)) return@btn
                show("Menjalankan Antrean Anti-Lag...", Hud.sub)
                Thread { show(NetOpt.applyQueue(ctx)) }.start()
            })
        feature("⛔", "Hentikan App Latar", "ROOT / SHIZUKU",
            "Pilih sendiri aplikasi yang berjalan di latar lalu dihentikan agar tidak memakai jaringan.",
            btn("Buka") { onStop?.invoke() })

        // ================= 6. PENJELASAN =================
        val explain = tv("▸ Penjelasan: apa yang bisa dan tidak bisa dilakukan?", 11f, Hud.cyan, true)
        explain.setPadding(0, px(14), 0, px(6))
        val explainBody = tv(
            "• Ping = waktu pulang-pergi paket ke server. Terdiri dari: HP → router (Wi-Fi), router → provider, provider → server game.\n" +
                "• Aplikasi ini memperbaiki bagian di HP: radio tidak tidur, antrean tidak penuh, DNS cepat, lalu lintas latar dibuang.\n" +
                "• Jarak ke server dan kualitas provider tidak bisa diubah aplikasi. Karena itu ping ke internet umumnya 10–40 ms, " +
                "bukan 1–5 ms (angka itu hanya ke router).\n" +
                "• Wi-Fi 5 GHz dekat router biasanya paling rendah dan stabil. Bila data seluler lebih kecil di Tes jalur, matikan Wi-Fi saat bermain.\n" +
                "• Hasil terbaik: mode OPTIMAL MAX + Fokus game Sedang + Wi-Fi 5 GHz. ULTRA hanya bila perlu, karena memblokir app lain.\n" +
                "• Semua setelan asli disimpan; tombol Reset di bawah mengembalikannya.",
            10f, Hud.sub)
        explainBody.visibility = View.GONE
        explain.setOnClickListener {
            Sfx.tap()
            val open = explainBody.visibility != View.VISIBLE
            explainBody.visibility = if (open) View.VISIBLE else View.GONE
            explain.text = (if (open) "▾ " else "▸ ") + "Penjelasan: apa yang bisa dan tidak bisa dilakukan?"
        }
        box.addView(explain)
        box.addView(explainBody)

        box.addView(btn("↺ Reset semua ke bawaan") {
            if (!Access.requires(ctx, "Reset jaringan", false)) return@btn
            Thread {
                show(NetOpt.resetAll(ctx))
                root.post { refreshActive(); refreshBg() }
            }.start()
        }, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(16) })

        result.textSize = 10f
        result.setTextColor(Hud.sub)
        box.addView(result, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8); it.bottomMargin = px(8) })

        refreshNet()
        refreshActive()
        refreshBg()
        quickPing()
    }

    private fun refreshNet() {
        netTxt.text = when (NetOpt.kind(ctx)) {
            "none" -> "Tidak ada koneksi"
            "wifi" -> "Terhubung: Wi-Fi"
            "cell" -> "Terhubung: Data seluler"
            else -> "Terhubung"
        }
    }

    private fun refreshActive() {
        val m = store.get("net_active").toIntOrNull() ?: 0
        activeTxt.text = if (m in 1..4) "Mode aktif: ${NetOpt.modeName(m)}" else "Belum ada mode aktif"
    }

    private fun refreshBg() {
        val on = NetBg.active(ctx)
        bgStatus.text = NetBg.status(ctx)
        bgStatus.setTextColor(if (on) Color.parseColor("#38E8A5") else Hud.sub)
        allowBtn.text = "Aplikasi diizinkan (${NetBg.allow(ctx).size})"
        paintChips(bgChips, NetBg.level(ctx))
    }

    private fun quickPing() {
        pingTxt.text = "…"
        pingTxt.setTextColor(Color.WHITE)
        Thread {
            val p = NetOpt.probe("8.8.8.8", 443, 4, 1500)
            root.post { refreshNet(); setPing(p.avg) }
        }.start()
    }

    private fun diagnose() {
        if (busy) return
        busy = true
        pingTxt.text = "…"
        pingTxt.setTextColor(Color.WHITE)
        detail.text = "Mengukur ping, jitter, DNS, sinyal..."
        Thread {
            val d = NetOpt.diagnose(ctx)
            val sb = StringBuilder()
            if (d.kind == "wifi") {
                sb.append("Wi-Fi: ").append(d.rssi).append(" dBm · ").append(d.linkMbps).append(" Mbps · ")
                    .append(if (d.freqMhz in 2400..2500) "2.4 GHz" else if (d.freqMhz > 4900) "5 GHz" else "${d.freqMhz} MHz").append("\n")
                if (d.gw != null) sb.append("Router: ").append(NetOpt.fmt(d.gw)).append("\n")
            }
            sb.append("Internet").append(if (d.netName.isNotEmpty()) " (server terdekat: ${d.netName})" else "").append(": ").append(NetOpt.fmt(d.net)).append("\n")
            if (d.dnsMs >= 0) sb.append("DNS: ").append(d.dnsMs).append(" ms\n")
            sb.append("\n")
            for (a in d.advice) sb.append("• ").append(a).append("\n")
            busy = false
            root.post {
                refreshNet()
                setPing(d.net.avg)
                detail.text = sb.toString().trim()
            }
        }.start()
    }

    private fun startMode(m: Int) {
        if (!Access.requires(ctx, NetOpt.modeName(m), false)) return
        if (busy || NetOpt.running) { show("Masih ada proses berjalan, tunggu sebentar.", Hud.sub); return }
        busy = true
        show("Memulai ${NetOpt.modeName(m)}...", Hud.sub)
        Thread {
            val txt = NetOpt.runMode(ctx, m, false) { show(it, Hud.sub) }
            val p = NetOpt.probe("8.8.8.8", 443, 4, 1500)
            busy = false
            show(txt)
            root.post { refreshNet(); setPing(p.avg); refreshActive(); refreshBg() }
        }.start()
    }

    // level 0..3 dari chip "Fokus game"
    private fun setBg(level: Int) {
        if (!Access.requires(ctx, "Batasi jaringan latar", false)) return
        if (busy) return
        busy = true
        show(if (level == 0) "Melepas pembatasan..." else "Menerapkan pembatasan latar...", Hud.sub)
        Thread {
            val txt = if (level == 0) NetBg.stop(ctx) else {
                val r = NetBg.apply(ctx, level)
                val sb = StringBuilder()
                for (l in r.lines) sb.append(l).append("\n")
                for (l in NetBg.verify(ctx)) sb.append(l).append("\n")
                if (r.count == 0) sb.append("Tidak ada aplikasi latar yang perlu dibatasi.\n")
                sb.toString().trim()
            }
            busy = false
            show(txt)
            root.post { refreshBg() }
        }.start()
    }

    private fun openAllow() {
        if (allowView != null) return
        val a = NetAllowSheet(ctx) {
            allowView?.let { root.removeView(it.root) }
            allowView = null
            main.visibility = View.VISIBLE
            refreshBg()
        }
        allowView = a
        main.visibility = View.GONE
        root.addView(a.root, LinearLayout.LayoutParams(-1, -1))
    }

    private fun dnsChips(): View {
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.HORIZONTAL
        val opts = listOf(
            Triple("Otomatis", "opportunistic", ""),
            Triple("Google", "hostname", "dns.google"),
            Triple("Cloudflare", "hostname", "one.one.one.one"),
            Triple("Quad9", "hostname", "dns.quad9.net"),
            Triple("Mati", "off", "")
        )
        for ((name, mode, host) in opts) {
            l.addView(btn(name) {
                val cmd = "settings put global private_dns_mode $mode" +
                    if (host.isNotEmpty()) "; settings put global private_dns_specifier $host" else ""
                runCmd("DNS $name", false, cmd)
            }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(6) })
        }
        hs.addView(l)
        return hs
    }
}
